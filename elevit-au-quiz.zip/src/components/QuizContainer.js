import React, { useEffect, useState, useLayoutEffect } from "react";
import { Cases } from "../utils/API/index";
import axios from "axios";
import Loader from "../components/common/loader";
import StartQuizContainer from "./StartQuizContainer";
import QuestionCard from "../components/common/QuestionCard";
import ResultContainer from "./ResultContainer";
import ResultForPregnancy from "./ResultForPregnancy";

import EndQuiz from "./EndQuiz";
import Nothrushsymptoms from "./Nothrushsymptoms";
import RecurrentThrush from "./RecurrentThrush";
import "../css/components/quizContainer.scss";
import isMobileDevice from "responsive-react";
import Result from "../utils/result";
import { withResizeDetector } from "react-resize-detector/build/withPolyfill";
import utility from "../utils/utility";

const QuizContainer = ({ height }) => {
  const [step, setStep] = useState(1);
  const [loadResult, setLoadResult] = useState([]);
  const [quizTitle, setQuizTitle] = useState("");
  const [quizInstruction, setQuizInstruction] = useState("");
  const [resultSet, setResultSet] = useState([]);
  const [quizDesc, setQuizDesc] = useState("");
  const [quizAction, setQuizAction] = useState([]);
  const [questions, setQuestion] = useState([]);
  const [loading, setLoading] = useState(false);
  const [startQuiz, setstartQuiz] = useState(true);
  const [choices, setChoices] = useState([]);
  const [choicesIndex, setChoicesIndex] = useState([]);
  const [resultNumber, setResultNumber] = useState(0);
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0);
  const [lang, setLang] = useState("de");
  const [questionAnswersList, setQuestionAnswersList] = useState([]);
  const [multiplechoices, setmultiplechoices] = useState({});
  const [display, setDisplay] = useState("Start");

  useLayoutEffect(() => {
    if (window.parent.document.getElementById("iFrameResizer0")) {
      window.parent.document.getElementById("iFrameResizer0").height =
        document.getElementById("mainWrapper").offsetHeight;
    }
  }, [height]);

  useEffect(() => {
    let language = window.parent.document.documentElement.lang;
    setLang(language);
  }, [lang]);

  useEffect(() => {
    setLoading(true);

    Cases.findQuiz()
      .then((quizID) => {
        axios
          .all([
            Cases.getQuiz(quizID),
            Cases.getQuizQuestions(quizID),
            Cases.getResults(),
          ])
          .then(
            axios.spread((...responses) => {
              const quizTitle = responses[0][0];
              const quizAction = [];
              const quizDesc = responses[0][1];
              quizAction.push(responses[0][2]);
              const general_questions = responses[1];
              const quizInstruction =
                typeof responses[0][3] !== "undefined" && responses[0][3]
                  ? responses[0][3]
                  : "";
              setQuizInstruction(quizInstruction);
              setQuizTitle(quizTitle);
              setQuestion(general_questions);
              setQuizAction(quizAction);
              setQuizDesc(quizDesc);
              setResultSet(responses[2]);
            })
          )
          .catch((errors) => {
            console.log(errors);
          });
      })
      .catch((e) => console.log(e))
      .finally(() => {
        setLoading(false);
        setDisplay("Start");
        // setDisplay("Result");
      });
  }, []);

  const backClick = () => {
    setDisplay("Questions");
  };

  const setResult = () => {
    setResultNumber(1);
  };

  const nextStep = (e) => {
    if (step === 1) {
      if (e.target.id === "NO") {
        setDisplay("EndQuiz");
        return true;
      }
    } else if (step === 2) {
      if (e.target.id === "YES") {
        setDisplay("Nothrushsymptoms");
        return true;
      }
    } else if (step === 3) {
      if (e.target.id === "YES") {
        setDisplay("RecurrentThrush");
        return true;
      }
    } else if (step === 4) {
      if (e.target.id === "YES") {
        let result = resultSet.filter((result) => result[2].result == "yes");
        //setCorrectAnswersCount(utility.rightAnswersCount(choicesIndex));
        setLoadResult(result);
        //setResultNumber(resultNumber);
        setDisplay("PregnantSymptom");
        return true;
      }
    }

    if (questions.length !== step) {
      setStep(step + 1);
    }
    // else {
    //   setDisplay("Result");
    // }
  };

  const onStartClick = () => {
    setDisplay("Questions");
    setstartQuiz(false);
  };
  const closeClick = () => {
    setDisplay("Start");
    setStep(1);
    setstartQuiz(true);
    setChoices([]);
    setChoicesIndex([]);
    setmultiplechoices({});
  };

  const onHomeClick = () => {
    window.parent.location.href = window.location.origin;
  };
  const updatemultipleChoices = (choice) => {
    setmultiplechoices(choice);
  };
  const updateChoices = (choice) => {
    setChoices(choice);
  };

  const updateChoicesIndex = (choice) => {
    setChoicesIndex(choice);
  };
  const updateQuestionAnswerList = (data) => {
    setQuestionAnswersList(data);
  };
  useEffect(() => {
    if (questions.length === step) {
      //let resultNumber = Result.getResult(choicesIndex);
      let resultNumber = choicesIndex[step];
      let result = resultSet.filter(
        (result) => result[2].result == resultNumber
      );
      setCorrectAnswersCount(utility.rightAnswersCount(choicesIndex));
      setLoadResult(result);
      setResultNumber(resultNumber);

      setDisplay("Result");
    }
  }, [choicesIndex]);

  return (
    <div className="quiz__container">
      {
        {
          Loader: <Loader />,
          Start: (
            <StartQuizContainer
              startQuiz={startQuiz}
              quizTitle={quizTitle}
              quizAction={quizAction}
              quizDesc={quizDesc}
              quizInstruction={quizInstruction}
              onStartClick={onStartClick}
            />
          ),
          Questions: (
            <div className="quizContainer">
              {
                <QuestionCard
                  question={questions[step - 1]}
                  onNext={nextStep}
                  key={step}
                  choices={choices}
                  updateChoices={updateChoices}
                  step={step}
                  choicesIndex={choicesIndex}
                  updateChoicesIndex={updateChoicesIndex}
                  lang={lang}
                  questionAnswersList={questionAnswersList}
                  updateQuestionAnswerList={updateQuestionAnswerList}
                  multiplechoices={multiplechoices}
                  updatemultipleChoices={updatemultipleChoices}
                />
              }
            </div>
          ),
          Result: (
            <ResultContainer
              resultNumber={resultNumber}
              loadResult={loadResult}
              onHomeClick={onHomeClick}
              correctAnswersCount={correctAnswersCount}
              lang={"en"}
              questionAnswersList={questionAnswersList}
              backClick={backClick}
              setResult={setResult}
            />
          ),
          EndQuiz: (
            <div className="resultContainer">
              <EndQuiz backClick={backClick} closeClick={closeClick} />
            </div>
          ),
          Nothrushsymptoms: (
            <div className="resultContainer">
              <Nothrushsymptoms backClick={backClick} closeClick={closeClick} />
            </div>
          ),
          RecurrentThrush: (
            <div className="resultContainer">
              <RecurrentThrush backClick={backClick} closeClick={closeClick} />
            </div>
          ),
          PregnantSymptom: (
            <ResultForPregnancy
              resultNumber={1}
              loadResult={loadResult}
              onHomeClick={onHomeClick}
              correctAnswersCount={0}
              lang={"en"}
              questionAnswersList={questionAnswersList}
              backClick={backClick}
            />
          ),
        }[display]
      }
    </div>
  );

  // switch (true) {
  //   case loading:
  //     return <Loader />;
  //     break;
  //   case startQuiz:
  //     return (
  //       <>
  //         <StartQuizContainer
  //           startQuiz={startQuiz}
  //           quizTitle={quizTitle}
  //           quizAction={quizAction}
  //           quizDesc={quizDesc}
  //           onStartClick={onStartClick}
  //         />
  //       </>
  //     );
  //   case questions?.length &&
  //     step < questions?.length + 1 &&
  //     loadResult.length == 0:
  //     return (
  //       <>
  //         <div className="quizContainer">
  //           {
  //             <QuestionCard
  //               question={questions[step - 1]}
  //               onNext={nextStep}
  //               key={step}
  //               choices={choices}
  //               updateChoices={updateChoices}
  //               step={step}
  //               choicesIndex={choicesIndex}
  //               updateChoicesIndex={updateChoicesIndex}
  //               lang={lang}
  //               questionAnswersList={questionAnswersList}
  //               updateQuestionAnswerList={updateQuestionAnswerList}
  //               multiplechoices={multiplechoices}
  //               updatemultipleChoices={updatemultipleChoices}
  //             />
  //           }
  //         </div>
  //       </>
  //     );

  //   case loadResult.length != 0:
  //     return (
  //       <ResultContainer
  //         resultNumber={resultNumber}
  //         loadResult={loadResult.length ? loadResult : ""}
  //         onHomeClick={onHomeClick}
  //         correctAnswersCount={correctAnswersCount}
  //         lang={lang}
  //         questionAnswersList={questionAnswersList}
  //       />
  //     );
  //   default:
  //     return loading ? <Loader /> : <div></div>;
  // }
};
export default withResizeDetector(QuizContainer);
