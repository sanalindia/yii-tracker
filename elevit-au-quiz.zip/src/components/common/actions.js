import React from "react";
import "../../css/components/actionButton.scss";
import arrowIcon from "../../assets/Icons/right-arrow-red.png"

const Actions = ({ actions, onNext, onStartClick, selected, step,choicesIndex,multiplechoices }) => {
  const actionsList = actions.length ? actions : ["NO", "YES"];
  
  const handleChange = (e, i) => {
    alert("ss");
  };  
  
  selected =(step === 1 || step === 2) && (choicesIndex[step] && choicesIndex[step].length>0)?true : selected
  return (    
    <div
      className="actionsDiv"
      style={step === 3 || step === 4 ? { textAlign: "center", left: 0 } : {}}   
      
    >
      {actionsList.length && step !== 5
        ? actionsList.map((action, index) => {
            return (
              <button
                id={action}
                className={
                  action === "Próxima Pregunta" || action === "Finalizar"
                    ? "action-btn next-btn" :(action !== "LET'S GET STARTED" ?"action-btn next-btn" :"action-btn start-btn")
                    
                }
                onClick={
                  action !== "LET'S GET STARTED" ? onNext : onStartClick
                }
                key={action}
                disabled={
                  action === "Próxima Pregunta" || action === "Finalizar" || (action === "YES" && (step === 1 || step === 2))
                    ? !selected
                    : false
                }
              >
                {action} {action === "LET'S GET STARTED" ? (<span><img alt = "arrow" src={arrowIcon} /></span>) :  null}
              </button>
            );
          })
        : ""}
    </div>
  );
};

export default Actions;
