import React, { useState, useEffect } from "react";
import { Constants } from "../../constants";
import "../../css/components/radioImgGroup.scss";
import iconBg from "../../assets/Images/icon-bg.png"
import parse from "html-react-parser";

const RadioImgGrp = ({
  inputValues,
  choices,
  updateChoices,
  isSelected,
  step,
  updateChoicesIndex,
  choicesIndex,
  onNext,
  lang,
  question,
  questionAnswersList,
  updateQuestionAnswerList,
}) => { 
  const options = inputValues[1];
  const qID = inputValues[0].id;
  

  const [selected, setSelected] = useState();

  useEffect(() => {
    if (choices[qID]) {
      //setSelected(choices[qID]);
    }
  }, [choices, qID]);

  const handleChange = (event, index) => {  
    setSelected(event.target.id);
    updateChoices({ ...choices, [qID]: event.target.id });
    updateChoicesIndex({ ...choicesIndex, [step]: index + 1 });
    questionAnswersList.push({
      question: question,
      selectedAnswer: event.target.value,
      correctAnswer: options[Constants.ANSWERS[step - 1] - 1][1],
    });
    updateQuestionAnswerList(questionAnswersList);
    setTimeout(() => {
      setSelected(false);
      onNext();
      
    }, 2000);
  };
  const isAnswerCorrect = (index) => {
    return index + 1 === Constants.ANSWERS[step - 1];
    /* return (
      option[2] === "RICHTIG" || option[2] === "VRAI" || option[2] === "CORRECT"
    ); */
  };
  const getStatusText = (index) => {
    if (isAnswerCorrect(index)) {
      return lang === "fr" ? Constants.fr.correct : Constants.de.correct;
    }
    return lang === "fr" ? Constants.fr.incorrect : Constants.de.incorrect;
  };
  
  return (
    <div className="imgOption__container">
      {options.length
        ? options.map((option, index) => {
            return (
              <div key={index} className="innerDiv">
                <input
                  type="radio"
                  id={option[0]}
                  name="radioImgGroup"
                  ordernumber={index}
                  value={option[1]}
                  disabled={selected}
                  checked={option[0] === selected}
                  onChange={(event) => handleChange(event, index)}
                  className="input-hidden"
                />
                <label htmlFor={option[0]}>
                  <div className="img__container">
                    <div className="imageDiv">
                      {/* <img
                        src={  isMobileDevice() ?  (option[0] === selected) ? `Icons/Mobile/${step}-${index + 1}_active.png` :  `Icons/Mobile/${step}-${index + 1}.png` : (option[0] === selected) ?  `Icons/Desktop/${step}-${index + 1}_active.png` :  `Icons/Desktop/${step}-${index + 1}.png`                         
                          
                        }
                        alt={option[1]}
                      /> */}
                      <img
                        src={
                          option[0] === selected
                            ? iconBg
                            : iconBg
                        }
                        alt={option[1]}
                      />
                      <span className = "iconText">{option[1].charAt(0)}</span>                      
                    </div>
                    <div className="textDiv">
                      <p><strong>{option[1]}</strong></p>
                      <p
                        style={
                          option[0] !== selected
                            ? { visibility: "hidden" }
                            : { visibility: "visible" }
                        }
                        className={
                          option[0] === selected && isAnswerCorrect(index)
                            ? "correct_text"
                            : "incorrect_text"
                        }
                      >
                        {option[0] === selected ? getStatusText(index) : "..."}
                      </p>
                    </div>
                    <div className = "desctDiv">{parse(option[2])}</div>
                  </div>
                </label>
              </div>
            );
          })
        : ""}
    </div>
  );
};

export default RadioImgGrp;
