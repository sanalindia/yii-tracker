import React, { useState, useEffect, useRef } from "react";
import { Constants } from "../../constants";
import "../../css/components/MultipleProducts.scss";
import $ from "jquery";
import BuyButton from "./BuyButton";
const MultipleProducts = ({
  selectedTab,
  resultNumber,
  handleClick,
  scrollToView,
  setResult,
}) => {
  const myRef = useRef(null);
  return selectedTab === "oral" && resultNumber == 1 ? (
    <>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/CanesOral-Duo-Oral-Capsule-Thrush-Treatment_0-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">
              CanesOral Duo Oral Capsule + External Cream
            </h3>
            <div className="description">
              This treatment includes a single dose oral capsule to treat the
              infection internally and cream to relive the external itch.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesoral-duo-oral-capsule-external-cream"
                >
                  <button>
                    SEE PRODUCT DETAILS
                    <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                {/*<button>
                  BUY NOW <span className="down-arrow"></span>
                </button>*/}
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/52225/canesoral-duo-thrush-treatment-oral-capsule-external-cream",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-canesoral-duo-cream-10g-and-cap-x-1",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12574/s/canesoral-duo-150mg-capsule-1-10g-cream/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Oral-Capsule-Thrush-Treatment-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">CanesOral Oral Capsule</h3>
            <div className="description">
              This treatment includes a single dose oral capsule to treat the
              cause of the infection internally.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-oral-capsule"
                >
                  <button>
                    SEE PRODUCT DETAILS <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/50746/canesoral-thrush-treatment-150mg-fluconazole-capsule-1",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-canesoral-150mg-cap-x-1",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12573/s/canesoral-150mg-capsule-1/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="treatment_oral">
        If Oral Treatment options aren’t for you{" "}
        <a
          href="javascript:void(0);"
          onClick={(e) => {
            handleClick(e, "internal");
            scrollToView();
            // window.scrollTo(0, 100);
          }}
        >
          click here
        </a>{" "}
        to view our Canesten Internal Treatment Range.
      </div>
    </>
  ) : selectedTab === "internal" && resultNumber == 1 ? (
    <>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Thrush-1-Day-Cream_0-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 1 Day Cream</h3>
            <div className="description">
              This treatment includes a single dose cream which is applied
              internally to the vagina using an applicator.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-1-day-cream"
                >
                  <button>
                    SEE PRODUCT DETAILS <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/20123/canesten-1-day-thrush-treatment-internal-cream(s3)",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-once-cream-500mg-5g",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/19761/s/canesten-once-cream-5g-with-applicator/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Thrush-1-Day-Pessary-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 1 Day Pessary</h3>
            <div className="description">
              This treatment includes a single dose pessary (vaginally inserted
              tablet).
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-1-day-pessary"
                >
                  <button>
                    SEE PRODUCT DETAILS <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/Buy/57471/Canesten-Vaginal-1x500mg-Pessary-1-Day-Treatment",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-1-day-pessary-thrush-treatment-500mg",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12579/s/canesten-once-pessary-single-dose/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-1-Day-Pessary-External-Cream-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 1 Day Pessary + External Cream</h3>
            <div className="description">
              This treatment includes a single dose pessary (vaginally inserted
              tablet) plus a cream applied externally to treat itching.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/products/intimate-health/canesten-1-day-pessary-external-cream"
                >
                  <button>
                    SEE PRODUCT DETAILS <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/Buy/57469/Canesten-Vaginal-1-x-500mg-Pessary-1-Day-Treatment-Cream",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-once-pessary-500mg-plus-cream-10g",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12578/s/canesten-once-dose-pessary-plus-cream/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="treatment_oral">
        If Internal Treatment options aren’t for you{" "}
        <a
          href="javascript:void(0);"
          onClick={(e) => {
            handleClick(e, "oral");
            scrollToView();
            // window.scrollTo(0, 100);
          }}
        >
          click here
        </a>{" "}
        to view our Canesten Oral Treatment Range.
      </div>
    </>
  ) : selectedTab === "oral" && resultNumber == 2 ? (
    <>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Thrush-3-Day-Cream-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 3 Day Cream</h3>
            <div className="description">
              This treatment includes 3 doses of cream which are applied
              internally to the vagina once daily for 3 days using an
              applicator.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-3-day-cream"
                >
                  <button>
                    SEE PRODUCT DETAILS
                    <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/1889/canesten-3-day-thrush-treatment-internal-cream-(s3)",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-3-day-cream-2-20g",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12575/s/canesten-3-day-vaginal-cream-20g/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="treatment_oral">
        If Internal Treatment options aren’t for you{" "}
        <a
          href="javascript:void(0);"
          onClick={(e) => {
            setResult();
            scrollToView();
            // window.scrollTo(0, 100);
          }}
        >
          click here
        </a>{" "}
        to view our Canesten Oral Treatment Range.
      </div>
    </>
  ) : (
    <>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Thrush-6-Day-Cream-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 6 Day Cream</h3>
            <div className="description">
              This treatment includes 6 doses of cream which areapplied
              internally to the vagina once daily for 6 days using an
              applicator.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-6-day-cream"
                >
                  <button>
                    SEE PRODUCT DETAILS
                    <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/1886/canesten-clotrimazole-thrush-treatment-6-day-cream-1-(s3)",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-clotrimazole-6-day-cream-1-35g",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12577/s/canesten-6-day-vaginal-cream-35g/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="multiProductsContainer">
        <div className="multiProductsArea">
          <div className="productImage">
            <img
              src={require(`../../assets/Images/Canesten-Thrush-6-Day-Pessary-sm.png`)}
            />
          </div>
          <div className="productDetails">
            <h3 className="title">Canesten® 6 Day Pessary</h3>
            <div className="description">
              This treatment includes 6 pessaries (vaginally inserted tablets).
              One pessary is inserted into the vagina with an applicator each
              day for 6 days.
            </div>
            <div className="buttonArea">
              <div className="buttonSeeProduct">
                <a
                  target="_parent"
                  href="/discover-canesten-products/canesten-6-day-pessary"
                >
                  <button>
                    SEE PRODUCT DETAILS
                    <span className="right-arrow"></span>
                  </button>
                </a>
              </div>
              <div className="buttonBuynow">
                <BuyButton
                  buttonList={{
                    "Chemist-Warehouse":
                      "https://www.chemistwarehouse.com.au/buy/1887/canesten-6-day-thrush-treatment-pessary-(s3)",
                    "Pharmacy-Online":
                      "https://www.pharmacyonline.com.au/canesten-6-day-pessary-100mg-x-6",
                    "Discount-Chemist":
                      "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12576/s/canesten-6-day-pessary/",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="treatment_oral">
        If Internal Treatment options aren’t for you{" "}
        <a
          href="javascript:void(0);"
          onClick={(e) => {
            setResult();
            scrollToView();
            // window.scrollTo(0, 100);
          }}
        >
          click here
        </a>{" "}
        to view our Canesten Oral Treatment Range.
      </div>
    </>
  );
};

export default MultipleProducts;
