import React from "react";
import RadioImgGroup from "./radioImgGroup";
import CheckboxesGroup from "./checkboxesGroup";
const Choices = ({
  options,
  choices,
  updateChoices,
  updateChoicesIndex,
  choicesIndex,
  step,
  onNext,
  lang,
  question,
  questionAnswersList,
  updateQuestionAnswerList,
  multiplechoices,
  updatemultipleChoices,
}) => {
  return (
    <div>
      {options.length ? (
        <>
          {step === 5 ? (
            <RadioImgGroup
              step={step}
              key={options[0][0]}
              nextQuestion={options[2]}
              indicationValue={options[1]}
              choices={choices}
              updateChoices={updateChoices}
              inputValues={options}
              choicesIndex={choicesIndex}
              updateChoicesIndex={updateChoicesIndex}
              onNext={onNext}
              lang={lang}
              question={question}
              questionAnswersList={questionAnswersList}
              updateQuestionAnswerList={updateQuestionAnswerList}
            />
          ) : (
            ""
          )}
          {step === 1 || step === 2 ? (
            <CheckboxesGroup
              key={options[0][0]}
              multiplechoices={choicesIndex}
              nextQuestion={options[2]}
              // updatemultipleChoices={updatemultipleChoices}
              updateChoices={updateChoices}
              inputValues={options}
              updateChoicesIndex={updateChoicesIndex}
              step={step}
              choicesIndex={choicesIndex}
              questionAnswersList={questionAnswersList}
              updateQuestionAnswerList={updateQuestionAnswerList}
              onNext={onNext}
              lang={lang}
              multiplechoices={multiplechoices}
              updatemultipleChoices={updatemultipleChoices}
            />
          ) : (
            ""
          )}
        </>
      ) : (
        ""
      )}
    </div>
  );
};

export default Choices;
