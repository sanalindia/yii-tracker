import React, { useEffect, useState } from "react";
import parse from "html-react-parser";
import { Cases } from "../../utils/API/index";
import Choices from "./Choices";
import Actions from "./actions";
import "../../css/components/questionCard.scss";
import Loader from "../common/loader";
import { Constants } from "../../constants";

const QuestionCard = ({
  question,
  onNext,
  choices,
  updateChoices,
  step,
  updateChoicesIndex,
  choicesIndex,
  lang,
  questionAnswersList,
  updateQuestionAnswerList,
  multiplechoices,
  updatemultipleChoices,
  choice,
}) => {
  let qID = question.id;
  const selectionMade = choices[qID] ? true : false;
  const [qaArray, setQaArray] = useState([]);
  const [qAction, setQaction] = useState([]);
  const [qcardLoading, setQcardLoading] = useState(true);

  useEffect(() => {
    Cases.getAnswers4Question(qID)
      .then((response) => {
        let qaArr = [];
        qaArr.push(question, response);
        setQaArray(qaArr);
        setQcardLoading(false);
      })
      .catch((e) => console.log(e));

    /* Cases.getActions4QUestion(qID)
      .then((response) => {
        setQaction(response);
        setQcardLoading(false);
      })
      .catch((e) => console.log(e)); */
  }, [question, qID]);

  return (
    <div className="questionContainer">
      <div className="qa-inner-div">
        {qcardLoading ? (
          <Loader />
        ) : (
          <>
            <h6 className="questionIndex">
              {lang === "fr" ? Constants.fr.question : Constants.de.question}{" "}
              {qaArray.length ? step + "/" + Constants.QUESTIONS_COUNT : null}
            </h6>
            <div className="question-card">
              <h2>{qaArray.length ? parse(qaArray[0].title) : ""}</h2>
              {/* <div className="question-divider"></div> */}
            </div>

            <Choices
              choices={choices}
              updateChoices={updateChoices}
              options={qaArray.length ? qaArray : ""}
              step={step}
              choicesIndex={choicesIndex}
              updateChoicesIndex={updateChoicesIndex}
              onNext={onNext}
              lang={lang}
              question={question}
              questionAnswersList={questionAnswersList}
              updateQuestionAnswerList={updateQuestionAnswerList}
              multiplechoices={multiplechoices}
              updatemultipleChoices={updatemultipleChoices}
            />

            <Actions
              actions={qAction}
              onNext={onNext}
              selected={selectionMade}
              step={step}
              multiplechoices={multiplechoices}
              choicesIndex={choicesIndex}
              choices={choices}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default QuestionCard;
