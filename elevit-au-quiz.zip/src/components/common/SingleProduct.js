import React, { useState, useEffect } from "react";
import { Constants } from "../../constants";
import "../../css/components/SingleProduct.scss";
import BuyButton from "./BuyButton";
const SingleProduct = ({}) => {
  return (
    <div className="productsContainer">
      <div className="productsArea">
        <div className="productImage">
          <img
            src={require(`../../assets/Images/Canesten-Thrush-6-Day-Pessary-sm.png`)}
          />
        </div>
        <div className="productDetails">
          <h3 className="title">Canesten® 6 Day Pessary</h3>
          <div className="description">
            This treatment includes 6 pessaries (vaginally inserted tablets).
            One pessary is inserted into the vagina with an applicator each day
            for 6 days.
          </div>
          <div className="buttonArea">
            <div className="buttonSeeProduct">
              <a
                target="_parent"
                href="/discover-canesten-products/canesten-6-day-pessary"
              >
                <button>
                  SEE PRODUCT DETAILS
                  <span className="right-arrow"></span>
                </button>
              </a>
            </div>
            <div className="buttonBuynow">
              <BuyButton
                buttonList={{
                  "Chemist-Warehouse":
                    "https://www.chemistwarehouse.com.au/buy/1887/canesten-6-day-thrush-treatment-pessary-(s3)",
                  "Pharmacy-Online":
                    "https://www.pharmacyonline.com.au/canesten-6-day-pessary-100mg-x-6",
                  "Discount-Chemist":
                    "https://www.yourdiscountchemist.com.au/catalog/product/view/id/12576/s/canesten-6-day-pessary/",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SingleProduct;
