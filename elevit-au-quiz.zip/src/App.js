import React from "react";
import "./App.css";
import "./css/components/style.scss";
/*
 *Component Imports
 */
import QuizContainer from "./components/QuizContainer";

function App() {
  return (
    <div id="mainWrapper">
      <QuizContainer />
      <p className="bottomContent">
        This is a guide on which Canesten Thrush Treatment is best for you. For
        medical advice or diagnosis see your doctor.
      </p>
    </div>
  );
}

export default App;
