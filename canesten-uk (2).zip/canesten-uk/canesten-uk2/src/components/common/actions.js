import React from "react";
import "../../css/components/actionButton.scss";
import arrowIcon from "../../assets/Icons/right-arrow-red.png";

const Actions = ({
  actions,
  onNext,
  onStartClick,
  selected,
  step,
  choicesIndex,
  multiplechoices,
  options,
  questionData,
}) => {
  const actionsList = options ? options : actions;
  const qID = questionData ? questionData.id : 0;
  console.log("questionData", questionData);
  const handleChange = (e, i) => {
    onNext(qID, e);
  };

  return actionsList.length
    ? actionsList.map((action, index) => {
        return (
          <div
            id={action[0]}
            key={index}
            className="common__Button gtm-btn"
            onClick={action[0] !== "1" ? handleChange : onStartClick}
          >
            {action[1]}
          </div>

          // <button
          //   id={action}
          //   className={
          //     action === "Próxima Pregunta" || action === "Finalizar"
          //       ? "action-btn next-btn" :(action !== "LET'S GET STARTED" ?"action-btn next-btn" :"action-btn start-btn")

          //   }
          //   onClick={
          //     action !== "LET'S GET STARTED" ? onNext : onStartClick
          //   }
          //   key={action}
          //   disabled={
          //     action === "Próxima Pregunta" || action === "Finalizar" || (action === "YES" && (step === 1 || step === 2))
          //       ? !selected
          //       : false
          //   }
          // >
          //   {action} {action === "LET'S GET STARTED" ? (<span><img alt = "arrow" src={arrowIcon} /></span>) :  null}
          // </button>
        );
      })
    : "";
};

export default Actions;
