import * as React from "react";
import { useEffect, useState, useRef } from "react";
import $ from "jquery";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import parse from "html-react-parser";

const slideCount = window.matchMedia("(max-width: 768px)").matches ? 1 : 2;

const Carousel = ({ products, width }) => {
  console.log("slideCount", slideCount);
  console.log("width", width);
  const settings = {
    dots: width <= 768,
    infinite: true,
    speed: 500,
    slidesToShow: slideCount,
    slidesToScroll: slideCount,
  };
  const [nav2, setNav2] = useState();
  const slider2 = useRef();
  useEffect(() => {
    setNav2(slider2);
  }, []);
  return (
    <Slider {...settings}>
      {products.map((product, i) => {
        return (
          <div className="Recommendation__ProductCard" key={i}>
            <div className="Recommendation__RecommendationContainer">
              <div className="Recommendation__Window">
                <div className="Recommendation__ImageContainer">
                  <img
                    src={require(`../../assets/Images/product/${product.image}`)}
                    alt="Daily care product"
                  />
                </div>
                <h3>
                  {parse(product.title)}
                  {/* Canesfresh Feminine<b>Wash Soothing Wash Gel</b> */}
                </h3>
              </div>
              <p>
                {product.description}

                {/* This liquid wash was developed for those times when
                          you’re suffering from discomfort around your intimate
                          area, such as when you’re suffering from thrush or
                          vaginal dryness. It has been specially formulated to
                          help soothe your sensitive intimate area and contains
                          glycine, an amino acid known for its calming
                          properties. */}
              </p>
            </div>
          </div>
        );
      })}
    </Slider>
  );
};

export default Carousel;
