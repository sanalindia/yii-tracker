import { event } from "jquery";
import React, { useState, useEffect, useRef } from "react";
import { Constants } from "../../constants";
import "../../css/components/EmailFormCard.scss";
import useForm from "./customHooks";
import validate from "./formValidate";
const EmailFormCard = ({ downloadPdf, filename, product }) => {
  const { inputs, handleInputChange, handleSubmit, errors } = useForm(
    { firstname: "", lastname: "", email: "" },
    validate
  );
  const [checked, setChecked] = useState(true);
  const [success, setSuccess] = useState(false);

  /*const handleCheck = () => {
    setChecked(!checked);
  };*/
  useEffect(() => {
    if (success === true)
      setTimeout(() => {
        setSuccess(false);
      }, 5000);
  }, [success]);
  
  return (
    <div className="emailFormContainer">
      <div className="emailArea">
        <form
          onSubmit={(event) => {
            handleSubmit(event, checked, product, setSuccess);
          }}
        >
          <div className="emailText">Email me these treatment options</div>
          <div className="emailFormArea">
            <div className="firstForm">
              <div>
                <input
                  type="text"
                  placeholder="Your first name...."
                  name="firstname"
                  onChange={handleInputChange}
                  value={inputs.firstname}
                  required=""
                />
                {errors.firstname && (
                  <p className="help-is-danger">{errors.firstname}</p>
                )}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Your last name...."
                  name="lastname"
                  onChange={handleInputChange}
                  value={inputs.lastname}
                  required=""
                />
                {errors.lastname && (
                  <p className="help-is-danger">{errors.lastname}</p>
                )}
              </div>
            </div>
            <div className="secondForm">
              <input
                type="email"
                placeholder="Your email...."
                name="email"
                onChange={handleInputChange}
                value={inputs.email}
                required=""
              />
              {errors.email && <p className="help-is-danger">{errors.email}</p>}
            </div>
          </div>
          <div className="emailDescription">
            Privacy Statement: By providing my email address, I consent to the
            use of my personal information by Bayer Australia Ltd for the
            purposes of providing the treatment option information. I understand
            that further information about Bayer’s collection, use, storage and
            disclosure of my personal information is available in Bayer’s
            privacy policy which can be found at privacy policy
          </div>
          {/*
          <div className="emailCheckBoxContent">
            <label class="container">
              I would like to hear about future promotions and offers from Bayer
              Australia Ltd
              <input
                type="checkbox"
                name="accept"
                value={checked}
                onChange={handleCheck}
                defaultChecked={checked}
              />
              <span class="checkmark"></span>
          </label>*/}
            {/* <label>
                  <input type="checkbox" />I would like to hear about future
                  promotions and offers from Bayer Australia Ltd
                </label> */}
          {/*</div>*/}
          <div className="emailButtonArea">
            <button className="sendButton" type="submit">
              SEND
            </button>
            <button className="downloadPdf">
              <a href={downloadPdf} download={filename}>
                DOWNLOAD PDF
                <span className="right-arrow"></span>
              </a>
            </button>
          </div>
          {success ? (
            <div className="emailSuccess"> Email sent successfully</div>
          ) : (
            ""
          )}
        </form>
      </div>
    </div>
  );
};

export default EmailFormCard;
