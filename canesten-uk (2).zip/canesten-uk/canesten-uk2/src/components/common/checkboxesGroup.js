import React, { useState, useEffect } from "react";
import "../../css/components/checkboxesGroup.scss";
import { Constants } from "../../constants";
import parse from "html-react-parser";
const CheckboxesGroup = ({
  inputValues,
  choices,
  updateChoices,
  isSelected,
  step,
  updateChoicesIndex,
  choicesIndex,
  onNext,
  lang,
  question,
  questionAnswersList,
  updateQuestionAnswerList,

  // inputValues,
  multiplechoices,
  updatemultipleChoices,
  // updateChoiceIndex,
  // choiceIndex,
  // step,
}) => {
  const options = inputValues[1];
  const qID = inputValues[0].id;
  const [selected, setSelected] = useState([]);
  const field_instruction = inputValues[0].field_instruction ? parse(inputValues[0].field_instruction) :'' ;
  const field_explanation = inputValues[0].field_explanation ? parse(inputValues[0].field_explanation) :'' ;
  useEffect(() => {
    if (multiplechoices[qID]) {
      setSelected(multiplechoices[qID]);
    }
  }, [multiplechoices, qID]);

  const handleChange = (event, index) => {
    if (event.target.checked) {
      setSelected([...selected, event.target.id]);
      if (multiplechoices[qID]) {
        //   {
        //   qId: qID,
        //   selectedChoices: event.target.id,
        //   questionStep: `Pytanie ${step}`,
        //   order: step,
        //   question: inputValues[0].title,
        //   [qID]: event.target.id,
        // }

        updatemultipleChoices({
          qId: qID,
          selectedChoices: event.target.id,
          questionStep: `Pytanie ${step}`,
          order: step,
          question: inputValues[0].title,
          type: "multi",
          [qID]: [...multiplechoices[qID], event.target.id],
        });

        // updatemultipleChoices({
        //   ...multiplechoices,
        //   [qID]: [...multiplechoices[qID], event.target.id],
        // });

        updateChoicesIndex({ [step]: [...choicesIndex[step], index + 1] });
      } else {
        updatemultipleChoices({
          qId: qID,
          selectedChoices: event.target.id,
          questionStep: `Pytanie ${step}`,
          order: step,
          question: inputValues[0].title,
          type: "multi",
          [qID]: Array.of(event.target.id),
        });
        // updatemultipleChoices({
        //   ...multiplechoices,
        //   [qID]: Array.of(event.target.id),
        // });

        updateChoicesIndex({
          ...choicesIndex,
          [step]: Array.of(index + 1),
        });
      }
    } else {
      let temp = selected;
      if (temp.includes(event.target.id))
        temp.splice(temp.indexOf(event.target.id), 1);
      setSelected(temp);
      updatemultipleChoices({
        qId: qID,
        selectedChoices: event.target.id,
        questionStep: `Pytanie ${step}`,
        order: step,
        question: inputValues[0].title,
        type: "multi",
        [qID]: temp,
      });
      // updatemultipleChoices({ ...multiplechoices, [qID]: temp });

      let indexTemp = choicesIndex[step];

      if (indexTemp.includes(index + 1))
        indexTemp.splice(indexTemp.indexOf(index + 1), 1);
      updateChoicesIndex({ ...choicesIndex, [step]: indexTemp });
    }
  };
  // const handleChange = (event, index) => {
  //   if (event.target.checked) {
  //     setSelected([...selected, event.target.id]);
  //     if (multiplechoices[qID]) {
  //       // updatemultipleChoices({
  //       //   ...multiplechoices,
  //       //   [qID]: [...multiplechoices[qID], event.target.id],
  //       // });
  //       // updateChoiceIndex({ [step]: [...choiceIndex[step], index + 1] });
  //     } else {
  //       // updatemultipleChoices({
  //       //   ...multiplechoices,
  //       //   [qID]: Array.of(event.target.id),
  //       // });
  //       // updateChoiceIndex({
  //       //   ...choiceIndex,
  //       //   [step]: Array.of(index + 1),
  //       // });
  //     }
  //   } else {
  //     let temp = selected;
  //     if (temp.includes(event.target.id))
  //       temp.splice(temp.indexOf(event.target.id), 1);
  //     setSelected(temp);
  //     // updatemultipleChoices({ ...multiplechoices, [qID]: temp });

  //     let indexTemp = choiceIndex[step];

  //     if (indexTemp.includes(index + 1))
  //       indexTemp.splice(indexTemp.indexOf(index + 1), 1);
  //     // updateChoiceIndex({ ...choiceIndex, [step]: indexTemp });
  //   }
  // };

  return (
    <div className="optionQuestion">
      {field_instruction !=''?(<div className="applyOption">( {field_instruction})</div>):''}
      
      
      {options.length
        ? options.map((option, index) => {
            return (
              <div className="checkboxOption" key={index}>
                <label>
                  <input
                    type="checkbox"
                    id={option[0]}
                    key={option[0]}
                    name={"checkbox" + index}
                    ordernumber={index}
                    value={option[1]}
                    checked={
                      selected.length ? selected.includes(option[0]) : false
                    }
                    onChange={(event) => handleChange(event, index)}
                  />
                  <span className="checkboxText">{option[1]}</span>
                  <span className="checkmark"></span>
                </label>
                <span className="divider"></span>
              </div>
            );
          })
        : ""}
        {
              step === 1? (<div className="applyOption">
              {field_explanation}
            </div>):null
            }
    </div>
  );
};

export default CheckboxesGroup;
