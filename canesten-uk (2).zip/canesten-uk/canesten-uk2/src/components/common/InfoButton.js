import React, { useState, useEffect } from "react";
import { Constants } from "../../constants";

const InfoButton = ({ fieldExplanation, top, lastSelectedOption }) => {
  // fieldExplanationMapping
  const [click, setClick] = useState(false);
  const [fieldDescription, setFieldDescription] = useState(false);

  let description = fieldExplanation;

  useEffect(() => {
    let description = fieldExplanation;
    if (Constants["fieldExplanationMapping"][lastSelectedOption]) {
      description = Constants["fieldExplanationMapping"][lastSelectedOption];
    }
    setFieldDescription(description);
  }, [lastSelectedOption, fieldExplanation]);
  const clickInfo = () => {
    setClick(!click);
  };
  return (
    <>
      <button
        className="InfoButton__OpenButton gtm-btn"
        data-gtm-label="Info Button"
        style={{ top: `${top}%` }}
      >
        <div className="react-reveal">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            xmlnsXlink="http://www.w3.org/1999/xlink"
            width="54"
            height="101"
            viewBox="0 0 54 101"
          >
            <defs>
              <filter
                id="a"
                width="131.4%"
                height="115%"
                x="-17.6%"
                y="-5.5%"
                filterUnits="objectBoundingBox"
              >
                <feMorphology
                  in="SourceAlpha"
                  operator="dilate"
                  radius=".5"
                  result="shadowSpreadOuter1"
                ></feMorphology>
                <feOffset
                  dx="-1"
                  dy="2"
                  in="shadowSpreadOuter1"
                  result="shadowOffsetOuter1"
                ></feOffset>
                <feGaussianBlur
                  in="shadowOffsetOuter1"
                  result="shadowBlurOuter1"
                  stdDeviation="2"
                ></feGaussianBlur>
                <feColorMatrix
                  in="shadowBlurOuter1"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.167531687 0"
                ></feColorMatrix>
              </filter>
              <path
                id="b"
                d="M54.07 17V0c0 9.353-7.86 16.942-17.579 17h-.49C16.117 17 0 31.775 0 50l.004.546C.323 68.519 16.317 83 36 83h.38c9.77 0 17.69 7.612 17.69 17V83H54V17h.07z"
              ></path>
            </defs>
            {click ? (
              <g fill="none" fillRule="evenodd" onClick={() => clickInfo()}>
                <g transform="translate(6.102 2)">
                  <use fill="#000" filter="url(#a)" xlinkHref="#b"></use>
                  <use fill="#FEFEFE" xlinkHref="#b"></use>
                </g>
                <g stroke="#C1172F" strokeLinecap="round" strokeWidth="2">
                  <path d="M40.102 43.345l-14 14M26.102 43.345l14 14"></path>
                </g>
              </g>
            ) : (
              <g fill="none" fillRule="evenodd" onClick={() => clickInfo()}>
                <use fill="#000" filter="url(#a)" xlinkHref="#b"></use>
                <use fill="#C1172F" xlinkHref="#b"></use>
                <g className="i-icon" fill="#FFF">
                  <path d="M31.26 40.851a2.556 2.556 0 0 1-1.945.865c-.716 0-1.364-.285-1.872-.824-.5-.527-.753-1.144-.753-1.832 0-.715.253-1.348.75-1.88.51-.548 1.158-.835 1.875-.835.783 0 1.437.266 1.943.788.492.51.742 1.114.742 1.795 0 .73-.25 1.376-.74 1.923m-.106 16l-.51 2.11c-.03.126-.135.258-.23.295l-.175.068c-.969.377-1.728.634-2.32.785-.625.158-1.152.236-1.613.236-1.012 0-1.8-.278-2.346-.826-.537-.54-.81-1.21-.81-1.994 0-.263.024-.538.07-.818.043-.261.11-.581.208-.977l1.608-6.264c.075-.323.152-.685.225-1.063.068-.35.102-.643.102-.873 0-.157-.01-.277-.021-.368-.017-.128-.156-.262-.288-.278a2.99 2.99 0 0 0-.394-.022c-.12 0-.348.016-.75.09-.352.066-.619.122-.794.166l-.931.238c-.13.033-.21-.042-.178-.168l.474-1.958c.03-.126.128-.258.218-.298l.164-.071a15.942 15.942 0 0 1 2.231-.8c.698-.187 1.248-.276 1.68-.276 1.035 0 1.82.267 2.335.793.504.515.76 1.198.76 2.027a8.028 8.028 0 0 1-.266 1.809l-1.614 6.25c-.097.373-.183.74-.256 1.093-.066.32-.099.58-.099.769 0 .418.09.581.123.609.044.034.23.148.789.148.109 0 .321-.013.724-.067.381-.052.577-.105.676-.14l1.037-.37c.125-.046.201.02.17.146"></path>
                </g>
              </g>
            )}
          </svg>
        </div>
      </button>
      {click ? (
        <div className="InfoButton__Backdrop">
          <div className="InfoButton__Window">
            <div>{fieldDescription ? fieldDescription : ""}</div>
          </div>
        </div>
      ) : (
        ""
      )}
      {/*  */}
    </>
  );
};

export default InfoButton;
