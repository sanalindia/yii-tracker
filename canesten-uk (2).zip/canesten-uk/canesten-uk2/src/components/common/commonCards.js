import React, { useEffect } from "react";
import Card from "react-bootstrap/Card";
const CommonCards = ({ number, question, correctOPT, selection, quizText }) => {
  const getCustomClass = () => {
    return selection && selection.trim() === correctOPT.trim()
      ? "correctAns"
      : "wrongAns";
  };

  return (
    <div className="col-md-4">
      <Card>
        <Card.Body>
          <h6>
            {quizText.questionCountText} {number}
          </h6>
          <div className="quesWrapper">
            <p className="quesSection">{question} </p>
          </div>
          <p className="yourAnswer">{quizText.resultCardText1}</p>
          <p className={getCustomClass()}>{selection}</p>
          <hr />
          <p className="correctLabel">{quizText.resultCardText2}</p>
          <p className="correctAns rightOpt">{correctOPT}</p>
        </Card.Body>
      </Card>
    </div>
  );
};

export default CommonCards;
