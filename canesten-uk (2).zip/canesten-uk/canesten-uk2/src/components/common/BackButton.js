import React from "react";

const BackButton = ({ backToPreviousPage, display, width, animationObj }) => {
  return (
    <div
      className="react-reveal"
      style={{ zIndex: 1, display: "flex", opacity: 1 }}
    >
      <div
        className="BackButton__Button gtm-btn"
        data-gtm-label="Previous Question"
        style={
          display === "Result"
            ? width > 500
              ? { width: "2rem" }
              : { width: "5rem" }
            : {}
        }
        onClick={backToPreviousPage}
      >
        <svg
          width="12"
          height="18"
          viewBox="0 0 12 18"
          xmlns="http://www.w3.org/2000/svg"
        >
          <title>Group 3</title>
          <path
            d="M10.415 15.721l-1.398 1.38-8.602-8.5 8.602-8.5 1.398 1.381-7.205 7.12z"
            fill="#C1172F"
            fillRule="evenodd"
          ></path>
        </svg>
      </div>
      {display === "Result" ? (
        <p className="Product__AdviceText">
          Based on your answers we suggest this treatment to cure your
          infection.
        </p>
      ) : (
        ""
      )}
    </div>
  );
};

export default BackButton;
