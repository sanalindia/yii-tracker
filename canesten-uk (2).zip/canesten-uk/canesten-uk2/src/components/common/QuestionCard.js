import React, { useEffect, useState } from "react";
import parse from "html-react-parser";
import { Cases } from "../../utils/API/index";
import Actions from "./actions";
import "../../css/components/questionCard.scss";
import Loader from "../common/loader";
import ProgressBar from "../common/ProgressBar";
import InfoButton from "../common/InfoButton";
import { Constants } from "../../constants";

const QuestionCard = ({
  question,
  onNext,
  choices,
  updateChoices,
  step,
  updateChoicesIndex,
  choicesIndex,
  lang,
  questionAnswersList,
  updateQuestionAnswerList,
  multiplechoices,
  updatemultipleChoices,
  choice,
  progress,
  animationObj,
  lastSelectedOption,
}) => {
  let qID = question.id;
  const selectionMade = choices[qID] ? true : false;
  const [qaArray, setQaArray] = useState([]);
  const [qAction, setQaction] = useState([]);
  const [qcardLoading, setQcardLoading] = useState(true);

  useEffect(() => {
    Cases.getAnswers4Question(qID)
      .then((response) => {
        let qaArr = [];
        qaArr.push(question, response);
        setQaArray(qaArr);
        setQcardLoading(false);
      })
      .catch((e) => console.log(e));

    /* Cases.getActions4QUestion(qID)
      .then((response) => {
        setQaction(response);
        setQcardLoading(false);
      })
      .catch((e) => console.log(e)); */
  }, [question, qID]);

  return (
    <>
      <div className="Questionnaire__HighBlock">
        {qcardLoading ? (
          <Loader />
        ) : (
          <>
            <InfoButton
              fieldExplanation={parse(qaArray[0].field_explanation)}
              top={8}
              lastSelectedOption={lastSelectedOption}
              // title={}
            />
            <div className="Questionnaire__FullHeightContainer">
              <div className="react-reveal">
                <h1 className="Questionnaire__Title">
                  {parse(qaArray[0].field_instruction)}
                </h1>
              </div>
              <div className="react-reveal">
                <h3 className="Questionnaire__Question">
                  {qaArray.length ? parse(qaArray[0].title) : ""}
                  {/* Are you male or female? */}
                </h3>
              </div>
              <div className="react-reveal">
                <div className="Questionnaire__AnswerContainer">
                  <Actions
                    onNext={onNext}
                    selected={selectionMade}
                    step={step}
                    multiplechoices={multiplechoices}
                    choicesIndex={choicesIndex}
                    choices={choices}
                    options={qaArray.length ? qaArray[1] : ""}
                    questionData={qaArray.length ? qaArray[0] : ""}
                  />
                  {/* <div className="common__Button">Male</div>
                <div className="common__Button">Female</div> */}
                </div>
              </div>
              <ProgressBar progress={progress} />
            </div>
          </>
        )}
      </div>
    </>
    // <div className="questionContainer">
    //   <div className="qa-inner-div">
    //     {qcardLoading ? (
    //       <Loader />
    //     ) : (
    //       <>
    //         <h6 className="questionIndex">
    //           {lang === "fr" ? Constants.fr.question : Constants.de.question}{" "}
    //           {qaArray.length ? step + "/" + Constants.QUESTIONS_COUNT : null}

    //         </h6>
    //         <div className="question-card">
    //           <h2>{qaArray.length ? parse(qaArray[0].title) : ""}</h2>
    //         </div>

    //         <Choices
    //           choices={choices}
    //           updateChoices={updateChoices}
    //           options={qaArray.length ? qaArray : ""}
    //           step={step}
    //           choicesIndex={choicesIndex}
    //           updateChoicesIndex={updateChoicesIndex}
    //           onNext={onNext}
    //           lang={lang}
    //           question={question}
    //           questionAnswersList={questionAnswersList}
    //           updateQuestionAnswerList={updateQuestionAnswerList}
    //           multiplechoices={multiplechoices}
    //           updatemultipleChoices={updatemultipleChoices}
    //         />

    //         <Actions
    //           actions={qAction}
    //           onNext={onNext}
    //           selected={selectionMade}
    //           step={step}
    //           multiplechoices={multiplechoices}
    //           choicesIndex={choicesIndex}
    //           choices={choices}
    //         />

    //       </>
    //     )}
    //   </div>
    // </div>
  );
};

export default QuestionCard;
