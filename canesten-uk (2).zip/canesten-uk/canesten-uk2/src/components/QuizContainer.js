import React, { useEffect, useState, useLayoutEffect } from "react";
import { Cases } from "../utils/API/index";
import axios from "axios";
import Loader from "../components/common/loader";
import StartQuizContainer from "./StartQuizContainer";
import ThanksValidation from "./ThanksValidation";
import QuestionCard from "../components/common/QuestionCard";
import BackButton from "../components/common/BackButton";
import useWindowSize from "../components/common/useWindowSize";
import ResultContainer from "./ResultContainer";
import Male_Bg from "../assets/Images/male_bg.jpg";
import Female_bg from "../assets/Images/female_bg.jpg";
import Female2_bg from "../assets/Images/female2_bg.jpg";
import Female3_bg from "../assets/Images/female3_bg.jpg";
import Male_Tiny from "../assets/Images/male_tiny.jpg";
import Female_Tiny from "../assets/Images/female_tiny.jpg";
import Female2_Tiny from "../assets/Images/female2_tiny.jpg";
import Female3_Tiny from "../assets/Images/female3_tiny.jpg";
import result from "../utils/result";

import "../css/components/quizContainer.scss";
import isMobileDevice from "responsive-react";
import Result from "../utils/result";
import { Constants } from "../constants";

import { withResizeDetector } from "react-resize-detector/build/withPolyfill";
import utility from "../utils/utility";
const tempArray = [];
const getHistoryQIds = [];
const getImageData = (width) => {
  let obj = {
    male: width > 500 ? Male_Bg : Male_Tiny,
    female: width > 500 ? Female_bg : Female_Tiny,
    female2: width > 500 ? Female2_bg : Female2_Tiny,
    female3: width > 500 ? Female3_bg : Female3_Tiny,
  };
  return obj;
};
const animationObj = {
  opacity: 1,
  position: "relative",
  animationName: "example",
  animationDuration: "1000ms",
  animationFillMode: "both",
  animationDelay: "0ms",
  animationIterationCount: 1,
};
const QuizContainer = ({ height }) => {
  const { width } = useWindowSize();
  const [step, setStep] = useState(0);
  const [loadResult, setLoadResult] = useState([]);
  const [quizTitle, setQuizTitle] = useState("");
  const [titleContent, setTitleContent] = useState("");
  const [infoContent, setInfoContent] = useState("");
  const [quizInstruction, setQuizInstruction] = useState("");
  const [resultSet, setResultSet] = useState("");
  const [quizDesc, setQuizDesc] = useState("");
  const [quizAction, setQuizAction] = useState([]);
  const [questions, setQuestion] = useState([]);
  const [loading, setLoading] = useState(false);
  const [startQuiz, setstartQuiz] = useState(true);
  const [choices, setChoices] = useState([]);
  const [choicesIndex, setChoicesIndex] = useState([]);
  const [resultNumber, setResultNumber] = useState(0);
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0);
  const [lang, setLang] = useState("de");
  const [questionAnswersList, setQuestionAnswersList] = useState([]);
  const [multiplechoices, setmultiplechoices] = useState({});
  const [display, setDisplay] = useState("Start");
  const [nextQuestion, setNextQuestion] = useState("");
  const [progress, setProgress] = useState(10);
  const [changeBackground, setChangeBackground] = useState(
    getImageData(width).female2
  );

  const [windowHeight, setLastWindowSize] = useState(0);
  const [validationImage, setValidationImage] = useState(0);
  const [lastSelectedOption, setLastSelectedOption] = useState(0);
  const [initialSelectOption, setInitialSelectOption] = useState("");
  useLayoutEffect(() => {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (window.parent.document.getElementById("iFrameResizer0")) {
      let height = document.getElementById("mainWrapper").offsetHeight;
      setTimeout(() => {
        const customHeight = height;
        var index = 1;
        if (
          window.parent.document.getElementsByTagName("iframe")[1] === undefined
        ) {
          index = 0;
        }
        window.parent.document.getElementsByTagName("iframe")[
          index
        ].style.height = customHeight + "px";
        window.parent.document.getElementById("iFrameResizer0").height = height;
      }, 1000);
      if (window.parent.document.getElementById("block-floatingactionbutton-2"))
        window.parent.document.getElementById(
          "block-floatingactionbutton-2"
        ).style.display = "none";
    }
  });

  // useLayoutEffect(() => {
  //   var ua = window.navigator.userAgent;
  //   var msie = ua.indexOf("MSIE ");

  //   if (window.parent.document.getElementById("iFrameResizer0")) {
  //     let height = document.getElementById("mainWrapper").offsetHeight;
  //     if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
  //       height = 800;
  //     }
  //     window.parent.document.getElementById("iFrameResizer0").height = height;

  //     window.parent.document.getElementById(
  //       "block-floatingactionbutton-2"
  //     ).style.display = "none";
  //   }
  // }, [height]);

  useEffect(() => {
    let language = window.parent.document.documentElement.lang;
    setLang(language);
  }, [lang]);

  useEffect(() => {
    setLoading(true);

    Cases.findQuiz()
      .then((quizID) => {
        axios
          .all([
            Cases.getQuiz(quizID),
            Cases.getQuizQuestions(quizID),
            // Cases.getResults(),
          ])
          .then(
            axios.spread((...responses) => {
              const quizTitle = responses[0][0];
              const quizAction = [];
              const quizDesc = responses[0][1];
              quizAction.push(responses[0][2]);
              const infoContent = responses[0][2];
              const titleContent = responses[0][3];
              const general_questions = responses[1];
              const quizInstruction =
                typeof responses[0][3] !== "undefined" && responses[0][3]
                  ? responses[0][3]
                  : "";
              setQuizInstruction(quizInstruction);
              setQuizTitle(quizTitle);
              setInfoContent(infoContent);
              setTitleContent(titleContent);
              setQuestion(general_questions);
              setNextQuestion(general_questions[0]);

              setQuizAction(quizAction);
              setQuizDesc(quizDesc);

              // setResultSet(responses[2]);
            })
          )
          .catch((errors) => {
            console.log(errors);
          });
      })
      .catch((e) => console.log(e))
      .finally(() => {
        setLoading(false);
        setDisplay("Start");
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: "virtualPageView",
          vpvPage: "Quiz Home", //dynamic value e.g. Quiz Home
          contentCategory: "PAGE",
          country: "GB", //dynamic value e.g. GB
          environment: "Testing", //dynamic value e.g. Production
          brand: "Canesten",
        });
        // setDisplay("Result");
      });
  }, []);

  const backClick = () => {
    setDisplay("Questions");
  };

  const setResult = () => {
    setResultNumber(1);
  };

  const getResult = () => {
    setDisplay("ThanksValidation");

    let resultData = Constants.ResultMappingArray;
    let objectStr = [];
    let data = Object.assign({}, resultData);
    for (let i = 0; i < tempArray.length; i++) {
      objectStr = [tempArray[i]];
      data = data[objectStr];
      if (i === tempArray.length - 1) {
        setResultSet(data);
        let validationImage = result.getThanksValidationImage(data, width);
        setValidationImage(validationImage);
        setTimeout(() => {
          setDisplay("Result");
          window.dataLayer = window.dataLayer || [];
          window.dataLayer.push({
            event: "gaGenericEvent",
            eventCategory: "Canesten Quiz",
            eventAction: "Completed",
            eventLabel: initialSelectOption, //dynamic value e.g. Female
            contentCategory: "PAGE",
            country: "GB", //dynamic value e.g. GB
            environment: "Testing", //dynamic value e.g. Production
            brand: "Canesten",
          });
          window.dataLayer.push({
            event: "virtualPageView",
            vpvPage: "Quiz End", //dynamic value e.g. Quiz Home
            contentCategory: "PAGE",
            country: "GB", //dynamic value e.g. GB
            environment: "Testing", //dynamic value e.g. Production
            brand: "Canesten",
          });
        }, 5000);
        // setDisplay("Result");
      }
    }

    // setDisplay("Result");
  };
  const backToPreviousPage = () => {
    if (windowHeight !== 0) {
      window.innerHeight = windowHeight;
      setLastWindowSize(0);
    }
    let fetchQuestion, getPreviousQuizID;
    getHistoryQIds.splice(-1, 1);

    getPreviousQuizID = getHistoryQIds[getHistoryQIds.length - 1];
    fetchQuestion = getPreviousQuizID
      ? questions.find((data) => data.id === getPreviousQuizID.qId)
      : "";

    tempArray.splice(-1, 1);
    let lastselectedOpt = tempArray[tempArray.length - 1];
    setLastSelectedOption(lastselectedOpt);
    if (fetchQuestion) {
      // setDisplay("Questions");
      if (display === "Questions") setStep(step - 1);

      setChangeBackground(getPreviousQuizID.pic);
      // setStep(step - 1);
      if (progress > 15 && display === "Questions") setProgress(progress - 15);
      setNextQuestion(fetchQuestion);
      setTimeout(() => {
        setDisplay("Questions");
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: "virtualPageView",
          vpvPage: "Quiz Question", //dynamic value e.g. Quiz Home
          contentCategory: "PAGE",
          country: "GB", //dynamic value e.g. GB
          environment: "Testing", //dynamic value e.g. Production
          brand: "Canesten",
        });
      }, 1000);
    } else {
      if (progress >= 15) setProgress(progress - 15);
      setDisplay("Start");
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "virtualPageView",
        vpvPage: "Quiz Home", //dynamic value e.g. Quiz Home
        contentCategory: "PAGE",
        country: "GB", //dynamic value e.g. GB
        environment: "Testing", //dynamic value e.g. Production
        brand: "Canesten",
      });
    }
  };

  const nextStep = (qId, e) => {
    if (step === 1) {
      let gaArray = {
        "7529905e-52ca-40d9-9606-f684bbf616bc": "Male",
        "433b3af0-eb08-4ca9-a75f-d05c4de5636b": "Female",
      };
      setInitialSelectOption(gaArray[e.target.id]);
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "gaGenericEvent",
        eventCategory: "Canesten Quiz",
        eventAction: "Step 1 - Are you male or female?",
        eventLabel: gaArray[e.target.id], //dynamic value e.g. Female
        contentCategory: "PAGE",
        country: "GB", //dynamic value e.g. GB
        environment: "Testing", //dynamic value e.g. Production
        brand: "Canesten",
      });
    }
    setLastSelectedOption(e.target.id);
    let fetchOptionsFromMapping = Constants["questionMappingArray"][qId];
    if (fetchOptionsFromMapping) {
      tempArray.push(e.target.id);

      let getNextQuizId = fetchOptionsFromMapping[e.target.id];
      let fetchQuestion = getNextQuizId
        ? questions.find((data) => data.id === getNextQuizId)
        : "";

      if (fetchQuestion) {
        let backgroundPic = getImageData(width).female; // Female_bg;
        if (step === 1) {
          if (Constants.q2 === getNextQuizId) {
            backgroundPic = getImageData(width).male; //Male_Bg
          }
          if (Constants.q3 === getNextQuizId) {
            backgroundPic = getImageData(width).female3;
          }
        }

        if (step === 3) {
          backgroundPic = getImageData(width).female2;
        }
        if (step === 4) {
          backgroundPic = getImageData(width).female3;
        }

        getHistoryQIds.push({ qId: getNextQuizId, pic: backgroundPic });
        setChangeBackground(backgroundPic);
        setStep(step + 1);
        setProgress(progress + 15);
        setNextQuestion(fetchQuestion);
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: "virtualPageView",
          vpvPage: "Quiz Question", //dynamic value e.g. Quiz Home
          contentCategory: "PAGE",
          country: "GB", //dynamic value e.g. GB
          environment: "Testing", //dynamic value e.g. Production
          brand: "Canesten",
        });
      } else {
        setLastWindowSize(window.innerHeight);
        getHistoryQIds.push({ qId: 0, pic: "result" });
        getResult();
      }
    }
  };

  const onStartClick = () => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "gaGenericEvent",
      eventCategory: "Canesten Quiz",
      eventAction: "Start",
      eventLabel: "Click on Click on find product",
      contentCategory: "PAGE",
      country: "GB", //dynamic value e.g. GB
      environment: "Testing", //dynamic value e.g. Production
      brand: "Canesten",
    });
    getHistoryQIds.push({
      qId: questions[0].id,
      pic: getImageData(width).female2,
    });
    setStep(1);
    setProgress(progress + 15);
    setDisplay("Questions");
    setstartQuiz(false);
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "virtualPageView",
      vpvPage: "Quiz Question", //dynamic value e.g. Quiz Home
      contentCategory: "PAGE",
      country: "GB", //dynamic value e.g. GB
      environment: "Testing", //dynamic value e.g. Production
      brand: "Canesten",
    });
  };
  const closeClick = () => {
    setDisplay("Start");
    setStep(1);
    setstartQuiz(true);
    setChoices([]);
    setChoicesIndex([]);
    setmultiplechoices({});
  };

  const onHomeClick = () => {
    window.parent.location.href = window.location.origin;
  };
  const updatemultipleChoices = (choice) => {
    setmultiplechoices(choice);
  };
  const updateChoices = (choice) => {
    setChoices(choice);
  };

  const updateChoicesIndex = (choice) => {
    setChoicesIndex(choice);
  };
  const updateQuestionAnswerList = (data) => {
    setQuestionAnswersList(data);
  };

  return (
    <div id="__next">
      <div
        // height={
        //   windowHeight !== 0 ? `${windowHeight}px` : `${window.innerHeight}px`
        // }
        style={
          windowHeight !== 0
            ? { minHeight: `${windowHeight}px` }
            : { minHeight: `${window.innerHeight}px` }
        }
        className="layout__Container"
      >
        {
          {
            Loader: <Loader />,
            ThanksValidation: (
              <div className="Background__Container">
                <div
                  className="Background__Bg"
                  style={{
                    backgroundImage: `url(${validationImage})`,
                  }}
                ></div>
                <div
                  className="common__Content"
                  style={{ justifyContent: "flex-end" }}
                >
                  <ThanksValidation validationImage={validationImage} />
                </div>
              </div>
            ),
            Start: (
              <div className="Background__Container">
                <div
                  className="Background__Bg"
                  style={{
                    backgroundImage: `url(${getImageData(width).female})`,
                  }}
                ></div>
                <div
                  className={["common__Content", "startQuiz_Area"].join(" ")}
                  style={{ justifyContent: "flex-end" }}
                >
                  <StartQuizContainer
                    startQuiz={startQuiz}
                    quizTitle={quizTitle}
                    quizAction={quizAction}
                    quizDesc={quizDesc}
                    quizInstruction={quizInstruction}
                    onStartClick={onStartClick}
                    progress={progress}
                    infoContent={infoContent}
                    titleContent={titleContent}
                    animationObj={animationObj}
                  />
                </div>
              </div>
            ),
            Questions: (
              <div className="Background__Container">
                <div
                  className="Background__Bg"
                  style={{
                    // background: `url(${changeBackground}) no-repeat absolute cover`,
                    backgroundSize: `cover`,
                    backgroundImage: `url(${changeBackground})`,
                  }}
                ></div>
                <div
                  className="common__Content"
                  style={{ justifyContent: "space-between" }}
                >
                  <BackButton
                    width={width}
                    display={display}
                    backToPreviousPage={backToPreviousPage}
                    animationObj={animationObj}
                  />
                  <QuestionCard
                    question={nextQuestion}
                    progress={progress}
                    onNext={nextStep}
                    key={step}
                    choices={choices}
                    updateChoices={updateChoices}
                    step={step}
                    choicesIndex={choicesIndex}
                    updateChoicesIndex={updateChoicesIndex}
                    lang={lang}
                    questionAnswersList={questionAnswersList}
                    updateQuestionAnswerList={updateQuestionAnswerList}
                    multiplechoices={multiplechoices}
                    updatemultipleChoices={updatemultipleChoices}
                    animationObj={animationObj}
                    lastSelectedOption={lastSelectedOption}
                  />
                </div>
              </div>
            ),
            Result: (
              <div className="Product__Background">
                <ResultContainer
                  backToPreviousPage={backToPreviousPage}
                  resultNumber={resultNumber}
                  loadResult={loadResult}
                  onHomeClick={onHomeClick}
                  correctAnswersCount={correctAnswersCount}
                  lang={"en"}
                  questionAnswersList={questionAnswersList}
                  backClick={backClick}
                  setResult={setResult}
                  resultSet={resultSet}
                  display={display}
                  width={width}
                  animationObj={animationObj}
                />
              </div>
            ),
          }[display]
        }
      </div>
    </div>
  );
};
export default withResizeDetector(QuizContainer);
