import React from "react";
import parse from "html-react-parser";
import Actions from "./common/actions";
import "../css/components/StartQuizContainer.scss";
import ProgressBar from "../components/common/ProgressBar";
import InfoButton from "../components/common/InfoButton";

const StartQuizContainer = ({
  startQuiz,
  quizTitle,
  quizAction = [],
  quizDesc,
  onStartClick,
  progress,
  infoContent,
  titleContent,
  animationObj,
  fromResultScreen,
  quizInstruction,
}) => {
  return (
    <>
      <div className="Start__TitleContainer">
        <div className="react-reveal" style={animationObj}>
          <h1 className="Start__Title">{parse(titleContent)}</h1>
        </div>
      </div>
      <div className="react-reveal" style={animationObj}>
        <div className={["common__Block", "welcomeArea"].join(" ")}>
          <InfoButton
            animationObj={animationObj}
            fieldExplanation={parse(infoContent)}
            top={35}
          />
          <div className="react-reveal" style={animationObj}>
            <h2 className="Start__SubTitle">
              {quizTitle}
              {/* Welcome to your product selector. */}
            </h2>
          </div>
          <div className="react-reveal" style={animationObj}>
            <div className="Start__Text">
              {quizDesc ? parse(quizDesc) : " "}
              {/* Answer a few questions and we'll find the best product for you, so
              you can find fast relief. */}
            </div>
          </div>
          <div className="react-reveal" style={animationObj}>
            <div className="common__ButtonContainer">
              {quizAction.length ? (
                <Actions
                  actions={[
                    [
                      "1",
                      quizAction[0].action
                        ? quizAction[0].action
                        : "FIND PRODUCT",
                      "",
                    ],
                  ]}
                  onStartClick={onStartClick}
                />
              ) : (
                " "
              )}
              {/* <div
                className="common__Button"
                onClick={() => {
                  onStartClick();
                }}
              >
                Find product
              </div> */}
            </div>
          </div>
          <ProgressBar progress={progress} />
        </div>
      </div>
      {/* <div className="quizContainer container startContainer">
        <div className="row">
          <div className="leftImage col-lg-6">
            <img src={fromResultScreen ? resultImage : startImage} />
          </div>
          <div className="rightSide col-lg-6">
            <div className="quizHeader">
              <h1>
                {quizTitle}
              </h1>
              <div className={fromResultScreen ? "result_desc" : ""}>
                {quizDesc ? parse(quizDesc) : " "}
              </div>
              {quizAction.length ? (
                <Actions
                  actions={Array.of(quizAction[0].action)}
                  onStartClick={onStartClick}
                />
              ) : (
                " "
              )}
            </div>
          </div>
        </div>
      </div> */}
    </>
  );
};
export default StartQuizContainer;
