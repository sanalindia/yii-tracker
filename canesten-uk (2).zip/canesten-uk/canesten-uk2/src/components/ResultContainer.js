import React, { useState, useEffect, useRef } from "react";
import "../css/components/resultContainer.scss";
import parse from "html-react-parser";
import { Constants } from "../constants";
// import CommonCards from "./common/commonCards";
import BackButton from "../components/common/BackButton";
import Carousel from "../components/common/carousel";
import result from "../utils/result";
const ResultContainer = ({
  resultNumber,
  loadResult,
  onHomeClick,
  correctAnswersCount,
  lang,
  questionAnswersList,
  backClick,
  backToPreviousPage,
  resultSet,
  display,
  width,
  animationObj,
  setResult,
}) => {
  const [resultData, setResultData] = useState();
  const [icon, setIcon] = useState("+");

  useEffect(() => {
    let getResult = result.fetchResult(resultSet);
    setResultData(getResult);
  }, [resultSet]);
  const leanMore = (resultSet) => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "gaGenericEvent",
      eventCategory: "CTA (Local)",
      eventAction: "Learn more", //dynamic value
      eventLabel: "", //dynamic value
      contentCategory: "PAGE",
      country: "GB", //dynamic value e.g. GB
      environment: "Testing", //dynamic value e.g. Production
      brand: "Canesten",
    });
    document.getElementById("Product__Content").scrollIntoView();
    let getResult = result.fetchResult(resultSet);
    setResultData(getResult);
  };
  const mainTopButtonClick = (text) => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "gaGenericEvent",
      eventCategory: "CTA (Local)",
      eventAction: text, //dynamic value
      eventLabel: "", //dynamic value
      contentCategory: "PAGE",
      country: "GB", //dynamic value e.g. GB
      environment: "Testing", //dynamic value e.g. Production
      brand: "Canesten",
    });
  };

  const handleClick = (e) => {
    let id = e.target.id;
    let getAccordionBody = document
      .getElementsByClassName("Accordion__Container")
      [id].getElementsByClassName("Accordion__Body")[0];
    let getHeader = document
      .getElementsByClassName("Accordion__Container")
      [id].getElementsByClassName("Accordion__Header")[0];
    let isThere = getAccordionBody.classList.contains(`title_${id}`);
    if (isThere) {
      let getTitleClass = document
        .getElementsByClassName("Accordion__Container")
        [id].getElementsByClassName(`title_${id}`)[0];
      getTitleClass.style.display = "none";
      getAccordionBody.classList.remove(`title_${id}`);
      getHeader.getElementsByTagName("span")[0].innerHTML = "+";
    } else {
      getAccordionBody.classList.add(`title_${id}`);
      let getTitleClass = document
        .getElementsByClassName("Accordion__Container")
        [id].getElementsByClassName(`title_${id}`)[0];
      getTitleClass.style.display = "block";
      getHeader.getElementsByTagName("span")[0].innerHTML = "-";
    }
  };
  return (
    <>
      <div className="Product__Content" id="Product__Content">
        <BackButton
          width={width}
          display={display}
          backToPreviousPage={backToPreviousPage}
          animationObj={animationObj}
        />
        <div className="Product__TopRow"></div>
        {/* <!--produc data --> */}
        {resultData?.productDetails ? (
          <div className="Product__RecommendationContainer">
            <div className="Product__Info">
              <div className="react-reveal" style={animationObj}>
                <div className="Product__ImageContainer">
                  <img
                    src={require(`../assets/Images/product/${resultData?.productDetails?.productImage}`)}
                    alt="Product"
                  />
                </div>
              </div>
            </div>
            <div className="Product__Info">
              <div className="react-reveal" style={animationObj}>
                <h1 className="Product__Title">
                  {resultData?.productDetails?.productName}
                </h1>
              </div>
              <div className="react-reveal" style={animationObj}>
                <div className="Product__SecondaryTitle">
                  {resultData?.productDetails?.productDescription}
                </div>
              </div>
              <div className="react-reveal" style={animationObj}>
                <div
                  className="Product__FirstButton gtm-btn"
                  onClick={() =>
                    mainTopButtonClick(resultData?.productDetails?.buttonText)
                  }
                >
                  {resultData?.productDetails?.buttonText}
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
      {resultData?.availableProduct ? (
        <div className="react-reveal" style={animationObj}>
          {/* {jsjdij} */}
          <div className="Product__OnlineAlternative">
            <h4>or available online as combi-pack</h4>
            <div className="Product__AlternativeWrapper">
              <div className="Product__ImageContainer_Sub">
                <img
                  src={require(`../assets/Images/product/${resultData?.availableProduct?.image}`)}
                  alt="Online alternative product"
                />
              </div>
              <div>
                <h3 className="Product__SubHeader">
                  <b>{resultData?.availableProduct?.header} </b>
                </h3>
                <h3 className="Product__SmallHeader">
                  {resultData?.availableProduct?.smallHeader}
                </h3>
                <p>{resultData?.availableProduct?.description}</p>

                <div
                  className="common__Button_Sub gtm-btn"
                  onClick={() =>
                    leanMore(resultData?.availableProduct?.learnMoreLink)
                  }
                >
                  Learn more
                </div>
                <div className="common__Button_Sub_1">Buy online</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}

      <div className="Product__Block">
        <div className="Product__Details">
          <div className="react-reveal" style={animationObj}>
            {resultData?.textHead ? (
              <h3 className="Product__SubHeader">{resultData?.textHead}</h3>
            ) : (
              ""
            )}
          </div>
          {resultData?.textDescription ? (
            <div className="divv" style={animationObj}>
              {resultData?.textDescription}
            </div>
          ) : (
            ""
          )}
          <div className="react-reveal" style={animationObj}>
            <div className="Product__Divider"></div>
          </div>
          {resultData?.toggleList &&
            resultData?.toggleList.map((data, i) => {
              return (
                <div className="react-reveal" key={i} style={animationObj}>
                  <div className="Accordion__Container">
                    <h3
                      className={"Accordion__Header"}
                      id={i}
                      onClick={(e) => handleClick(e)}
                    >
                      {data?.title} <span id={i}>+</span>
                    </h3>
                    <div
                      className={[`Accordion__Body`, "react-reveal"].join(" ")}
                      style={animationObj}
                    >
                      <div className="divv">{parse(data?.description)}</div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
      {resultData?.dailyProducts.length ? (
        <div className="Product__BlockSecondary">
          <div className="Product__Content">
            <div className="react-reveal" style={animationObj}>
              <h3 className="Product__SubHeader">Daily care</h3>
            </div>
            <div className="description" style={animationObj}>
              The below products are daily care products that are intended to
              complement your treatment products.
            </div>
            <div className="react-reveal" style={animationObj}>
              <div className="Recommendation__CardContainer">
                <Carousel products={resultData?.dailyProducts} width={width} />
              </div>
            </div>
          </div>
        </div>
      ) : (
        ""
      )}
    </>
  );
};

export default ResultContainer;
