import React from "react";
import parse from "html-react-parser";
import Actions from "./common/actions";
import "../css/components/StartQuizContainer.scss";
import ProgressBar from "./common/ProgressBar";
import InfoButton from "./common/InfoButton";

const ThanksValidation = ({
  validationImage,
  quizTitle,
  quizAction = [],
  quizDesc,
  onStartClick,
  progress,
  infoContent,
  titleContent,
  animationObj,
  fromResultScreen,
  quizInstruction,
}) => {
  console.log("quizAction[0]", quizAction[0]);
  return (
    <>
      <div className="Start__TitleContainer_Thanks">
        <div className="react-reveal" style={animationObj}>
          <h1 className="Start__Title_Thanks">
            {/* {parse(titleContent)} */}
            {"Finding product..."}
          </h1>
        </div>
      </div>
      <div className="react-reveal" style={animationObj}>
        <div className="common__Block_Thanks">
          <div className="react-reveal" style={animationObj}>
            <div className="Start__Text_Thanks">
              {"Thank you for sharing your answers. We hope you get well soon!"}
              {/* Answer a few questions and we'll find the best product for you, so
              you can find fast relief. */}
            </div>
          </div>

          <ProgressBar progress={progress} />
        </div>
      </div>
    </>
  );
};
export default ThanksValidation;
