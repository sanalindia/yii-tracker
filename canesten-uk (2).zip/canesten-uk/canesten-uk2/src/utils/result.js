import Male_Bg from "../assets/Images/male_bg.jpg";
import Male_Tiny from "../assets/Images/male_tiny.jpg";
import Female_bg from "../assets/Images/female_bg.jpg";
import Female_Tiny from "../assets/Images/female_tiny.jpg";
import Female2_bg from "../assets/Images/female2_bg.jpg";
import Female2_Tiny from "../assets/Images/female2_tiny.jpg";
import Female3_bg from "../assets/Images/female3_bg.jpg";
import Female3_Tiny from "../assets/Images/female3_tiny.jpg";

export default {
  getThanksValidationImage: (type, width) => {
    let image;
    switch (type) {
      case "Result_1": {
        image = Male_Tiny;
        if (width > 500) image = Male_Bg;
        return image;
        break;
      }
      case "Result_2": {
        image = Male_Tiny;
        if (width > 500) image = Male_Bg;
        return image;
        break;
      }
      case "Result_3": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_4": {
        image = Female_Tiny;
        if (width > 500) image = Female_bg;
        return image;
        break;
      }
      case "Result_5": {
        image = Female_Tiny;
        if (width > 500) image = Female_bg;
        return image;
        break;
      }
      case "Result_6": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_7": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_8": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_9": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_10": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_11": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_12": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_13": {
        image = Female2_Tiny;
        if (width > 500) image = Female2_bg;
        return image;
        break;
      }
      case "Result_14": {
        image = Female_Tiny;
        if (width > 500) image = Female_bg;
        return image;
        break;
      }
      default:
        return Male_Bg;
    }
  },
  fetchResult: (resultType) => {
    let data;
    switch (resultType) {
      case "Result_1": {
        data = {
          productDetails: {
            productName: "Thrush Duo",
            productDescription: "Oral Capsule & External Cream",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Duo_Oral-Capsule-External-Cream.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Canesten Thrush Duo Oral Capsule & External Cream is a very convenient, easy way to both calm the itch and clear the infection. The on-the-go single-dose oral capsule which contains fluconazole works from within to clear the thrush infection, while the double strength thrush cream* containing clotrimazole effectively calms the itch. The cream should be used 2 or 3 times a day until the symptoms disappear. Canesten Thrush Duo Oral Capsule & External Cream can also effectively help your partner if he is suffering from thrush. * compared to Canesten 1% Cream",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a single-dose oral capsule and a tube of external cream.<br>The capsule is to treat thrush at the site of infection and should be swallowed whole with a glass of water, with or without food.<br>The cream is to treat the itching and soreness of the vulva. The cream should be thinly and evenly applied to the area around the entrance of the vagina, 2-3 times a day and smoothed in gently. It should be used until the symptoms of the infection disappear.<br>The symptoms of thrush should disappear within two days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. To reduce the frequency of these attacks, your male partner’s penis can be treated with the cream to prevent re-infection, even if he has no symptoms of thrush.  You may also consider trying Canesflor which helps prevent recurrences of thrush or BV (bacterial vaginosis).<br>*compared to Canesten 1% Cream</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The oral capsule contains fluconazole and the active substance in the double strength external cream* is clotrimazole. Both are antifungal agents which fight fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Duo, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>Do not use this product if you are pregnant, trying for a baby or breast-feeding.<br>Consult your doctor or a pharmacist before use if you are taking any medication other than the contraceptive pill and if you are aged under 16 or over 60.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Duo.</p>",
            },
          ],
          dailyProducts: [],
        };
        return data;
        break;
      }
      case "Result_2": {
        data = {
          productDetails: {
            productName: "Thrush Oral Capsule",
            productDescription: "",
            buttonText: "FIND PHARMACY",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Oral-Capsule.png",
          },
          availableProduct: {
            header: "Thrush Duo",
            smallHeader: "Oral Capsule & External Cream",
            image: "Canesten_Thrush_Duo_Oral-Capsule-External-Cream.png",
            description:
              "Canesten Thrush Oral Capsule is available online with an external cream.",
            learnMoreLink: "Result_1",
          },
          textHead: "Thrush Oral Capsule",
          textDescription:
            "This is a convenient option that can treat your thrush with only one dose. All you need to do is swallow it whole with a glass of water. Your male partner can also use this treatment if he is suffering from thrush. Contains Fluconazole.",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The capsule should be swallowed whole with a glass of water. It can be taken with or without food.<br>The symptoms of thrush should disappear within two days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. In this case, you may also consider trying Canesflor which helps prevent recurrences of thrush or BV (bacterial vaginosis).</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The oral capsule contains fluconazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>Do not use this product if you are pregnant, trying for a baby or breast-feeding.<br>Consult your doctor or a pharmacist before use if you are taking any other medication and if you are aged under 16 or over 60.</p>",
            },
          ],
          dailyProducts: [],
        };
        return data;
        break;
      }
      case "Result_14": {
        data = {
          productDetails: {
            productName: "CanesOasis",
            productDescription: "Cystitis relief",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "CanesOasis_Cystitus-Relief.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "CanesOasis contains an active ingredient that reduces the acidity of your urine. This reduction of acidity level helps alleviate the stinging and pain that you experience when you urinate. CanesOasis is a two-day remedy which is quick and easy to use – for each dose you simply dissolve the powder from one sachet into a glass of water and drink. It’s available in great-tasting cranberry flavour. CanesOasis is available at pharmacies and in larger grocery stores. Remember if you suffer from frequent or severe cystitis, visit your doctor who will help you to determine your triggers and advise you on the best way to treat your infection.",
          toggleList: [
            {
              title: "What is it and what is it used for?",
              description:
                "<p>CanesOasis contains sodium citrate, which is used to relieve discomfort in urinary tract infections such as cystitis, by making the urine less acidic.<br>CanesOasis sachets are used for the relief of the symptoms of cystitis in women. Cystitis is an inflammation of the bladder, which causes painful irritation and an unpleasant burning sensation when passing water.</p>",
            },
            {
              title: "How to take?",
              description:
                "<p>Mix the contents of the sachet with a (200ml) glass of water and drink immediately. This is a 2-day course of treatment. Adult women: 1 sachet 3 times a day for 2 days, as required. This medicine is not to be used by men or children.<br>Do not exceed the stated dose. If symptoms persist or worsen after the 2-day course is completed, consult your doctor or pharmacist. Do not repeat the treatment without medical advice.</p>",
            },
            {
              title: "Possible side effects",
              description:
                "<p>Most people do not have any side effects while taking this medicine.<br>However, if you experience any side effects, or anything unusual happens, stop taking the medicine immediately, and see your doctor or pharmacist.</p>",
            },
            {
              title: "Pregnancy and breastfeeding",
              description:
                "<p>This medicine is not recommended if you are pregnant or breastfeeding. Please see your doctor or pharmacist before taking this medicine.<br>CanesOasis Cystitis Relief contains sodium citrate. Always read the label.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_12": {
        data = {
          productDetails: {
            productName: "Canesbalance Bacterial Vaginosis (BV) Vaginal Gel",
            productDescription: "",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesbalance_BV_Vaginal_Gel.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Canesbalance BV Gel is a triple benefit, 7-day treatment that relieves the symptoms of your BV infection. In just 3 days you can start to see a difference - it helps to regulate the pH balance which effectively relieves unpleasant odour and abnormal discharge, restricts growth of bad bacteria and supports good bacteria (lactobacillus). It’s easy to use, with our handy and hygienic squeeze tubes.",
          toggleList: [
            {
              title: "When to use?",
              description:
                "<p>Use Canesbalance to treat the symptoms of BV. It combats unpleasant odour, abnormal discharge and discomfort and restores pH to a normal level.</p>",
            },
            {
              title: "How to use?",
              description:
                "<p>Treatment: For effective relief from the symptoms of BV such as unpleasant odour, abnormal discharge and discomfort use 1 tube daily for 7 days.<br>Canesbalance comes in hygienic single use tube applicators. Twist off the end tab, sit or lie in a comfortable position and gently insert the neck of the applicator into the vagina as far as it will comfortably go. Gently squeeze the applicator to release the contents. Remove the tube, still squeezing, and discard. It is best to use Canesbalance at bedtime. It may be helpful to wear a panty liner as it is common to notice slight leakage. This does not mean the treatment has not worked.</p>",
            },
            {
              title: "Clinically tested",
              description:
                "<p>Clinical trials have shown that Canesbalance Vaginal Gel’s formulation is well tolerated and effective. It provides triple benefit as it effectively relieves unpleasant odour and abnormal discharge by restoring pH balance, inhibits the growth of bad bacteria and supports good bacteria (Lactobacillus) to restore the natural environment.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>Do not use if the end tab is broken off. Do not use if tube is past its expiry date. Keep out of the reach of children.</p>",
            },
            {
              title: "Caution",
              description:
                "<p>Avoid using Canesbalance if you are trying to conceive, as the gel has a low pH which can make the environment less suitable for sperm. Do not use as a contraceptive.</p>",
            },
            {
              title: "Usage during pregnancy and possible side effects",
              description:
                "<p>Canesbalance can be used during pregnancy and during menstruation. However, you should see your doctor if you think you may have a vaginal infection during pregnancy. Canesbalance may cause some stinging. This is only temporary and should ease over time. If you are concerned seek medical advice.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>Contact your doctor if your symptoms worsen, if you experience pain, if the discomfort does not cease, if your discharge is blood-stained or if your discharge occurs during the menopause. You should see your doctor if you think you may have a vaginal infection during pregnancy. If you experience no symptom relief after using Canesbalance as instructed, you should contact immediately your doctor for further advice. Please speak to your doctor for professional diagnosis of BV.</p>",
            },
            {
              title: "What does Canesbalance contain?",
              description:
                "<p>The pack contains 7 x 5 ml hygienic single-use applicators for one course of treatment.<br>Each applicator contains the following ingredients: Lactic acid, Glycogen, Propylene glycol, Methylhydroxypropyl cellulose, Sodium lactate, water, pH3.8.<br>Contains no preservatives.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_13": {
        data = {
          productDetails: {
            productName:
              "Canesbalance Bacterial Vaginosis (BV) Vaginal Pessaries",
            productDescription: "",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesbalance_Vaginal Pessaries.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Canesbalance BV Gel is a triple benefit, 7-day treatment that relieves the symptoms of your BV infection. In just 3 days you can start to see a difference - it helps to regulate the pH balance which effectively relieves unpleasant odour and abnormal discharge, restricts growth of bad bacteria and supports good bacteria (lactobacillus). It’s easy to use, with our handy and hygienic squeeze tubes.",
          toggleList: "",
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_3": {
        data = {
          productDetails: {
            productName: "Thrush Combi",
            productDescription: "Soft Gel Pessary & External Cream",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage:
              "Canesten_Thrush_Combi_Soft-Gel-Pessary-External-cream.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Designed for comfort, the single-dose soft gel pessary is easy to insert and effectively clears the thrush infection. The pack also contains a tube of double strength thrush cream* to be used externally to calm the symptoms such as itchiness and soreness. The cream should be used 2 or 3 times a day until the symptoms completely disappear. Contains Clotrimazole. * compared to Canesten 1% Cream",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a full course of treatment which consists of a single teardrop shaped vaginal capsule (a soft gel pessary) with applicator to treat the cause of vaginal thrush and one tube of double strength* cream to treat and soothe external thrush symptoms.<br>The soft gel pessary should be inserted as high as possible into the vagina with the help of the applicator, preferably before going to sleep at night for convenient and comfortable treatment.<br>The cream should be thinly and evenly applied to the area around the entrance of the vagina, 2-3 times a day and smoothed in gently. It should be used until the symptoms of the infection disappear.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you  may consider trying Canesflor which helps prevent recurrences of thrush.<br>*compared to Canesten 1% Cream</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance in Canesten Thrush Combi is Clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Combi, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Combi. Medicines can affect the unborn baby.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Combi.<br>Do not use tampons, intravaginal douches, spermicides or other vaginal products while using Canesten Thrush Combi.<br>Avoid vaginal intercourse while you have thrush and during treatment with Canesten Thrush Combi because your partner may become infected.<br>Do not use this product during your period as it may be less effective.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_4": {
        data = {
          productDetails: {
            productName: "Thrush Duo",
            productDescription: "Oral Capsule & External Cream",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Duo_Oral-Capsule-External-Cream.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Canesten Thrush Duo Oral Capsule & External Cream is a very convenient, easy way to both calm the itch and clear the infection. The on-the-go single-dose oral capsule which contains fluconazole works from within to clear the thrush infection, while the double strength thrush cream* containing clotrimazole effectively calms the itch. The cream should be used 2 or 3 times a day until the symptoms disappear. Canesten Thrush Duo Oral Capsule & External Cream can also effectively help your partner if he is suffering from thrush. * compared to Canesten 1% Cream",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a single-dose oral capsule and a tube of external cream.<br>The capsule is to treat thrush at the site of infection and should be swallowed whole with a glass of water, with or without food.<br>The cream is to treat the itching and soreness of the vulva. The cream should be thinly and evenly applied to the area around the entrance of the vagina, 2-3 times a day and smoothed in gently. It should be used until the symptoms of the infection disappear.<br>The symptoms of thrush should disappear within two days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. To reduce the frequency of these attacks, your male partner’s penis can be treated with the cream to prevent re-infection, even if he has no symptoms of thrush.  You may also consider trying Canesflor which helps prevent recurrences of thrush or BV (bacterial vaginosis).</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The oral capsule contains fluconazole and the active substance in the double strength external cream* is clotrimazole. Both are antifungal agents which fight fungal infections such as thrush.<br>*compared to Canesten 1% Cream</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Duo, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>Do not use this product if you are pregnant, trying for a baby or breast-feeding.<br>Consult your doctor or a pharmacist before use if you are taking any medication other than the contraceptive pill and if you are aged under 16 or over 60.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Duo.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_5": {
        data = {
          productDetails: {
            productName: "Thrush Oral Capsule",
            productDescription: "",
            buttonText: "FIND PHARMACY",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Oral-Capsule.png",
          },
          availableProduct: {
            header: "Thrush Duo",
            smallHeader: "Oral Capsule & External Cream",
            image: "Canesten_Thrush_Duo_Oral-Capsule-External-Cream.png",
            description:
              "Canesten Thrush Oral Capsule is available online with an external cream.",
            learnMoreLink: "Result_4",
          },
          textHead: "Thrush Oral Capsule",
          textDescription:
            "This is a convenient option that can treat your thrush with only one dose. All you need to do is swallow it whole with a glass of water. Your male partner can also use this treatment if he is suffering from thrush. Contains Fluconazole.",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The capsule should be swallowed whole with a glass of water. It can be taken with or without food.<br>The symptoms of thrush should disappear within two days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. In this case, you may also consider trying Canesflor which helps prevent recurrences of thrush or BV (bacterial vaginosis).</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The oral capsule contains fluconazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>Do not use this product if you are pregnant, trying for a baby or breast-feeding.<br>Consult your doctor or a pharmacist before use if you are taking any other medication and if you are aged under 16 or over 60.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_7": {
        data = {
          productDetails: {
            productName: "Thrush Soft Gel Pessary",
            productDescription: "",
            buttonText: "FIND PHARMACY",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Soft-Gel-Pessary.png",
          },
          availableProduct: {
            header: "Thrush Combi",
            smallHeader: "Soft Gel Pessary & External Cream",
            image: "Canesten_Thrush_Combi_Soft-Gel-Pessary-External-cream.png",
            description:
              "Canesten Thrush Soft Gel Pessary is available online with an external cream.",
            learnMoreLink: "Result_3",
          },
          textHead: "Thrush Soft Gel Pessary",
          textDescription:
            "To get rid of thrush you should treat the yeast infection from within. Canesten single-dose soft gel pessary is designed to be comfortable to insert and effectively treats the thrush infection at the source. Contains Clotrimazole.",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a single teardrop shaped vaginal capsule (a soft gel pessary) with applicator to treat the cause of vaginal thrush in one go. When suffering from the discomfort of thrush, you may find that you prefer a format like this, specially designed to be comfortable to insert. <br>The soft gel pessary should be inserted as high as possible into the vagina with the help of the applicator, preferably before going to sleep at night for convenient and comfortable treatment.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you may consider trying Canesflor which helps prevent recurrences of thrush.</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance in Canesten Thrush Soft Gel Pessary is Clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Soft Gel Pessary, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Soft Gel Pessary. Medicines can affect the unborn baby. Your doctor may recommend that you use the pessary without the help of an applicator.<br>As with other pessaries, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Soft Gel Pessary.<br>You should not use tampons, intravaginal douches, spermicides or other vaginal products while using Canesten Thrush Soft Gel Pessary.<br>It’s better that you avoid vaginal intercourse while you have thrush and during treatment with Canesten Thrush Soft Gel Pessary because your partner may become infected.<br>You should not use this product during your period as it may be less effective.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_8": {
        data = {
          productDetails: {
            productName: "Thrush Combi",
            productDescription: "Internal & External Creams",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Combi_Internal-External-Cream.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "This is a good option if you are looking for a treatment that works directly at the source of your thrush infection but you don’t feel comfortable using a pessary. The single-dose internal cream comes in a pre-filled and easy to use applicator. The pack also comes with double strength thrush cream* to treat your uncomfortable external symptoms. This option may be preferred by those suffering from vaginal dryness. Contains Clotrimazole * compared to Canesten 1% Cream",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a full course of treatment which consists of one pre-filled applicator with internal cream to treat the cause of vaginal thrush and one tube of double strength* soothing cream to treat the external thrush symptoms.<br>The internal cream should be inserted as high as possible into the vagina with the help of the applicator, as indicated in the product leaflet, preferably before going to sleep at night for convenient and comfortable treatment.<br>The external cream should be thinly and evenly applied to the area around the entrance of the vagina, 2-3 times a day and smoothed in gently. It should be used until the symptoms of the infection disappear.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you may consider trying Canesflor which helps prevent recurrences of thrush.<br>*compared to Canesten 1% Cream</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance in Canesten Thrush Combi is Clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Combi, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Combi. Medicines can affect the unborn baby. To treat internal thrush, your doctor may recommend that you use a treatment that can be inserted in the vagina without the help of an applicator, such as Canesten Thrush Combi  Pessary &amp; External Cream.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Combi.<br>Do not use tampons, intravaginal douches, spermicides or other vaginal products while using Canesten Thrush Combi.<br>Avoid vaginal intercourse while you have thrush and during treatment with Canesten Thrush Combi because your partner may become infected.<br>Do not use this product during your period as it may be less effective.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_9": {
        data = {
          productDetails: {
            productName: "Thrush",
            productDescription: "Internal Vaginal cream",
            buttonText: "FIND PHARMACY",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Internal-Cream.png",
          },
          availableProduct: {
            header: "Thrush Combi",
            smallHeader: "Internal & External Creams",
            image: "Canesten_Thrush_Combi_Internal-External-Cream.png",
            description:
              "Canesten Thrush Internal Vaginal cream is available online with an external cream",
            learnMoreLink: "Result_8",
          },
          textHead: "Thrush Internal Vaginal cream",
          textDescription:
            "If you would prefer not to use a pessary but want to treat the infection at the source, this may be a good option for you. Treat your thrush effectively with a single-dose of internal cream, supplied conveniently in a pre-filled applicator. Contains Clotrimazole.",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The internal cream should be inserted as high as possible into the vagina with the help of the applicator, as indicated in the product leaflet, preferably before going to sleep at night for convenient and comfortable treatment.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you may consider trying Canesflor which helps prevent recurrences of thrush.</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance is clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Internal Cream. Medicines can affect the unborn baby. To treat internal thrush, your doctor may recommend that you use a treatment that can be inserted in the vagina without the help of an applicator, such as Canesten Thrush Combi  Pessary &amp; External Cream.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after treatment.<br>You should not use tampons, intravaginal douches, spermicides or other vaginal products during the treatment. Also, it’s better that you avoid vaginal intercourse while you have thrush and during treatment because your partner may become infected.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_10": {
        data = {
          productDetails: {
            productName: "Thrush Combi",
            productDescription: "Pessary & External Cream",
            buttonText: "BUY NOW",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Combi_Pessary-External-Cream.png",
          },
          availableProduct: "",
          textHead: "",
          textDescription:
            "Our classic combi pack includes a traditional pessary to treat your internal infection at the source, and a tube of double strength thrush cream* to relieve your irritating symptoms. Contains Clotrimazole. * compared to Canesten 1% Cream",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a full course of treatment which consists of a single pessary with applicator to treat the cause of vaginal thrush and one tube of double strength* cream to treat and soothe external thrush symptoms.<br>The pessary should be inserted as high as possible into the vagina with the help of the applicator, preferably before going to sleep at night for convenient and comfortable treatment.<br>The cream should be thinly and evenly applied to the area around the entrance of the vagina, 2-3 times a day and smoothed in gently. It should be used until the symptoms of the infection disappear.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you may consider trying Canesflor which helps prevent recurrences of thrush.<br>*compared to Canesten 1% Cream</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance in Canesten Thrush Combi is Clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days since you started using Canesten Thrush Combi, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Combi. Medicines can affect the unborn baby. To treat internal thrush, your doctor may recommend that you use the Pessary without the help of an applicator.<br>As with other creams, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Combi.<br>Do not use tampons, intravaginal douches, spermicides or other vaginal products while using Canesten Thrush Combi.<br>Avoid vaginal intercourse while you have thrush and during treatment with Canesten Thrush Combi because your partner may become infected.<br>Do not use this product during your period as it may be less effective.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      case "Result_11": {
        data = {
          productDetails: {
            productName: "Thrush Pessary",
            productDescription: "",
            buttonText: "FIND PHARMACY",
            buyNowUrl: "",
            productImage: "Canesten_Thrush_Pessary.png",
          },
          availableProduct: {
            header: "Thrush Combi",
            smallHeader: "Pessary & External Cream",
            image: "Canesten_Thrush_Combi_Pessary-External-Cream.png",
            description:
              "Canesten Thrush Pessary is available online with an external cream.",
            learnMoreLink: "Result_10",
          },
          textHead: "Thrush Pessary",
          textDescription:
            "This is another convenient, single dose thrush treatment which works right at the site of the infection. Contains Clotrimazole.",
          toggleList: [
            {
              title: "How to use?",
              description:
                "<p>The pack contains a single pessary with applicator to treat the cause of vaginal thrush in one go. <br>The pessary should be inserted as high as possible into the vagina with the help of the applicator, preferably before going to sleep at night for convenient and comfortable treatment.<br>The symptoms of thrush should disappear within three days of treatment.<br>Some of us, though, suffer from recurrent attacks of thrush. If that is also your case, you may consider trying Canesflor which helps prevent recurrences of thrush.</p>",
            },
            {
              title: "What does it contain?",
              description:
                "<p>The active substance in Canesten Thrush Pessary is Clotrimazole, an antifungal agent which fights fungal infections such as thrush.</p>",
            },
            {
              title: "When should you see your doctor?",
              description:
                "<p>If you see no improvement after seven days, you should tell your doctor. Also, if you have had more than two thrush infections within six months, you should talk to your doctor about it.</p>",
            },
            {
              title: "Warnings",
              description:
                "<p>You should only use this product if you have been previously diagnosed by your doctor as having thrush.<br>If you are pregnant or trying for a baby, tell your doctor or midwife before using Canesten Thrush Pessary. Medicines can affect the unborn baby. Your doctor may recommend that you use the pessary without the help of an applicator.<br>As with other pessaries, this product may reduce the effectiveness of rubber contraceptives, such as condoms or diaphragms.  That is why it is better that you use alternative precautions for at least five days after using Canesten Thrush Pessary.<br>You should not use tampons, intravaginal douches, spermicides or other vaginal products while using Canesten Thrush Pessary.<br>It’s better that you avoid vaginal intercourse while you have thrush and during the treatment because your partner may become infected.<br>You should not use this product during your period as it may be less effective.</p>",
            },
          ],
          dailyProducts: [
            {
              title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
              description:
                "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
              image: "CanesFresh_Feminine Wash.png",
            },
            {
              title: "Canesflor Probiotics<b> for Vaginal Use </b>",
              description:
                "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
              image: "Canesflor_Probiotics.png",
            },
          ],
        };
        return data;
        break;
      }
      default:
    }
  },
};
