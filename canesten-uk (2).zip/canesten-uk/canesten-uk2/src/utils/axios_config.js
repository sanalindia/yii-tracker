import axios from "axios";
import {Constants} from "./constants";

const baseURL = Constants.BASE_URL;

const apiClient = axios.create({ baseURL });

const { post } = apiClient;

export { post};