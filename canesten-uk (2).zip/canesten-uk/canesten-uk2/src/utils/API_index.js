import API_Calls from "./API_calls";

export const API_Call = API_Calls;