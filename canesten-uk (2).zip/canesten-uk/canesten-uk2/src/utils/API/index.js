import cases from "./cases-prod";

export const Cases = cases;
