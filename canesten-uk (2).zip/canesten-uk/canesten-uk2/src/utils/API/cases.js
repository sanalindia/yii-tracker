import { get } from "./config";
import Utility from "../utility";

export default {
  findQuiz: async () => {
    const response = await get("jsonapi_ssp/node/quiz/index.json");
    let quizID = response.data.data[1].id;
    return quizID;
  },
  getQuiz: async (quizID) => {
    let quizData = [];
    const response = await get(`jsonapi_ssp/node/quiz/${quizID}.json`);
    const quiz = response.data;
    quizData.push(quiz.data.attributes.title);
    quizData.push(quiz.data.attributes.field_disclaimer.value);
    let field_references =
      quiz.data.attributes.field_references &&
      quiz.data.attributes.field_references.value
        ? quiz.data.attributes.field_references.value
        : "";
    // let field_references = quiz.data.attributes.field_references
    //   ? Utility.jsonStringToObj(quiz.data.attributes.field_references.value)
    //   : "";
    let field_instruction =
      typeof quiz.data.attributes.field_instruction !== "undefined" &&
      quiz.data.attributes.field_instruction
        ? quiz.data.attributes.field_instruction.value
        : "";
    quizData.push(field_references);

    quizData.push(field_instruction);
    return quizData;
  },
  getQuizQuestions: async (quizID) => {
    const response = await get(`jsonapi_ssp/node/question/index.json`);
    let questions = response.data.included;
    let quesIDs = [];
    for (let question of questions) {
      let field_instruction =
        question.attributes.field_instruction &&
        question.attributes.field_instruction.value
          ? question.attributes.field_instruction.value
          : "";
      let field_explanation =
        question.attributes.field_explanation &&
        question.attributes.field_explanation.value
          ? question.attributes.field_explanation.value
          : "";

      quesIDs.push({
        id: question.id,
        title: question.attributes.title,
        field_instruction: field_instruction,
        field_explanation: field_explanation,
      });
    }
    return quesIDs;
  },
  getAnswers4Question: async (qID) => {
    const response = await get(
      `/jsonapi_ssp/node/question/answers/${qID}.json`
    );
    let ansObj = response.data.included;
    let ansOp = [];
    ansOp = ansObj.map((answer) => {
      let field_answer_summary =
        answer.attributes.field_answer_summary &&
        answer.attributes.field_answer_summary.value
          ? answer.attributes.field_answer_summary.value
          : "";
      return [answer.id, answer.attributes.title, field_answer_summary];
    });

    return ansOp;
  },
  getActions4QUestion: async (qID) => {
    const response = await get(
      `/jsonapi_ssp/node/question/actions/${qID}.json`
    );
    let actObj = response.data.included;
    let actOp = actObj.map((action) => action.attributes.name);

    return actOp;
  },
  getResults: async () => {
    const response = await get(`/jsonapi_ssp/node/result/index.json`);
    let results = response.data.data;

    let resultSet = [];

    for (let result of results) {
      resultSet.push([
        result.attributes.title,
        result.attributes.field_instruction.value,
        Utility.jsonStringToObj(result.attributes.field_references.value),
      ]);
    }

    return resultSet;
  },
};
