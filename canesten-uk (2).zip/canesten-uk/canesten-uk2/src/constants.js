// 1b12fb45-2c79-42dd-87ae-09d6dbaf93e9 =>  "Are you suffering from itching?",
// 	a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6 => YES
// 	c00c2f96-d2d5-40c0-911a-aee59a5d3199 => NO

// 2ef46d88-9971-40c3-9fef-89d8a45b401a => What format would you prefer?
// 	0f3d0043-5efd-4fd6-ab38-988ba6484fcd = >EASY INSERT SOFT GEL
// 	d57b3f8b-b0de-4387-9c21-959cb1ae45a0 => SOOTHING VAGINAL CREAM
// 	2f1dba46-6250-439f-be37-007b735e5627 => VAGINAL TABLET

// 82d49ade-1e56-40a1-bd16-dd997e1ce1bc => Do you prefer an oral or a vaginal treatment?
// 	4211e4d6-ca1e-4440-8e60-bf2af064b67b => "ORAL",
// 	8d64b717-3736-4e2d-97b8-7cf36c7ad1da => VAGINAL

// 7613ca6f-1459-4426-9f3c-a5916121c058 => Are you male or female?
// 	7529905e-52ca-40d9-9606-f684bbf616bc => MALE
// 	433b3af0-eb08-4ca9-a75f-d05c4de5636b => FEMALE

// a79cca53-edab-4e55-937f-7a11be655a9b => Are you searching for a product for
// 	74d382c1-bbcc-44c7-ad4d-6e149d9cd0a2 => THRUSH
// 	5046ab7d-b8bb-40be-b131-14ea1f4870e3 => BACTERIAL VAGINOSIS (BV)
// 	1c8da33e-35db-4b1b-8179-e5d8e6a25da3 => CYSTITIS

// cce5728e-2922-444b-bb3a-d87eeea4d99f => Are you pregnant?
// 	fa32b062-5f44-436e-a874-80b616284271 => YES
// 	5bfd7119-6c64-4391-bff4-c00a8a45a523 => NO

// d0e11505-48ed-4d3a-9e5d-b489845b19f0 => What format would you prefer?
// 	9bc559a5-590c-42cd-96f2-828ee062f83e => VAGINAL GEL
// 	5d6aedb7-8f70-42dc-87c3-230a236c8b1d => VAGINAL PESSARY

export const Constants = {
  q1: "7613ca6f-1459-4426-9f3c-a5916121c058",
  q2: "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
  q3: "a79cca53-edab-4e55-937f-7a11be655a9b",
  q4: "cce5728e-2922-444b-bb3a-d87eeea4d99f",
  q5: "d0e11505-48ed-4d3a-9e5d-b489845b19f0",
  q6: "2ef46d88-9971-40c3-9fef-89d8a45b401a",
  q7: "82d49ade-1e56-40a1-bd16-dd997e1ce1bc",

  questionMappingArray: {
    // "Are you male or female?",
    "7613ca6f-1459-4426-9f3c-a5916121c058": {
      // Male
      "7529905e-52ca-40d9-9606-f684bbf616bc":
        "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
      //Female
      "433b3af0-eb08-4ca9-a75f-d05c4de5636b":
        "a79cca53-edab-4e55-937f-7a11be655a9b",
    },
    //Are you suffering from itching?
    "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9": {
      // yes
      "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "",
      //No
      "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "",
    },
    //"Are you searching for product?"
    "a79cca53-edab-4e55-937f-7a11be655a9b": {
      //thrush
      "74d382c1-bbcc-44c7-ad4d-6e149d9cd0a2":
        "cce5728e-2922-444b-bb3a-d87eeea4d99f",
      //BACTERIAL VAGINOSIS (BV)
      "5046ab7d-b8bb-40be-b131-14ea1f4870e3":
        "d0e11505-48ed-4d3a-9e5d-b489845b19f0",
      //CYSTITIS
      "1c8da33e-35db-4b1b-8179-e5d8e6a25da3": "",
    },
    //"Are you pregnant?"
    "cce5728e-2922-444b-bb3a-d87eeea4d99f": {
      //Yes
      "fa32b062-5f44-436e-a874-80b616284271": "",
      //No
      "5bfd7119-6c64-4391-bff4-c00a8a45a523":
        "82d49ade-1e56-40a1-bd16-dd997e1ce1bc",
    },
    //What format would you prefer?
    "d0e11505-48ed-4d3a-9e5d-b489845b19f0": {
      //VAGINAL GEL
      "9bc559a5-590c-42cd-96f2-828ee062f83e": "",
      //VAGINAL PESSARY
      "5d6aedb7-8f70-42dc-87c3-230a236c8b1d": "",
    },
    //What format would you prefer?
    "2ef46d88-9971-40c3-9fef-89d8a45b401a": {
      //EASY INSERT SOFT GEL
      "0f3d0043-5efd-4fd6-ab38-988ba6484fcd":
        "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
      //SOOTHING VAGINAL CREAM
      "d57b3f8b-b0de-4387-9c21-959cb1ae45a0":
        "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
      //VAGINAL TABLET
      "2f1dba46-6250-439f-be37-007b735e5627":
        "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
    },
    //Do you prefer an oral or a vaginal treatment?
    "82d49ade-1e56-40a1-bd16-dd997e1ce1bc": {
      //ORAL
      "4211e4d6-ca1e-4440-8e60-bf2af064b67b":
        "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
      //VAGINAL
      "8d64b717-3736-4e2d-97b8-7cf36c7ad1da":
        "2ef46d88-9971-40c3-9fef-89d8a45b401a",
    },
  },

  ResultMappingArray: {
    // Male
    "7529905e-52ca-40d9-9606-f684bbf616bc": {
      // yes
      "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_1",
      //No
      "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_2",
    },
    //Female
    "433b3af0-eb08-4ca9-a75f-d05c4de5636b": {
      //thrush
      "74d382c1-bbcc-44c7-ad4d-6e149d9cd0a2": {
        //Yes
        "fa32b062-5f44-436e-a874-80b616284271": "Result_3",
        //No
        "5bfd7119-6c64-4391-bff4-c00a8a45a523": {
          //ORAL
          "4211e4d6-ca1e-4440-8e60-bf2af064b67b": {
            //yes
            "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_4",
            //No
            "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_5",
          },
          //VAGINAL
          "8d64b717-3736-4e2d-97b8-7cf36c7ad1da": {
            //EASY INSERT SOFT GEL
            "0f3d0043-5efd-4fd6-ab38-988ba6484fcd": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_3",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_7",
            },
            //SOOTHING VAGINAL CREAM
            "d57b3f8b-b0de-4387-9c21-959cb1ae45a0": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_8",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_9",
            },
            //VAGINAL TABLET
            "2f1dba46-6250-439f-be37-007b735e5627": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_10",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_11",
            },
          },
        },
      },
      //BACTERIAL VAGINOSIS (BV)
      "5046ab7d-b8bb-40be-b131-14ea1f4870e3": {
        //VAGINAL GEL
        "9bc559a5-590c-42cd-96f2-828ee062f83e": "Result_12",
        //VAGINAL PESSARY
        "5d6aedb7-8f70-42dc-87c3-230a236c8b1d": "Result_13",
      },
      //CYSTITIS
      "1c8da33e-35db-4b1b-8179-e5d8e6a25da3": "Result_14",
    },
    // male: {
    //   yes: "Result_1",
    //   no: "Result_2",
    // },
    // female: {
    //   trush: {
    //     yes: "Result_3",
    //     no: {
    //       oral: {
    //         yes: "Result_4",
    //         no: "Result_5",
    //       },
    //       vaginal: {
    //         EASY_INSERT_SOFT_GEL: {
    //           yes: "Result_6",
    //           no: "Result_7",
    //         },
    //         SOOTHING_VAGINAL_CREAM: { yes: "Result_8", no: "Result_9" },
    //         VAGINAL_TABLET: { yes: "Result_10", no: "Result_11" },
    //       },
    //     },
    //   },
    //   BACTERIAL_VAGINOSIS: {
    //     VAGINAL_GEL: "Result_12",
    //     VAGINAL_PESSARY: "Result_13",
    //   },
    //   CYSTITIS: "Result_14",
    // },
  },

  fieldExplanationMapping: {
    "4211e4d6-ca1e-4440-8e60-bf2af064b67b":
      "Whilst the oral capsule will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "2f1dba46-6250-439f-be37-007b735e5627":
      "Whilst the vaginal tablet will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "d57b3f8b-b0de-4387-9c21-959cb1ae45a0":
      "Whilst the vaginal cream will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "0f3d0043-5efd-4fd6-ab38-988ba6484fcd":
      "Whilst the soft gel will treat the infection, itching & external discomfort can be calmed via an external cream.",
  },

  DISCLAIMER:
    "<p>Dieser Online-Test dient ausschliesslich zu Ihrer Information. Der Test ersetzt in keinem Fall eine Beratung durch eine Fachperson, sondern gibt lediglich eine Hilfestellung entsprechend Ihrer subjektiv empfundenen Beschwerden. Ihre Apotheke oder Drogerie wird Sie hierzu gerne beraten. </p>",
  ANSWERS: [2, 1, 3, 2, 1],
  QUESTIONS_COUNT: 5,
  de: {
    correct: "RICHTIG",
    incorrect: "FALSCH",
    question: "Question",
    your_answer: "Ihre Antwort",
    correct_answer: "Richtige Antwort",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },

  fr: {
    correct: "VRAI",
    incorrect: "FAUX",
    question: "Question",
    your_answer: "Votre réponse",
    correct_answer: "Réponse correcte",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },
};
