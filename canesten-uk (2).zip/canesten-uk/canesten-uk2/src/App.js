import React from "react";
import "./App.css";
import "./css/components/style.scss";
import Bg from "./assets/Images/female_bg.jpg";
import QuizContainer from "./components/QuizContainer";
// import TagManager from "react-gtm-module";
// const tagManagerArgs = {
//   gtmId: "GTM-M59RR8K",
// };
// TagManager.initialize(tagManagerArgs);
/*
 *Component Imports
 */

function App() {
  return (
    <div id="mainWrapper">
      <QuizContainer />
    </div>
  );
}

export default App;
