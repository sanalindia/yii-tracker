import mysql from "mysql";
var connection = mysql.createConnection({
  host: "localhost", //'SG-SQLCluster-25-master.devservers.scalegrid.io',
  user: "root",
  password: "password",
  database: "test",
  port: 3306,
});
connection.connect(function (err) {
  if (err) throw err;
  console.log("Connected!");
});
