import 'react-app-polyfill/ie11';
import "react-app-polyfill/stable";

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { AppRouter } from './src/Scenes/AppRouter';
import './i18n';

const createReactDOMStyle = require('react-native-web/dist/exports/StyleSheet/createReactDOMStyle.js')

const original = createReactDOMStyle.default
createReactDOMStyle.default = style => {
  const resolved = original(style)
  if (resolved.flexBasis === '0%') {
    resolved.flexBasis = 'auto'
  }
  return resolved
}

export default function App() {
  return (
    <View style={styles.container}>
      
      <AppRouter/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    // display:'flex',
    // flex: 1,
    width:'100%',
    height:'100%',
    backgroundImage: 'linear-gradient(#12c9b3, #12c9b3)',
    backgroundRepeat: '',
    backgroundSize: 'auto',
    // alignItems: 'center',
    // justifyContent: 'flex-start',
    // width: '100%'
  },
 
  
});
