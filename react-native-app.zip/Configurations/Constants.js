export const BASE_URL = "http://10.19.1.76:9091/v1/symptom/mapping"
// export const BASE_URL = "http://c42c8018.ngrok.io/v1/symptom/mapping"