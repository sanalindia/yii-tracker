import Colors from "../res/Colors";
export const H1_STYLE = {
    color:Colors.gray,
    fontSize:50,
    textAlign:'center',
    fontWeight:'300'
}

export const H2_STYLE = {
    color:Colors.gray,
    fontSize:30,
    textAlign:'center',
    fontWeight:'500'
}

export const H3_Bold_STYLE = {
    color:Colors.gray,
    fontSize:25,
    fontWeight:'bold'
}

export const H3_STYLE = {
    color:Colors.gray,
    fontSize:25,
    fontWeight:'400'
}

export const H4_STYLE = {
    color:Colors.gray,
    fontSize:15,
    fontWeight:'400'
}

export const H4_Bold_STYLE = {
    color:Colors.gray,
    fontSize:15,
    fontWeight:'bold'
}


export const IMAGE_STYLE = {
    flex:1, 
    height:undefined, 
    width:undefined
}
