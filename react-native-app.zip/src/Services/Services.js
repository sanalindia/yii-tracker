import axios from "axios";
import { Alert } from "react-native";

export const getData = (requestFor,params)=>{
    const header = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    var postData={...params}
    //postData=JSON.stringify(postData)
    return new Promise((resolve, reject) => {
        // const url = 'http://3.14.251.74:6006/health/cvd/calculateRisk'
        //const url = 'http://3.14.251.74:6200/health/cvd/calculateRisk'
        const url = 'https://heartageriskcalc.com/health/cvd/calculateRisk'
        
        axios.post(url,postData,header)
        .then((res) => {
            console.log('res'+res);
            
            resolve(res.data)
        })
        .catch((err)=>{
            console.log('err'+err);
            showAlert()
            reject(err)
        })
    })

} 
const showAlert = () => {
    Alert.alert(
        'Error',
        'Network error',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed')},
        ],
        {cancelable: false},
      )
}