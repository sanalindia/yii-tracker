import axios from "axios";
import { Alert } from "react-native";
export const getService = (reqUrl ) => {
    const header = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    
    //postData=JSON.stringify(postData)
    return new Promise((resolve, reject) => {
        const url = reqUrl;

        
        axios.get(url)
        .then((res) => {
            console.log('res'+res);
            
            resolve(res.data)
        })
        .catch((err)=>{
            console.log('err'+err);
            showAlert()
            reject(err)
        })
    })
}

const showAlert = () => {
    Alert.alert(
        'Error',
        'Network error',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed')},
        ],
        {cancelable: false},
      )
}