import React, { Component } from "react";
import { StyleSheet, View, Dimensions, Text } from "react-native";
import { HeaderComp } from "../Views";
import { ContentComp } from "../Views";
import { HeaderCompMobile } from "../Views";
import { FooterComp } from "../Views";
import { ContentCompMobile } from "../Views";
import { withTranslation } from "react-i18next";
import Geolocation from "@react-native-community/geolocation";
import "@expo/match-media";
import { useMediaQuery } from "react-responsive";
import MediaQuery from "react-responsive";
import { withResizeDetector } from "react-resize-detector/build/withPolyfill";

class HomeScene extends Component {
  constructor(props) {
    super(props);
    parent.dataLayer = parent.dataLayer || [];
    parent.dataLayer.push({
      event: "gaGenericEvent",
      eventCategory: "Form",
      eventAction: "Start",
      eventLabel: "Test del Corazón",
    });
  }

  componentDidUpdate(prevProps) {
    const { height } = this.props;

    if (height !== prevProps.height) {
      if (window.parent.document.getElementById("iFrameResizer0")) {
        window.parent.document.getElementById("iFrameResizer0").height =
          document.getElementById("root").offsetHeight;
      }
    }
  }

  render() {
    const { t, i18n } = this.props;

    const screenWidth = Math.round(Dimensions.get("window").width);
    const isTabletOrMobileDevice = screenWidth > 702 ? true : false;
    sessionStorage.clear();

    return (
      <View>
        <MediaQuery minDeviceWidth={721}>
          <View
            style={{
              width: "100%",
              backgroundImage: "linear-gradient(#078182, #12c9b3)",
              // backgroundColor: 'green',
              backgroundRepeat: "",
              backgroundSize: "auto",
            }}
          >
            <HeaderComp style={styles.header} screenProps={{ t, i18n }} />
            <View style={styles.contentContainer}>
              <ContentComp screenProps={{ t, i18n }}></ContentComp>
            </View>
            <FooterComp
              screenProps={{ t, i18n }}
              screen="homeScreen"
            ></FooterComp>
          </View>
        </MediaQuery>
        <MediaQuery maxDeviceWidth={720}>
          <View
            style={{
              width: "100%",
              backgroundImage: "linear-gradient(#078182, #12c9b3)",
              // backgroundColor: 'green',
              backgroundRepeat: "",
              backgroundSize: "auto",
            }}
          >
            <HeaderCompMobile
              style={styles.header}
              screenProps={{
                t,
                i18n,
              }}
            />
            <View style={styles.contentContainer}>
              <ContentCompMobile
                screenProps={{
                  t,
                  i18n,
                }}
              ></ContentCompMobile>
            </View>
            <FooterComp
              screenProps={{ t, i18n }}
              screen="homeScreen"
            ></FooterComp>
          </View>
        </MediaQuery>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  contentContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    margin: "auto",
  },
});
// export default HomeScene;
const firstHOC = withResizeDetector(HomeScene);

export default withTranslation()(firstHOC);
