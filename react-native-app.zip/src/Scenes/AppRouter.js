import React from 'react'
import { Router, Stack, Scene } from 'react-native-router-flux'
import HomeScene from './HomeScene'
import ResultDisplayScene from './ResultDisplayScene'
const TabIcon = ({
    params,
}) => (
        <View>
            <Text></Text>
        </View>
    );
export const AppRouter = () => {
    return (
        <Router>
            <Stack key="root" >
                <Scene key="home" navigationBarStyle={{ display: 'none' }}  component={HomeScene}></Scene>
                <Scene key="resultDisplay" component={ResultDisplayScene}
                    navigationBarStyle={{ display: 'none' }}

                > </Scene>
            </Stack>
        </Router>
    )

}