import React from 'react';
import { ReportViewList } from '../Views';
import {
	Document,
	Page,
	Text,
	View,
	StyleSheet
} from '@react-pdf/renderer';

// Create styles
const styles = StyleSheet.create({
	page: {
		flexDirection: 'row',
		backgroundColor: '#E4E4E4',
		marginTop:'0px',
	},
	section: {
		margin: 10,
		padding: 10,
		flexGrow: 1
	},
	mainContentStyle: {
		
		color: '#979797',
		
	},
	aboutYouBlock:{width:'180px',marginTop:'10px',flexDirection:'row',marginRight:'10px'},
	aboutYouBlockText:{width:'60%',fontSize:11,fontFamily:'amiri'},
	aboutYouBlockVal:{width:'40%',fontSize:10,fontFamily:'amiri'},
	dispBlock:{display:'block'},
	disNone:{display:'none'},
	reportLine:{
		marginTop:'10px'
	}
});

// Create Document Component
const PdfDocument = (data) =>
 {
	 const { t, i18n } = data.screenProps;
	 let riskVal = data.pdfDocumentData.heartRisk;
	 let risk= riskVal < 5 ? t('veryLowRisk') 
                    : riskVal >= 5 && riskVal < 10 ? t('lowRisk')
                    : riskVal >= 10 && riskVal< 20 ? t('moderateRisk')
                    : riskVal >=20 && riskVal < 30 ? t('highRisk')
					: riskVal >=30  ? t('veryHighRisk') :'';
	let riskColor= riskVal < 5 ? "#3CDD03" 
        :  riskVal >= 5 && riskVal < 10  ? '#D9CB05'
        : riskVal >= 10 && riskVal< 20 ?'#E67C1D'
        : riskVal >=20 && riskVal < 30 ?'#F72779'
        : riskVal >=30  ?'#BF1010':''
	 
	 return (
	<Document>
		<Page size="A4" style={styles.page}>
			
					<View style={{ display:'flex',flexDirection: 'Column', margin:'20px,20px,20px,20px'}}>
						<View style={{justifyContent:'center',fontSize:20}}><Text style={{margin:'auto',fontFamily:'amiri'}}>{t('detailedReport')} </Text></View>
						<View style={{ flexDirection: 'column',marginTop:'24px'}}>
							<View><Text style={{fontSize:15,width:'120px',fontFamily:'amiri'}}>{t('aboutYou')} :</Text></View>
							<View style={{ flexDirection: 'row',marginTop:'10px',marginLeft:'10px'}}>
								<View style={styles.aboutYouBlock}>
									<Text style={[styles.aboutYouBlockText,{fontFamily:'amiri'}]}>{t('gender')}  </Text>
									<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.gender=='F'?t('female'):t('male')}</Text>
								</View>
								<View style={styles.aboutYouBlock}>
									<Text style={[styles.aboutYouBlockText,{fontFamily:'amiri'}]}>{t('age')}  </Text>
									{/* <Text style={styles.aboutYouBlockText}>Age : </Text> */}
									<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.age}</Text>
								</View>
								<View style={styles.aboutYouBlock}>
									<Text style={[styles.aboutYouBlockText,{fontFamily:'amiri'}]}>{t('height')}  </Text>
									{data.pdfDocumentData.unitHeight=='cm'?
										<Text style={styles.aboutYouBlockVal}>
											{data.pdfDocumentData.height} {t('cm')}
										</Text>:
										<Text style={styles.aboutYouBlockVal}>
											{data.pdfDocumentData.height}' {data.pdfDocumentData.heightinch}"
										</Text>
									}
								</View>
							</View>
							<View style={{ flexDirection: 'row',marginLeft:'10px'}}>
								<View style={styles.aboutYouBlock}>
									<Text style={[styles.aboutYouBlockText,{fontFamily:'amiri'}]}>{t('weight')}  </Text>
	 								<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.weight} {data.pdfDocumentData.unitWeight=='kg'?t('kg'):t('lbs')}</Text>
								</View>
							</View>
							<View style={{ flexDirection: 'row',marginLeft:'10px',marginTop:'10px',marginRight:'5px'}}>
								<View style={styles.aboutYouBlock}>
									<Text style={[styles.aboutYouBlockText,{paddingRight:'5px'}]}>{t('bloodPressure')}: </Text>
	 								<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.bp}{ t('mmHg')}</Text>
								</View>
								<View style={styles.aboutYouBlock}>
									<Text style={styles.aboutYouBlockText}>{t('treatmentForHypertension')} : </Text>
									<Text style={[styles.aboutYouBlockVal]}>{data.pdfDocumentData.hypertension=='1'? t('yes') : t('no')}</Text>
								</View>
								<View style={styles.aboutYouBlock}>
									<Text style={styles.aboutYouBlockText}>{t('diabetes')} : </Text>
									<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.diabetic=='Y'? t('yes') : t('no')}</Text>
								</View>
							</View>
							<View style={{ flexDirection: 'row',marginLeft:'10px',marginTop:'10px'}}>
								<View style={styles.aboutYouBlock}>
									<Text style={styles.aboutYouBlockText}>{t('totalCholestrol')}: </Text>
	 								<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.cholestrol }{data.pdfDocumentData.cholestrolUnit=='mg/dl'?t('mgdl'):t('mmoll')}</Text>
								</View>
								<View style={styles.aboutYouBlock}>
									<Text style={styles.aboutYouBlockText}>{t('smoking')} : </Text>
									<Text style={styles.aboutYouBlockVal}>{data.pdfDocumentData.smoker=='Y'? t('yes') : t('no')}</Text>
								</View>
								
							</View>
						</View>
						{/* section Result */}
						<View style={{ flexDirection: 'Column',marginTop:'24px'}}>
							<View><Text style={{fontSize:15,width:'200px',fontFamily:'amiri'}}>{t('concludedReport')}: </Text></View>
							<View style={{ width: '100%' ,marginTop:'15px',marginLeft:'10px'}}>
                                <View style={{ flexDirection: 'row'}}>
                                    <View style={{ flexDirection: 'column' }}>
                                        <Text style={{ color: '#50cb13',fontSize:12,fontFamily:'amiri' }}> {t('actualAge')}</Text>
                                        <Text style={{ color: '#50cb13',fontSize:10,fontFamily:'amiri' }}> {data.pdfDocumentData.age}</Text>
                                    </View>
                                    <View style={{ flexDirection: 'column', marginLeft:'15px' }}>
                                        <Text style={{ color: '#ed750e',fontSize:12,fontFamily:'amiri'}}> {t('heartAge')}</Text>
                                        <Text style={{ color: '#ed750e' ,fontSize:10,fontFamily:'amiri'}}>{data.pdfDocumentData.heartAge} </Text>
                                    </View>
									<View style={{ flexDirection: 'column', marginLeft:'15px'  }}>
                                        <Text style={{ color: '#ed750e',fontSize:12,fontFamily:'amiri' }}>
                                            {t('riscLevel')}
                                    	</Text>
                                        <Text style={{ color: riskColor,fontSize:10,fontFamily:'amiri' }}>
                                            {data.pdfDocumentData.heartRisk ? risk:' - '} 
                                    	</Text>
                                    </View>
                                </View>
                                <View >
                                    <Text style={[styles.mainContentStyle, { marginTop: '10px',fontSize:12,fontFamily:'amiri'}]}>{t('healthyHeartQuote')}</Text>
                                </View>
                                
                            </View>
							<View style={{marginTop:'10px',marginLeft:'10px'}}>
	 							<View style={[data.pdfDocumentData.addInfo.heartAgeLead?styles.dispBlock:styles.disNone,styles.reportLine]}>
									 <Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartAgeLead}</Text>
								</View>
								<View style={[data.pdfDocumentData.addInfo.heartAgeRiskInfo0?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartAgeRiskInfo0}</Text>
								</View>
								<View style={[data.pdfDocumentData.addInfo.heartAgeRiskInfo1?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartAgeRiskInfo1}</Text>
								</View>
								<View style={[data.pdfDocumentData.addInfo.heartAgeSmoking?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartAgeSmoking}</Text>
								</View>
								<View style={[data.pdfDocumentData.addInfo.heartageBmi?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartageBmi}</Text>
								</View>

								<View style={[data.pdfDocumentData.addInfo.heartageBp?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.heartageBp}</Text>
								</View>
								<View style={[data.pdfDocumentData.addInfo.bloodCholestrol?styles.dispBlock:styles.disNone,styles.reportLine]}>
									<Text style={{fontSize:11,fontFamily:'amiri'}}>{data.pdfDocumentData.addInfo.bloodCholestrol}</Text>
								</View>
								<View>
                                    <Text style={[{marginTop: '10px',fontSize:11,fontFamily:'amiri'}]}>
                                        {data.pdfDocumentData.addInfo.shootMe ? data.pdfDocumentData.addInfo.shootMe : ''}
                                    </Text>
                                </View>
								
							</View>
                            
						</View>
						
                    </View>
		</Page>
	</Document>
);
 }
 

export default PdfDocument;