import React, { Component } from "react";
import {  View} from "react-native";
import { withTranslation } from 'react-i18next';
import {FooterComp} from '../Views'
import { ResultComp } from '../Views';
import { ResultCompMobile } from '../Views';
import MediaQuery from 'react-responsive';
class ResultDisplayScene extends Component {
    constructor(props) {
        super(props);
        let { t, i18n } = this.props.screenProps;
        this.resp = props.res;
    }
    render() {
        let { t, i18n } = this.props.screenProps;
        return (
            <View  style={{
                width: '100%',
                backgroundImage: 'linear-gradient(#078182, #12c9b3)',
                backgroundRepeat: '',
                backgroundSize: 'auto'}}>
                <MediaQuery minDeviceWidth={721}>
                    <ResultComp
                        screenProps={{ t, i18n }} res={this.props.res}>
                    </ResultComp>
                    <FooterComp screenProps={{ t, i18n }}></FooterComp>
                </MediaQuery>
                <MediaQuery maxDeviceWidth={720}>
                    <ResultCompMobile
                        screenProps={{ t, i18n }} res={this.props.res}>
                    </ResultCompMobile>
                    <FooterComp screenProps={{ t, i18n }}></FooterComp>
                </MediaQuery>
            </View>
        )
    }
}
// export default ResultDisplayScene;
export default withTranslation()(ResultDisplayScene);
