import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {HeaderComp} from './Views/HeaderComp';
import {ContentComp} from './Views/ContentComp';
import {AppRouter} from "./Scenes/AppRouter";

import 'react-app-polyfill/ie11';
import "react-app-polyfill/stable";

export default function App() {
  return (
    <View style={styles.container}>
      <AppRouter/>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
