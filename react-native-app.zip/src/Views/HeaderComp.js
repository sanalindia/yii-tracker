import React from 'react'
import { Button } from 'react-native-elements';
import { StyleSheet, View, Image, Text, TouchableOpacity } from 'react-native';
import MediaQuery from 'react-responsive';
import logoBayerCross from '../../assets/logoBayerCross.png'
const HeaderComp = ({ screenProps: { t, i18n } }) => {
  return(
    <View style={styles.header}>
      {/* <Text style={styles.mainHeader}>{t('screen', { order: 1 })}</Text> */}
      <View>
        <MediaQuery minDeviceWidth={721}>
        <View>
              
              <Text style={{ textAlign: 'right',marginRight:'25px' }}>
                <Image
                    source={{ uri: logoBayerCross }}
                    style={{ width: 50, height: 50 }}
                />
              </Text>
              
            
          </View>
          <Text style={[styles.mainHeader]}>{t('cardiovascularRiskAssessment')}
          </Text>
          <Text style={[styles.subHeader]}>{t('pleaseTellUsALittleAboutYourself')}
          </Text>
        </MediaQuery>
        <MediaQuery maxDeviceWidth={720}>
        <View>
              
              <Text style={{ textAlign: 'right',marginRight:'25px' }}>
                <Image
                    source={{ uri: logoBayerCross }}
                    style={{ width: 50, height: 50 }}
                />
              </Text>
              
            
          </View>
          <Text style={[styles.mainHeader]}>{t('cardiovascularRiskAssessment')}
          </Text>
          <Text style={[styles.subHeader]}>{t('pleaseTellUsALittleAboutYourself')}</Text>
        </MediaQuery>
      </View>
    </View>
    
  )

};
const styles = StyleSheet.create({
  header: {
    marginTop: '20px;'
  },
  langChangeText:{
    marginHorizontal: '10px', textDecorationLine: 'underline',color:'#8A3B11'
  },
  mainHeader: {
    color: 'white' ,
    fontSize: '35px',
    fontWeight: "500",
    fontFamily: 'Semibold 40px/55px Open Sans',
    textAlign: 'center'
  },
  subHeader: {
    color: 'white' ,
    fontSize: '25px',
    textAlign: 'center',
    fontFamily: 'Regular 25px/34px Open Sans'
  },
  langButton: {
    width: '50px',
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 20,
    margin: 'auto'
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 20,
    marginTop: '75px'
  }
});
export { HeaderComp };
