import React, { Component } from "react";
import { StyleSheet, FlatList, View, Text, TouchableHighlight, TouchableOpacity } from "react-native";
const ReportViewList = ({ listdata, screenProps }) => (
    <View>
        <FlatList
            data={[
                    { key: listdata.heartAgeLead },
                    { key: listdata.heartAgeRiskInfo0 },
                    { key: listdata.heartAgeRiskInfo1 },
                    { key: listdata.heartAgeSmoking },
                    { key: listdata.heartageBmi },
                    { key: listdata.heartageBp },
                    { key: listdata.bloodCholestrol },
                    { key: listdata.shootMe },
            ]}
            renderItem={({ item }) => {
                if (item.key)
                    return (
                        // <Text>
                        //     <Text style={{ color: '#00A79D' }}>{'\u2022'}</Text><Text style={styles.mainContentStyle}>{item.key}</Text>
                        // </Text>
                        <View style={ screenProps.i18n.language!=='arb' ? { flexDirection: 'row' }: { flexDirection: 'row-reverse' }}>
                            <View style={{width: '3%'}}>
                                <Text style={{ color: '#00A79D', fontSize : '30px', marginTop: '-8px' }}>{'\u2022'}</Text>
                            </View>
                            <View style={{width: '96%'}}>
                                <Text style={styles.mainContentStyle}>{item.key}</Text>
                            </View>
                        </View>
                    )
            }}
        />
    </View>
);

const styles = StyleSheet.create({
    mainContentStyle: {
        fontSize: '17px',
        color: '#979797'
    }
});
export { ReportViewList } 