import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  ActivityIndicator,
  Share,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image, Button } from "react-native-elements";
import { Actions } from "react-native-router-flux";
import * as Device from "expo-device";
import connectionLinesMobile from "../../assets/ChileConnectionlinesResultActionsmobile.svg";
import bookAppointmentIcon from "../../assets/bookAppointmentIcon.svg";
import findNearbyPharmaciesIcon from "../../assets/findNearbyPharmaciesIcon.svg";
import inviteFamilyIcon from "../../assets/inviteFamilyIcon.svg";
import saveAssessmentIcon from "../../assets/saveAssessmentIcon.svg";
import setReminderIcon from "../../assets/setReminderIcon.svg";
import sendReportIcon from "../../assets/sendReportIcon.svg";
import riskLevelChart from "../../assets/riskLevelChart.png";
import riskLevelChartSpanish from "../../assets/riskLevelChartSpanish.png";
import Modal from "modal-enhanced-react-native-web";
import { ReportViewList } from "../Views";
import ReactTooltip from "react-tooltip";
import { saveAs } from "file-saver";
import { pdf, Font } from "@react-pdf/renderer";
import PdfDocument from "../Scenes/PdfDocument";
import { InlineShareButtons } from "sharethis-reactjs";
import { Linking } from "react-native";
import amiri from "../../assets/amiri-regular.ttf";
import i18n from "../../i18n";

class ResultCompMobile extends Component {
  constructor(props) {
    super(props);
    let { t, i18n } = this.props.screenProps;
    this.resp = props.res;
    this.state = {
      modalVisible: false,
      animating: false,
    };
    Font.register({ family: "amiri", src: amiri });
  }
  getMailBodyText = (text) => {
    let bodyText = text ? ">  " + text + "%0D%0A" : "";
    return bodyText;
  };
  handleMail = () => {
    let { t, i18n } = this.props.screenProps;
    let gender = this.resp.gender == "F" ? t("female") : t("male");
    let hypertns = this.resp.hypertension == "1" ? t("yes") : t("no");
    let diabetic = this.resp.diabetic == "Y" ? t("yes") : t("no");
    let smoker = this.resp.smoker == "Y" ? t("yes") : t("no");
    var body = "";
    body = body + t("aboutYou") + "  :  " + "%0D%0A%0D%0A";
    body =
      body +
      t("gender") +
      gender +
      "    " +
      t("age") +
      this.resp.age +
      "    " +
      t("height") +
      this.resp.height +
      " " +
      this.resp.unitHeight +
      "%0D%0A%0D%0A" +
      t("weight") +
      this.resp.weight +
      " " +
      this.resp.unitWeight +
      "    " +
      t("bloodPressure") +
      " : " +
      this.resp.bp +
      " mmHg" +
      "%0D%0A%0D%0A" +
      t("treatmentForHypertension") +
      " : " +
      hypertns +
      "    " +
      t("diabetes") +
      " : " +
      diabetic +
      "%0D%0A%0D%0A" +
      t("totalCholestrol") +
      " : " +
      this.resp.cholestrol +
      " " +
      this.resp.cholestrolUnit +
      "    " +
      t("smoking") +
      " : " +
      smoker +
      "%0D%0A%0D%0A%0D%0A";
    body = body + t("concludedReport") + "  :  " + "%0D%0A%0D%0A";
    body =
      body +
      t("actualAge") +
      " : " +
      this.resp.age +
      "    " +
      t("heartAge") +
      " : " +
      this.resp.heartAge +
      "    " +
      t("riscLevel") +
      " : " +
      this.getRiskLevel(this.resp.heartRisk) +
      "%0D%0A%0D%0A" +
      this.getMailBodyText(this.resp.addInfo.heartAgeRiskInfo0) +
      this.getMailBodyText(this.resp.addInfo.heartAgeRiskInfo1) +
      this.getMailBodyText(this.resp.addInfo.heartAgeLead) +
      this.getMailBodyText(this.resp.addInfo.heartAgeSmoking) +
      this.getMailBodyText(this.resp.addInfo.heartageBp) +
      this.getMailBodyText(this.resp.addInfo.heartageBmi) +
      this.getMailBodyText(this.resp.addInfo.bloodCholestrol) +
      this.getMailBodyText(this.resp.addInfo.shootMe);
    Linking.openURL(
      "mailto:?subject=Mi reporte de riesgo cardiovascular&body=" + body
    );
  };
  setReminder() {
    if (Device.osName === "Android") {
      Linking.openURL("https://calendar.google.com/calendar/r");
    } else {
      Linking.openURL("calshow:");
    }
  }
  getContacts() {
    const phoneNumber = "";
    Linking.openURL(`tel:${phoneNumber}`);
  }

  generatePdfDocument = async (documentData) => {
    this.setState({ ...this.state, animating: true });
    let { t, i18n } = this.props.screenProps;
    const blob = await pdf(
      <PdfDocument
        title="My PDF"
        pdfDocumentData={documentData}
        screenProps={{ t, i18n }}
      />
    ).toBlob();
    saveAs(blob, "Resultados Test de riesgo cardiovascular.pdf");
    this.closeActivityIndicator();
  };
  setModalVisible = (visible) => {
    this.setState({ ...this.state, modalVisible: false });
  };
  _renderButton = (text, onPress) => (
    <TouchableOpacity onPress={onPress}>
      <View style={{ float: "right", flexDirection: "row-reverse" }}>
        <Text style={{ width: "auto" }}>{text}</Text>
      </View>
    </TouchableOpacity>
  );
  closeActivityIndicator = () => {
    this.setState({ ...this.state, animating: false });
  };
  getModalLoader = () => {
    return (
      <View>
        <Modal
          ariaHideApp={false}
          backdropColor="transparent"
          isVisible={this.state.animating}
        >
          <ActivityIndicator
            animating={this.state.animating}
            color="#00E2C2"
            size="large"
            style={this.styles.activityIndicator}
          />
        </Modal>
      </View>
    );
  };
  getRiskColor(riskVal) {
    let riskColor =
      riskVal < 5
        ? "#3CDD03"
        : riskVal >= 5 && riskVal < 10
        ? "#D9CB05"
        : riskVal >= 10 && riskVal < 20
        ? "#E67C1D"
        : riskVal >= 20 && riskVal < 30
        ? "#F72779"
        : riskVal >= 30
        ? "#BF1010"
        : "";
    return riskColor;
  }
  getRiskLevel(riskVal) {
    let { t, i18n } = this.props.screenProps;
    let risk =
      riskVal < 5
        ? t("veryLowRisk")
        : riskVal >= 5 && riskVal < 10
        ? t("lowRisk")
        : riskVal >= 10 && riskVal < 20
        ? t("moderateRisk")
        : riskVal >= 20 && riskVal < 30
        ? t("highRisk")
        : riskVal >= 30
        ? t("veryHighRisk")
        : "";
    return risk;
  }
  getModalContent() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View>
        <Modal
          ariaHideApp={false}
          style={{ margin: "5px" }}
          isVisible={this.state.modalVisible}
          onBackdropPress={() =>
            this.setState({ ...this.state, modalVisible: false })
          }
        >
          <View style={this.styles.modalContent}>
            <View>
              {this._renderButton("X", () =>
                this.setState({ ...this.state, modalVisible: false })
              )}
            </View>
            <View>
              <Text
                style={{
                  textAlign: "center",
                  color: "#00a79d",
                  fontSize: "xx-large",
                  paddingBottom: "25px",
                  fontWeight: "600",
                }}
              >
                {t("reportDetails")}
              </Text>
            </View>
            <View
              style={{ margin: "auto", height: "450px", overflow: "scroll" }}
            >
              <View>
                <View>
                  <ReportViewList
                    listdata={this.resp.addInfo}
                    screenProps={this.props.screenProps}
                  ></ReportViewList>
                </View>
              </View>
              <View>
                <View style={{ paddingLeft: "5px" }}>
                  <View
                    style={{
                      flexDirection: "row",
                      textAlign: "center",
                      margin: "auto",
                      marginVertical: "0px",
                    }}
                  >
                    <View style={{ flexDirection: "column" }}>
                      <Text style={{ color: "#ed750e", fontSize: "x-large" }}>
                        {t("riscLevel")}
                      </Text>
                      <Text
                        style={{
                          color: this.getRiskColor(this.resp.heartRisk),
                          fontSize: "large",
                        }}
                      >
                        {this.getRiskLevel(this.resp.heartRisk)}
                      </Text>
                    </View>
                  </View>
                </View>
                <View>
                  <Text
                    style={{
                      color: "#00A79D",
                      fontSize: "20px",
                      paddingVertical: "15px",
                      textAlign: "center",
                    }}
                  >
                    {t("riskLevelRange")}
                  </Text>
                </View>
                <View>
                  <Text style={{ textAlign: "center" }}>
                    <Image
                      source={
                        i18n.language !== "sp_co"
                          ? { uri: riskLevelChart }
                          : { uri: riskLevelChartSpanish }
                      }
                      style={{ width: "300px", height: "212px" }}
                    />
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    );
  }
  getLanguageAndBackButton() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View>
        <View style={{ flexDirection: "row", marginTop: "10px" }}>
          <Text style={{ color: "white" }} onPress={() => Actions.home()}>
            {t("back")}
          </Text>
        </View>
      </View>
    );
  }
  getDisplayGradient() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View style={{ flexGrow: 1, marginTop: "8px" }}>
        {this.getLanguageAndBackButton()}
        <View
          style={{
            minHeight: "130px",
            width: "325px",
            justifyContent: "center",
            margin: "auto",
            marginTop: "5px",
            textAlign: "center",
            //marginTop:'8px'
          }}
        >
          <LinearGradient
            colors={["#00E2C2", "#00E2C2"]}
            style={this.styles.linearGradient}
            start={[0, 1]}
            end={[1, 0]}
          >
            <View style={this.styles.gradientResultHolder}>
              <View style={this.styles.gradientBoxes}>
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    i18n.language !== "en"
                      ? { fontSize: "15px", height: "40px" }
                      : {},
                  ]}
                >
                  {t("actualAge")}
                </Text>
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    this.styles.gradientBoxVal,
                  ]}
                >
                  {this.resp.age}
                </Text>
              </View>
              <View
                style={[this.styles.gradientBoxes, this.styles.borderstyle]}
              >
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    ,
                    i18n.language !== "en"
                      ? { fontSize: "15px", height: "40px" }
                      : {},
                  ]}
                >
                  {t("heartAge")}
                </Text>
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    this.styles.gradientBoxVal,
                  ]}
                >
                  {this.resp.heartAge}
                </Text>
              </View>
              <View style={this.styles.gradientBoxes}>
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    i18n.language !== "en"
                      ? { fontSize: "15px", height: "40px" }
                      : {},
                  ]}
                >
                  {t("riscLevel")}
                </Text>
                <Text
                  style={[
                    this.styles.gradientBoxContent,
                    this.styles.gradientBoxVal,
                    {
                      backgroundColor: "#fff",
                      borderRadius: "5px",
                      color: this.getRiskColor(this.resp.heartRisk),
                    },
                    { fontSize: "14px" },
                  ]}
                >
                  {this.getRiskLevel(this.resp.heartRisk)}
                </Text>
              </View>
            </View>
            <View style={this.styles.moreInfoTab}>
              <Text
                style={this.styles.moreInfoTabContent}
                onPress={() => {
                  this.setState({ ...this.state, modalVisible: true });
                }}
              >
                {t("viewReportDetails")}
              </Text>
            </View>
          </LinearGradient>
        </View>
      </View>
    );
  }
  getRiskColor(riskVal) {
    let riskColor =
      riskVal < 5
        ? "#3CDD03"
        : riskVal >= 5 && riskVal < 10
        ? "#D9CB05"
        : riskVal >= 10 && riskVal < 20
        ? "#E67C1D"
        : riskVal >= 20 && riskVal < 30
        ? "#F72779"
        : riskVal >= 30
        ? "#BF1010"
        : "";
    return riskColor;
  }
  getRiskLevel(riskVal) {
    let { t, i18n } = this.props.screenProps;
    let risk =
      riskVal < 5
        ? t("veryLowRisk")
        : riskVal >= 5 && riskVal < 10
        ? t("lowRisk")
        : riskVal >= 10 && riskVal < 20
        ? t("moderateRisk")
        : riskVal >= 20 && riskVal < 30
        ? t("highRisk")
        : riskVal >= 30
        ? t("veryHighRisk")
        : "";
    return risk;
  }
  getActionBoxes1() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View style={this.styles.actionBoxSection}>
        <View
          style={[
            this.styles.contentBoxWrapper,
            this.styles.contentBox1Wrapper,
          ]}
        >
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxAppointmentBcg,
              this.styles.contentBoxexLeftEnglishSpanish,
            ]}
            onClick={() => this.getContacts()}
          >
            <Text style={{ textAlign: "center" }}>
              <Image
                source={{ uri: bookAppointmentIcon }}
                style={{ width: 55, height: 48 }}
              />
            </Text>
            <Text style={this.styles.contentBoxText}>
              {t("bookAppointmentWithYourDoctor")}
            </Text>
          </View>
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxNearPharmBcg,
              this.styles.contentBoxexRightEnglishSpanish,
            ]}
          >
            <TouchableOpacity
              onPress={() => {
                i18n.language == "en"
                  ? window.open(
                      "https://www.google.com/maps/search/near+pharmacy"
                    )
                  : window.open(
                      "https://www.google.com/maps/search/Farmacia+Cercana"
                    );
              }}
            >
              <Text style={{ textAlign: "center" }}>
                <Image
                  source={{ uri: findNearbyPharmaciesIcon }}
                  style={{ width: 50, height: 50 }}
                />
              </Text>
              <Text style={this.styles.contentBoxText}>
                {t("findNearByPharmacy")}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <View
          style={[
            this.styles.contentBoxWrapper,
            this.styles.contentBox2Wrapper,
          ]}
        >
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxResultToDocBcg,
              this.styles.contentBoxexLeftEnglishSpanish,
            ]}
            onClick={() => this.handleMail()}
          >
            <Text style={{ textAlign: "center" }}>
              <Image
                source={{ uri: sendReportIcon }}
                style={{ width: 50, height: 50 }}
              />
            </Text>
            <Text style={this.styles.contentBoxText}>
              {t("sendResultToYourDoctor")}
            </Text>
          </View>
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxSaveResultBcg,
              this.styles.contentBoxexRightEnglishSpanish,
            ]}
            onClick={() => this.generatePdfDocument(this.resp)}
          >
            <Text style={{ textAlign: "center" }}>
              <Image
                source={{ uri: saveAssessmentIcon }}
                style={{ width: 50, height: 50 }}
              />
            </Text>
            <Text style={this.styles.contentBoxText}>
              {t("saveResultForLater")}
            </Text>
          </View>
        </View>

        <View
          style={[
            this.styles.contentBoxWrapper,
            this.styles.contentBox2Wrapper,
          ]}
        >
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxsetReminderBcg,
              this.styles.contentBoxexLeftEnglishSpanish,
              { padding: "5px" },
            ]}
            onClick={() => this.setReminder()}
          >
            <Text style={{ textAlign: "center" }}>
              <Image
                source={{ uri: setReminderIcon }}
                style={{ width: 45, height: 40 }}
              />
            </Text>
            <Text style={[this.styles.contentBoxText]}>
              {t("setUpReminderToTalkToYourDocor")}
            </Text>
          </View>
          <View
            style={[
              this.styles.contentBoxes,
              this.styles.boxInviteBcg,
              this.styles.contentBoxexRightEnglishSpanish,
            ]}
            data-tip
            data-for="sharethis-tip"
            data-event="click"
          >
            <Text style={{ textAlign: "center" }}>
              <Image
                source={{ uri: inviteFamilyIcon }}
                style={{ width: 50, height: 50 }}
              />
            </Text>
            <Text style={this.styles.contentBoxText}>
              {t("inviteSomeoneToUseTheCalculator")}
            </Text>
          </View>
        </View>
        <ReactTooltip
          id="sharethis-tip"
          place="left"
          type="light"
          effect="solid"
          globalEventOff="click"
          clickable="true"
          multiline="true"
          backgroundColor="white"
        >
          <div style={{ height: "2px", width: "150px" }}>&nbsp;</div>
          <InlineShareButtons
            config={{
              alignment: "center", // alignment of buttons (left, center, right)
              color: "social", // set the color of buttons (social, white)
              enabled: true, // show/hide buttons (true, false)
              font_size: 16, // font size for the buttons
              language: "en", // which language to use (see LANGUAGES)
              networks: [
                // which networks to include (see SHARING NETWORKS)
                "twitter",
                "email",
                "whatsapp",
              ],
              labels: "",
              show_total: false,
              padding: 12, // padding within buttons (INTEGER)
              radius: 10, // the corner radius on each button (INTEGER)
              size: 35, // the size of each button (INTEGER)
            }}
          />
          <View
            style={{
              marginTop: "2px",
              height: "10px",
              backgroundColor: "transparent",
            }}
          ></View>
          <InlineShareButtons
            config={{
              alignment: "center", // alignment of buttons (left, center, right)
              color: "social", // set the color of buttons (social, white)
              enabled: true, // show/hide buttons (true, false)
              font_size: 16, // font size for the buttons
              language: "en", // which language to use (see LANGUAGES)
              networks: [
                // which networks to include (see SHARING NETWORKS)
                "linkedin",
                "facebook",
                "instagram",
                "messenger",
              ],
              labels: "",
              show_total: false,
              padding: 12, // padding within buttons (INTEGER)
              radius: 10, // the corner radius on each button (INTEGER)
              size: 35, // the size of each button (INTEGER)
            }}
          />
        </ReactTooltip>
        <View style={{ margin: "auto", flexDirection: "column" }}>
          <TouchableOpacity
            onPress={() =>
              window.open(
                `${window.parent.location.origin}/notas_y_consejos`,
                "_blank"
              )
            }
          >
            <View
              style={[
                {
                  height: "70px",
                  width: "300px",
                  margin: "auto",
                  paddingLeft: "20px",
                  paddingRight: "20px",
                  borderRadius: "5px",
                  backgroundColor: "#0eac04",
                  justifyContent: "center",
                  marginTop: "25px",
                },
                this.styles.bottomButton,
              ]}
            >
              <Text
                style={{ color: "#fff", fontSize: "18px", textAlign: "center" }}
              >
                {t("TakeCareTips")}
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  render() {
    let { t, i18n } = this.props.screenProps;
    this.generateCss();
    return (
      <View>
        <View
          style={{
            backgroundImage: "url(" + connectionLinesMobile + ")",
            backgroundRepeat: "no-repeat",
            backgroundSize: "371px 590px",
            backgroundPosition: "top",
            paddingBottom: "50px",
            paddingTop: "28px",
          }}
        >
          {this.getDisplayGradient()}

          {this.getActionBoxes1()}
        </View>
        <View>{this.getModalContent()}</View>
        <View>{this.getModalLoader()}</View>
      </View>
    );
  }
  getArabicNumbers(data) {
    var arabicNumbers = ["۰", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];
    var chars = data.toString().split("");
    for (var i = 0; i < chars.length; i++) {
      if (/\d/.test(chars[i])) {
        chars[i] = arabicNumbers[chars[i]];
      }
    }
    return chars.join("");
  }
  generateCss() {
    this.styles = StyleSheet.create({
      modalContent: {
        backgroundColor: "white",
        padding: 22,
        borderRadius: 4,
        borderColor: "rgba(0, 0, 0, 0.1)",
        // height:'500px',
        // width:'500px'
      },
      modalContentForShare: {
        height: "80px",
        width: "300px",
        borderColor: "red",
      },
      actionBoxSection: {
        width: "100%",
        flexGrow: 1,
        // paddingLeft: '20px',
        // paddingRight: '20px',
        marginTop: "30px",
        flexDirection: "column",
      },
      contentBoxes: {
        height: "130px",
        width: "140px",
        margin: "auto",
        // marginHorizontal: '30px',
        borderRadius: "25px",
        padding: "15px",

        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
      },
      contentBoxexLeftArabic: {
        marginRight: "30px",
      },
      contentBoxexRightArabic: {
        marginLeft: "30px",
      },
      contentBoxexLeftEnglishSpanish: {
        marginRight: "35px",
      },
      contentBoxexRightEnglishSpanish: {
        marginLeft: "35px",
      },
      contentBoxWrapper: {
        flexGrow: 1,
        flexDirection: "row",
        margin: "auto",
      },
      contentBoxText: {
        borderTopWidth: 1,
        borderTopColor: "white",
        color: "#fff",
        textAlign: "center",
      },
      contentBox2Wrapper: {
        marginTop: "20px",
        // height: '250px'
        margin: "auto",
      },
      contentBox1Wrapper: {
        alignItems: "flex-start",
      },

      boxAppointmentBcg: {
        backgroundColor: "#089B85",
        shadowColor: "#565656",
        // marginRight: '560px'
      },
      boxNearPharmBcg: {
        backgroundColor: "#089B85",
        shadowColor: "#565656",
      },
      boxResultToDocBcg: {
        // marginRight: '5px',
        marginTop: "0px",
        backgroundColor: "#0DBCA3",
        shadowColor: "#565656",
      },
      boxSaveResultBcg: {
        backgroundColor: "#0BDABB",
        shadowColor: "#565656",
      },
      boxsetReminderBcg: {
        backgroundColor: "#0BDABB",
        shadowColor: "#565656",
      },

      boxInviteBcg: {
        marginTop: "0px",
        backgroundColor: "#0DBCA3",
        shadowColor: "#565656",
      },
      linearGradient: {
        flex: 1,
        flexDirection: "column",
        minHeight: "130px",
        width: "325px",
        borderRadius: "55px",
        paddingLeft: 15,
        paddingRight: 15,
        justifyContent: "space-evenly",
      },
      gradientResultHolder: {
        flexDirection: "row",
        paddingTop: "5px",
      },
      moreInfoTabContent: {
        color: "#00E2C2",
        backgroundColor: "#fff",
        fontSize: "13PX",
        padding: "8px",
        borderRadius: "24px",
        shadowColor: "#565656",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.8,
        shadowRadius: 1,
        elevation: 1,
      },

      moreInfoTab: {
        margin: "auto",
        justifyContent: "center",
      },
      gradientBoxes: {
        justifyContent: "center",
        minHeight: "50px",
        width: "100px",
        margin: "auto",
        marginTop: "10px",
        flexDirection: "column",
      },
      gradientBoxContent: {
        color: "#ffffff",
        fontSize: "14px",
        width: "100px",
        margin: "auto",
      },
      gradientBoxVal: {
        fontSize: "25px",
        width: "80px",
        margin: "auto",
        fontWeight: "Bold",
      },
      borderstyle: {
        borderTopWidth: 0,
        borderBottomWidth: 0,
        borderWidth: 1,
        borderRightWidth: 1,
        borderColor: "#fff",
      },
      bottomButton: {
        shadowColor: "#565656",
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
      },
      mainContentStyle: {
        textAlign: "center",
        color: "#979797",
        fontSize: "20px",
        fontFamily: "Semibold 24px/25px Open Sans",
      },
      marginAuto: {
        margin: "auto",
      },
    });
  }
}
// export default ResultCompMobile;
export { ResultCompMobile };
