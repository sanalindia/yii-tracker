export * from './HeaderComp';
export * from './ContentComp';
export * from './FooterComp';
// export * from './ViewReport';
export * from './ReportViewList';
export * from './ContentCompMobile';
export * from './HeaderCompMobile';
export * from './resultComp';
export * from './resultCompMobile';
