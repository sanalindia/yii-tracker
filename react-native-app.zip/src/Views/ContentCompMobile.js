import React, { Component } from "react";
import { CheckBox } from "react-native-elements";
import { Button, Icon } from "react-native-elements";
import {
  StyleSheet,
  View,
  Image,
  Text,
  TouchableOpacity,
  TextInput,
  Picker,
} from "react-native";

import { Actions } from "react-native-router-flux";
import { getData } from "../Services/Services";
import * as Device from "expo-device";
import infoIcon from "../../assets/infoIconArabic.svg";

import homeScreenLinesMobile from "../../assets/homeScreenLinesMobile.svg";
import i18n from "../../i18n";
import ReactTooltip from "react-tooltip";
class ContentCompMobile extends Component {
  constructor(props) {
    super(props);
    let { t, i18n } = this.props.screenProps;
    this.generateCss();
    this.state = {
      valid: true,
      validAge: false,
      validHeight: false,
      validWeight: false,
      validGender: false,
      validBP: false,
      validCholestrol: false,
      gender: "",
      isDropdownData: false,
      age: "0",
      height: "0",
      heightinch: "0",
      weight: "0",
      diabetes: false,
      bloodPressure: false,
      treatmentForBP: false,
      bpValue: "0",
      bpUnit: "mmHg",
      cholestrolLevel: false,
      cholestrolval: "0",
      cholestrolUnit: false,
      heightUnit: "cm",
      weightUnit: "kg",
      cholestrolUnitText: "mg/dl",
      smoking: false,
    };
    if (sessionStorage.getItem("stateData")) {
      this.state = JSON.parse(sessionStorage.getItem("stateData"));
    } else {
      this.updateSession();
    }
  }
  setCheckedState(stateVal) {
    return stateVal ? false : true;
  }
  updateSession() {
    sessionStorage.setItem("stateData", JSON.stringify(this.state));
  }
  updateSessionStorage() {
    sessionStorage.setItem("stateData", JSON.stringify(this.state));
    this.validate();
  }
  updateStateValidations(updateStateForFlag) {
    if (updateStateForFlag) {
      if (!this.state.bloodPressure) {
        this.updateStateData({ ...this.state, bpValue: "" });
      }
    } else {
      if (!this.state.cholestrolLevel) {
        // this.updateStateData({ ...this.state, cholestrolval: '' })
        this.updateStateData({ ...this.state, cholestrolval: "" });
      }
    }
  }

  updateStateData(object) {
    this.setState(object, () => this.updateSessionStorage());
  }
  dataLayer(event, eventCategory, eventAction, eventLabel) {
    let isData = parent.dataLayer.filter(function (el) {
      return el.eventAction === eventAction && el.eventLabel === eventLabel;
    });
    parent.dataLayer = parent.dataLayer || [];
    if (isData.length === 0) {
      parent.dataLayer.push({
        event,
        eventCategory,
        eventAction,
        eventLabel,
      });
    }
  }
  isValidWeight() {
    if (
      this.state.weight &&
      this.state.weight != "0" &&
      ((this.state.weightUnit == "lbs" &&
        this.state.weight >= 90 &&
        this.state.weight <= 600) ||
        (this.state.weightUnit == "kg" &&
          this.state.weight >= 41 &&
          this.state.weight <= 271))
    ) {
      this.setState({ ...this.state, validWeight: false }, () => {
        this.isValidGender();
      });
    } else {
      this.setState({ ...this.state, validWeight: true }, () => {
        this.isValidGender();
      });
    }
  }
  isValidGender() {
    if (this.state.gender) {
      this.setState({ ...this.state, validGender: false }, () => {
        this.isValidBp();
      });
    } else {
      this.setState({ ...this.state, validGender: true }, () => {
        this.isValidBp();
      });
    }
  }
  isValidBp() {
    if (
      this.state.bloodPressure &&
      this.state.bpValue != "" &&
      this.state.bpValue != "0"
    ) {
      this.setState({ ...this.state, validBp: false }, () => {
        this.isValidCholestrol();
      });
    } else {
      this.setState({ ...this.state, validBp: true }, () => {
        this.isValidCholestrol();
      });
    }
  }

  isValidCholestrol() {
    if (
      this.state.isKnowCholestrol ||
      (this.state.cholestrolLevel &&
        this.state.cholestrolval != "0" &&
        this.state.cholestrolval != "")
    ) {
      this.updateStateData({ ...this.state, validCholestrol: false });
    } else {
      this.updateStateData({ ...this.state, validCholestrol: true });
    }
  }
  isValidHeight() {
    if (
      this.state.height &&
      this.state.height != "0" &&
      ((this.state.heightUnit == "cm" &&
        this.state.height >= 70 &&
        this.state.height <= 244) ||
        (this.state.heightUnit == "footinch" &&
          this.state.height >= 2 &&
          this.state.height <= 8))
    ) {
      this.setState({ ...this.state, validHeight: false }, () => {
        this.isValidWeight();
      });
    } else {
      this.setState({ ...this.state, validHeight: true }, () => {
        this.isValidWeight();
      });
    }
  }
  isAllValid() {
    if (this.state.age >= 40 && this.state.age <= 74 && this.state.age != "0") {
      this.setState({ ...this.state, validAge: false }, () => {
        this.isValidHeight();
      });
    } else {
      this.setState({ ...this.state, validAge: true }, () => {
        this.isValidHeight();
      });
    }
  }
  validate() {
    if (
      this.state.age >= 30 &&
      this.state.age <= 74 &&
      this.state.age != "0" &&
      this.state.gender &&
      this.state.height &&
      this.state.height != "0" &&
      ((this.state.heightUnit == "cm" &&
        this.state.height >= 70 &&
        this.state.height <= 244) ||
        (this.state.heightUnit == "footinch" &&
          this.state.height >= 2 &&
          this.state.height <= 8)) &&
      this.state.weight &&
      this.state.weight != "0" &&
      ((this.state.weightUnit == "lbs" &&
        this.state.weight >= 90 &&
        this.state.weight <= 600) ||
        (this.state.weightUnit == "kg" &&
          this.state.weight >= 41 &&
          this.state.weight <= 271)) &&
      this.state.bloodPressure &&
      this.state.bpValue != "" &&
      this.state.bpValue != "0" &&
      (this.state.isKnowCholestrol ||
        (this.state.cholestrolLevel &&
          this.state.cholestrolval != "0" &&
          this.state.cholestrolval != ""))
      // (  (this.state.cholestrolLevel && (this.state.isKnowCholestrol || (this.state.cholestrolval!='0' && this.state.cholestrolval!='' ))) )
    ) {
      //this.setState({...this.state,valid:false})
      this.setState({ ...this.state, valid: false });
    } else {
      //this.setState({...this.state,valid:false})
      this.setState({ ...this.state, valid: true });
    }
  }
  getContentBoxInSequence() {
    let { t, i18n } = this.props.screenProps;

    return (
      <View style={this.styles.containerContent}>
        {this.getBox1Content()}
        {this.getBox2Content()}
        {this.getBox3Content()}
      </View>
    );
  }
  getBox1Content() {
    let { t, i18n } = this.props.screenProps;
    let ftArb = t("ft") + "/" + t("in");

    return (
      <View style={[this.styles.contentBoxes, this.styles.paddingLtRt0]}>
        <View>
          <Text
            style={[
              this.styles.rowWrapperBP,
              this.state.validGender
                ? this.state.gender
                  ? {}
                  : this.styles.errBackground
                : {},
            ]}
          >
            <Text
              style={[
                { paddingLeft: "5px" },
                this.state.validGender
                  ? this.state.gender
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              *
            </Text>
            <Text
              style={[
                this.state.validGender
                  ? this.state.gender
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              {t("gender")}
            </Text>
            <CheckBox
              iconType="font-awesome"
              uncheckedIcon="circle"
              checkedIcon="dot-circle-o"
              size={15}
              textStyle={[
                {
                  marginLeft: 0,
                  marginRight: 0,
                  color: "white",
                  fontWeight: "normal",
                },
                this.state.validGender
                  ? this.state.gender
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
              checkedColor="white"
              uncheckedColor="white"
              containerStyle={[
                this.styles.checkBoxView2,
                this.styles.marginRight0,
                { marginLeft: "0px" },
              ]}
              title={t("male")}
              onPress={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  "Test del Corazón:Male"
                );
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  "Test del Corazón:Male"
                );
                this.updateStateData({ ...this.state, gender: "M" });
              }}
              checked={this.state.gender == "M" ? true : false}
            />
            <CheckBox
              iconType="font-awesome"
              uncheckedIcon="circle"
              checkedIcon="dot-circle-o"
              size={15}
              textStyle={[
                {
                  marginLeft: 0,
                  marginRight: 0,
                  color: "white",
                  fontWeight: "normal",
                },
                this.state.validGender
                  ? this.state.gender
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
              checkedColor="white"
              containerStyle={[
                this.styles.checkBoxView2,
                this.styles.marginRight0,
                { paddingLeft: "0px" },
              ]}
              title={t("female")}
              uncheckedColor="white"
              onPress={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  "Test del Corazón:Female"
                );
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  "Test del Corazón:Female"
                );
                this.updateStateData({ ...this.state, gender: "F" });
              }}
              checked={this.state.gender == "F" ? true : false}
            />
          </Text>
          {/* <Text style={this.styles.rowWrapper} ref={ref => this.fooRef = ref} data-tip='tooltip'> */}
          <Text
            style={[
              this.styles.rowWrapper,
              this.state.validAge
                ? this.state.age >= 40 && this.state.age <= 74
                  ? {}
                  : this.styles.errBackground
                : {},
            ]}
          >
            <Text
              style={[
                { paddingLeft: "20px" },
                this.state.validAge
                  ? this.state.age >= 40 && this.state.age <= 74
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              *
            </Text>
            <Text
              style={[
                this.state.validAge
                  ? this.state.age >= 40 && this.state.age <= 74
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              {t("age")}
            </Text>
            <TextInput
              style={this.styles.textInputStyle}
              value={this.state.age}
              keyboardType="phone-pad"
              selectTextOnFocus
              onClick={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  `Test del Corazón: ${t("age")}`
                );
              }}
              onChangeText={(text) => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  `Test del Corazón: ${t("age")}`
                );
                let prevText = this.state.age;
                if (text > 99) {
                  this.updateStateData({ ...this.state, age: prevText });
                } else {
                  const value = text.replace(/[^\d]/g, "");
                  this.updateStateData({ ...this.state, age: value });
                }
              }}
            ></TextInput>

            <Text
              style={[
                this.state.validAge
                  ? this.state.age >= 40 && this.state.age <= 74
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              {" "}
              {t("years")}
            </Text>
          </Text>
          <Text
            style={[
              this.styles.rowWrapper,
              this.state.heightUnit == "cm"
                ? this.state.validHeight
                  ? this.state.height > 69 && this.state.height < 245
                    ? {}
                    : this.styles.errBackground
                  : {}
                : this.state.validHeight
                ? this.state.height > 1 && this.state.height < 9
                  ? {}
                  : this.styles.errBackground
                : {},
            ]}
          >
            <Text
              style={[
                { paddingLeft: "13px" },
                this.state.heightUnit == "cm"
                  ? this.state.validHeight
                    ? this.state.height > 69 && this.state.height < 245
                      ? {}
                      : this.styles.errTextColor
                    : {}
                  : this.state.validHeight
                  ? this.state.height > 1 && this.state.height < 9
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              *
            </Text>
            <Text
              style={[
                this.state.heightUnit == "cm"
                  ? this.state.validHeight
                    ? this.state.height > 69 && this.state.height < 245
                      ? {}
                      : this.styles.errTextColor
                    : {}
                  : this.state.validHeight
                  ? this.state.height > 1 && this.state.height < 9
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              {t("height")}
            </Text>
            <TextInput
              style={[
                this.styles.textInputStyle,
                this.state.heightUnit !== "cm" ? { width: "25px" } : {},
              ]}
              value={this.state.height}
              keyboardType="phone-pad"
              selectTextOnFocus
              onClick={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  `Test del Corazón: ${t("height")} in ${this.state.heightUnit}`
                );
              }}
              onChangeText={(text) => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  `Test del Corazón: ${t("height")} in ${this.state.heightUnit}`
                );
                let prevText = this.state.height;
                if (text > 999) {
                  this.updateStateData({ ...this.state, height: prevText });
                } else {
                  const value = text.replace(/[^\d]/g, "");
                  this.updateStateData({ ...this.state, height: value });
                }
              }}
            ></TextInput>
            <TextInput
              style={[
                this.styles.textInputStyle,
                this.state.heightUnit === "cm"
                  ? { display: "none" }
                  : { width: "35px", marginLeft: "5px" },
              ]}
              value={this.state.heightinch}
              keyboardType="phone-pad"
              selectTextOnFocus
              onClick={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  `Test del Corazón: ${t("height")} in ${this.state.heightUnit}`
                );
              }}
              onChangeText={(text) => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  `Test del Corazón: ${t("height")} in ${this.state.heightUnit}`
                );

                let prevText = this.state.heightinch;
                if (text > 11) {
                  this.updateStateData({ ...this.state, heightinch: prevText });
                } else {
                  const value = text.replace(/[^\d]/g, "");
                  this.updateStateData({ ...this.state, heightinch: value });
                }
              }}
            ></TextInput>
            <Text style={{ paddingLeft: "5px" }}>
              <Picker
                selectedValue={this.state.heightUnit}
                style={[
                  this.styles.pickerStyle,
                  this.styles.pickerForHtWt,
                  this.state.heightUnit == "cm"
                    ? this.state.validHeight
                      ? this.state.height > 69 && this.state.height < 245
                        ? {}
                        : this.styles.errPickerStyle
                      : {}
                    : this.state.validHeight
                    ? this.state.height > 1 && this.state.height < 9
                      ? {}
                      : this.styles.errPickerStyle
                    : {},
                ]}
                onValueChange={(itemValue, itemIndex) => {
                  this.updateStateData({
                    ...this.state,
                    heightUnit: itemValue,
                    height: "",
                    heightinch: "",
                  });
                }}
              >
                <Picker.Item color="black" label={ftArb} value="footinch" />
                {/* <Picker.Item color='black' label="in" value="in" /> */}
                <Picker.Item color="black" label={t("cm")} value="cm" />
              </Picker>
              <Icon
                name="caret-down"
                type="font-awesome"
                color="transparet"
                size={14}
                iconStyle={this.styles.caratIconStyle}
                containerStyle={{ backgroundColor: "transparent" }}
              />
            </Text>
          </Text>
          <Text
            style={[
              this.styles.rowWrapper,
              this.state.weightUnit == "kg"
                ? this.state.validWeight
                  ? this.state.weight >= 41 && this.state.weight <= 271
                    ? {}
                    : this.styles.errBackground
                  : {}
                : this.state.validWeight
                ? this.state.weight >= 90 && this.state.weight <= 600
                  ? {}
                  : this.styles.errBackground
                : {},
            ]}
          >
            <Text
              style={[
                { paddingLeft: "20px" },
                this.state.weightUnit == "kg"
                  ? this.state.validWeight
                    ? this.state.weight >= 41 && this.state.weight <= 271
                      ? {}
                      : this.styles.errTextColor
                    : {}
                  : this.state.validWeight
                  ? this.state.weight >= 90 && this.state.weight <= 600
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              *
            </Text>
            <Text
              style={[
                this.state.weightUnit == "kg"
                  ? this.state.validWeight
                    ? this.state.weight >= 41 && this.state.weight <= 271
                      ? {}
                      : this.styles.errTextColor
                    : {}
                  : this.state.validWeight
                  ? this.state.weight >= 90 && this.state.weight <= 600
                    ? {}
                    : this.styles.errTextColor
                  : {},
              ]}
            >
              {t("weight")}
            </Text>
            <TextInput
              style={this.styles.textInputStyle}
              value={this.state.weight}
              keyboardType="phone-pad"
              selectTextOnFocus
              onClick={() => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Focus",
                  `Test del Corazón: ${t("weight")} in ${this.state.weightUnit}`
                );
              }}
              onChangeText={(text) => {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  `Test del Corazón: ${t("weight")} in ${this.state.weightUnit}`
                );
                let prevText = this.state.weight;
                if (text > 999) {
                  this.updateStateData({ ...this.state, weight: prevText });
                } else {
                  const value = text.replace(/[^\d]/g, "");
                  this.updateStateData({ ...this.state, weight: value });
                }
              }}
            ></TextInput>{" "}
            <Text>
              <Picker
                selectedValue={this.state.weightUnit}
                style={[
                  this.styles.pickerStyle,
                  this.styles.pickerForHtWt,
                  this.state.weightUnit == "kg"
                    ? this.state.validWeight
                      ? this.state.weight >= 41 && this.state.weight <= 271
                        ? {}
                        : this.styles.errPickerStyle
                      : {}
                    : this.state.validWeight
                    ? this.state.weight >= 90 && this.state.weight <= 600
                      ? {}
                      : this.styles.errPickerStyle
                    : {},
                ]}
                onValueChange={(itemValue, itemIndex) =>
                  this.updateStateData({ ...this.state, weightUnit: itemValue })
                }
              >
                <Picker.Item color="black" label="kg" value="kg" />
                <Picker.Item color="black" label="lbs" value="lbs" />
              </Picker>
              <Icon
                name="caret-down"
                type="font-awesome"
                color="transparet"
                size={14}
                iconStyle={this.styles.caratIconStyle}
                containerStyle={{ backgroundColor: "transparent" }}
              />
            </Text>
          </Text>
        </View>
      </View>
    );
  }
  getBox2Content() {
    let { t, i18n } = this.props.screenProps;

    return (
      <View style={[this.styles.contentBoxesView2, this.styles.paddingLtRt0]}>
        <Text
          style={[
            this.styles.rowWrapperView2,
            this.state.validBp
              ? this.state.bpValue > 0
                ? {}
                : this.styles.errBackground
              : {},
          ]}
        >
          <Text
            style={[
              this.state.validBp
                ? this.state.bpValue > 0
                  ? {}
                  : this.styles.errTextColor
                : {},
            ]}
          >
            *
          </Text>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            size={15}
            onPress={() => {
              this.setState(
                {
                  ...this.state,
                  bloodPressure: !this.state.bloodPressure,
                },
                () => {
                  this.updateSessionStorage();
                  this.updateStateValidations(true);
                }
              );
            }}
            uncheckedColor="white"
            checkedColor="white"
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
              this.state.validBp
                ? this.state.bpValue > 0
                  ? {}
                  : this.styles.errTextColor
                : {},
            ]}
            containerStyle={[
              this.styles.checkBoxView2,
              i18n.language == "en"
                ? { width: "172px", marginLeft: "0px" }
                : { width: "240px", marginRight: "0px", marginLeft: "0px" },
            ]}
            title={t("bloodPressure")}
            checked={this.state.bloodPressure}
          />
          <Image
            source={{ uri: infoIcon }}
            style={{ width: 15, height: 15 }}
            data-tip="tooltip"
            data-for="bp-tip"
            data-event="click"
          />
        </Text>

        <Text style={[this.styles.rowWrapperBP, { paddingLeft: "32px" }]}>
          <TextInput
            disabled={!this.state.bloodPressure}
            style={[
              this.styles.textInputStyle,
              this.state.bloodPressure ? {} : { backgroundColor: "#CAC9C9" },
            ]}
            value={this.state.bpValue}
            keyboardType="phone-pad"
            selectTextOnFocus
            onClick={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("bloodPressure")}`
              );
            }}
            onChangeText={(text) => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Complete",
                `Test del Corazón: ${t("bloodPressure")}`
              );
              let prevText = this.state.bpValue;
              if (text > 999) {
                this.updateStateData({ ...this.state, bpValue: prevText });
              } else {
                const value = text.replace(/[^\d]/g, "");
                this.updateStateData({ ...this.state, bpValue: value });
              }
            }}
          ></TextInput>
          <ReactTooltip
            id="bp-tip"
            place="left"
            effect="solid"
            globalEventOff="click"
            clickable={true}
            backgroundColor="transparent"
          >
            <div
              style={{
                width: "200px",
                flexDirection: "column",
                padding: 0,
                marginLeft: "20px",
              }}
            ></div>
            <View
              style={{
                width: "200px",
                flexDirection: "column",
                margin: "0px",
                padding: "0px",
                borderColor: "#ffff",
                borderWidth: "2px",
                color: "#000000",
              }}
            >
              <Text style={{ padding: "5px", backgroundColor: "#4ce600" }}>
                {t("lessThan120")}
              </Text>
              <Text style={{ padding: "5px", backgroundColor: "#ffff00" }}>
                {t("between120And139")}
              </Text>

              <Text style={{ padding: "5px", backgroundColor: "#ff9966" }}>
                {t("between140And159")}
              </Text>
              <Text style={{ padding: "5px", backgroundColor: "#cc4400" }}>
                {t("between160And179")}
              </Text>
              <Text style={{ padding: "5px", backgroundColor: "#ff0000" }}>
                {t("higherThan180")}
              </Text>
            </View>
          </ReactTooltip>
          <Text style={{ paddingLeft: "5px" }}>{t("mmHg")}</Text>
        </Text>
        <Text style={this.styles.rowWrapperView2}>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            size={15}
            onPress={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("treatmentForHypertension")}`
              );
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Complete",
                `Test del Corazón: ${t("treatmentForHypertension")}`
              );
              this.updateStateData({
                ...this.state,
                treatmentForBP: !this.state.treatmentForBP,
              });
            }}
            uncheckedColor="white"
            checkedColor="white"
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
            ]}
            containerStyle={[this.styles.checkBoxView2, { marginLeft: "0px" }]}
            title={t("treatmentForHypertension")}
            checked={this.state.treatmentForBP}
          />
        </Text>
        <Text style={this.styles.rowWrapperView2}>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            size={15}
            onPress={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("diabetes")}`
              );
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Complete",
                `Test del Corazón: ${t("diabetes")}`
              );
              this.updateStateData({
                ...this.state,
                diabetes: !this.state.diabetes,
              });
            }}
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
            ]}
            uncheckedColor="white"
            checkedColor="white"
            containerStyle={[this.styles.checkBoxView2, { marginLeft: "0px" }]}
            title={t("diabetes")}
            checked={this.state.diabetes}
          />
        </Text>
      </View>
    );
  }
  getCholestrolMgdl() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View
        style={{
          flexDirection: "column",
          margin: "0px",
          padding: "0px",
          borderColor: "#ffff",
          borderWidth: "2px",
          color: "#000000",
        }}
      >
        <Text style={{ padding: "5px", backgroundColor: "#00b33c" }}>
          {t("lessThan150mgdl")}
        </Text>
        <Text style={{ padding: "5px", backgroundColor: "#99cc00" }}>
          {t("between200mgdl")}
        </Text>

        <Text style={{ padding: "5px", backgroundColor: "#ffff00" }}>
          {t("between200and239mgdl")}
        </Text>
        <Text style={{ padding: "5px", backgroundColor: "#e60000" }}>
          {t("moreThan240mgdl")}
        </Text>
      </View>
    );
  }
  getCholestrolmmol() {
    let { t, i18n } = this.props.screenProps;
    return (
      <View
        style={{
          flexDirection: "column",
          margin: "0px",
          padding: "0px",
          borderColor: "#ffff",
          borderWidth: "2px",
          color: "#000000",
        }}
      >
        <Text style={{ padding: "5px", backgroundColor: "#00b33c" }}>
          {t("lessThan39mmol")}
        </Text>
        <Text style={{ padding: "5px", backgroundColor: "#99cc00" }}>
          {t("between52mmol")}
        </Text>

        <Text style={{ padding: "5px", backgroundColor: "#ffff00" }}>
          {t("between52and62mmol")}
        </Text>
        <Text style={{ padding: "5px", backgroundColor: "#e60000" }}>
          {t("moreThan62")}
        </Text>
      </View>
    );
  }
  getBox3Content() {
    let { t, i18n } = this.props.screenProps;

    return (
      <View
        style={[
          i18n.language !== "arb"
            ? this.styles.contentBoxesVeiew3
            : this.styles.contentBoxes,
          this.styles.paddingLtRt0,
        ]}
      >
        <Text
          style={[
            this.styles.rowWrapperView2,
            this.state.validCholestrol
              ? this.state.isKnowCholestrol || this.state.cholestrolval > 0
                ? {}
                : this.styles.errBackground
              : {},
          ]}
        >
          <Text
            style={[
              this.state.validCholestrol
                ? this.state.isKnowCholestrol || this.state.cholestrolval > 0
                  ? {}
                  : this.styles.errTextColor
                : {},
            ]}
          >
            *
          </Text>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            size={15}
            onPress={() => {
              this.setState(
                {
                  ...this.state,
                  cholestrolLevel: !this.state.cholestrolLevel,
                },
                () => {
                  this.updateSessionStorage();
                  this.updateStateValidations(false);
                  // if(this.state.cholestrolLevel==false){
                  //     this.setState({
                  //         ...this.state, isKnowCholestrol: false
                  //     }, () => {
                  //         this.updateSessionStorage();
                  //         this.updateStateValidations(false);
                  //     });
                  // }
                }
              );
            }}
            uncheckedColor="white"
            checkedColor="white"
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
              this.state.validCholestrol
                ? this.state.isKnowCholestrol || this.state.cholestrolval > 0
                  ? {}
                  : this.styles.errTextColor
                : {},
            ]}
            containerStyle={[this.styles.checkBoxView2, { marginLeft: "0px" }]}
            title={t("totalCholestrol")}
            checked={this.state.cholestrolLevel}
          />
          <Image
            source={{ uri: infoIcon }}
            style={[
              { width: 15, height: 15 },
              this.state.cholestrolUnitText === "mg/dl"
                ? { width: 15 }
                : { display: "none" },
            ]}
            data-tip="tooltip"
            data-for="mgdl-tip"
          />
          <Image
            source={{ uri: infoIcon }}
            style={[
              { width: 15, height: 15 },
              this.state.cholestrolUnitText === "mmol/L"
                ? { width: 15 }
                : { display: "none" },
            ]}
            data-tip="tooltip"
            data-for="mmol-tip"
          />
          <ReactTooltip
            id="mgdl-tip"
            place="bottom"
            effect="solid"
            // globalEventOff="click"
            clickable={true}
            backgroundColor="transparent"
          >
            <div style={{ flexDirection: "column", padding: 0 }}></div>
            {this.getCholestrolMgdl()}
          </ReactTooltip>
          <ReactTooltip
            id="mmol-tip"
            place="bottom"
            effect="solid"
            // globalEventOff="click"
            clickable={true}
            backgroundColor="transparent"
          >
            <div style={{ flexDirection: "column", padding: 0 }}></div>
            {this.getCholestrolmmol()}
          </ReactTooltip>
        </Text>
        <Text style={{ paddingLeft: "22px" }}>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            // disabled={!this.state.cholestrolLevel}
            size={15}
            onPress={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("totalCholestrol")} :  ${t("iDontKnow")}`
              );
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Complete",
                `Test del Corazón: ${t("totalCholestrol")}  : ${t("iDontKnow")}`
              );
              this.setState(
                {
                  ...this.state,
                  isKnowCholestrol: !this.state.isKnowCholestrol,
                },
                () => {
                  this.updateSessionStorage();
                  this.updateStateData({ ...this.state, cholestrolval: "" });
                }
              );
            }}
            uncheckedColor="white"
            checkedColor="white"
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
            ]}
            containerStyle={this.styles.checkBoxView2}
            title={t("iDontKnow")}
            checked={this.state.isKnowCholestrol}
          />
        </Text>

        <Text style={[this.styles.rowWrapperBP, { paddingLeft: "32px" }]}>
          <TextInput
            disabled={
              !this.state.cholestrolLevel || this.state.isKnowCholestrol
            }
            style={[
              this.styles.textInputStyle,
              this.state.cholestrolLevel
                ? !this.state.isKnowCholestrol
                  ? {}
                  : { backgroundColor: "#CAC9C9" }
                : { backgroundColor: "#CAC9C9" },
            ]}
            value={this.state.cholestrolval}
            keyboardType="phone-pad"
            selectTextOnFocus
            onClick={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("totalCholestrol")} in ${
                  this.state.cholestrolUnitText
                }`
              );
            }}
            onChangeText={(text) => {
              {
                this.dataLayer(
                  "gaGenericEvent",
                  "Form",
                  "Complete",
                  `Test del Corazón: ${t("totalCholestrol")} in ${
                    this.state.cholestrolUnitText
                  }`
                );
                this.setState(
                  { ...this.state, isKnowCholestrol: false },
                  () => {
                    let prevText = this.state.cholestrolval;
                    const value = text.replace(/[^0-9.]/g, "");
                    if (text > 999)
                      this.updateStateData({
                        ...this.state,
                        cholestrolval: prevText,
                      });
                    else if (text.includes(".")) {
                      let isUpdate =
                        text.split(".").length > 1
                          ? text.split(".")[1].length > 2
                            ? "yes"
                            : "no"
                          : "no";
                      let val = Number(value).toFixed(2);
                      let val1 = "";
                      if (isUpdate == "yes") val1 = Number(text).toFixed(2);
                      else val1 = text;
                      this.updateStateData({
                        ...this.state,
                        cholestrolval: val1,
                      });
                    } else {
                      this.updateStateData({
                        ...this.state,
                        cholestrolval: value,
                      });
                    }
                  }
                );
              }
            }}
            // data-tip='tooltip' data-for='cholestrol-tip'
          ></TextInput>

          <Text style={[this.styles.rowWrapperBP, { paddingLeft: "5px" }]}>
            <Picker
              selectedValue={this.state.cholestrolUnitText}
              style={this.styles.pickerStyle}
              mode="dropdown"
              onValueChange={(itemValue, itemIndex) =>
                this.updateStateData({
                  ...this.state,
                  cholestrolUnitText: itemValue,
                })
              }
            >
              <Picker.Item color="black" label={t("mgdl")} value="mg/dl" />
              <Picker.Item color="black" label={t("mmoll")} value="mmol/L" />
            </Picker>
            <Icon
              name="caret-down"
              type="font-awesome"
              color="transparet"
              size={14}
              iconStyle={this.styles.caratIconStyle}
              containerStyle={{ backgroundColor: "transparent" }}
            />
          </Text>
        </Text>
        <Text style={this.styles.rowWrapperView2}>
          <CheckBox
            iconType="font-awesome"
            checkedIcon="check-square"
            uncheckedIcon="square"
            size={15}
            onPress={() => {
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Focus",
                `Test del Corazón: ${t("smoking")}`
              );
              this.dataLayer(
                "gaGenericEvent",
                "Form",
                "Complete",
                `Test del Corazón: ${t("smoking")}`
              );
              this.updateStateData({
                ...this.state,
                smoking: !this.state.smoking,
              });
            }}
            uncheckedColor="white"
            checkedColor="white"
            textStyle={[
              {
                marginLeft: "5px",
                marginRight: 0,
                color: "white",
                fontWeight: "normal",
              },
            ]}
            containerStyle={this.styles.checkBoxView2}
            title={t("smoking")}
            checked={this.state.smoking}
          />
        </Text>
      </View>
    );
  }
  calculateButton(reqObj) {
    const finalObj = { ...reqObj };
    if (finalObj.unitHeight !== "footinch") {
      finalObj.heightinch = "";
    }
    this.isAllValid();
    this.dataLayer("gaGenericEvent", "Form", "Submit", "Test del Corazón");

    if (!this.state.valid) {
      this.dataLayer(
        "gaGenericEvent",
        "Form",
        "Submit successful",
        "Test del Corazón"
      );
      getData("", finalObj)
        .then((res) => {
          let { t, i18n } = this.props.screenProps;
          const propertiesToSend = {};
          propertiesToSend.screenProps = { t, i18n };
          propertiesToSend.res = res;
          Actions.resultDisplay(propertiesToSend);
        })
        .catch((err) => {});
    }
  }
  getRiskLevel(riskVal) {
    let { t, i18n } = this.props.screenProps;
    let risk =
      riskVal < 5
        ? t("veryLowRisk")
        : riskVal >= 5 && riskVal < 10
        ? t("lowRisk")
        : riskVal >= 10 && riskVal < 20
        ? t("moderateRisk")
        : riskVal >= 20 && riskVal < 30
        ? t("highRisk")
        : riskVal >= 30
        ? t("veryHighRisk")
        : "";
    return risk;
  }
  render() {
    let { t, i18n } = this.props.screenProps;
    this.generateCss();
    let cholestrolVal = "0.0";
    cholestrolVal =
      !this.state.cholestrolLevel || this.state.isKnowCholestrol
        ? "0.0"
        : this.state.cholestrolval;
    var requestObj = {
      smoker: this.state.smoking ? "Y" : "N",
      gender: this.state.gender,
      diabetic: this.state.diabetes ? "Y" : "N",
      bp: this.state.bpValue,
      age: this.state.age,
      regionCode: 3,
      cholestrol: cholestrolVal,
      hypertension: this.state.treatmentForBP ? 1 : 0,
      unitHeight: this.state.heightUnit,
      unitWeight: this.state.weightUnit,
      height: this.state.height,
      heightinch: this.state.heightinch,
      weight: this.state.weight,
      lang: i18n.language == "sp_co" ? "es" : i18n.language,
      cholestrolUnit: this.state.cholestrolUnitText,
    };

    return (
      <View style={this.styles.parentContainerStyle}>
        {this.getContentBoxInSequence()}

        <View style={this.styles.buttonContainer}>
          <TouchableOpacity>
            <Button
              disabledStyle={[
                this.styles.calculateButton,
                { backgroundColor: "#00e2c2" },
              ]}
              buttonStyle={[
                this.styles.calculateButton,
                this.state.valid
                  ? { backgroundColor: "#00e2c2" }
                  : { backgroundColor: "rgba(0,167,157,1)" },
              ]}
              titleStyle={{ fontWeight: "500", fontSize: "30px" }}
              title={t("calculateRisk")}
              onPress={() => this.calculateButton(requestObj)}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  generateCss() {
    let { t, i18n } = this.props.screenProps;
    this.styles = StyleSheet.create({
      parentContainerStyle:
        i18n.language === "en"
          ? {
              // backgroundImage: "url(" + bgImage + ")",
              // backgroundRepeat: 'no-repeat',
              // backgroundSize: '435px auto',
            }
          : {
              // backgroundImage: "url(" + bgImage + ")",
              // backgroundRepeat: 'no-repeat',
              // backgroundSize: '435px auto',
            },
      caratIconStyle: {
        color: "#fff",
        marginLeft: "-10px",
        marginRight: "0px",
        display: Device.osName !== "Android" ? "" : "none",
      },
      errTextColor: {
        color: "red",
      },
      errBackground: {
        backgroundColor: "rgba(230, 255, 230,0.8)",
        //backgroundColor:'#e6ffe6'
      },
      errPickerStyle: {
        color: "red",
        borderBottomColor: "transparent",
      },
      paddingLtRt0: {
        paddingLeft: "0px",
        paddingRight: "0px",
      },
      pickerForVal: {
        paddingLeft: 0,
        marginLeft: "5px",
        height: "30px",
        width: "161px",
      },
      pickerForCholestol: {
        padding: "0px",
        marginLeft: "5px",
        height: "25px",
        width: "135px",
      },
      Box3Padding: {
        paddingLeft: "5px",
        paddingRight: "5px",
      },
      langButton: {
        width: "200px ",
        flex: 1,
        paddingTop: 20,
        margin: "5px",
      },
      container: {
        flexDirection: "row",
        marginTop: "40px",
        textAlign: "center",
        marginHorizontal: "auto",
      },
      contentBoxes: {
        height: "200px",
        width: i18n.language == "en" ? "240px" : "270px",
        // marginRight: '50px',
        // marginLeft: '30px',
        backgroundColor: "#2BE8CD",
        borderRadius: "25px",
        padding: "20px",
        borderWidth: 0,
        borderColor: "#ddd",
        borderBottomWidth: 0,
        shadowColor: "#565656",
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
        margin: "20px",
      },
      calculateButton: {
        height: "80px",
        width: "310px",
        borderRadius: "50px",
        backgroundColor: "#00A79D",
        borderWidth: 0,
        borderColor: "#ddd",
        borderBottomWidth: 0,
        shadowColor: "#565656",
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
        margin: "40px",
      },
      contentBoxesVeiew3: {
        height: "200px",
        width: i18n.language == "en" ? "240px" : "270px",
        // marginRight: '50px',
        backgroundColor: "#00A78F",

        borderRadius: "25px",
        padding: "20px",
        borderWidth: 0,
        borderColor: "#ddd",
        borderBottomWidth: 0,
        shadowColor: "#565656",
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
        margin: "20px",
      },
      buttonContainer: {
        margin: "auto",
        marginTop: "0px",
        backgroundImage: "url(" + homeScreenLinesMobile + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "100px 200px;",
        backgroundPosition: "center",
        paddingVertical: "20px",
      },
      pickerForHtWt: { width: "50px" },
      pickerStyle: {
        height: "25px",
        width: "80px",
        color: "#fff",
        borderTopColor: "transparent",
        borderRightColor: "transparent",
        borderLeftColor: "transparent",
        backgroundColor: "transparent",
        borderBottomColor: "#ffffff",
      },
      contentBoxesView2: {
        height: "200px",
        width: i18n.language == "en" ? "240px" : "270px",
        // marginRight: '50px',
        backgroundColor: "#14CEB3",
        borderRadius: "25px",
        padding: "20px",
        borderWidth: 0,
        borderColor: "#ddd",
        borderBottomWidth: 0,
        shadowColor: "#565656",
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 1,
        margin: "20px",
      },
      rowWrapperBP: {
        // textAlign: 'center',
        flexDirection: "row",
        marginTop: "10px",
        color: "white",
        fontStyle: "Open Sans",
        paddingRight: i18n.language == "en" ? "10px" : "0px",
        paddingLeft: i18n.language == "en" ? "10px" : "5px",
      },
      marginRight0: {
        marginRight: 0,
      },
      rowWrapper: {
        // textAlign: 'right',
        flexDirection: "row",
        marginTop: "15px",
        color: "white",
        paddingRight: i18n.language == "en" ? "10px" : "0px",
        paddingLeft: i18n.language == "en" ? "10px" : "5px",
      },
      checkBoxView2: {
        padding: 0,
        margin: 0,
        borderColor: "transparent",
        backgroundColor: "transparent",
      },
      rowWrapperView2: {
        flexDirection: "row",
        marginTop: "10px",
        margin: 0,
        color: "white",
        paddingRight: i18n.language == "en" ? "10px" : "0px",
        paddingLeft: i18n.language == "en" ? "10px" : "5px",
      },
      textInputStyle: {
        width: "50px",
        borderRadius: "2px",
        height: "20px",
        backgroundColor: "#fff",
        padding: "5px",
      },
      containerContent: {
        // flexDirection: 'row',
        marginTop: "20px",
        marginHorizontal: "auto",
      },
      checkboxStyle: {
        borderColor: "transparent",
        backgroundColor: "transparent",
      },
      alignRight: {
        textAlign: "right",
      },
    });
  }
}
export { ContentCompMobile };
