import React from 'react'
import { StyleSheet, View, Image, Text, TouchableOpacity } from 'react-native';
import MediaQuery from 'react-responsive';
const FooterComp = (props) =>{
    const t = props.screenProps.t;
    return(
    <View >
        <View style={[styles.footerWrapper,{flexDirection:'column'}]}>
            <MediaQuery minDeviceWidth={721}>
                <Text style={styles.footerText}>{props.screenProps.t('disclaimerArgentina')}
                </Text>
                <Text style={[styles.footerText,props.screen=='homeScreen'?{marginLeft:'0px'}:{display:'none'}]}>{t('disclaimerChilleApprovalCode')}
                </Text>
            </MediaQuery>
        
            <MediaQuery maxDeviceWidth={720}>
                <Text style={styles.footerText}>{t('disclaimerArgentina')}
                </Text>
                <Text style={[styles.footerText,props.screen=='homeScreen'?{marginLeft:'0px'}:{display:'none'}]}>{t('disclaimerChilleApprovalCode')}
                </Text>
            </MediaQuery>
        </View>
     </View>
);}

const styles = StyleSheet.create({
    header: {
      marginTop: '20px;'
    },
    footerWrapper:{
        padding:'10px',
        margin: 'auto'
    },
    
    footerText:{
        margin:'auto',
        marginTop:'5px',
        width: '90vw'
    },
});
export {FooterComp};