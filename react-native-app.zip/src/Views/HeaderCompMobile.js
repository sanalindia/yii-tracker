import React from 'react'
import logoBayerCross from '../../assets/logoBayerCross.png'
import { StyleSheet, View, Image, Text, TouchableOpacity } from 'react-native';
const HeaderCompMobile = ({ screenProps: { t, i18n } }) => (
  <View style={styles.header}>
    <View>
      <View style={{ flexDirection: 'row'}}>
          <Text style={[styles.headerText,{margin:'auto',height:'50px',paddingTop:'10px'}]}>{t('headerEvaluation')}</Text>
          <Text style={{ marginLeft:'80vw',marginRight:'25px',position:'absolute' }}>
            <Image
                source={{ uri: logoBayerCross }}
                style={{ width: 50, height: 50 }}
            />
          </Text>
      </View>
    </View>
    <Text style={[styles.headerText,styles.mainHeader]}>{t('headerCardiovascularRiskAssessment')}
    </Text>
    <Text style={[styles.subHeader, {color:  'white'}]}>{t('pleaseTellUsALittleAboutYourself')}</Text>
  </View>
);
const styles = StyleSheet.create({
  header: {
    marginTop: '20px;'
  },
  headerText:{
    color: '#FFF',
    fontSize: '30px',
    fontWeight: "400",
    fontFamily: 'Semibold 40px/55px Open Sans',
  },
  mainHeader: {
    
    textAlign: 'center',
    marginTop:'0px'
  },
  subHeader: {
    color: '#0C5F98',
    fontSize: '25px',
    textAlign: 'center',
    fontFamily: 'Regular 25px/34px Open Sans'
  },
  langButton: {
    width: '50px ',
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 20,
    margin: 'auto'
  },
  
});
export { HeaderCompMobile };
