import React, { useEffect, useState } from 'react'
import './circularOptionsCard.css';

export default function CircularOptionsCard({
    optionsList,
    isContinueClicked,
    optionsSelected,
    quizNo,
    isOptionError,
    resetOptionError,
    previousSelectedValue
}) {

    const [selectedData, setSelectedData] = useState(previousSelectedValue || '');

    useEffect(() => {
        if (isContinueClicked) {
            optionsSelected({ value: selectedData });
        }
    }, [isContinueClicked, selectedData, optionsSelected]);

    const circularOptionSelected = (index) => {
        if (isOptionError) {
            resetOptionError();
        }

        let data = selectedData;
        if (data === optionsList[index].field_answer_summary) {
            data = "";
        } else {
            data = optionsList[index].field_answer_summary;
        }
        setSelectedData(data);
    }

    return (
        <div
            className='circularOptnMainView'
        >
            {optionsList.map((item, index) =>
                <React.Fragment
                    key={`circularOption-${quizNo}-${index}`}
                >
                    <div
                        className='circularOptionsView'
                    >
                        <button
                            className={selectedData === optionsList[index].field_answer_summary
                                ? 'circularOptions circularOptionsSelected'
                                : isOptionError
                                    ? 'circularOptions circularOptionErrorView'
                                    : 'circularOptions'}
                            onClick={() => circularOptionSelected(index)}
                        >
                            <p
                                className={selectedData === optionsList[index].field_answer_summary
                                    ? 'circularOptnSelectedText'
                                    : 'circularOptnText'}
                            >
                                {item.title}
                            </p>
                        </button>
                    </div>
                </React.Fragment>
            )
            }
        </div >
    )
}
