import React from "react";
import { Col, Row } from "react-bootstrap";
import "./sectionHome.css";
import { slideInRight, fadeIn } from "react-animations";
import Radium, { StyleRoot } from "radium";
function SectionHome({ data, goToQuizSection }) {
  const goToQuiz = (event) => {
    event.stopPropagation();
    let elem = document.querySelector(".sectionContinueBtn");
    const evt = new CustomEvent("GTM-custom-event", {
      detail: { actionLabel: "Continue", fromAssess: "section" },
    });
    document.dispatchEvent(evt);
    goToQuizSection();
  };
  const styles = {
    slideInRight: {
      animation: "x 2s",
      animationName: Radium.keyframes(slideInRight, "slideInRight"),
    },
    fadeIn: {
      animation: "x 2s",
      animationName: Radium.keyframes(fadeIn, "fadeIn"),
    },
  };
  return (
    <div>
      <Row
        className={
          data?.isQuizCompletion
            ? "sectionMainView completionDetailsMainView"
            : "sectionMainView"
        }
      >
        <StyleRoot className="desktopSection">
          <Col xs={12} md={6} className="sectionIconView">
            <img
              src={data?.icon}
              alt={data?.imageText}
              className="sectionIcon"
              style={data.isAnimate ? styles.slideInRight : styles.fadeIn}
            />
          </Col>

          <div
            className="displayMobileDevice"
            style={data.isAnimate ? styles.slideInRight : styles.fadeIn}
          >
            <p
              className={
                data?.isQuizCompletion
                  ? "sectionTitle completionTitle"
                  : "sectionTitle"
              }
            >
              {data?.title}
            </p>
            {data?.description ? (
              <p
                className={
                  data?.isQuizCompletion
                    ? "sectionDesc completionDesc"
                    : "sectionDesc"
                }
              >
                {data?.description}
              </p>
            ) : null}
          </div>
        </StyleRoot>
        <Col
          xs={12}
          md={6}
          className={
            data?.isQuizCompletion
              ? "sectionDetailsView completionDetailsView"
              : "sectionDetailsView"
          }
        >
          <StyleRoot
            style={data.isAnimate ? styles.slideInRight : styles.fadeIn}
            className="displayDesktopDevice"
          >
            <div>
              <p
                className={
                  data?.isQuizCompletion
                    ? "sectionTitle completionTitle"
                    : "sectionTitle"
                }
              >
                {data?.title}
              </p>
              {data?.description ? (
                <p
                  className={
                    data?.isQuizCompletion
                      ? "sectionDesc completionDesc"
                      : "sectionDesc"
                  }
                >
                  {data?.description}
                </p>
              ) : null}
            </div>

            {!data?.isQuizCompletion ? (
              <button className="sectionContinueBtn" onClick={goToQuiz}>
                Continue
              </button>
            ) : null}
          </StyleRoot>
          <div className="displayMobileDevice">
            {!data?.isQuizCompletion ? (
              <button className="sectionContinueBtn" onClick={goToQuiz}>
                Continue
              </button>
            ) : null}
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default SectionHome;
