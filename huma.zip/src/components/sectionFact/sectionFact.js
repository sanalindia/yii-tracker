import React, { useState, useEffect } from "react";
import "./sectionFact.css";
import { fadeIn, fadeOut } from "react-animations";
import Radium, { StyleRoot } from "radium";
import heartSmartFactGif from "../../assets/images/PC_HeartSmartFact.gif";

const styles = {
  fadeIn: {
    animation: "x 4s",
    animationName: Radium.keyframes(fadeIn, "fadeIn"),
  },
  fadeOut: {
    animation: "x 3s",
    animationName: Radium.keyframes(fadeOut, "fadeOut"),
  },
};

export default function SectionFact({ data, skipQuizFact }) {
  const [animate, setAnimate] = useState(styles.fadeIn);
  const factSkipBtnClicked = () => {
    setAnimate(styles.fadeOut);
    setTimeout(() => {
      skipQuizFact();
    }, 1000);
  };

  useEffect(() => {
    setTimeout(() => {
      setAnimate(styles.fadeOut);
    }, 6000);
  });

  return (
    <div className="sectionFactMainView">
      <StyleRoot>
        <div style={animate} className="factView" title={data?.heartImgText}>
          <div className="factContentView">
            <img
              src={heartSmartFactGif}
              alt="Heart Smart Fact Gif"
              className="heartSmartFactGif"
            />
            <p className="factContentText">{data?.title}</p>
          </div>
          <div className="factSkipBtnView">
            <button className="factSkipBtn" onClick={factSkipBtnClicked}>
              Skip
            </button>
          </div>
        </div>
      </StyleRoot>
      <div className="factBottomView">
        {data?.sourceName ? <p className="sourceTitle">*Source:</p> : ""}
        <p className="sourceContent">{data?.sourceName}</p>
      </div>
    </div>
  );
}
