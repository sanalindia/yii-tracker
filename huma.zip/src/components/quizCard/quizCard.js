import React, { useCallback, useEffect, useState } from "react";
import { Cases } from "../../utils/API";
import Header from "../header/header";
import "./quizCard.css";
import OptionsCard from "../optionsCard/optionsCard";
import QuizButton from "../quizButton/quizButton";
import { slideInRight, slideInLeft } from "react-animations";
import Radium, { StyleRoot } from "radium";
let headerBG = "";
let headerTitle = "";

const selectedValue = { requestParams: {}, previousData: {} };

export default function QuizCard({
  question,
  quizNo,
  goToPreviousQuiz,
  goToNextQuiz,
  sectionNo,
  backBtn,
}) {
  const questionID = question.id;
  const isSkipButton = quizNo === 6 || quizNo === 7 ? true : false;

  const [answerOptions, setAnswerOptions] = useState([]);
  const [isContinueClicked, setIsContinueClicked] = useState(false);
  const [isOptionError, setOptionError] = useState(false);
  const [isSubOptionError, setSubOptionError] = useState(false);

  const styles = {
    slideInRight: {
      animation: "x 1s",
      animationName: Radium.keyframes(slideInRight, "slideInRight"),
    },
    slideInLeft: {
      animation: "x 1s",
      animationName: Radium.keyframes(slideInLeft, "slideInLeft"),
    },
  };

  const setHeaderBGAndTitle = useCallback(() => {
    if (sectionNo === 1) {
      headerBG = "gettingToKnowBG";
      headerTitle = "Getting to know you";
    } else if (sectionNo === 2) {
      headerBG = "yourBodyBG";
      headerTitle = "Your Body";
    } else if (sectionNo === 3) {
      headerBG = "lifestyleBG";
      headerTitle = "Your Lifestyle";
    } else if (sectionNo === 4) {
      headerBG = "healthHistoryBG";
      headerTitle = "Health & History";
    }
  }, [sectionNo]);

  useEffect(() => {
    setHeaderBGAndTitle();

    Cases.getAnswers4Question(questionID)
      .then((response) => {
        setAnswerOptions(response);
      })
      .catch((errors) => {
        console.log(errors);
      });
  }, [questionID, question, setHeaderBGAndTitle]);

  const quizBackBtnClicked = () => {
    if (isOptionError) {
      resetOptionError();
    }

    if (isSubOptionError) {
      resetSubOptionError();
    }

    goToPreviousQuiz();
  };

  const quizContinueBtnClicked = () => {
    if (quizNo === 7) {
      if (!selectedValue?.requestParams?.waistCircumference) {
        selectedValue.requestParams.waistCircumference = 0;
        selectedValue.previousData.quiz7Waist = 0;
      }

      if (!selectedValue?.requestParams?.hipCircumference) {
        selectedValue.requestParams.hipCircumference = 0;
        selectedValue.previousData.quiz7Hip = 0;
      }
      setIsContinueClicked(true);
      // goToNextQuiz(selectedValue?.requestParams);
    } else {
      setIsContinueClicked(true);
    }
  };

  const quizSkipBtnClicked = () => {
    goToNextQuiz(selectedValue?.requestParams);
  };

  const validateSelectedAnswer = (data) => {
    switch (quizNo) {
      case 1:
        selectedValue.requestParams.age = data.value;
        selectedValue.previousData.quiz1 = data.value;
        break;

      case 2:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.sportsFrequency = data.value;
          selectedValue.previousData.quiz2 = data;
        }

        break;

      case 3:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.fanRating = data.value;
          selectedValue.previousData.quiz3 = data;
        }

        break;

      case 4:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.gender = data.value;
          selectedValue.previousData.quiz4 = data;
        }
        break;

      case 5:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.overallHealth = data.value;
          selectedValue.previousData.quiz5 = data;
        }
        break;

      case 6:
        selectedValue.requestParams.heartRate = data.value;
        selectedValue.previousData.quiz6 = data.value;
        break;

      case 8:
        selectedValue.requestParams.sleepDuration = data.value;
        selectedValue.previousData.quiz8 = data.value;
        break;

      case 9:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.walkingPace = data.value;
          selectedValue.previousData.quiz9 = data;
        }
        break;

      case 10:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.tobaccoSmoking = data.value;
          selectedValue.previousData.quiz10 = data.value;
        }
        break;

      case 11:
        if (data.value === "") {
          return true;
        } else {
          selectedValue.requestParams.alcoholIntake = data.value;
          selectedValue.previousData.quiz11 = data;
        }
        break;

      case 12:
        if (data.value.length === 0) {
          return true;
        } else {
          selectedValue.requestParams.otherDiseases =
            data.value.length === 1 && data.value[0] === "" ? [] : data.value;
          selectedValue.previousData.quiz12 = data.value;
        }
        break;

      case 13:
        if (data.value.length === 0) {
          return true;
        } else {
          selectedValue.requestParams.symptoms =
            data.value.length === 1 && data.value[0] === "" ? [] : data.value;
          selectedValue.previousData.quiz13 = data.value;
        }
        break;

      case 14:
        if (data.value.length === 0) {
          return true;
        } else {
          selectedValue.requestParams.currentMedications =
            data.value.length === 1 && data.value[0] === "" ? [] : data.value;
          selectedValue.previousData.quiz14 = data.value;
        }
        break;

      case 15:
        if (data.value.length === 0) {
          return true;
        } else {
          selectedValue.requestParams.relativesHeartDisease =
            data.value.length === 1 && data.value[0] === "" ? [] : data.value;
          selectedValue.previousData.quiz15 = data.value;
        }
        break;

      default:
        break;
    }
  };

  const answerOptionsSelected = (data) => {
    setIsContinueClicked(false);

    const isError = validateSelectedAnswer(data);

    if (isError) {
      if ((quizNo === 3 || quizNo === 11) && data.subOptionNotSelected) {
        setSubOptionError(true);
      } else {
        setOptionError(true);
      }
    } else {
      goToNextQuiz(selectedValue?.requestParams);
    }
  };

  const resetOptionError = () => {
    setOptionError(false);
  };

  const resetSubOptionError = () => {
    setSubOptionError(false);
  };

  const sliderValueUpdated = (sliderType, value) => {
    if (sliderType === "WaistSize") {
      selectedValue.requestParams.waistCircumference = value * 2.54; // converting inches to cms
      selectedValue.previousData.quiz7Waist = value;
    } else if (sliderType === "HipSize") {
      selectedValue.requestParams.hipCircumference = value * 2.54; // converting inches to cms
      selectedValue.previousData.quiz7Hip = value;
    }
  };

  return (
    <div>
      <Header
        bgType={headerBG}
        title={headerTitle}
        showBackTextInMobile={false}
        showCloseIcon={true}
        backButtonAction={quizBackBtnClicked}
      />

      <div className="quizMainView">
        <StyleRoot
          className={
            quizNo === 1
              ? "slider-width"
              : quizNo === 6
              ? "slider-width"
              : quizNo === 7
              ? "slider-width"
              : quizNo === 8
              ? "slider-width"
              : null
          }
          style={backBtn ? styles.slideInLeft : styles.slideInRight}
        >
          <div className="quizQuestion">
            <p className="questionNo">
              <span className="currentQuestionNo">{`${quizNo}`}</span>
              {` of `}
              <span className="totalQuestionNo">15</span>
            </p>
            <p
              className="questionTitle"
              dangerouslySetInnerHTML={{
                __html: question.title,
              }}
            >
              {/* {question.title} */}
            </p>
            {question.field_instruction ? (
              <p
                className={`questionSubTitle quiz${quizNo}SubTitle`}
                dangerouslySetInnerHTML={{
                  __html: question.field_instruction,
                }}
              >
                {/* {question.field_instruction} */}
              </p>
            ) : null}
          </div>

          {answerOptions.length > 0 ? (
            <OptionsCard
              quizNo={quizNo}
              optionsList={answerOptions}
              answerOptionsSelected={answerOptionsSelected}
              isContinueClicked={isContinueClicked}
              isOptionError={isOptionError}
              resetOptionError={resetOptionError}
              previousSelectedData={selectedValue?.previousData}
              sliderValueUpdated={sliderValueUpdated}
              isSubOptionError={isSubOptionError}
              resetSubOptionError={resetSubOptionError}
            />
          ) : null}
        </StyleRoot>
        <QuizButton
          quizNo={quizNo}
          quizContinueBtnClicked={quizContinueBtnClicked}
          quizSkipBtnClicked={quizSkipBtnClicked}
          isSkip={isSkipButton}
        />
      </div>
      {quizNo === 15 ? (
        <div className="lastQnDisclaimer">
          Heart disease includes myocardial infarction, heart failure, angina
          pectoris, stroke, and transient ischaemic attack.{" "}
        </div>
      ) : (
        ""
      )}
    </div>
  );
}
