import React, { useState } from 'react'
import { Col, Row } from 'react-bootstrap';
import './header.css';
import backArrowWhite from '../../assets/images/back-arrow-white.png';
import backArrowBlack from '../../assets/images/back_arrow.png';
import closeIcon from '../../assets/images/close-white.png';
import CustomModal from '../customModal/customModal';

export default function Header({
    bgType,
    title,
    showBackTextInMobile,
    showCloseIcon,
    backButtonAction
}) {

    const [modalShow, setModalShow] = useState(false);

    const backButtonTapped = () => {
        backButtonAction();
    }

    const headerExitIconTapped = () => {
        setModalShow(true)
    }

    const exitModalDismissAction = () => {
        setModalShow(false);
    }

    const exitAssessment = () => {
        setModalShow(false);
        window.parent.location.href = "/be-heart-smart/";
    }

    return (
        <Row
            className={bgType ? `headerView ${bgType}` : 'headerView defaultHeaderBG'}
        >
            <Col xs={3} md={2}>
                <button
                    className='headerBackArrowView'
                    onClick={backButtonTapped}
                >
                    <img
                        src={showBackTextInMobile ? backArrowBlack : backArrowWhite}
                        alt="Back Arrow"
                        className='headerBackArrow'
                    />
                    <p
                        className={showBackTextInMobile ? 'headerBackArrowText headerBackArrowBlack' : 'headerBackArrowText hideHeaderBackArrowText'}
                    >
                        Back
                    </p>
                </button>
            </Col>
            <Col xs={6} md={8}>
                {title ? (
                    <p
                        className='headerTitle'
                    >
                        {title}
                    </p>
                ) : null}
            </Col>
            <Col xs={3} md={2}>
                {showCloseIcon ? (
                    <div
                        className='headerCloseIconView'
                    >
                        <button
                            className='headerBackArrowView'
                            onClick={headerExitIconTapped}
                        >
                            <img
                                src={closeIcon}
                                alt="Close Icon"
                                className='headerCloseIcon'
                            />
                        </button>
                        <CustomModal
                            show={modalShow}
                            onHide={exitModalDismissAction}
                            title={"Are you sure you want to leave the assessment? Your progress will be lost!"}
                            titleOne={"Why are you leaving the assessment?"}
                            isExitModal={true}
                            exitAssessment={exitAssessment}
                        />
                    </div>
                ) : null}
            </Col>
        </Row>
    )
}
