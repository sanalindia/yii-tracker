import React from 'react'
import OptionsDropdown from '../optionsDropdown/optionsDropdown';
import './detailedOptionsCard.css';
import alertIcon from "../../assets/images/alert_icon_red.png";

export default function DetailedOptionsCard({
    detailedOptionData,
    quizNo,
    singleSelectedIndex,
    subOptionSelected,
    prevSelectedData,
    isSubOptionError
}) {

    const subOptionData = detailedOptionData.find((ele) => ele.quizNo === quizNo && ele.index === singleSelectedIndex);

    return (
        <div
            className="detailedOptionsView"
        >
            <p
                className='detailedOptionsTitle'
            >
                {subOptionData?.dropdownTitle}
            </p>

            {isSubOptionError ? (
                <div className="subOptionsErrorView">
                    <img
                        className="subOptionsErrorIcon"
                        src={alertIcon}
                        alt="sub options alert icon"
                    />
                    <p className="subOptionsErrorText">
                        Select an option
                    </p>
                </div>
            ) : null}

            <div className={isSubOptionError ? "vertical_shake" : null}>
                <OptionsDropdown
                    options={subOptionData?.dropDownOptions}
                    subOptionSelected={subOptionSelected}
                    isSubOptionError={isSubOptionError}
                    prevSelectedData={prevSelectedData}
                    type="quizSubOptions"
                />
            </div>
        </div>
    )
}
