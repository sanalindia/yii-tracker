import React, { useState } from "react";
import { Container, Modal, Row, Col } from "react-bootstrap";
import Carousel from "react-bootstrap/Carousel";
import "./carouselModal.scss";

export default function CarouselModal({ carouselItem, show, onHide }) {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };

  return (
    <Modal className="carouselModalView" show={show} onHide={onHide} centered>
      <Modal.Header closeButton></Modal.Header>
      <Modal.Body>
        <Carousel
          activeIndex={index}
          onSelect={handleSelect}
          className="carouselModal"
        >
          {carouselItem.map((carouselItem, i) => {
            return (
              <Carousel.Item key={i}>
                <h3 className="carouselModalTitle onlyMobile">
                  {carouselItem.title}
                </h3>

                <Container>
                  <Row>
                    <Col xs={12} md={6} lg={6} className="leftContent">
                      <div className="cimage">
                        <img
                          className="carouselModalImg"
                          src={carouselItem.imageSRC}
                          alt={carouselItem.imageALT}
                        />
                      </div>
                    </Col>
                    <Col xs={12} md={6} lg={6} className="rightContent">
                      <h3 className="carouselModalTitle onlyDesktop">
                        {carouselItem.title}
                      </h3>
                      <p
                        className="carouselModalText"
                        dangerouslySetInnerHTML={{
                          __html: carouselItem.text,
                        }}
                      ></p>
                    </Col>
                  </Row>
                </Container>
              </Carousel.Item>
            );
          })}
        </Carousel>
      </Modal.Body>
    </Modal>
  );
}
