import React from "react";
import { Col, Row } from "react-bootstrap";
import "./errorComponent.css";
import { slideInRight, fadeIn } from "react-animations";
import Radium, { StyleRoot } from "radium";
function ErrorComponent({ data, goToQuizSection }) {
  const goToQuiz = (event) => {
    event.stopPropagation();
    let elem = document.querySelector(".sectionContinueBtn");
    const evt = new CustomEvent("GTM-custom-event", {
      detail: { actionLabel: "Continue", fromAssess: "section" },
    });
    document.dispatchEvent(evt);
    goToQuizSection();
  };
  const styles = {
    slideInRight: {
      animation: "x 2s",
      animationName: Radium.keyframes(slideInRight, "slideInRight"),
    },
    fadeIn: {
      animation: "x 2s",
      animationName: Radium.keyframes(fadeIn, "fadeIn"),
    },
  };
  return (
    <div>
      <Row
        className={
          data?.isQuizCompletion
            ? "sectionMainView completionDetailsMainView"
            : "sectionMainView"
        }
      >
        <Col
          xs={12}
          md={6}
          className={
            data?.isQuizCompletion
              ? "sectionDetailsView completionDetailsView"
              : "sectionDetailsView"
          }
        >
          <StyleRoot
            style={data.isAnimate ? styles.slideInRight : styles.fadeIn}
            className="displayDesktopDeviceError"
          >
            <div>
              <p
                className={
                  data?.isQuizCompletion
                    ? "sectionTitle completionTitle"
                    : "sectionTitle"
                }
              >
                {data?.title}
              </p>
              {data?.description ? (
                <p
                  className={
                    data?.isQuizCompletion
                      ? "sectionDescError completionDesc"
                      : "sectionDescError"
                  }
                >
                  {data?.description}
                </p>
              ) : null}
            </div>

            {!data?.isQuizCompletion ? (
              <button className="sectionContinueBtn" onClick={goToQuiz}>
                Restart
              </button>
            ) : null}
          </StyleRoot>
          <div className="displayMobileDevice">
            {!data?.isQuizCompletion ? (
              <button className="sectionContinueBtn" onClick={goToQuiz}>
                Restart
              </button>
            ) : null}
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default ErrorComponent;
