import React, { useState } from "react";
import { Button, Modal, Row } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import "./helpText.scss";
export default function HelpText({
  show,
  onHide,
  title,
  titleOne,
  isExitModal,
  text,
}) {
  const [exitBtnClick, setexitBtnClick] = useState(false);

  const exitBtnclick = () => {
    setexitBtnClick(true);
  };

  return (
    <Modal className="helpTextArea" show={show} onHide={onHide} centered>
      <Modal.Header closeButton></Modal.Header>
      <Modal.Body>
        <Card className="helpTextContainer">
          <Row>
            <div className="helpTextTitle">{title}</div>
          </Row>
          <Row>
            <div className="helpTextDescription">{text}</div>
          </Row>
        </Card>
      </Modal.Body>
    </Modal>
  );
}
