import React, { useEffect, useState } from "react";
import ArrowBlack from "../../../assets/images/Arrow-black.png";
import Img from "../../../assets/images/Img.png";
import "./articleComponent.scss";

export default function ArticleComponent({
  changeScreen,
  artlceList,
  readMoreLinkFn,
}) {
  console.log("artlceList", artlceList);
  const changeToArticleScreen = (readmore) => {
    let domain = readmore
      .replace("http://", "")
      .replace("https://", "")
      .split(/[/?#]/)[0];
    console.log("domain", domain);
    if (domain != "") {
      window.open(readmore, "_blank");
      return false;
    }
    readMoreLinkFn(readmore);
    changeScreen("ARTICLE");
  };

  return (
    <div className="articleContainer">
      <div className="title">
        Learn about symptoms of heart attacks & strokes
      </div>
      <div className="articleList">
        {artlceList.length > 0 &&
          artlceList.map((article, i) => {
            return (
              <div className="articleItem" key={i}>
                <div
                  className="image-article"
                  style={{
                    backgroundImage: `url(${article.image})`,
                  }}
                ></div>
                <div className="content">
                  <div className="description">{article.title}</div>
                  <div
                    className="readmore"
                    onClick={() => changeToArticleScreen(article.readmore)}
                  >
                    Read more
                    <img src={ArrowBlack} />
                  </div>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}
