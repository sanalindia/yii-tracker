import React, { useEffect, useState } from "react";
import lowRiskLove from "../../../assets/images/lowRiskLove.png";
import averageRiskLove from "../../../assets/images/averageRiskLove.png";
import highRiskLove from "../../../assets/images/highRiskLove.png";
import information_icon_low from "../../../assets/images/information_icon_low.png";
import information_icon_high from "../../../assets/images/information_icon_high.png";
import { pulse } from "react-animations";
import Radium, { StyleRoot } from "radium";
import "./riskLoveComponent.scss";
import HelpText from "../helpText/helpText";

export default function RiskLoveComponent(props) {
  const riskClass = props.riskClass;
  console.log("type ", typeof riskClass);
  const [modalShow, setModalShow] = useState();
  const styles = {
    pulse: {
      animation: "y 1s",
      animationName: Radium.keyframes(pulse, "pulse"),
    },
  };
  useEffect(() => {
    const risk = props.riskClass.toLowerCase() + " risk";
    const evt = new CustomEvent("GTM-custom-event", {
      detail: { actionLabel: risk, fromAssess: "onloadresult" },
    });
    document.dispatchEvent(evt);
    // Make HTTP call or other code
  }, [riskClass]);
  return (
    <div>
      {
        {
          LOWER: (
            <StyleRoot>
              <div style={styles.pulse}>
                <div className="riskLoveContainer low">
                  <img src={lowRiskLove} />
                  <div className="riskContent">
                    <div className="yearWise"></div>
                    <div className="lowRisk"></div>
                    <div className="riskCVDContent"></div>
                  </div>
                </div>
              </div>
            </StyleRoot>
          ),
          AVERAGE: (
            <StyleRoot>
              <div style={styles.pulse}>
                <div className="riskLoveContainer average">
                  <img src={averageRiskLove} />
                  <div className="riskContent">
                    <div className="lowRisk"></div>
                  </div>
                </div>
              </div>
            </StyleRoot>
          ),
          HIGHER: (
            <StyleRoot>
              <div style={styles.pulse}>
                <div className="riskLoveContainer low">
                  <img src={highRiskLove} />
                  <div className="riskContent">
                    <div className="yearWise"></div>
                    <div className="lowRisk"></div>
                  </div>
                </div>
              </div>
            </StyleRoot>
          ),
        }[riskClass]
      }
    </div>
  );
}
