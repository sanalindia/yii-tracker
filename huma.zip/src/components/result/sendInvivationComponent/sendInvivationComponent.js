import React, { useEffect, useState } from "react";

import "./sendInvivationComponent.scss";
import ArrowBlack from "../../../assets/images/Arrow-black.png";
import ReactShare from "../reactShare/reactShare";
import EmailResultComponent from "../emailResult/emailResult";
import { Constants } from "../../../Constants";

export default function SendInvivationComponent(props) {
  const riskClass = props.riskClass;
  console.log("type ", typeof riskClass);
  const [modalShow, setModalShow] = useState();

  const openMailBox = () => {
    window.location.assign(
      "mailto:?Subject=You’re Invited – Find Out Your Heart Health Risk&body= Hi, %0D%0A %0D%0A I used this quick assessment to find out more about my heart health , you might want to try it too.%0D%0A %0D%0A Link: https://www.bayeraspirin.com/heart-attack-and-stroke-risk-assessment/ "
    );
    // setModalShow(true);
  };
  useEffect(() => {
    // Make HTTP call or other code
  }, [riskClass]);

  return (
    <div
      className="talkToDotor"
      style={riskClass === "LOWER" ? { order: 1 } : {}}
    >
      {
        {
          LOWER: (
            <div
              className={
                riskClass === "LOWER"
                  ? "shareArea low lowercase"
                  : "shareArea low"
              }
            >
              <div className="heading">
                Be proactive: Get a heart health care plan
              </div>
              <p>
                Make sure to talk to your doctor or healthcare professional
                about your risk. Annual or regular visits are a great time to do
                this. If you've recently been, it's great to follow up soon.
              </p>
              <div className="parentButton">
                <div className="talktoButton">
                  <a
                    href="/heart-health/doctor/talk-to-your-doctor-about-heart-attack-risks/"
                    rel="noreferrer"
                    target="_blank"
                  >
                    <span> Questions to start the conversation</span>
                  </a>
                </div>
                <div
                  className="talktoButton"
                  onClick={() => setModalShow(true)}
                >
                  Share results with my doctor or healthcare professional
                </div>
              </div>
            </div>
          ),
          AVERAGE: (
            <div className="shareArea average">
              <div className="heading">
                Help save lives by sharing this quick assessment
              </div>
              <p>Encourage loved ones to check their heart risk factors now.</p>
              <div className="talktoButton1" onClick={openMailBox}>
                Send invitation <img src={ArrowBlack} />
              </div>
            </div>
          ),
          HIGHER: (
            <div className="shareArea high">
              <div className="heading">
                Help save lives by sharing this quick assessment
              </div>
              <p>Encourage loved ones to check their heart risk factors now.</p>
              <div className="talktoButton1" onClick={openMailBox}>
                Send invitation <img src={ArrowBlack} />
              </div>
            </div>
          ),
        }[riskClass]
      }
      <EmailResultComponent
        show={modalShow}
        onHide={() => {
          setModalShow(false);
          props.resendEmail();
        }}
        title={"Share results with my doctor or healthcare professional"}
        description={
          "Please carefully review the email address you are entering before submitting. Understand that by entering an email address you are consenting to your results being sent to the address and party you provide. As a result, Bayer’s Privacy Statement will not apply to the information that is leaving this site."
        }
        isExitModal={false}
        downloadClick={props.downloadClick}
        text={""}
        emailSent={props.emailSent}
        resendEmail={props.resendEmail}
        hcp={props.hcp}
      />
    </div>
  );
}
