import React, { useState } from "react";
import back_arrow from "../../../assets/images/back_arrow.png";
import "./backButton.scss";
export default function BackButton({ changeScreen, text }) {
  return (
    <div className="backButtonContainer" onClick={() => changeScreen("RESULT")}>
      <img src={back_arrow} />
      <span>{text}</span>
    </div>
  );
}
