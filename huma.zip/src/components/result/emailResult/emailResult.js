import React, { useState } from "react";
import { Button, Modal, Row } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import "./emailResult.scss";
import parse from "html-react-parser";

export default function EmailResultComponent({
  show,
  onHide,
  title,
  description,
  titleOne,
  isExitModal,
  text,
  downloadClick,
  emailSent,
  resendEmail,
  hcp,
}) {
  console.log("emailSent", emailSent);
  const [error, setEror] = useState(false);

  const sendResultValidate = () => {
    let emailID = document.myForm.email.value;
    let atpos = emailID.indexOf("@");
    let dotpos = emailID.lastIndexOf(".");

    if (atpos < 1 || dotpos - atpos < 2) {
      setEror(true);
      document.myForm.email.focus();
      return false;
    }
    setEror(false);
    downloadClick(emailID, hcp);
  };

  return (
    <Modal
      className="emailResultComponent"
      show={show}
      onHide={onHide}
      centered
    >
      <Modal.Header closeButton>
        {/* <Modal.Title>{title}</Modal.Title> */}
      </Modal.Header>
      <Modal.Body>
        <Card className="emailResultComponentCard">
          {emailSent ? (
            <Row className="successEmail">
              <div className="text text-success"> Email sent successfully</div>
              <div className="">
                If you didn't recieve please click{" "}
                <span onClick={() => resendEmail(false)}>here</span> to resend{" "}
              </div>
            </Row>
          ) : (
            <>
              {" "}
              <Row>
                <div className="helpTextTitle">{title}</div>
                <div className="helpTextDescription">{description}</div>
              </Row>
              <Row>
                <div>
                  <div className="emailResultComponentContinueDiv">
                    <p>{text ? parse(text) : ""}</p>
                  </div>
                  <div className="myForm">
                    <form name="myForm">
                      {error ? (
                        <p className="errorValide">
                          Please enter valid email address
                        </p>
                      ) : (
                        ""
                      )}
                      <input
                        type="text"
                        name={"email"}
                        className={error ? "errorClass" : ""}
                        placeholder="Email Address"
                      />
                    </form>
                  </div>
                  {text ? (
                    <div className="assessmentIntroCheckbox">
                      <div className="assessmentIntroCheckboxIcon form-check">
                        <input
                          type="checkbox"
                          id="checkboxes"
                          className="form-check-input"
                        />
                      </div>
                      <label
                        title=""
                        className="form-check-label"
                        htmlFor="checkboxes"
                      >
                        <p className="introTermsText" htmlFor="checkboxes">
                          I want to receive marketing and promotional offers via
                          email from Bayer’s U.S. Consumer Health division,
                          based on the personal information I provided. I
                          understand that I can withdraw my consent to Bayer
                          processing my information at any time
                        </p>
                      </label>
                    </div>
                  ) : (
                    ""
                  )}

                  {/* <div className="emailResultComponentExitDiv"> */}
                  <Button
                    className={"sendResultValidate"}
                    onClick={() => sendResultValidate()}
                  >
                    Send Results
                  </Button>
                  {/* </div> */}
                </div>
              </Row>
            </>
          )}
        </Card>
      </Modal.Body>
    </Modal>
  );
}
