import React, { useEffect, useState } from "react";

import MailIcon from "../../../assets/images/mail-icon.png";
import { Constants } from "../../../Constants";
import EmailResultComponent from "../emailResult/emailResult";
import "./emailResultButton.scss";

export default function EmailResultButton({
  downloadClick,
  riskClass,
  emailSent,
  resendEmail,
  hcp,
}) {
  const [modalShow, setModalShow] = useState();
  console.log("riskClass", riskClass);
  return (
    <div className="buttonContainer">
      <div onClick={() => setModalShow(true)}>
        <span>
          Get my results <img src={MailIcon} />
        </span>
      </div>
      <EmailResultComponent
        show={modalShow}
        onHide={() => {
          setModalShow(false);
          resendEmail();
        }}
        title={"Email Results"}
        isExitModal={false}
        downloadClick={downloadClick}
        text={Constants[riskClass].emailDescription}
        emailSent={emailSent}
        resendEmail={resendEmail}
        hcp={hcp}
      />
    </div>
  );
}
