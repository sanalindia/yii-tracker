import React, { useEffect, useState, useRef } from "react";
import "./aboutRisk.scss";

export default function AboutRisk() {
  /* end chart */

  return (
    <div className="aboutRiskContainer">
      <div className="title">About the Risk Assessment</div>
      <p className="description">
        This assessment is based on data from 466,052 participants in the UK
        recruited from 2006 to 2010. The assessment estimates your 10-year risk
        of CVD by comparing your answers to the research population. This
        assessment asks about well known risk factors for CVD. The research is
        published in{" "}
        <a
          href="https://academic.oup.com/ehjdh/advance-article/doi/10.1093/ehjdh/ztab057/6310013"
          target="_blank"
        >
          {" "}
          European Heart Journal Digital Health (EHJ-DH)
        </a>
        .
      </p>
    </div>
  );
}
