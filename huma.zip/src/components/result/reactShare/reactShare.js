import React, { useState } from "react";
import { Button, Modal, Row } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import "./reactShare.scss";
import {
  FacebookShareButton,
  TwitterShareButton,
  TelegramShareButton,
  LinkedinShareButton,
  WhatsappShareButton,
} from "react-share";
import {
  FacebookIcon,
  TwitterIcon,
  TelegramIcon,
  LinkedinIcon,
  WhatsappIcon,
} from "react-share";

import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Tooltip from "react-bootstrap/Tooltip";

export default function ReactShare({
  show,
  onHide,
  title,
  titleOne,
  isExitModal,
  text,
}) {
  const [exitBtnClick, setexitBtnClick] = useState(false);

  const exitBtnclick = () => {
    setexitBtnClick(true);
  };

  return (
    <Modal className="reactShare" show={show} onHide={onHide} centered>
      <Modal.Header closeButton></Modal.Header>
      <Modal.Body>
        <Card className="reactShareCard">
          <Row>
            <div className="title">Share</div>
          </Row>
          <Row>
            <div className="shareContainer">
              <div className="shareItem">
                <OverlayTrigger
                  key={"bottom"}
                  placement={"bottom"}
                  overlay={<Tooltip>Facebook</Tooltip>}
                >
                  <FacebookShareButton
                    url={"https://www.bayeraspirin.com/be-heart-smart/"}
                    quote={"HUMA - Cardiovascular Risk Asessment Tool"}
                    title={"Facebook Share"}
                    // hashtag={"#Cardiovascular Risk Asessment Tool"}
                    description={`Understand your heart with our quick assessment*. You’ll learn about your potential risk of getting cardiovascular disease** – and how to take care of your heart today.`}
                    className="Demo__some-network__share-button"
                  >
                    <FacebookIcon size={32} round />
                  </FacebookShareButton>
                </OverlayTrigger>
              </div>
              <div className="shareItem">
                <OverlayTrigger
                  key={"bottom"}
                  placement={"bottom"}
                  overlay={<Tooltip>Twitter</Tooltip>}
                >
                  <TwitterShareButton
                    title={"Facebook Share"}
                    url={"https://www.bayeraspirin.com/be-heart-smart/"}
                    // hashtags={["hashtag1", "hashtag2"]}
                  >
                    <TwitterIcon size={32} round />
                  </TwitterShareButton>
                </OverlayTrigger>
              </div>
              <div className="shareItem">
                <OverlayTrigger
                  key={"bottom"}
                  placement={"bottom"}
                  overlay={<Tooltip>Telegram</Tooltip>}
                >
                  <TelegramShareButton
                    url={"https://www.bayeraspirin.com/be-heart-smart/"}
                  >
                    <TelegramIcon size={32} round />
                  </TelegramShareButton>
                </OverlayTrigger>
              </div>
              <div className="shareItem">
                <OverlayTrigger
                  key={"bottom"}
                  placement={"bottom"}
                  overlay={<Tooltip>Linkedin</Tooltip>}
                >
                  <LinkedinShareButton
                    url={"https://www.bayeraspirin.com/be-heart-smart/"}
                  >
                    <LinkedinIcon size={32} round />
                  </LinkedinShareButton>
                </OverlayTrigger>
              </div>
              <div className="shareItem">
                <OverlayTrigger
                  key={"bottom"}
                  placement={"bottom"}
                  overlay={<Tooltip>Whatsapp</Tooltip>}
                >
                  <WhatsappShareButton
                    url={"https://www.bayeraspirin.com/be-heart-smart/"}
                    title={"HUMA - Cardiovascular Risk Asessment Tool"}
                  >
                    <WhatsappIcon size={32} round />
                  </WhatsappShareButton>
                </OverlayTrigger>
              </div>
            </div>
          </Row>
        </Card>
      </Modal.Body>
    </Modal>
  );
}
