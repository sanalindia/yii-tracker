import React, { useCallback, useEffect, useState } from "react";

import Arrow from "../../../assets/images/Arrow.png";
import ArrowBlack from "../../../assets/images/Arrow-black.png";
import icnAlert from "../../../assets/images/icn-alert.png";
import "./inviteFriend.scss";
import ReactShare from "../reactShare/reactShare";
import { fadeInRight } from "react-animations";
import Radium, { StyleRoot } from "radium";
import EmailResultComponent from "../emailResult/emailResult";

const MAX_MOBILE_SCREEN_WIDTH = 768;

export default function FriendInvitation(props) {
  const riskClass = props.riskClass;
  console.log("type ", typeof riskClass);
  const [modalShow, setModalShow] = useState();
  const [isMobile, setIsMobile] = useState(
    window.innerWidth <= MAX_MOBILE_SCREEN_WIDTH
  );

  const handleWindowSizeChange = useCallback(() => {
    setIsMobile(window.innerWidth <= MAX_MOBILE_SCREEN_WIDTH);
  }, []);

  useEffect(() => {
    document.querySelectorAll(
      '.inviFriend div[data-radium="true"]'
    )[0].style.height = "100%";
    // Make HTTP call or other code
    window.addEventListener("resize", handleWindowSizeChange);

    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
  }, [riskClass, handleWindowSizeChange]);

  const styles = {
    fadeInRight: {
      animation: "x 2s",
      animationName: Radium.keyframes(fadeInRight, "fadeInRight"),
    },
  };

  const goToRiskScore = () => {
    var reviewRect = document
      .getElementById("cvdRiskScoreDetails")
      ?.getBoundingClientRect();
    var topPos = reviewRect.top + window.scrollY;
    window.parent.scrollTo(0, topPos);
  };

  const openMailBox = () => {
    window.location.assign(
      "mailto:?Subject=You’re Invited – Find Out Your Heart Health Risk&body= Hi, %0D%0A %0D%0A I used this quick assessment to find out more about my heart health , you might want to try it too.%0D%0A %0D%0A Link: https://www.bayeraspirin.com/heart-attack-and-stroke-risk-assessment/ "
    );
  };

  return (
    <StyleRoot
      className="inviFriend"
      style={riskClass === "LOWER" ? { order: 2 } : {}}
    >
      <div style={isMobile ? styles.fadeInRight : null}>
        <div
          className={
            riskClass === "LOWER" ? "secondArea lowercase" : "secondArea"
          }
        >
          {
            {
              LOWER: (
                <div className="shareArea low">
                  <div className="heading">
                    Help save lives by sharing this quick assessment
                  </div>
                  <div className="inVitPtext">
                    Encourage loved ones to check their heart risk factors now.
                  </div>
                  <div className="sendInvitation" onClick={openMailBox}>
                    Send invitation <img src={Arrow} />
                  </div>
                </div>
              ),
              AVERAGE: (
                <div className="shareArea average">
                  <div className="heading">
                    Be proactive: Get a heart health care plan
                  </div>
                  <div className="inVitPtext">
                    Make sure to talk to your doctor or healthcare professional
                    about your risk. Annual or regular visits are a great time
                    to do this. If you've recently been, it's great to follow up
                    soon.
                  </div>
                  <div className="parentButton">
                    <div className="talkToButton">
                      <span>
                        <a
                          href="/heart-health/doctor/talk-to-your-doctor-about-heart-attack-risks/"
                          rel="noreferrer"
                          target="_blank"
                        >
                          Questions to start the conversation
                        </a>
                      </span>
                    </div>
                    <div
                      className="talkToButton"
                      onClick={() => setModalShow(true)}
                    >
                      <span>
                        Share results with my doctor or healthcare professional
                      </span>
                    </div>
                  </div>
                </div>
              ),
              HIGHER: (
                <div className="shareArea high">
                  <div className="heading">
                    <img src={icnAlert} />
                    <span>Get your heart checked now</span>
                  </div>
                  <div className="inVitPtext">
                    Make it a priority to talk to your doctor or healthcare
                    professional soon based on your risk factors. Annual or
                    regular visits are a great time to talk to your doctor or
                    healthcare professional about your heart risk factors. If
                    you've recently been, it's great to follow up soon.
                  </div>
                  <div className="parentButton">
                    <div className="talkToButton1">
                      <span>
                        <a
                          href="/heart-health/doctor/talk-to-your-doctor-about-heart-attack-risks/"
                          rel="noreferrer"
                          target="_blank"
                        >
                          Questions to start the conversation
                        </a>
                      </span>
                    </div>
                    <div
                      className="talkToButton1"
                      onClick={() => setModalShow(true)}
                    >
                      <span>
                        {" "}
                        Share results with my doctor or healthcare professional
                      </span>
                    </div>
                  </div>
                </div>
              ),
            }[riskClass]
          }
          <EmailResultComponent
            show={modalShow}
            onHide={() => {
              setModalShow(false);
              props.resendEmail();
            }}
            title={"Share results with my doctor or healthcare professional"}
            description={
              "Please carefully review the email address you are entering before submitting. Understand that by entering an email address you are consenting to your results being sent to the address and party you provide. As a result, Bayer’s Privacy Statement will not apply to the information that is leaving this site."
            }
            isExitModal={false}
            downloadClick={props.downloadClick}
            text={""}
            emailSent={props.emailSent}
            resendEmail={props.resendEmail}
            hcp={props.hcp}
          />
        </div>
      </div>
    </StyleRoot>
  );
}
