import React, { useCallback, useEffect, useState } from "react";
import "./optionsCard.css";
import RangeSlider from "../../elements/rangeSlider/rangeSlider";
import CustomMultiSelectOption from "../../elements/customMultiSelectOption/customMultiSelectOption";
import CustomSingleSelectOption from "../../elements/customSingleSelectOption/customSingleSelectOption";
import CircularOptionsCard from "../circularOptionsCard/circularOptionsCard";
import CustomModal from "../customModal/customModal";
import HeartFrame_1 from "../../assets/images/Heart-Frame_1.png";
import Frame_1 from "../../assets/images/Frame_1.png";
import Group_1 from "../../assets/images/Group_1.png";
import PulseCheck_1 from "../../assets/images/pulse_check_1.png";
import Waist from "../../assets/images/frame-waist.png";
import Hip from "../../assets/images/frame-hip.png";
import CarouselModal from "../carouselModal/carouselModal";
import alertIcon from "../../assets/images/alert_icon_red.png";

export default function OptionsCard({
  quizNo,
  optionsList,
  answerOptionsSelected,
  isContinueClicked,
  isOptionError,
  resetOptionError,
  previousSelectedData,
  sliderValueUpdated,
  isSubOptionError,
  resetSubOptionError,
}) {
  const [sliderValue, setSliderValue] = useState(0);
  const [waistSizeValue, setWaistSizeValue] = useState(0);
  const [hipSizeValue, setHipSizeValue] = useState(0);
  const [modalShow, setModalShow] = useState(false);

  const handleSliderInitialValue = useCallback(() => {
    const previousSelectedValue =
      previousSelectedData &&
      previousSelectedData.hasOwnProperty(`quiz${quizNo}`)
        ? previousSelectedData[`quiz${quizNo}`]
        : "";

    let sliderInitialValue;
    switch (quizNo) {
      case 1:
        sliderInitialValue = previousSelectedValue || 18;
        break;
      case 6:
        sliderInitialValue = previousSelectedValue || 30;
        break;
      case 7:
        sliderInitialValue = 0;
        break;
      case 8:
        sliderInitialValue = previousSelectedValue || 1;
        break;
      default:
        sliderInitialValue = 0;
    }
    return sliderInitialValue;
  }, [quizNo, previousSelectedData]);

  useEffect(() => {
    const value = handleSliderInitialValue();
    if (quizNo === 7) {
      const previousSelectedWaistValue =
        previousSelectedData &&
        previousSelectedData.hasOwnProperty(`quiz${quizNo}Waist`)
          ? previousSelectedData[`quiz${quizNo}Waist`]
          : "";
      const previousSelectedHipValue =
        previousSelectedData &&
        previousSelectedData.hasOwnProperty(`quiz${quizNo}Hip`)
          ? previousSelectedData[`quiz${quizNo}Hip`]
          : "";
      setWaistSizeValue(previousSelectedWaistValue || value);
      setHipSizeValue(previousSelectedHipValue || value);
    } else {
      setSliderValue(value);
    }
  }, [handleSliderInitialValue, quizNo, previousSelectedData]);

  const onChangeSlider = (sliderType, value) => {
    if (sliderType === "WaistSize") {
      setWaistSizeValue(value);
    } else if (sliderType === "HipSize") {
      setHipSizeValue(value);
    } else {
      setSliderValue(value);
    }
  };

  // slider change completion callback
  const sliderValueChanged = (sliderType, value) => {
    sliderValueUpdated(sliderType, value);
  };

  const carouselItemOne = [
    {
      title: "How to figure it out",
      text: "If you own a wearable fitness device, use this to measure your resting heart rate. If not, follow the next steps.",
      imageSRC: Group_1,
      imageALT: "Smart Watch icon",
    },
    {
      title: "How to figure it out",
      text: "<strong>Step 1:</strong> Make sure your heart is resting, ie., not immediately after a workout or caffeine fix.",
      imageSRC: HeartFrame_1,
      imageALT: "Heart Rate Step 1 Icon",
    },
    {
      title: "How to figure it out",
      text: "<strong>Step 2:</strong> Place your middle finger and index finger on your wrist or neck to find your pulse.",
      imageSRC: PulseCheck_1,
      imageALT: "Heart Rate Step 2 Icon",
    },
    {
      title: "How to figure it out",
      text: "<strong>Step 3:</strong> Count the number of beats in 15 seconds, and multiply by four – that's your heart rate.",
      imageSRC: Frame_1,
      imageALT: "Heart Rate Step 3 Icon",
    },
  ];

  const carouselItemTwo = [
    {
      title: "Where to measure",
      text: "Waist",
      imageSRC: Waist,
      imageALT: "Waist measurement position",
    },
    {
      title: "Where to measure",
      text: "Hips",
      imageSRC: Hip,
      imageALT: "Hips measurement position",
    },
  ];

  const intersexLabelBtnClicked = () => {
    setModalShow(true);
  };

  const heartRateInfoBtnClicked = () => {
    setModalShow(true);
  };

  const measuringInfoBtnClicked = () => {
    setModalShow(true);
  };

  const optionsSelected = (data) => {
    answerOptionsSelected(data);
  };

  return (
    <div
      className={
        isOptionError
          ? `quiz${quizNo}OptionsView optionErrorQuizView`
          : `quiz${quizNo}OptionsView`
      }
    >
      {isOptionError ? (
        <div className="optionsErrorView">
          <img
            className="optionsErrorIcon"
            src={alertIcon}
            alt="options alert icon"
          />
          <p className="optionsErrorText">Select an option</p>
        </div>
      ) : null}

      {quizNo === 1 ? (
        <div className="ageSlider">
          <React.Fragment key="ageSliderView">
            <RangeSlider
              minValue={18}
              maxValue={100}
              progressStep={1}
              isTooltip={true}
              keepTooltip={true}
              initialValue={sliderValue}
              type="age"
              onChangeSlider={onChangeSlider}
              sliderValueChanged={sliderValueChanged}
              quizNo={quizNo}
              optionsSelected={optionsSelected}
              isContinueClicked={isContinueClicked}
              isOptionError={isOptionError}
              resetOptionError={resetOptionError}
            />
          </React.Fragment>
        </div>
      ) : null}
      {quizNo === 2 ||
      quizNo === 3 ||
      quizNo === 5 ||
      quizNo === 9 ||
      quizNo === 11 ? (
        <div className={isOptionError ? "vertical_shake" : null}>
          <div className="singleSelectView">
            <React.Fragment key={`singleOptions-${quizNo}`}>
              <CustomSingleSelectOption
                optionsList={optionsList}
                quizNo={quizNo}
                optionsSelected={optionsSelected}
                isContinueClicked={isContinueClicked}
                isOptionError={isOptionError}
                resetOptionError={resetOptionError}
                previousSelectedValue={
                  previousSelectedData &&
                  previousSelectedData.hasOwnProperty(`quiz${quizNo}`)
                    ? previousSelectedData[`quiz${quizNo}`]
                    : ""
                }
                isSubOptionError={isSubOptionError}
                resetSubOptionError={resetSubOptionError}
              />
            </React.Fragment>
          </div>
        </div>
      ) : null}
      {quizNo === 4 ? (
        <div className={isOptionError ? "vertical_shake" : null}>
          <div className="singleSelectView">
            <React.Fragment key={`singleOptions-${quizNo}`}>
              <CustomSingleSelectOption
                optionsList={optionsList}
                quizNo={quizNo}
                optionsSelected={optionsSelected}
                isContinueClicked={isContinueClicked}
                isOptionError={isOptionError}
                resetOptionError={resetOptionError}
                previousSelectedValue={
                  previousSelectedData &&
                  previousSelectedData.hasOwnProperty(`quiz${quizNo}`)
                    ? previousSelectedData[`quiz${quizNo}`]
                    : ""
                }
              />

              <button
                className="intersexLabelBtn"
                onClick={intersexLabelBtnClicked}
              >
                <p className="intersexLabel">I’m intersex</p>
              </button>
              <CustomModal
                show={modalShow}
                onHide={() => setModalShow(false)}
                title={"I’m intersex"}
                isExitModal={false}
                text={
                  "It’s estimated that between 0.05% and 1.7% of people are born with sex traits that don’t fit neatly into either binary definition of male or female. If this affects you and you’re not sure how to answer, we recommend asking your healthcare professional for advice."
                }
              />
            </React.Fragment>
          </div>
        </div>
      ) : null}
      {quizNo === 6 ? (
        <>
          <div className="heartRateIconView">
            <p className="heartRateValueView">
              <span className="heartRateValue">{sliderValue}</span>
              <span className="heartRateValueText">BPM</span>
            </p>
          </div>
          <div className="heartRateSlider">
            <React.Fragment key="heartRateSliderView">
              <RangeSlider
                minValue={30}
                maxValue={174}
                progressStep={1}
                isTooltip={false}
                keepTooltip={false}
                initialValue={sliderValue}
                type="heartRate"
                onChangeSlider={onChangeSlider}
                sliderValueChanged={sliderValueChanged}
                quizNo={quizNo}
                optionsSelected={optionsSelected}
                isContinueClicked={isContinueClicked}
                isOptionError={isOptionError}
                resetOptionError={resetOptionError}
              />
            </React.Fragment>
          </div>
          <button
            className="heartRateInfoBtn"
            onClick={heartRateInfoBtnClicked}
          >
            <p className="heartRateInfoText">How to work it out</p>
          </button>
          <CarouselModal
            carouselItem={carouselItemOne}
            show={modalShow}
            onHide={() => setModalShow(false)}
          />
        </>
      ) : null}
      {quizNo === 7 ? (
        <>
          <div className="sizeSelectorMainView">
            {optionsList.map((item, index) => (
              <React.Fragment key={`${item.title}SizeSlider`}>
                <div className="sizeSelectorView">
                  <p className="sizeSelectorTitle">{item.title}</p>
                  <div className="sizeSlider">
                    <RangeSlider
                      minValue={0}
                      maxValue={196}
                      progressStep={1}
                      isTooltip={true}
                      keepTooltip={true}
                      initialValue={index === 0 ? waistSizeValue : hipSizeValue}
                      type={`${item.title}Size`}
                      onChangeSlider={onChangeSlider}
                      sliderValueChanged={sliderValueChanged}
                      quizNo={quizNo}
                      optionsSelected={optionsSelected}
                      isContinueClicked={isContinueClicked}
                      isOptionError={isOptionError}
                      resetOptionError={resetOptionError}
                    />
                  </div>
                </div>
              </React.Fragment>
            ))}
          </div>
          <button
            className="measuringInfoBtn"
            onClick={measuringInfoBtnClicked}
          >
            <p className="measuringInfoText">Where to measure</p>
          </button>
          <CarouselModal
            carouselItem={carouselItemTwo}
            show={modalShow}
            onHide={() => setModalShow(false)}
          />
        </>
      ) : null}
      {quizNo === 8 ? (
        <div
          className={
            isOptionError
              ? "sliderMainView sliderMainViewWithError"
              : "sliderMainView"
          }
        >
          <div className="ageSlider">
            <React.Fragment key="sleepHoursSliderView">
              <RangeSlider
                minValue={1}
                maxValue={12}
                progressStep={0.25}
                isTooltip={true}
                keepTooltip={true}
                initialValue={sliderValue}
                type="sleepHours"
                onChangeSlider={onChangeSlider}
                sliderValueChanged={sliderValueChanged}
                quizNo={quizNo}
                optionsSelected={optionsSelected}
                isContinueClicked={isContinueClicked}
                isOptionError={isOptionError}
                resetOptionError={resetOptionError}
              />
            </React.Fragment>
          </div>
        </div>
      ) : null}
      {quizNo === 10 ? (
        <div className={isOptionError ? "vertical_shake" : null}>
          <React.Fragment key={`circularOption-${quizNo}`}>
            <CircularOptionsCard
              optionsList={optionsList}
              quizNo={quizNo}
              optionsSelected={optionsSelected}
              isContinueClicked={isContinueClicked}
              isOptionError={isOptionError}
              resetOptionError={resetOptionError}
              previousSelectedValue={
                previousSelectedData &&
                previousSelectedData.hasOwnProperty(`quiz${quizNo}`)
                  ? previousSelectedData[`quiz${quizNo}`]
                  : ""
              }
            />
          </React.Fragment>
        </div>
      ) : null}
      {quizNo === 12 || quizNo === 13 || quizNo === 14 || quizNo === 15 ? (
        <div className={isOptionError ? "vertical_shake" : null}>
          <div className="healthHistoryOptionsView">
            <React.Fragment key={`multiOptions-${quizNo}`}>
              <CustomMultiSelectOption
                optionsList={optionsList}
                quizNo={quizNo}
                optionsSelected={optionsSelected}
                isContinueClicked={isContinueClicked}
                isOptionError={isOptionError}
                resetOptionError={resetOptionError}
                previousSelectedValue={
                  previousSelectedData &&
                  previousSelectedData.hasOwnProperty(`quiz${quizNo}`)
                    ? previousSelectedData[`quiz${quizNo}`]
                    : ""
                }
              />
            </React.Fragment>
          </div>
        </div>
      ) : null}
    </div>
  );
}
