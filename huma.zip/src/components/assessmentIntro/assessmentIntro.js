import React, { useState, useEffect } from "react";
import { Button, Form, Stack } from "react-bootstrap";
import "./assessmentIntro.scss";
import Header from "../header/header";
import alertIcon from "../../assets/images/alert_icon_red.png";

export default function AssessmentIntro({
  submitAssessmentIntro,
  previousUsername,
}) {
  const [username, setUsername] = useState(previousUsername || "");
  const [termsCheckbox, setTermsCheckbox] = useState(false);
  const [isIntroError, setIntroError] = useState(false);
  const [introErrorText, setIntroErrorText] = useState("");

  useEffect(() => {
    const assessmentPage = document.getElementsByClassName("assessmentIntroHeading");
    const evt = new CustomEvent("GTM-custom-event", {
      detail: { actionLabel: "GET HEART SMART IN THREE MINUTES", fromAssess: "onload", },
    });
    document.dispatchEvent(evt);
  }, [])

  const backBtnClicked = () => {
    window.parent.location.href = "/be-heart-smart/";
  };

  const termsCheckboxClicked = (checkedStatus) => {
    setIntroError(false);
    setTermsCheckbox(checkedStatus);
  };

  const usernameChanged = (value) => {
    setIntroError(false);
    setIntroErrorText("");
    setUsername(value);
  };

  const isUsernameValid = (name) => {
    var regName = /^[a-zA-Z][a-zA-Z\s]*$/;
    if (!regName.test(name)) {
      return false;
    }
    return true;
  };

  const submitBtnClicked = (event) => {
    event.stopPropagation();
    let elem = document.querySelector(".assessmentIntroButton");
    const evt = new CustomEvent("GTM-custom-event", {
      detail: { actionLabel: "N/A", fromAssess: "letsgo" },
    });
    document.dispatchEvent(evt);
    if (username !== "" && termsCheckbox && isUsernameValid(username)) {
      submitAssessmentIntro(username);
    } else {
      if (username === "") {
        setIntroErrorText("Please enter your name");
      } else if (username !== "" && !isUsernameValid(username)) {
        setIntroErrorText("Please enter valid name");
      }
      setIntroError(true);
    }
  };

  return (
    <>
      <Header
        showBackTextInMobile={true}
        showCloseIcon={false}
        backButtonAction={backBtnClicked}
      />
      <Stack className="assessmentIntroStack" gap={3}>
        <h1 className="assessmentIntroHeading">
          Take our heart smart assessment
        </h1>
        <div className="assessmentIntroDiv">
          It’s simple: you answer <span className="textBold">15 quick questions</span>{" "}and then we explain what your answers reveal about your heart health and tips to help you have a conversation with your doctor or healthcare professional.
        </div>
        <Form>
          <Form.Group className="assessmentIntroUsername">
            <Form.Label>What’s your name?</Form.Label>
            {introErrorText ? (
              <div className="assessmentIntroError">
                <img
                  className="assessmentErrorIcon"
                  src={alertIcon}
                  alt="options alert icon"
                />
                <p className="assessmentIntroErrorText">{introErrorText}</p>
              </div>
            ) : null}
            <div className={isIntroError ? "vertical_shake" : null}>
              <Form.Control
                className={
                  isIntroError && username === ""
                    ? "assessmentIntroTextarea introTextAreaError"
                    : "assessmentIntroTextarea"
                }
                type="text"
                placeholder="Answer here"
                value={username}
                onChange={(event) => usernameChanged(event.target.value)}
              />
            </div>
          </Form.Group>
          <Form.Group className="assessmentIntroCheckbox">
            <Form.Check
              type="checkbox"
              label=""
              className={
                isIntroError && !termsCheckbox
                  ? "assessmentIntroCheckboxIcon introCheckboxIconError"
                  : "assessmentIntroCheckboxIcon"
              }
              checked={termsCheckbox}
              onChange={(event) =>
                termsCheckboxClicked(event.currentTarget.checked)
              }
            />

            <p
              onClick={() => termsCheckboxClicked(!termsCheckbox)}
              className="introTermsText"
            >
              By continuing, you consent to Bayer collecting your personal
              information, including certain health information. Bayer will
              process your information to provide you with results for this
              assessment. For more details on how Bayer handles personal data,
              please read our <a className="checkboxLink textBold" href="https://www.livewell.bayer.com/privacy-statement" target="_blank" rel="noreferrer"><u>Privacy Statement</u></a>
              {/* By continuing, you are agreeing to share personal information with
              us during the assesssment.{" "}
              <span className="textBold"> We never keep your data</span> - it
              will only be used to work out your result. */}
            </p>
          </Form.Group>
        </Form>
        <Button
          className="assessmentIntroButton"
          variant="primary"
          type="submit"
          onClick={submitBtnClicked}
        >
          Let’s go
        </Button>
      </Stack>
    </>
  );
}
