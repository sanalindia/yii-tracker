import React, { useState } from "react";
import { Button, Modal, Row } from "react-bootstrap";
import OptionsDropdown from "../optionsDropdown/optionsDropdown";
import Card from "react-bootstrap/Card";
import "./customModal.scss";
import { bounceInUp } from "react-animations";
import Radium, { StyleRoot } from "radium";
export default function CustomModal({
  show,
  onHide,
  title,
  titleOne,
  isExitModal,
  text,
  exitAssessment,
}) {
  const [exitBtnClick, setExitBtnClick] = useState(false);
  const [exitReason, setExitReason] = useState("");
  const [isExitReasonError, setExitReasonError] = useState(false);
  const exitBtnclick = () => {
    if (exitBtnClick) {
      if (exitReason !== "") {
        setExitBtnClick(false);
        setExitReason("");
        exitAssessment();
      } else {
        setExitReasonError(true);
      }
    } else {
      setExitBtnClick(true);
    }
  };

  const modalCloseButtonClicked = () => {
    if (isExitReasonError) {
      setExitReasonError(false);
    }

    setExitBtnClick(false);
    setExitReason("");
    onHide();
  };

  // why exiting selected answer
  const subOptionSelected = (value) => {
    if (isExitReasonError) {
      setExitReasonError(false);
    }

    setExitReason(value);
  };

  const options = [
    {
      title: "It takes too long",
      value: "It takes too long",
    },
    {
      title: "I don't know the answer",
      value: "I don't know the answer",
    },
    {
      title: "Loading Issue",
      value: "Loading Issue",
    },
    {
      title: "I'd prefer not to say",
      value: "I'd prefer not to say",
    },
    {
      title: "Other",
      value: "Other",
    },
  ];

  return (
    <Modal
      className="customModal"
      show={show}
      onHide={modalCloseButtonClicked}
      centered
    >
      <Modal.Header closeButton></Modal.Header>
      <Modal.Body>
        <Card className="customModalCard">
          <Row>
            {title || titleOne ? (
              <div
                className={
                  isExitModal ? "customModalTitle" : "customModalHeading"
                }
              >
                {exitBtnClick ? <p>{titleOne}</p> : <p>{title}</p>}
              </div>
            ) : null}
          </Row>
          <Row className="customModalContentView">
            {isExitModal ? (
              <div
                className={
                  exitBtnClick
                    ? "exitModalBtnView exitModalOptionsView"
                    : "exitModalBtnView"
                }
              >
                <div
                  className={
                    exitBtnClick
                      ? "customModalContinueDiv customModalOptionsBtn"
                      : "customModalContinueDiv"
                  }
                >
                  {exitBtnClick ? (
                    <div
                      className={isExitReasonError ? "vertical_shake" : null}
                    >
                      <OptionsDropdown
                        options={options}
                        subOptionSelected={subOptionSelected}
                        isSubOptionError={isExitReasonError}
                        type="exit"
                      />
                    </div>
                  ) : (
                    <Button className="customModalContinueBtn" onClick={onHide}>
                      Continue assessment
                    </Button>
                  )}
                </div>

                <div
                  className={
                    exitBtnClick
                      ? "customModalExitDiv optionsExitBtnView"
                      : "customModalExitDiv"
                  }
                >
                  <Button
                    className={
                      exitBtnClick ? "optionsExitBtn" : "customModalExitBtn"
                    }
                    onClick={exitBtnclick}
                  >
                    Exit now
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <div>
                  {text ? <p className="customModalText">{text}</p> : null}
                </div>
              </div>
            )}
          </Row>
        </Card>
      </Modal.Body>
    </Modal>
  );
}
