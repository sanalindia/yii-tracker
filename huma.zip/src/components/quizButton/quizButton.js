import React from "react";
import "./quizButton.css";

export default function QuizButton({
  quizContinueBtnClicked,
  quizSkipBtnClicked,
  isSkip,
  quizNo,
}) {
  return (
    <div className="quizBtnsView">
      {isSkip ? (
        <button className="quizBtn quizSkipBtn" onClick={quizSkipBtnClicked}>
          Skip question
        </button>
      ) : null}
      <button
        className="quizBtn quizContinueBtn"
        onClick={quizContinueBtnClicked}
      >
        Continue
      </button>
    </div>
  );
}
