import React, { useState } from 'react'
import './optionsDropdown.css';
import dropdownArrow from "../../assets/images/dropdown-arrow.png"

export default function OptionsDropdown({
  options,
  subOptionSelected,
  isSubOptionError,
  prevSelectedData,
  type
}) {

  const defaultValue = "Select an answer";

  const [dropdownValue, setDropdownValue] = useState(prevSelectedData || defaultValue);

  /* When the user clicks on the button,
  toggle between hiding and showing the dropdown content */
  const toggleDropdown = () => {
    document.getElementById(`dropdown-list${type}`).classList.toggle("show");
  }

  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function (event) {
    if (!event.target.matches('.dropdownToggleView')) {
      var dropdowns = document.getElementsByClassName("dropdownList");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }

  const selectDropdownOption = (data) => {
    setDropdownValue(data?.title);

    subOptionSelected(data?.value);
  }

  return (
    <>
      <div className={isSubOptionError ? "optionsDropdown optionsDropdownError" : "optionsDropdown"}>
        <button
          className='dropdownToggleView'
          onClick={() => toggleDropdown()}
        >
          <span
            className='dropdownSelectedOptn'
          >
            {dropdownValue}
          </span>
          <img
            className='dropdownArrowIcon'
            src={dropdownArrow}
            alt='dropdown arrow'
          />
        </button>
      </div>
      <div
        id={`dropdown-list${type}`}
        className="dropdownList"
      >
        <p>
          {defaultValue}
        </p>
        {options.map((ele, index) =>
          <React.Fragment key={`dropdown-${type}-${index}`}>
            <p onClick={() => selectDropdownOption(ele)}>
              {ele?.title}
            </p>
          </React.Fragment>
        )}
      </div>
    </>
  )
}
