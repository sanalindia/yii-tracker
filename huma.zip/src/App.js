import { Routes, Route } from "react-router-dom";
import "./App.css";
import { Container } from "react-bootstrap";
import Assessment from "./pages/assessment/assessment";
import FinalResultContainer from "./pages/finalResult/finalResultContainer";

function App() {
  if (window.document.querySelectorAll("iframe").length > 0) {
    if (window.parent.document.getElementsByTagName("header").length > 0) {
      window.parent.document.getElementsByTagName("header")[0].style.cssText =
        "position: relative; z-index: 1; border-bottom-right-radius: 30px";
    }

    if (
      window.parent.document.querySelector(
        ".coh-style-configurable-header .burger-menu-icon"
      ) != null
    ) {
      window.parent.document.querySelector(
        ".coh-style-configurable-header .burger-menu-icon"
      ).style.display = "none";
    }
    if (
      window.parent.document.querySelector(".block-quiz.decoupled-component") !=
      null
    ) {
      window.parent.document.querySelector(
        ".block-quiz.decoupled-component"
      ).style.cssText = "display: block; position: relative; bottom: 24px;";
    }
  }

  return (
    <Container fluid={true}>
      <Routes>
        <Route path="/" element={<FinalResultContainer />} />
        <Route path="/assessment" element={<Assessment />} />
      </Routes>
    </Container>
  );
}

export default App;
