const jsonStringToObj = (s) => {
  s = s.replace(/(\r\n|\n|\r)/gm, "");
  var span = document.createElement("span");
  span.innerHTML = s;
  s = span.textContent || span.innerText;
  s = s.trim();
  s = JSON.parse(s);
  return s;
};

const formatData = (array) => {
  let stringData = "";
  let comma = ", ";
  array.forEach((element, i) => {
    if (array.length === i + 1) {
      comma = "";
    }
    stringData += `${element.label}${comma}`;
  });
  return stringData;
};

const stripHtml = (html) => {
  let tmp = document.createElement("DIV");
  tmp.innerHTML = html;
  let textString = tmp.textContent || tmp.innerText || "";
  textString = textString.replace(/(\r\n|\n|\r)/gm, "");
  return textString;
};

const utility = {
  jsonStringToObj,
  stripHtml,
  formatData,
};

export default utility;
