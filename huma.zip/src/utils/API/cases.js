import { get, post } from "./config";
import Utility from "../utility";

const findQuiz = async () => {
  const response = await get("jsonapi/node/quiz/");
  let quizID = response.data.data[2].id;
  return quizID;
};

const getQuizQuestions = async (quizID) => {
  const response = await get(
    `/jsonapi/node/quiz/${quizID}?include=field_quiz_question`
  );
  let questions = response.data.included;
  let quesIDs = [];
  for (let question of questions) {
    let field_instruction =
      question.attributes.field_instruction &&
      question.attributes.field_instruction.value
        ? question.attributes.field_instruction.value
        : "";
    let field_explanation =
      question.attributes.field_explanation &&
      question.attributes.field_explanation.value
        ? question.attributes.field_explanation.value
        : "";

    quesIDs.push({
      id: question.id,
      title: question.attributes.title,
      field_instruction: field_instruction,
      field_explanation: field_explanation,
    });
  }
  return quesIDs;
};

const getAnswers4Question = async (qID) => {
  const response = await get(
    `/jsonapi/node/question/${qID}?include=field_answer`
  );
  let ansObj = response.data.included;
  let ansOp = [];

  for (let answer of ansObj) {
    let field_answer_summary =
      answer.attributes.field_answer_summary &&
      answer.attributes.field_answer_summary.value
        ? answer.attributes.field_answer_summary.value
        : "";
    field_answer_summary = Utility.stripHtml(field_answer_summary);

    ansOp.push({
      id: answer.id,
      title: answer.attributes.title,
      field_answer_summary,
    });
  }

  return ansOp;
};

const getResult = async (riskClass) => {
  let typeOfRisk = `${riskClass}_RISK`;
  const response = await get(`jsonapi/node/result?filter[title]=${typeOfRisk}`);
  let result = response.data.data[0].attributes.field_instruction.value;
  return result;
};

const getTeaserImage = async (nodeID) => {
  const response = await get(
    `jsonapi/node/article?filter[drupal_internal__nid]=${nodeID}&include=field_teaser_image`
  );
  let image = response.data.included[0].attributes.uri.url;
  return image;
};

const emailSFMCAPI = async (obj, flag) => {
  const randomContactKey = String(Math.floor(Math.random() * 10000000));
  let params = {
    ContactKey: randomContactKey,
    EventDefinitionKey: "APIEvent-23319498-d28c-f93e-5888-5a171d790721",
    EstablishContactKey: true,
    Data: {
      Email: null,
      RiskMeterFlag: null,
      InvitationLink: null,
      GraphImageURL: null,
      ContactKey: randomContactKey,
      RiskValue: null,
      RiskCVDYear: null,
      PotentialRiskFactor: null,
      DoingWellFactors: null,
      Brand: "Bayer Aspirin",
      CreatedDate: obj.CreatedDate,
      Source: "HUMA_CARDIO_WEB_SPORTS",
      Country: "US",
      HCP: null,
      Age: obj.Age,
      SportsFrequency: obj.SportsFrequency,
      FanRating: obj.FanRating,
    },
  };

  if (flag === 2) {
    params = {
      ContactKey: randomContactKey,
      EventDefinitionKey: "APIEvent-23319498-d28c-f93e-5888-5a171d790721",
      EstablishContactKey: true,
      Data: {
        Email: obj.email,
        RiskMeterFlag: obj.RiskMeterFlag,
        InvitationLink: obj.InvitationLink,
        GraphImageURL: obj.GraphImageURL,
        ContactKey: randomContactKey,
        RiskValue: obj.RiskValue,
        RiskCVDYear: obj.RiskCVDYear,
        PotentialRiskFactor: obj.PotentialRiskFactor,
        DoingWellFactors: obj.DoingWellFactors,
        Brand: "Bayer Aspirin",
        CreatedDate: obj.CreatedDate,
        Source: "HUMA_CARDIO_WEB_SPORTS",
        Country: "US",
        HCP: obj.HCP,
        Age: obj.Age,
        SportsFrequency: obj.SportsFrequency,
        FanRating: obj.FanRating,
      },
    };
  }

  console.log("params", params);
  const config = {
    headers: { "Content-Type": "application/json" },
  };
  const response = await post(`/emailResult`, params, config);

  return response;
};

const uploadImage = async (uploadData) => {
  console.log("uploadData", uploadData);
  const fd = new FormData();
  fd.append("data", uploadData.data);
  fd.append("name", uploadData.name);
  const response = await post(`/upload`, fd);
  return response.data;
};

const submitForCalculateCvdLite = async (body) => {
  console.log("body data", body);
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  const response = await post(`/calculateCvdLite`, body, config);
  return response;
};

const APIList = {
  findQuiz,
  getQuizQuestions,
  getAnswers4Question,
  uploadImage,
  submitForCalculateCvdLite,
  getResult,
  getTeaserImage,
  emailSFMCAPI,
};

export default APIList;
