import { get, post } from "./config";
import Utility from "../utility";

const findQuiz = async () => {
  const response = await get("jsonapi/node/quiz/index.json");
  let quizID = response.data.data[1].id;
  return quizID;
};

const getQuizQuestions = async (quizID) => {
  const response = await get(`jsonapi/node/question/index.json`);
  let questions = response.data.included;
  let quesIDs = [];
  for (let question of questions) {
    let field_instruction =
      question.attributes.field_instruction &&
      question.attributes.field_instruction.value
        ? question.attributes.field_instruction.value
        : "";
    let field_explanation =
      question.attributes.field_explanation &&
      question.attributes.field_explanation.value
        ? question.attributes.field_explanation.value
        : "";

    quesIDs.push({
      id: question.id,
      title: question.attributes.title,
      field_instruction,
      field_explanation,
    });
  }
  return quesIDs;
};

const getAnswers4Question = async (qID) => {
  const response = await get(`/jsonapi/node/question/answers/${qID}.json`);
  let ansObj = response.data.included;
  let ansOp = [];

  for (let answer of ansObj) {
    let field_answer_summary =
      answer.attributes.field_answer_summary &&
      answer.attributes.field_answer_summary.value
        ? answer.attributes.field_answer_summary.value
        : "";
    field_answer_summary = Utility.stripHtml(field_answer_summary);

    ansOp.push({
      id: answer.id,
      title: answer.attributes.title,
      field_answer_summary,
    });
  }

  return ansOp;
};

const getResult = async (riskClass) => {
  const response = await get("jsonapi/node/result/averageRisk.json");
  let result = response.data.data[0].attributes.field_instruction.value;
  return result;
};

const getTeaserImage = async (nodeID) => {
  const response = await get(
    `jsonapi/node/article?filter[drupal_internal__nid]=${nodeID}&include=field_teaser_image`
  );
  let image = response.data.included[0].attributes.uri.url;
  return image;
};

const emailSFMCAPI = async (obj, flag) => {
  let params = [
    {
      keys: {
        Email: "bayeremails@gmail.com",
      },
      values: {
        Email: null,
        RiskMeterFlag: null,
        InvitationLink: null,
        GraphImageURL: null,
        RiskValue: null,
        RiskCVDYear: null,
        PotentialRiskFactor: null,
        DoingWellFactors: null,
        Brand: "Bayer Aspirin",
        CreatedDate: obj.CreatedDate,
        Source: "HUMA_CARDIO_WEB_SPORTS",
        Country: "US",
        Age: obj.Age,
        SportsFrequency: obj.SportsFrequency,
        FanRating: obj.FanRating,
      },
    },
  ];

  if (flag === 2) {
    params = [
      {
        keys: {
          Email: "bayeremails@gmail.com",
        },
        values: {
          Email: obj.email,
          RiskMeterFlag: obj.RiskMeterFlag,
          InvitationLink: obj.InvitationLink,
          GraphImageURL: obj.GraphImageURL,
          RiskValue: obj.RiskValue,
          RiskCVDYear: obj.RiskCVDYear,
          PotentialRiskFactor: obj.PotentialRiskFactor,
          DoingWellFactors: obj.DoingWellFactors,
          Brand: "Bayer Aspirin",
          CreatedDate: obj.CreatedDate,
          Source: "HUMA_CARDIO_WEB_SPORTS",
          Country: "US",
          Age: obj.Age,
          SportsFrequency: obj.SportsFrequency,
          FanRating: obj.FanRating,
        },
      },
    ];
  }
  console.log("params", params);
  const config = {
    headers: { "Content-Type": "Application/json" },
  };
  const response = await post(`/emailResult`, params, config);

  return response;
};

const uploadImage = async (uploadData) => {
  console.log("uploadData", uploadData);
  const fd = new FormData();
  fd.append("data", uploadData.data);
  fd.append("name", uploadData.name);
  const response = await post(`/upload`, fd);
  console.log("responseppppppppp", response);
  return response.data;
};

const submitForCalculateCvdLite = async (body) => {
  console.log("body data", body);
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  const response = await post(`/calculateCvdLite`, body, config);
  return response;
};

const devAPIList = {
  findQuiz,
  getQuizQuestions,
  getAnswers4Question,
  uploadImage,
  submitForCalculateCvdLite,
  getResult,
  getTeaserImage,
  emailSFMCAPI,
};

export default devAPIList;
