import React, { useEffect, useState } from 'react'
import Slider from 'react-rangeslider-withkeeptooltip';
import 'react-rangeslider-withkeeptooltip/lib/index.css'
import './rangeSlider.css';
import sliderTooltip from '../../assets/images/slider_tooltip_icon.png';
import sizeTooltip from '../../assets/images/size_slider_tooltip_icon.png';

export default function RangeSlider({
    minValue,
    maxValue,
    progressStep,
    isTooltip,
    keepTooltip,
    initialValue,
    type,
    onChangeSlider,
    sliderValueChanged,
    isContinueClicked,
    optionsSelected,
    isOptionError,
    resetOptionError
}) {

    const [value, setValue] = useState(initialValue);

    useEffect(() => {
        setValue(initialValue);

        if (isContinueClicked) {
            optionsSelected({ type, value });
        }
    }, [initialValue, isContinueClicked, optionsSelected, type, value]);

    const handleChangeStart = () => {
        if (isOptionError) {
            resetOptionError();
        }
    };

    const handleChange = value => {
        setValue(value);
        onChangeSlider(type, value);
    };

    const handleChangeComplete = () => {
        if (isOptionError) {
            resetOptionError();
        }
        
        sliderValueChanged(type, value);
    };

    const sliderCustomTooltip = (value) => {
        return (
            <div
                className="customTooltip"
            >
                <img
                    src={sliderTooltip}
                    alt="Slider Tooltip Icon"
                    className="customTooltipIcon"
                />
                <p
                    className="customTooltipValue"
                >
                    {value}
                </p>
            </div>
        )
    }

    const sizeSliderTooltip = (value) => {
        return (
            <div
                className="sizeSelectorTooltip"
            >
                <img
                    src={sizeTooltip}
                    alt="Size Slider Tooltip Icon"
                    className="sizeTooltipIcon"
                />
                <p
                    className="sizeTooltipValue"
                >
                    {`${value}in`}
                </p>
            </div>
        )
    }

    return (
        <div className={`${type}SliderView`}>
            <Slider
                min={minValue}
                max={maxValue}
                step={progressStep}
                value={value}
                onChangeStart={handleChangeStart}
                onChange={handleChange}
                onChangeComplete={handleChangeComplete}
                tooltip={isTooltip}
                keepTooltip={keepTooltip}
                format={type === "WaistSize" || type === "HipSize" ? sizeSliderTooltip : sliderCustomTooltip}
            />
        </div>
    )
}
