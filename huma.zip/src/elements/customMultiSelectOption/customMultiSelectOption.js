import React, { useEffect, useState } from "react";
import "./customMultiSelectOption.css";
import plusIcon from "../../assets/images/plus_icon.png";
import tickIcon from "../../assets/images/checkmark.png";
import { rotateIn } from "react-animations";
import Radium, { StyleRoot } from "radium";

export default function CustomMultiSelectOption({
  optionsList,
  isContinueClicked,
  optionsSelected,
  quizNo,
  isOptionError,
  resetOptionError,
  previousSelectedValue,
}) {
  const [multiSelectedData, setMultiSelectedData] = useState(
    previousSelectedValue || []
  );
  const [animate, setAnimate] = useState();
  const [selectedObject, setSelectedObject] = useState();

  useEffect(() => {
    if (isContinueClicked) {
      optionsSelected({ value: multiSelectedData });
    }
  }, [isContinueClicked, multiSelectedData, optionsSelected]);

  const multiSelectOptionSelected = (index) => {
    setSelectedObject(index);
    const styles = {
      [index]: {
        rotateIn: {
          animation: "x 0.4s",
          animationName: Radium.keyframes(rotateIn, "rotateIn"),
        },
      },
    };
    setAnimate(styles[index].rotateIn);
    if (isOptionError) {
      resetOptionError();
    }

    let array = [...multiSelectedData];

    const itemIndex = array.indexOf(optionsList[index].field_answer_summary);
    if (itemIndex > -1) {
      array.splice(itemIndex, 1);
    } else {
      if (optionsList[index].title === "None of the above") {
        array = [];
        array.push(optionsList[index].field_answer_summary);
      } else {
        const noneOption = optionsList.find(
          (ele) => ele.title === "None of the above"
        );
        const noneIndex = array.indexOf(noneOption?.field_answer_summary);
        if (noneIndex > -1) {
          array.splice(noneIndex, 1);
        }
        array.push(optionsList[index].field_answer_summary);
      }
    }

    setMultiSelectedData(array);
  };

  return (
    <>
      {optionsList.map((item, index) => (
        <React.Fragment key={`multiOptions-${quizNo}-${index}`}>
          <button
            className={
              multiSelectedData.includes(item.field_answer_summary)
                ? "multiSelectOptionView multiOptionSelectedView"
                : isOptionError
                  ? "multiSelectOptionView multiSelectErrorView"
                  : "multiSelectOptionView"
            }
            onClick={() => multiSelectOptionSelected(index)}
          >
            <div className="multiSelectOption">
              <StyleRoot>
                <img
                  src={
                    multiSelectedData.includes(item.field_answer_summary)
                      ? tickIcon
                      : plusIcon
                  }
                  alt="Plus Icon"
                  className="multiOptionPlusIcon"
                  style={index === selectedObject ? animate : {}}
                />
              </StyleRoot>

              <p className={multiSelectedData.includes(item.field_answer_summary)
                ? "multiOptionSelectedText"
                :"multiOptionText"}>{item.title}</p>
            </div>
          </button>
        </React.Fragment>
      ))}
    </>
  );
}
