import React, { useEffect, useMemo, useState } from "react";
import "./customSingleSelectOption.css";
import radioUnselectedIcon from "../../assets/images/radio_unselected_button.png";
import radioSelectedIcon from "../../assets/images/radio_selected_button.png";
import DetailedOptionsCard from "../../components/detailedOptionsCard/detailedOptionsCard";
import { pulse } from "react-animations";
import Radium, { StyleRoot } from "radium";

export default function CustomSingleSelectOption({
  optionsList,
  isContinueClicked,
  optionsSelected,
  quizNo,
  isOptionError,
  resetOptionError,
  previousSelectedValue,
  isSubOptionError,
  resetSubOptionError,
}) {
  const [animate, setAnimate] = useState();
  const [selectedObject, setSelectedObject] = useState();
  const prevIndex =
    previousSelectedValue?.prevSelectedIndex !== undefined
      ? previousSelectedValue?.prevSelectedIndex
      : "";

  const [singleSelectedData, setSingleSelectedData] = useState(
    previousSelectedValue?.selectedMainOption || ""
  );
  const [singleSelectedIndex, setSingleSelectedIndex] = useState(prevIndex);
  const [subSelectedData, setSubSelectedData] = useState(
    previousSelectedValue?.selectedDropdownOption || ""
  );

  const detailedOptionData = useMemo(
    () => [
      {
        quizNo: 3,
        index: 0,
        dropdownTitle: "Why do you see your doctor or healthcare professional?",
        dropDownOptions: [
          {
            title: "Regular health checks",
            value: "Regular health checks",
          },
          {
            title: "When I’m sick",
            value: "When I’m sick",
          },
          {
            title: "For ongoing treatment",
            value: "For ongoing treatment",
          },
        ],
      },
      {
        quizNo: 3,
        index: 1,
        dropdownTitle: "Why do you see your doctor or healthcare professional?",
        dropDownOptions: [
          {
            title: "Regular health checks",
            value: "Regular health checks",
          },
          {
            title: "When I’m sick",
            value: "When I’m sick",
          },
          {
            title: "For ongoing treatment",
            value: "For ongoing treatment",
          },
        ],
      },
      {
        quizNo: 3,
        index: 2,
        dropdownTitle:
          "Why do you avoid going to your doctor or healthcare professional?",
        dropDownOptions: [
          {
            title: "I don't go unless I’m very sick",
            value: "I don't go unless I’m very sick",
          },
          {
            title: "It's expensive",
            value: "It's expensive",
          },
          {
            title: "I don't trust healthcare practitioners",
            value: "I don't trust healthcare practitioners",
          },
          {
            title: "I prefer to self-diagnose and self-treat",
            value: "I prefer to self-diagnose and self-treat",
          },
          {
            title: "I don't have time",
            value: "I don't have time",
          },
        ],
      },
      {
        quizNo: 3,
        index: 3,
        dropdownTitle:
          "Why do you avoid going to your doctor or healthcare professional?",
        dropDownOptions: [
          {
            title: "I don't go unless I’m very sick",
            value: "I don't go unless I’m very sick",
          },
          {
            title: "It's expensive",
            value: "It's expensive",
          },
          {
            title: "I don't trust healthcare practitioners",
            value: "I don't trust healthcare practitioners",
          },
          {
            title: "I prefer to self-diagnose and self-treat",
            value: "I prefer to self-diagnose and self-treat",
          },
          {
            title: "I don't have time",
            value: "I don't have time",
          },
        ],
      },
      {
        quizNo: 3,
        index: 4,
        dropdownTitle:
          "Why do you avoid going to your doctor or healthcare professional?",
        dropDownOptions: [
          {
            title: "I don't go unless I’m very sick",
            value: "I don't go unless I’m very sick",
          },
          {
            title: "It's expensive",
            value: "It's expensive",
          },
          {
            title: "I don't trust healthcare practitioners",
            value: "I don't trust healthcare practitioners",
          },
          {
            title: "I prefer to self-diagnose and self-treat",
            value: "I prefer to self-diagnose and self-treat",
          },
          {
            title: "I don't have time",
            value: "I don't have time",
          },
        ],
      },
      {
        quizNo: 11,
        index: 0,
        dropdownTitle: "How often?",
        dropDownOptions: [
          {
            title: "Daily or almost daily",
            value: "DAILY_OR_ALMOST_DAILY",
          },
          {
            title: "Three or four times a week",
            value: "THREE_OR_FOUR_TIMES_A_WEEK",
          },
          {
            title: "Once or twice a week",
            value: "ONCE_OR_TWICE_A_WEEK",
          },
          {
            title: "One to three times a month",
            value: "ONE_TO_THREE_TIMES_A_MONTH",
          },
          {
            title: "Special occasions only",
            value: "SPECIAL_OCCASIONS_ONLY",
          },
        ],
      },
    ],
    []
  );

  useEffect(() => {
    if (isContinueClicked) {
      if (quizNo === 11 && singleSelectedIndex === 0) {
        const subOptionData = detailedOptionData.find(
          (ele) => ele.quizNo === quizNo && ele.index === singleSelectedIndex
        );
        const dropdownSelectedOption =
          subSelectedData &&
          subOptionData.dropDownOptions.find(
            (ele) =>
              ele.value === subSelectedData || ele.title === subSelectedData
          );

        optionsSelected({
          value: subSelectedData,
          selectedMainOption: singleSelectedData,
          selectedDropdownOption: dropdownSelectedOption?.title,
          prevSelectedIndex: singleSelectedIndex,
          subOptionNotSelected: singleSelectedData && !subSelectedData,
        });
      } else {
        optionsSelected({
          value: singleSelectedData,
          selectedMainOption: singleSelectedData,
          selectedDropdownOption: "",
          prevSelectedIndex: singleSelectedIndex,
          subOptionNotSelected: false,
        });
      }
    }
  }, [
    isContinueClicked,
    singleSelectedData,
    optionsSelected,
    quizNo,
    subSelectedData,
    singleSelectedIndex,
    detailedOptionData,
  ]);

  const singleOptionSelected = (index) => {
    setSelectedObject(index);
    const styles = {
      [index]: {
        pulse: {
          animation: "x 0.4s",
          animationName: Radium.keyframes(pulse, "pulse"),
        },
      },
    };
    setAnimate(styles[index].pulse);
    if (isOptionError) {
      resetOptionError();
    }

    if (isSubOptionError) {
      resetSubOptionError();
    }

    let selectedOption = singleSelectedData;
    if (selectedOption === optionsList[index].field_answer_summary) {
      selectedOption = "";
    } else {
      selectedOption = optionsList[index].field_answer_summary;
    }
    setSingleSelectedData(selectedOption);

    const selectedIndex = singleSelectedIndex === index ? "" : index;
    setSingleSelectedIndex(selectedIndex);

    setSubSelectedData("");
  };

  const subOptionSelected = (value) => {
    if (isSubOptionError) {
      resetSubOptionError();
    }

    setSubSelectedData(value);
  };

  return (
    <>
      {optionsList.map((item, index) => (
        <React.Fragment key={`singleOptions-${quizNo}-${index}`}>
          <button
            className={
              singleSelectedData === item.field_answer_summary
                ? "singleSelectOptionView singleOptionSelectedView"
                : isOptionError && singleSelectedData === ""
                ? "singleSelectOptionView singleSelectErrorView"
                : "singleSelectOptionView"
            }
            onClick={() => singleOptionSelected(index)}
          >
            <div className="singleSelectOption">
              <p
                className={
                  singleSelectedData === item.field_answer_summary
                    ? "singleOptionSelectedText"
                    : "singleOptionText"
                }
              >
                {item.title}
              </p>
              <StyleRoot>
                <img
                  src={
                    singleSelectedData === item.field_answer_summary
                      ? radioSelectedIcon
                      : radioUnselectedIcon
                  }
                  alt="Radio Unselected Icon"
                  className="singleOptionRadioIcon"
                  style={index === selectedObject ? animate : {}}
                />
              </StyleRoot>
            </div>
          </button>
        </React.Fragment>
      ))}

      {quizNo === 11 && singleSelectedIndex === 0 ? (
        <React.Fragment
          key={`detailedOptions-${quizNo}-${singleSelectedIndex}`}
        >
          <DetailedOptionsCard
            detailedOptionData={detailedOptionData}
            quizNo={quizNo}
            singleSelectedIndex={singleSelectedIndex}
            subOptionSelected={subOptionSelected}
            prevSelectedData={subSelectedData}
            isSubOptionError={isSubOptionError}
          />
        </React.Fragment>
      ) : null}
    </>
  );
}
