let dev;
if (process.env.NODE_ENV === "development") {
  dev = {
    LOWER: {
      RiskMeterFlag: 1,
      InvitationLink:
        window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score. As your score is <strong> lower risk </strong>, we recommend storing them to compare to future assessment results.`,
    },
    AVERAGE: {
      RiskMeterFlag: 2,
      InvitationLink:
        window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score.  As your score is <strong> average risk </strong>, we recommend sharing them when you discuss how to manage your heart health with your health care practitioner.`,
    },
    HIGHER: {
      RiskMeterFlag: 3,
      InvitationLink:
        window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score.  As your score is <strong> higher risk </strong>, we urge you to share them with your health care practitioner as soon as possible.`,
    },
  };
} else {
  dev = {
    LOWER: {
      RiskMeterFlag: 1,
      InvitationLink:
        window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score. As your score is <strong> lower risk </strong>, we recommend storing them to compare to future assessment results.`,
    },
    AVERAGE: {
      RiskMeterFlag: 2,
      InvitationLink:
        window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score.  As your score is <strong> average risk </strong>, we recommend sharing them when you discuss how to manage your heart health with your health care practitioner.`,
    },
    HIGHER: {
      RiskMeterFlag: 3,
      InvitationLink:
       window.location.origin+ "/deco/aspirin-elements/huma_Sports_RiskCalc/build/index.html?FriendInvitation",
      emailDescription: `Enter your email address below to receive a copy of your CVD risk score.  As your score is <strong> higher risk </strong>, we urge you to share them with your health care practitioner as soon as possible.`,
    },
  };
}
export const Constants = dev;
