import React, { useEffect, useState } from "react";
import { Cases } from "../../utils/API/index";
import SectionHome from "../../components/sectionHome/sectionHome";
import gettingToKnowIcon from "../../assets/images/getting_to_know_you_logo.png";
import yourBodyIcon from "../../assets/images/your_body_logo.png";
import yourLifestyleIcon from "../../assets/images/your_lifestyle_logo.png";
import healthAndHistoryIcon from "../../assets/images/health_history_logo.png";
import quizResultProgressIcon from "../../assets/images/quiz_result_progress_icon.png";
import AssessmentIntro from "../../components/assessmentIntro/assessmentIntro";
import QuizCard from "../../components/quizCard/quizCard";
import SectionFact from "../../components/sectionFact/sectionFact";
import { slideInRight, fadeIn } from "react-animations";
import Radium, { StyleRoot } from "radium";
import ErrorComponent from "../../components/errorComponent/errorComponent";

let skipFactTimer;
let username = "";
let skipSet = 0;
export default function Assessment() {
  const [sectionPageCount, setSectionPageCount] = useState(1);
  const [displayScenario, setDisplayScenario] = useState("AssessmentIntro");
  const [questionsList, setQuestions] = useState([]);
  const [quizPageCount, setQuizPageCount] = useState(0);
  const [sectionFactCount, setSectionFactCount] = useState(0);
  const [backBtnClicked, setBackBtnClicked] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const styles = {
    slideInRight: {
      animation: "1s",
      animationName: Radium.keyframes(slideInRight, "slideInRight"),
    },
    fadeIn: {
      animation: "x 3s",
      animationName: Radium.keyframes(fadeIn, "fadeIn"),
    },
  };

  const errorArray = {
    icon: healthAndHistoryIcon,
    imageText: "",
    title: "",
    description:
      "We are expeienceing some issue in your quiz input. Please and try gain",
    isAnimate: false,
  };
  const sectionHomeData = [
    {
      icon: gettingToKnowIcon,
      imageText: "Getting to know you icon",
      title: "Getting to know you",
      isAnimate: true,
    },
    {
      icon: yourBodyIcon,
      imageText: "Your Body Icon",
      title: "Your Body",
      description: "Great start! There are 4 quick questions here",
      isAnimate: false,
    },
    {
      icon: yourLifestyleIcon,
      imageText: "Your lifestyle icon",
      title: "Your Lifestyle",
      description: "Over halfway now! You’ve got this",
      isAnimate: false,
    },
    {
      icon: healthAndHistoryIcon,
      imageText: "Health and History Icon",
      title: "Health & History",
      description: "Nearly finished – this is the last section!",
      isAnimate: false,
    },
    {
      icon: quizResultProgressIcon,
      imageText: "Quiz Result Progress Icon",
      title: "We’re getting your results ready",
      description: "It won’t take us long!",
      isQuizCompletion: true,
      isAnimate: true,
    },
  ];

  const sectionFactData = [
    {
      heartImgText:
        "When your home team plays, heart attack risk can increase by more than 2x ",
      title:
        "When your home team plays, heart attack risk can increase by more than 2x",
      sourceName: "",
    },
    {
      heartImgText:
        "The average heart is estimated to beat over 3 billion times during its lifetime!",
      title:
        "The average heart is estimated to beat over 3 billion times during its lifetime!*",
      sourceName: "Open Oregon Educational Resources",
    },
    {
      heartImgText:
        "There are over 500 million people living with cardiovascular disease around the world",
      title:
        "There are over 500 million people living with cardiovascular disease around the world*",
      sourceName: "American College of Cardiology",
    },
  ];

  useEffect(() => {
    Cases.findQuiz()
      .then((quizID) => {
        Cases.getQuizQuestions(quizID)
          .then((response) => {
            setQuestions(response);
            console.log("haiiiiiiii", response);
          })
          .catch((errors) => {
            console.log(errors);
          })
          .finally(() => {});
      })
      .catch((e) => console.log(e))
      .finally(() => {});
  }, []);

  const first3QuestionsAPI = (selectedValue) => {
    localStorage.setItem("selectedValue", JSON.stringify(selectedValue));
    var today1 = new Date();
    var dd = String(today1.getDate()).padStart(2, "0");
    var mm = String(today1.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today1.getFullYear();
    today1 = mm + "/" + dd + "/" + yyyy;
    let obj = {
      Email: null,
      RiskMeterFlag: null,
      InvitationLink: null,
      GraphImageURL: null,
      RiskValue: null,
      RiskCVDYear: null,
      PotentialRiskFactor: null,
      DoingWellFactors: null,
      Brand: "Bayer Aspirin",
      CreatedDate: today1,
      Source: "HUMA_CARDIO_WEB_SPORTS",
      Country: "US",
      HCP: null,
      Age: selectedValue.age,
      SportsFrequency: selectedValue.sportsFrequency,
      FanRating: selectedValue.fanRating,
    };
    Cases.emailSFMCAPI(obj, 1).then((resp) => {
      setEmailSent(true);
      console.log("SFMC feedback", resp);
    });
  };

  const goToPreviousQuiz = () => {
    window.parent.scrollTo(0, 0);
    setBackBtnClicked(true);
    setQuizPageCount(quizPageCount - 1);
    if (quizPageCount === 1) {
      setDisplayScenario("AssessmentIntro");
    } else if (
      quizPageCount === 4 ||
      quizPageCount === 8 ||
      quizPageCount === 12
    ) {
      setSectionFactCount(sectionFactCount - 1);
      setSectionPageCount(sectionPageCount - 1);
    }
  };

  const goToNextQuiz = (selectedValue) => {
    window.parent.scrollTo(0, 0);
    setBackBtnClicked(false);
    skipSet = 0;
    if (quizPageCount === 3 || quizPageCount === 7 || quizPageCount === 11) {
      setSectionFactCount(sectionFactCount + 1);
      setDisplayScenario("SectionFact");

      skipFactTimer = setTimeout(() => {
        if (skipSet === 0) {
          skipQuizFact();
        }
      }, 5000);
      if (quizPageCount === 3) {
        first3QuestionsAPI(selectedValue);
        console.log("quizPageCount === 3 haiiiiiiiiiiiiiii", selectedValue);
      }
    } else if (quizPageCount < 15) {
      setQuizPageCount(quizPageCount + 1);
    } else if (quizPageCount === 15) {
      setSectionPageCount(sectionPageCount + 1);
      setDisplayScenario("SectionHome");
      console.log(
        "final request data: stringify",
        JSON.stringify(selectedValue)
      );
      Cases.submitForCalculateCvdLite(selectedValue)
        .then((resp) => {
          setTimeout(() => {
            localStorage.setItem(
              "humaData",
              JSON.stringify(resp.data.responseContent)
            );

            window.parent.location.href = "/huma-sport-assessment-result/";
          }, 3000);
        })
        .catch((e) => {
          setTimeout(() => {
            setDisplayScenario("ErrorSection");
          }, 4000);
        });
    }
  };

  const submitAssessmentIntro = (name) => {
    window.parent.scrollTo(0, 0);

    username = name;

    setDisplayScenario("SectionHome");
  };

  const goToQuizSection = () => {
    window.parent.scrollTo(0, 0);

    setBackBtnClicked(false);

    setQuizPageCount(quizPageCount + 1);
    setDisplayScenario("Quiz");
  };

  const goToStartSection = () => {
    window.parent.scrollTo(0, 0);

    setBackBtnClicked(false);

    setQuizPageCount(1);
    setDisplayScenario("Quiz");
  };

  const skipQuizFact = () => {
    skipSet = 1;
    window.parent.scrollTo(0, 0);

    clearTimeout(skipFactTimer);

    setSectionPageCount(sectionPageCount + 1);
    setDisplayScenario("SectionHome");
  };

  return (
    <div>
      {
        {
          AssessmentIntro: (
            <StyleRoot>
              <div style={styles.fadeIn}>
                <AssessmentIntro
                  submitAssessmentIntro={submitAssessmentIntro}
                  previousUsername={username}
                />
              </div>
            </StyleRoot>
          ),
          SectionHome: (
            <SectionHome
              data={sectionHomeData[sectionPageCount - 1]}
              goToQuizSection={goToQuizSection}
            />
          ),
          Quiz: (
            <React.Fragment key={`quizPages-${quizPageCount}`}>
              <QuizCard
                question={questionsList[quizPageCount - 1]}
                quizNo={quizPageCount}
                goToPreviousQuiz={goToPreviousQuiz}
                goToNextQuiz={goToNextQuiz}
                sectionNo={sectionPageCount}
                backBtn={backBtnClicked}
              />
            </React.Fragment>
          ),
          SectionFact: (
            <SectionFact
              data={sectionFactData[sectionFactCount - 1]}
              skipQuizFact={skipQuizFact}
            />
          ),
          ErrorSection: (
            <ErrorComponent
              data={errorArray}
              goToQuizSection={goToStartSection}
            />
          ),
        }[displayScenario]
      }
    </div>
  );
}
