import React from 'react';
import { Button, Col, Row } from 'react-bootstrap';
import heartLogo from '../../assets/images/heart_smart_logo.png';
import "./landing.css";

export default function Landing() {
    return (
        <>
            <Row className='landingPage'>
                <Col className='landingPageLeft'xs={12} lg={6}>
                    <h1 className='heading'>Get heart smart in two minutes</h1>
                    <p className='paragraphOne'>Understand your heart with our quick assessment*.
                        You ll learn about your potential risk of getting cardiovascular disease**
                        and how to take care of your heart today.
                    </p>
                    <Button className='button'>Get started now</Button>
                    <p className='paragraphTwo'>Disclaimer: We never keep your data
                        it will only be used to work out your assessment result.
                    </p>
                </Col>
                <Col className='landingPageRight' xs={{ order: 'first' }} lg={6}>
                    <img src={heartLogo}
                        alt=""></img></Col>
            </Row>
        </>
    )
}
