import React, { useEffect, useState, useRef } from "react";

import IconPotentialRisk from "../../assets/images/Icon-potential-risk.png";
import IconNonPotentialRisk from "../../assets/images/Icon-non-potential-risk.png";
import information_icon_black from "../../assets/images/information_icon_black.png";
import "./result.scss";
import RiskLoveComponent from "../../components/result/riskLoveComponent/riskLoveComponent";
import SendInvivationComponent from "../../components/result/sendInvivationComponent/sendInvivationComponent";
import EmailResultButton from "../../components/result/emailResultButton/emailResultButton";
import FriendInvitation from "../../components/result/inviteFriend/inviteFriend";
import ArticleComponent from "../../components/result/articleComponent/articleComponent";
import { Constants } from "../../Constants";
import { Cases } from "../../utils/API";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line } from "react-chartjs-2";
import utility from "../../utils/utility";
import HelpText from "../../components/result/helpText/helpText";
import BreakDown from "../breakdown/breakDown";
import AboutRisk from "../../components/result/aboutRisk/aboutRisk";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function Result({
  changeScreen,
  riskClass,
  resultData,
  artlceRecords,
  readMoreLinkFn,
}) {
  const [artlceList, setArtlceList] = useState([]);
  const [riskYear, setRiskYear] = useState();
  const [emailSent, setEmailSent] = useState(false);
  const [modalShow, setModalShow] = useState();
  const [selectedTab, setSelectedTab] = useState("doingWell");
  const [innerWidth, setInnerWidth] = useState(window.innerWidth);
  const getTeaser = (nodeId) => {};
  const setTab = (tab) => {
    setSelectedTab(tab);
  };
  useEffect(() => {
    console.log("artlceRecords", artlceRecords);
    let arr = [];
    if (artlceRecords.length > 0) {
      artlceRecords.forEach((article, i) => {
        arr.push({
          image: article.imageURL,
          title: article.titleContent,
          readmore: article.readMoreLink,
        });

        if (artlceRecords.length === i + 1) {
          setArtlceList(arr);
        }
      });
    }
  }, [artlceRecords]);
  const ref = useRef(null);
  const customRadius = function (context) {
    let index = context.dataIndex;
    let value = context.dataset.data[index];
    return index === 2 ? 6 : 6;
  };
  const customBack = function (context) {
    let index = context.dataIndex;
    let value = context.dataset.data[index];
    return index === 2 ? "#6a18d2" : "transparent";
  };
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
      title: {
        display: true,
      },
    },
    elements: {
      point: {
        radius: customRadius,
        backgroundColor: customBack,
        borderColor: "60px solid #000",
        display: true,
      },
    },
  };
  const labels = [
    "6mn",
    "1yr",
    "2yr",
    "3yr",
    "4yr",
    "5yr",
    "6yr",
    "7yr",
    "8yr",
    "9yr",
    "10yr",
  ];
  useEffect(() => {
    let Trajectory = resultData.riskTrajectory.sort(
      (a, b) => parseFloat(a.days) - parseFloat(b.days)
    );
    let filterYear = Trajectory.filter((x) => x.risk === resultData.risk);

    setRiskYear(parseInt(filterYear[0].days) / 365);
  }, [resultData.riskTrajectory]);
  const formatMapValues = (riskTrajectory) => {
    riskTrajectory = riskTrajectory.sort(
      (a, b) => parseFloat(a.days) - parseFloat(b.days)
    );
    let filterYear = riskTrajectory.filter((x) => x.risk === resultData.risk);

    let newArray = [];
    riskTrajectory.map((data, i) => {
      newArray.push(data.risk);
    });

    return newArray;
  };
  const data = {
    labels,
    datasets: [
      {
        label: "",
        data: formatMapValues(resultData.riskTrajectory),
        borderColor: "#6a18d2",
      },
    ],
  };
  const downloadClick = (email, hcp) => {
    let answersOfQuiz = JSON.parse(localStorage.getItem("selectedValue"));
    var today1 = new Date();
    var dd = String(today1.getDate()).padStart(2, "0");
    var mm = String(today1.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today1.getFullYear();
    today1 = mm + "/" + dd + "/" + yyyy;

    let obj = {
      email,
      RiskMeterFlag: Constants[riskClass].RiskMeterFlag,
      InvitationLink: Constants[riskClass].InvitationLink,
      GraphImageURL: "",
      RiskValue: resultData.risk,
      RiskCVDYear: riskYear,
      PotentialRiskFactor: utility.formatData(postiveArray),
      DoingWellFactors: utility.formatData(negativeArray),
      Brand: "Bayer Aspirin",
      CreatedDate: today1,
      Source: "HUMA_CARDIO_WEB",
      Country: "US",
      HCP: hcp,
      Age: answersOfQuiz.age,
      SportsFrequency: answersOfQuiz.sportsFrequency,
      FanRating: answersOfQuiz.fanRating,
    };
    Cases.emailSFMCAPI(obj, 2)
      .then((resp) => {
        setEmailSent(true);
        console.log("SFMC feedback", resp);
      })
      .catch((e) => console.log(e))
      .finally(() => {});
  };

  const resendEmail = () => {
    setEmailSent(false);
  };

  const DataURIToBlob = (dataURI) => {
    var arr = dataURI.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], "filename", { type: mime });
  };
  const postiveArray = resultData.riskFactors.filter(function (x) {
    return x.contribution > 0;
  });
  const negativeArray = resultData.riskFactors.filter(function (x) {
    return x.contribution < 0;
  });
  return (
    <div className="resultContainer">
      <div className="firstArea">
        <div className="cvdRiskContent">
          Your <br />
          <div className="iHelp">
            <strong>Risk Assessment Results</strong>
            <HelpText
              show={modalShow}
              onHide={() => setModalShow(false)}
              title={"CVD"}
              isExitModal={false}
              text={
                "*Cardiovascular disease (CVD) is the blanket term for conditions that affect the heart or blood vessels, like heart disease, angina and heart attack."
              }
            />
          </div>
        </div>
        <div className="topText">Based on other people like you</div>
        <RiskLoveComponent riskClass={riskClass} />
        <div className="topTextSubOne">
          {riskClass == "LOWER"
            ? "Over the next 10 years, you are at lower risk of CVD*"
            : riskClass == "AVERAGE"
            ? "Over the next 10 years, you are at average risk of CVD*"
            : "Over the next 10 years, you are at higher risk of CVD*"}
        </div>

        <div className="topTextSub">
          *Cardiovascular disease (CVD) is the blanket term for conditions that
          affect the heart or blood vessels, like heart disease, angina and
          heart attack.
        </div>
      </div>
      <div className="desktopView">
        <FriendInvitation
          riskClass={riskClass}
          resultData={resultData}
          downloadClick={downloadClick}
          emailSent={emailSent}
          resendEmail={resendEmail}
          hcp={true}
        />

        <div className="riskScoreContainer" id="cvdRiskScoreDetails">
          <div className="title head_title">Your assessment in detail</div>
          <div className="riskFactortabContainer">
            <div className="factorTab">
              <div
                className={
                  selectedTab === "doingWell" ? "title active" : "title"
                }
                onClick={() => setTab("doingWell")}
              >
                What you’re doing well
              </div>
              <div
                className={
                  selectedTab === "potential" ? "title active" : "title"
                }
                onClick={() => setTab("potential")}
              >
                Potential risk factors{" "}
              </div>
            </div>
            <div className="riskContainerArea">
              {innerWidth > 500 ? (
                selectedTab === "doingWell" ? (
                  <div className="riskScoreContainer riskScoreContainer1">
                    <div className="title">What you’re doing well</div>
                    <div className="riskFactorContainer riskFactorContainer1">
                      {negativeArray.map((riskfactor, i) => {
                        return (
                          <div className="itemfactor" key={i}>
                            <img src={IconNonPotentialRisk} />
                            <span>{riskfactor.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  ""
                )
              ) : (
                <div className="riskScoreContainer riskScoreContainer1">
                  <div className="title">What you’re doing well</div>
                  <div className="riskFactorContainer riskFactorContainer1">
                    {negativeArray.map((riskfactor, i) => {
                      return (
                        <div className="itemfactor" key={i}>
                          <img src={IconNonPotentialRisk} />
                          <span>{riskfactor.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              {innerWidth > 500 ? (
                selectedTab === "potential" ? (
                  <div className="riskScoreContainer riskScoreContainer1">
                    <div className="title">Potential risk factors </div>
                    <div className="riskFactorContainer riskFactorContainer1">
                      {postiveArray.map((riskfactor, i) => {
                        return (
                          <div className="itemfactor" key={i}>
                            <img src={IconPotentialRisk} />
                            <span>{riskfactor.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  ""
                )
              ) : (
                <div className="riskScoreContainer riskScoreContainer1">
                  <div className="title">Potential risk factors </div>
                  <div className="riskFactorContainer riskFactorContainer1">
                    {postiveArray.map((riskfactor, i) => {
                      return (
                        <div className="itemfactor" key={i}>
                          <img src={IconPotentialRisk} />
                          <span>{riskfactor.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            <div className="riskEmailResult">
              <EmailResultButton
                downloadClick={downloadClick}
                riskClass={riskClass}
                emailSent={emailSent}
                resendEmail={resendEmail}
                hcp={false}
              />
            </div>
          </div>
        </div>
        <AboutRisk />
        <SendInvivationComponent
          riskClass={riskClass}
          downloadClick={downloadClick}
          emailSent={emailSent}
          resendEmail={resendEmail}
          hcp={true}
        />

        {/* <!-- end --> */}
      </div>

      {artlceList.length > 0 ? (
        <ArticleComponent
          changeScreen={changeScreen}
          artlceList={artlceList}
          readMoreLinkFn={readMoreLinkFn}
        />
      ) : (
        ""
      )}
      <div className="bottomTextSub">
        Aspirin is not appropriate for everyone, so be sure to talk to your
        doctor before you begin an aspirin regimen.
      </div>
    </div>
  );
}
