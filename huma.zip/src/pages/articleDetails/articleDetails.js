import React, { useEffect, useState, useRef } from "react";
import BackButton from "../../components/result/backButton/backButton";
import "./articleDetails.scss";

export default function ArticleDetails({ changeScreen, readMoreLink }) {
  window.parent.scrollTo(0, 0);
  useEffect(() => {
    // Update the document title using the browser API
    setTimeout(() => {
      let frame = document.getElementById("articleIframe");
      let header = frame.contentDocument.querySelector("header");
      header.remove();
      let footer = frame.contentDocument.querySelector("footer");
      footer.remove();
    }, 3000);
  }, [readMoreLink]);
  return (
    <>
      <BackButton
        changeScreen={changeScreen}
        text={"Back to your heart score"}
      />

      <div className="articleDetailsContainer">
        <iframe
          id="articleIframe"
          src={readMoreLink}
          height="100%"
          width="100%"
        ></iframe>
      </div>
    </>
  );
}
