import React from 'react'
import CustomSingleSelectOption from '../../elements/customSingleSelectOption/customSingleSelectOption'

export default function Home() {
    return (
        <>
            {/* <Header
                showBackTextInMobile={true}
                showCloseIcon={false}
            />
            <Header
                bgType="gettingToKnowBG"
                title="Getting to know you"
                showCloseIcon={true}
            />
            <CustomMultiSelectOption /> */}
            <CustomSingleSelectOption />
        </>
    )
}
