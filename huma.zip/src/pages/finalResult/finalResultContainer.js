import React, { useEffect, useState } from "react";
import BreakDown from "../breakdown/breakDown";
import Result from "../result/result";
import ArticleDetails from "../articleDetails/articleDetails";
import FriendInvitation from "../../components/result/inviteFriend/inviteFriend";
import { Cases } from "../../utils/API";
import utility from "../../utils/utility";
import { fadeIn } from "react-animations";
import Radium, { StyleRoot } from "radium";
export default function FinalResultContainer() {
  const [resultData, setResultData] = useState();
  const [screen, setScreen] = useState();
  const [riskClass, setRiskClass] = useState();
  const [artlceRecords, setArtlceRecords] = useState([]);
  const [readMoreLink, setReadMoreLink] = useState("");
  const styles = {
    fadeIn: {
      animation: "x 1s",
      animationName: Radium.keyframes(fadeIn, "fadeIn"),
    },
  };
  useEffect(() => {
    if (localStorage.getItem("humaData") != undefined) {
      window.document.getElementsByClassName(
        "container-fluid"
      )[0].style.backgroundColor = "#f4f4f4";
      let getData = JSON.parse(localStorage.getItem("humaData"));

      setRiskClass(getData.riskClass);
      setResultData(getData);
      if (window.location.href.indexOf("FriendInvitation") > -1) {
        setScreen("FriendInvitation");
      } else if (window.location.href.indexOf("TalktoDoctor") > -1) {
        setScreen("TalktoDoctor");
      } else {
        Cases.getResult(getData.riskClass)
          .then((resp) => {
            setArtlceRecords(utility.jsonStringToObj(resp).articles);
          })
          .catch((e) => console.log(e))
          .finally(() => {});

        setScreen("RESULT");
      }
      window.parent.scrollTo(0, 0);
    }
  }, []);

  const changeScreen = (e) => {
    window.parent.scrollTo(0, 0);
    setScreen(e);
  };
  const readMoreLinkFn = (e) => {
    setReadMoreLink(e);
  };
  return (
    <div>
      {
        {
          RESULT: (
            <StyleRoot>
              <div style={styles.fadeIn}>
                <Result
                  changeScreen={changeScreen}
                  riskClass={riskClass}
                  resultData={resultData}
                  artlceRecords={artlceRecords}
                  readMoreLinkFn={readMoreLinkFn}
                />
              </div>
            </StyleRoot>
          ),
          BREAKDOWN: (
            <BreakDown
              changeScreen={changeScreen}
              riskClass={riskClass}
              resultData={resultData}
            />
          ),
          ARTICLE: (
            <ArticleDetails
              changeScreen={changeScreen}
              readMoreLink={readMoreLink}
            />
          ),
          FriendInvitation: (
            <FriendInvitation riskClass={riskClass} resultData={resultData} />
          ),
        }[screen]
      }
    </div>
  );
}
