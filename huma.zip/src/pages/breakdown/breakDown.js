import React, { useEffect, useState, useRef } from "react";
import EmailResultButton from "../../components/result/emailResultButton/emailResultButton";
import IconPotentialRisk from "../../assets/images/Icon-potential-risk.png";
import IconNonPotentialRisk from "../../assets/images/Icon-non-potential-risk.png";
import "./breakDown.scss";
import FriendInvitation from "../../components/result/inviteFriend/inviteFriend";
/* chart */
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { Cases } from "../../utils/API";
import BackButton from "../../components/result/backButton/backButton";
import { Constants } from "../../Constants";
import utility from "../../utils/utility";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function BreakDown({ changeScreen, riskClass, resultData }) {
  const [riskYear, setRiskYear] = useState();
  const [selectedTab, setSelectedTab] = useState("doingWell");
  const [innerWidth, setInnerWidth] = useState(window.innerWidth);
  const [emailSent, setEmailSent] = useState(false);
  const setTab = (tab) => {
    setSelectedTab(tab);
  };
  /*chart*/
  const ref = useRef(null);
  const customRadius = function (context) {
    let index = context.dataIndex;
    let value = context.dataset.data[index];
    return index === 2 ? 6 : 6;
  };
  const customBack = function (context) {
    let index = context.dataIndex;
    let value = context.dataset.data[index];
    return index === 2 ? "#6a18d2" : "transparent";
  };
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
        display: false,
      },
      title: {
        display: true,
      },
    },
    elements: {
      point: {
        radius: customRadius,
        backgroundColor: customBack,
        borderColor: "60px solid #000",
        display: true,
      },
    },
  };
  const labels = [
    "6mn",
    "1yr",
    "2yr",
    "3yr",
    "4yr",
    "5yr",
    "6yr",
    "7yr",
    "8yr",
    "9yr",
    "10yr",
  ];

  useEffect(() => {
    window.parent.scrollTo(0, 0);
    let Trajectory = resultData.riskTrajectory.sort(
      (a, b) => parseFloat(a.days) - parseFloat(b.days)
    );
    let filterYear = Trajectory.filter((x) => x.risk === resultData.risk);

    setRiskYear(parseInt(filterYear[0].days) / 365);
  }, [resultData.riskTrajectory]);

  const formatMapValues = (riskTrajectory) => {
    riskTrajectory = riskTrajectory.sort(
      (a, b) => parseFloat(a.days) - parseFloat(b.days)
    );
    let filterYear = riskTrajectory.filter((x) => x.risk === resultData.risk);

    let newArray = [];
    riskTrajectory.map((data, i) => {
      newArray.push(data.risk);
    });

    return newArray;
  };
  const data = {
    labels,
    datasets: [
      {
        label: "",
        data: formatMapValues(resultData.riskTrajectory),
        borderColor: "#6a18d2",
      },
    ],
  };

  const downloadClick = (email) => {
    var today1 = new Date();
    var dd = String(today1.getDate()).padStart(2, "0");
    var mm = String(today1.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today1.getFullYear();

    today1 = mm + "/" + dd + "/" + yyyy;

    let image = ref.current.toBase64Image();
    Cases.uploadImage({
      name: "image" + Date.now() + ".png",
      data: DataURIToBlob(image),
    })
      .then((response) => {
        console.log("upload response", response);

        let obj = {
          email,
          RiskMeterFlag: Constants[riskClass].RiskMeterFlag,
          InvitationLink: Constants[riskClass].InvitationLink,
          GraphImageURL: response,
          RiskValue: resultData.risk,
          RiskCVDYear: riskYear,
          PotentialRiskFactor: utility.formatData(postiveArray),
          DoingWellFactors: utility.formatData(negativeArray),
          Brand: "Bayer Aspirin",
          CreatedDate: today1,
          Source: "HUMA_CARDIO_WEB",
          Country: "US",
        };
        Cases.emailSFMCAPI(obj)
          .then((resp) => {
            setEmailSent(true);
            console.log("SFMC feedback", resp);
          })
          .catch((e) => console.log(e))
          .finally(() => {});
      })
      .catch((errors) => {
        console.log("errors", errors);
      });
  };
  const resendEmail = () => {
    setEmailSent(false);
  };

  const DataURIToBlob = (dataURI) => {
    var arr = dataURI.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], "filename", { type: mime });
  };

  const postiveArray = resultData.riskFactors.filter(function (x) {
    return x.contribution > 0;
  });
  const negativeArray = resultData.riskFactors.filter(function (x) {
    return x.contribution < 0;
  });

  /* end chart */

  return (
    <div className="firstCardArea">
      <div className="breakdownArea">
        <div className="graphContainer">
          <Line ref={ref} options={options} data={data} />
          <div className="riskText">
            {Math.floor(resultData.risk * 100)}% risk of suffering from CVD in{" "}
            {riskYear}
            yrs
          </div>
          <p>
            About <br />
            Your risk is shown based on developing cardiovascular disease (CVD)*
            over the next 10 years. Several factors affect your risk, some are
            outlined in your contributors below.
          </p>
          {/* <div className="riskEmailResultFirst">
              <EmailResultButton
                downloadClick={downloadClick}
                riskClass={riskClass}
              />
            </div> */}
          <div className="riskEmailContent">
            This assessment is based on the DiCAVA algorithm, which was
            developed by doctors or healthcare professionals and academics for
            Huma Therapeutics. It estimates your risk of developing
            cardiovascular disease (eg. heart attack, stroke, heart failure)
            over the next 10 years and then compares this risk with average
            statistics from other people of the same sex and age.
          </div>
        </div>
      </div>
    </div>
  );
}
