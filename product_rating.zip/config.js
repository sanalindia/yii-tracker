module.exports = [
    {
        brand: "bepanthen",
        lang: "en", // valid locale code
        country: "netherlands"
    },
    {
        brand: "bepanthen",
        lang: "nl",
        country: "netherlands"
    }
]