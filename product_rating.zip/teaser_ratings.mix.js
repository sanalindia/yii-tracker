const mix = require("laravel-mix");

mix.js(['teaser_ratings/jquery.star-rating-svg.min.js', "teaser_ratings/index.js"], "artifacts/teaser_ratings/index.js").setPublicPath("artifacts/teaser_ratings");
mix.copy('teaser_ratings/index.css', 'artifacts/teaser_ratings/index.css');
// mix.copy('teaser_ratings/jquery.star-rating-svg.min.js', 'artifacts/jquery.star-rating-svg.min.js');
