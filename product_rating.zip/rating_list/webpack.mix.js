// webpack.mix.js

let mix = require('laravel-mix');

mix.js('src/index.js', 'build').setPublicPath("build").react();
mix.copy('public/locales', 'build/locales');
mix.copy('public/apiResponse', 'build/apiResponse');