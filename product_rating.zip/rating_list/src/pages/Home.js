import React, { useCallback, useEffect, useRef, useState } from 'react';
import StarRating from '../elements/StarRating/StarRating';
import ReviewModal from "../components/ReviewModal/ReviewModal";
import Popup from '../elements/Popup/Popup';
import SuccessModal from "../components/SuccessModal/SuccessModal";
import { Row, Col, Button, Modal } from 'react-bootstrap'
import { useTranslation } from "react-i18next";
import './Home.css';
import RatingReviewCard from '../components/ratingReviewCard/ratingReviewCard';
import RatingReviewListCard from '../components/ratingReviewListCard/ratingReviewListCard';
import { Cases } from '../utils/API';
import { CaretDownFill, CaretLeftFill, CaretRightFill, FilterSquareFill, PlusCircle, Search, XCircleFill } from 'react-bootstrap-icons';

let productSchemaData = { aggregateRating: {} };

let schemaReviewsSaved = false;
let schemaRatingValueSaved = false;
let schemaReviewCountSaved = false;
let schemaProductDataSaved = false;

export default function Home({ appParams }) {
  const { t } = useTranslation();

  const PER_PAGE_COUNT = 10;

  const [starValue, setStarValue] = useState(0);
  const [reviewData, setReviewList] = useState({});
  const [favReviewData, setFavReviewData] = useState({});
  const [criticalReviewData, setCriticalReviewData] = useState({});
  const [sortOption, setSortOption] = useState({
    sortby: 'rid',
    sorttype: 'desc',
    title: 'most_recent'
  });
  const [starFilters, setStarFilters] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [starRatingCount, setStarRatingCount] = useState([]);
  const [recommendedData, setRecommendedData] = useState({});
  const [showFilterBtn, setFilterBtn] = useState(false);
  const [brandConfigValues, setBrandConfigValue] = useState([]);
  const [reviewFieldList, setFieldList] = useState([]);
  const [showReviewModal, setReviewModal] = useState(false);
  const [isReviewModal, setIsReviewModal] = useState(true);
  const [reviewSuccessLoading, setReviewSuccessLoading] = useState(true);
  const [termsURL, setTermsURL] = useState('');
  const [isReviewSuccess, setReviewSuccess] = useState(false);
  // const [schemaHtml, setSchemaHtml] = useState();

  const reviewModalRef = useRef(null);
  const reviewSuccessModalRef = useRef(null);

  const allSortOptions = [
    {
      sortby: 'rating',
      sorttype: 'desc',
      title: 'highest_to_lowest'
    },
    {
      sortby: 'rating',
      sorttype: 'asc',
      title: 'lowest_to_highest'
    },
    {
      sortby: 'rid',
      sorttype: 'desc',
      title: 'most_recent'
    }];

  const starFilterOptions = [
    {
      value: 1,
      title: `1 ${t('star_title')}`
    },
    {
      value: 2,
      title: `2 ${t('stars_title')}`
    },
    {
      value: 3,
      title: `3 ${t('stars_title')}`
    },
    {
      value: 4,
      title: `4 ${t('stars_title')}`
    },
    {
      value: 5,
      title: `5 ${t('stars_title')}`
    }
  ]

  const handleFavReview = useCallback((list) => {
    // get favorable review
    const favReviewDetails = list?.data || [];
    if (favReviewDetails.length > 0) {
      const favReview = { ...favReviewDetails[0] }
      favReview.title = 'fav_review_title';
      setFavReviewData(favReview);
    }
  }, [])

  const handleCriticalReview = useCallback((list) => {
    // get critical review
    const criticalReviewDetails = list?.data || [];
    if (criticalReviewDetails.length > 0) {
      const criticalReview = { ...criticalReviewDetails[0] }
      criticalReview.title = 'critical_review_title';
      setCriticalReviewData(criticalReview);
    }
  }, [])

  const fetchReviewData = useCallback((params, initialCall) => {
    Cases.fetchReviewList(params)
      .then((res) => {
        setReviewList(res);
        if (initialCall) {
          const list = res?.data || [];
          const schemaReviews = [];
          list.forEach((ele) => {
            const reviewObj = {
              "@type": "Review",
              "author": ele?.nickname || '',
              "datePublished": ele?.create_date || '',
              "reviewBody": ele?.review_description || '',
              "name": ele?.review_title || '',
              "reviewRating": {
                "@type": "Rating",
                "bestRating": "5",
                "ratingValue": String(ele?.rating) || '',
                "worstRating": "1"
              }
            }
            schemaReviews.push(reviewObj);
          })

          productSchemaData.review = schemaReviews;

          schemaReviewsSaved = true;
          loadProductSchema();
        }
      })
      .catch((e) => console.log(e));
  }, [])

  const fetchFavReview = useCallback((params) => {
    Cases.fetchReviewList(params)
      .then((res) => handleFavReview(res))
      .catch((e) => console.log(e));
  }, [handleFavReview])

  const fetchCriticalReview = useCallback((params) => {
    Cases.fetchReviewList(params)
      .then((res) => handleCriticalReview(res))
      .catch((e) => console.log(e));
  }, [handleCriticalReview])

  const getReviewRatingDetails = useCallback(() => {
    Cases.fetchProductRating()
      .then((res) => {
        setStarValue(res);

        productSchemaData.aggregateRating.ratingValue = res;

        schemaRatingValueSaved = true;
        loadProductSchema();
      })
      .catch((e) => console.log(e));

    fetchReviewData({ perpage: PER_PAGE_COUNT }, true);

    fetchFavReview({ sortby: 'rating', sorttype: 'desc', perpage: 1 });

    fetchCriticalReview({ sortby: 'rating', sorttype: 'asc', perpage: 1 });

    Cases.fetchStarRatingCount()
      .then((res) => {
        setStarRatingCount(res);

        productSchemaData.aggregateRating.reviewCount = res?.totalCount;

        schemaReviewCountSaved = true;
        loadProductSchema();
      })
      .catch((e) => console.log(e));

    Cases.fetchRecommendedCount()
      .then((res) => setRecommendedData(res))
      .catch((e) => console.log(e));

  }, [fetchReviewData, fetchFavReview, fetchCriticalReview])

  const refreshReviews = useCallback(() => {
    setSortOption({
      sortby: 'rid',
      sorttype: 'desc',
      title: 'most_recent'
    });
    setStarFilters([]);
    setSearchText('');
    setCurrentPage(1);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'none';

    getReviewRatingDetails();
  }, [getReviewRatingDetails]);

  const manageFieldList = (list, configValues) => {
    const phaseValues =
      configValues.includes("phase1") && configValues.includes("phase2")
        ? [1, 2]
        : configValues.includes("phase1")
          ? [1]
          : configValues.includes("phase2")
            ? [2]
            : [1];
    const fieldList = list.filter((ele) =>
      phaseValues.includes(Number(ele?.status))
    );
    setFieldList(fieldList);
  };

  useEffect(() => {
    Cases.getAppParams(appParams);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'none';

    const productTitle = window?.drupalSettings?.wsf_analytics?.node?.title || '';
    const pdtImgs = window?.drupalSettings?.wsfamv?.img_data;
    const productImg = pdtImgs && pdtImgs.length > 0 ? pdtImgs[0] : {};
    const imgUrl = productImg?.url || '';

    productSchemaData.name = productTitle;
    productSchemaData.image = imgUrl;

    schemaProductDataSaved = true;
    loadProductSchema();

    Cases.fetchBrandConfig()
      .then((configResponse) => {
        const configValues = configResponse?.configKey;

        setBrandConfigValue(configValues);

        setTermsURL(configResponse?.termsURL);

        Cases.fetchReviewFields()
          .then((res) => manageFieldList(res, configValues))
          .catch((e) => console.log(e));
      })
      .catch((e) => console.log(e));

    getReviewRatingDetails();

    if (isReviewModal && reviewModalRef && reviewModalRef.current) setIsReviewModal(false);

    if (reviewSuccessLoading && reviewSuccessModalRef && reviewSuccessModalRef.current) setReviewSuccessLoading(false);

  }, [getReviewRatingDetails, appParams, isReviewModal, reviewSuccessLoading]);

  const handleModal = () => {
    setReviewModal(!showReviewModal);
  }

  let recommendationText = t('recommendation_count');
  recommendationText = recommendationText.replace('<count>', recommendedData?.recommendedCount);
  recommendationText = recommendationText.replace('<total_count>', recommendedData?.totalRecommended);
  recommendationText = recommendationText.replace('<percentage>', recommendedData?.recommendedPercent);

  /* When the user clicks on the button,
  toggle between hiding and showing the dropdown content */
  const toggleDropdown = () => {
    document.getElementById("dropdown-list").classList.toggle("show");
  }
  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }

  const handleSortOptions = (option) => {
    setCurrentPage(1);
    setSortOption(option);

    let ratingParam = '';
    starFilters.forEach((ele) =>
      ratingParam = String(ratingParam) + String(ele) + ','
    )
    ratingParam = ratingParam.slice(0, -1);

    const params = {
      sortby: option?.sortby,
      sorttype: option?.sorttype,
      search: searchText,
      perpage: PER_PAGE_COUNT,
      rating: ratingParam,
      page: 1
    }
    fetchReviewData(params);
  }

  const toggleFilterOption = () => {
    setFilterBtn(!showFilterBtn);
  }

  const handleFilterRating = (ratingData) => {
    setCurrentPage(1);

    let ratingParam = '';
    ratingData.forEach((ele) =>
      ratingParam = String(ratingParam) + String(ele) + ','
    )
    ratingParam = ratingParam.slice(0, -1);

    const params = {
      sortby: sortOption?.sortby,
      sorttype: sortOption?.sorttype,
      search: searchText,
      perpage: PER_PAGE_COUNT,
      rating: ratingParam,
      page: 1
    }
    fetchReviewData(params);
  }

  const selectStarFilter = (option) => {
    const filterArray = [...starFilters];
    filterArray.push(option);
    filterArray.sort();
    const removeDuplicate = [...new Set(filterArray)];
    setStarFilters(removeDuplicate);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'block';

    handleFilterRating(removeDuplicate);
  }

  const clearStarFilter = (option) => {
    const filterArray = starFilters.filter((ele) => ele !== option);
    setStarFilters(filterArray);

    if (filterArray.length === 0) {
      const activeFilterBtn = document.getElementById("active-filter");
      if (activeFilterBtn) activeFilterBtn.style.display = 'none';
    }

    handleFilterRating(filterArray);
  }

  const clearAllFilters = () => {
    setStarFilters([]);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'none';

    handleFilterRating([]);
  }

  const seeMoreFilter = (ratingValue) => {
    const filterArray = [...starFilters];
    filterArray.push(ratingValue);
    const lowerRating = ratingValue - 1;
    if (lowerRating > 0) {
      filterArray.push(lowerRating);
    }
    filterArray.sort();
    const removeDuplicate = [...new Set(filterArray)];
    setStarFilters(removeDuplicate);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'block';

    handleFilterRating(removeDuplicate);
  }

  const searchReviews = () => {
    setCurrentPage(1);

    const params = {
      sortby: sortOption?.sortby,
      sorttype: sortOption?.sorttype,
      search: searchText,
      perpage: PER_PAGE_COUNT,
      page: 1
    }
    fetchReviewData(params);
  }

  const goToPrevReviewList = () => {
    const newPage = Number(currentPage) - 1;
    setCurrentPage(newPage);

    let ratingParam = '';
    starFilters.forEach((ele) =>
      ratingParam = String(ratingParam) + String(ele) + ','
    )
    ratingParam = ratingParam.slice(0, -1);

    const params = {
      sortby: sortOption?.sortby,
      sorttype: sortOption?.sorttype,
      search: searchText,
      perpage: PER_PAGE_COUNT,
      rating: ratingParam,
      page: newPage
    }
    fetchReviewData(params);
  }

  const goToNextReviewList = () => {
    const newPage = Number(currentPage) + 1;
    setCurrentPage(newPage);

    let ratingParam = '';
    starFilters.forEach((ele) =>
      ratingParam = String(ratingParam) + String(ele) + ','
    )
    ratingParam = ratingParam.slice(0, -1);

    const params = {
      sortby: sortOption?.sortby,
      sorttype: sortOption?.sorttype,
      search: searchText,
      perpage: PER_PAGE_COUNT,
      rating: ratingParam,
      page: newPage
    }
    fetchReviewData(params);
  }

  const starProgressClicked = (ratingValue) => {
    const filterArray = [...starFilters];
    filterArray.push(ratingValue);
    filterArray.sort();
    const removeDuplicate = [...new Set(filterArray)];
    setStarFilters(removeDuplicate);

    const activeFilterBtn = document.getElementById("active-filter");
    if (activeFilterBtn) activeFilterBtn.style.display = 'block';

    handleFilterRating(removeDuplicate);
  }

  const postReview = (reviewData) => {
    setReviewModal(false);
    Cases.postReview(reviewData)
      .then((res) => {
        if (res === "success") {
          setReviewSuccess(true);

          // after posting reviews, refreshing review apis
          refreshReviews();
        }
      })
      .catch((e) => console.log(e));
  };

  const closeSuccessModal = () => {
    setReviewSuccess(false);
  };

  const loadProductSchema = () => {
    if (schemaReviewsSaved && schemaRatingValueSaved && schemaReviewCountSaved && schemaProductDataSaved) {
      schemaReviewsSaved = false;
      schemaRatingValueSaved = false;
      schemaReviewCountSaved = false;
      schemaProductDataSaved = false;

      let data = {
        "@context": "https://schema.org",
        "@type": "Product",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": productSchemaData?.aggregateRating?.ratingValue ? `${productSchemaData.aggregateRating.ratingValue}` : "",
          "reviewCount": productSchemaData?.aggregateRating?.reviewCount ? `${productSchemaData.aggregateRating.reviewCount}` : ""
        },
        "name": productSchemaData?.name ? `${productSchemaData.name}` : "",
        "image": productSchemaData?.image ? `${productSchemaData.image}` : "",
        "review": productSchemaData?.review ? productSchemaData.review : []
      };


      const schemaData = JSON.stringify(data);
      // const scriptHTML = { __html: schemaData };
      console.log('Product schema loaded: ', data);

      // setSchemaHtml(scriptHTML);


      var schemeElement = document.createElement('script');
      schemeElement.type = 'application/ld+json';
      schemeElement.text = schemaData;

      document.querySelector('head').appendChild(schemeElement);
    }
  }

  const reviewList = reviewData?.data || [];
  const totalReviewCount = reviewData?.total || 0;
  const prevReviewNumber = Number((Number(currentPage) - 1) * PER_PAGE_COUNT);
  const startingReviewNumber = prevReviewNumber + 1;
  const endingReviewNumber = prevReviewNumber + reviewList.length;

  return (
    <>
      {/* <script
        type="application/ld+json"
        dangerouslySetInnerHTML={schemaHtml}
      /> */}
      <div id='rating_list_parent_element'>
        <div className='reviewTitle'>{t('reviews_title')}</div>

        <div className='d-flex align-items-end'>
          <StarRating value={starValue * 20} color="#276c9d" emptyColor="#CCCCCC" />
          <div className='ratingValue'>{`${starValue}`}</div>
          <div className='divider'></div>
          <div className='reviewCount'>{`${starRatingCount?.totalCount} ${t('reviews_title')}`}</div>

        </div>
        <div>
          <div className='recommendedTitle'>{recommendationText}</div>

          <div className="input-group rounded searchView">
            <input
              type="search"
              className="form-control"
              placeholder={`${t('search_reviews')}`}
              aria-label="Search"
              aria-describedby="search-addon"
              value={searchText}
              onChange={(ele) => setSearchText(ele.target.value)}
            />
            <button onClick={() => searchReviews()}>
              <Search color='#ffffff' size={20} />
            </button>
          </div>

          <div className="d-flex justify-content-start">
            <Button variant="dark" onClick={handleModal} className="addReviewButton">{t('write_a_review')}</Button>
          </div>
          <Row className='innerView'>
            <Col>
              <div className='ratingSnapshotTitle'>{t('rating_snapshot_title')}</div>
              <div className='ratingProgressTitle'>{t('star_progress_title')}</div>
              <Popup starRatingCount={starRatingCount} starProgressClicked={starProgressClicked} />
            </Col>
            <Col>
              <div className='avgCustomerRating'>{t('avg_customer_rating')}</div>
              <div className="d-flex overallRatingView align-items-center">
                <div className='overall'>{t('overall_title')}</div>
                <StarRating value={starValue * 20} color="#fff200" />
                <div className='overallRating'>{`${starValue}`}</div>
              </div>
            </Col>
          </Row>
          {starFilters.length === 0 ? (
            <Row className='helpfulReviewView'>
              {Object.keys(favReviewData).length > 0 ? (
                <Col lg={6} md={6}>
                  <RatingReviewCard
                    reviewData={favReviewData}
                    seeMoreFilter={seeMoreFilter}
                  />
                </Col>
              ) : null}
              {Object.keys(criticalReviewData).length > 0 ? (
                <Col lg={6} md={6}>
                  <RatingReviewCard
                    reviewData={criticalReviewData}
                    seeMoreFilter={seeMoreFilter}
                  />
                </Col>
              ) : null}
            </Row>
          ) : null}
          <div className='reviewListingSection'>
            <h6 className='reviewPage'>
              {`${startingReviewNumber} - ${endingReviewNumber} ${t('of_text')} ${totalReviewCount} ${t('reviews_title')}`}
            </h6>

            <div className='sortView'>
              <div className='d-flex align-items-center'>
                <h6 className='sortTitle'>
                  {`${t('sort_by')}:`}
                </h6>

                <div className="dropdown">
                  <button onClick={() => toggleDropdown()} className="dropbtn">
                    {`${t(sortOption?.title)}`}
                    <CaretDownFill size={12} className='dropdownIcon' />
                  </button>

                  <div id="dropdown-list" className="dropdown-content">
                    {allSortOptions.map((ele, index) =>
                      <React.Fragment key={`dropdown-${index}`}>
                        <p onClick={() => handleSortOptions(ele)}>
                          {`${t(ele?.title)}`}
                        </p>
                      </React.Fragment>
                    )}
                  </div>
                </div>
              </div>

              <button
                className='filterButton'
                onClick={() => toggleFilterOption()}
              >
                <FilterSquareFill size={24} />
              </button>

            </div>
          </div>

          <Row>
            {showFilterBtn ? (
              <div id="filter-button" className="starFilterView">
                {starFilterOptions.map((ele, index) =>
                  <React.Fragment key={`filterView-${index}`}>
                    <button className='starOption' onClick={() => selectStarFilter(ele?.value)}>
                      <PlusCircle className='plusIcon' size={12} />
                      {ele?.title}
                    </button>
                  </React.Fragment>
                )}
              </div>
            ) : null}

            {starFilters.length > 0 ? (
              <div id="active-filter" className="activeFilterSection">
                <p>
                  {`${t('active_filters')}`}
                </p>
                {starFilters.map((ele, index) =>
                  <React.Fragment key={`activeFilter-${index}`}>
                    <button className='starFilterOptn' onClick={() => clearStarFilter(ele)}>
                      {Number(ele) === 1 ? `${ele} ${t('star_title_caps')}` : `${ele} ${t('stars_title_caps')}`}
                      <XCircleFill className='clearIcon' size={12} />
                    </button>
                  </React.Fragment>
                )}
                <button className='clearFilter' onClick={() => clearAllFilters()}>
                  {t('clear_all')}
                  <XCircleFill className='clearIcon' size={12} />
                </button>
              </div>
            ) : null}

            {reviewList.map((item, index) => (
              <React.Fragment key={`list-in-${index}`}>
                <Col lg={12} md={12}>
                  <RatingReviewListCard
                    reviewItem={item}
                  />
                </Col>
              </React.Fragment>
            ))}

          </Row>

          <Row className='footerView'>
            <div className='d-flex justify-content-between align-items-center'>
              <h6 className='reviewPageFooter'>
                {`${startingReviewNumber} - ${endingReviewNumber} ${t('of_text')} ${totalReviewCount} ${t('reviews_title')}`}
              </h6>

              <div className='paginationBtns'>
                <button disabled={currentPage === 1} onClick={() => goToPrevReviewList()}>
                  <CaretLeftFill />
                </button>
                <button disabled={currentPage * PER_PAGE_COUNT >= totalReviewCount} onClick={() => goToNextReviewList()}>
                  <CaretRightFill />
                </button>

              </div>
            </div>

          </Row>
        </div>

        <div ref={reviewModalRef} className="review-modal-container">
          <Modal
            size="lg"
            show={showReviewModal}
            className="review_modal"
            onHide={() => {
              setReviewModal(false);
            }}
            aria-labelledby="example-modal-sizes-title-lg"
            container={!isReviewModal ? reviewModalRef.current : null}
          >
            <ReviewModal
              postReview={postReview}
              handleModal={handleModal}
              fieldList={reviewFieldList}
              brandConfigValues={brandConfigValues}
              termsURL={termsURL}
            />
          </Modal>
        </div>

        <div ref={reviewSuccessModalRef} className="successModalView">
          <Modal
            container={!reviewSuccessLoading ? reviewSuccessModalRef.current : null}
            show={isReviewSuccess}
            onHide={closeSuccessModal}
            size="sm"
            centered>
            <SuccessModal
              closeModal={closeSuccessModal}
            />
          </Modal>
        </div>
      </div>
    </>
  )
}