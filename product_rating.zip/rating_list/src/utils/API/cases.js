import Utility from "../Utility";
import { get, post } from "./config";

let brandName = '';
let productName = '';
let language = '';
let country = '';

const getAppParams = (params) => {
  brandName = params.brandName;
  productName = params.productName;
  language = params.language;
  country = params.country;
}

const fetchBrandConfig = async () => {
  let params = {
    "params[brand]": brandName,
    "params[language]": language,
    "params[country]": country,
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/front_brand_config", reqData);
  const brandConfigs = [...response.data.result];
  const termsURL = brandConfigs.length > 0 ? brandConfigs[0].terms : '';
  const configKey = [];
  brandConfigs.forEach((ele) => {
    configKey.push(ele?.config_key)
  });
  return {
    configKey,
    termsURL
  };
};

const fetchReviewFields = async () => {
  const response = await get("api/v1/fields");
  const fieldList = [...response.data.result];
  return fieldList;
};

const fetchProductRating = async () => {
  let params = {
    "params[brand]": brandName,
    "params[product]": productName,
    "params[language]": language,
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/product_rating", reqData);
  const ratingList = [...response.data.result];
  const ratingValue = Number(ratingList[0]?.rating);
  const roundedValue = Math.round(ratingValue * 10) / 10;
  return roundedValue;
}

const fetchReviewList = async (reviewParams) => {
  let params = {
    "params[brand]": brandName,
    "params[product]": productName,
    "params[language]": language,
    "params[sortby]": reviewParams?.sortby || '',
    "params[sorttype]": reviewParams?.sorttype || '',
    "params[search]": reviewParams?.search || '',
    "params[perpage]": reviewParams?.perpage || 10,
    "params[page]": reviewParams?.page || 1,
    "params[rating]": reviewParams?.rating || ''
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/product_review_list", reqData);
  const ratingList = response.data.result;
  return ratingList;
}

const fetchStarRatingCount = async () => {
  let params = {
    "params[brand]": brandName,
    "params[product]": productName,
    "params[language]": language
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/product_rating_count", reqData);
  const ratingCount = [...response.data.result];

  const fiveStarReview = ratingCount?.find((ele) => Number(ele.rating) === 5);
  const fourStarReview = ratingCount?.find((ele) => Number(ele.rating) === 4);
  const threeStarReview = ratingCount?.find((ele) => Number(ele.rating) === 3);
  const twoStarReview = ratingCount?.find((ele) => Number(ele.rating) === 2);
  const oneStarReview = ratingCount?.find((ele) => Number(ele.rating) === 1);

  const fiveStarCount = Number(fiveStarReview?.total) || 0;
  const fourStarCount = Number(fourStarReview?.total) || 0;
  const threeStarCount = Number(threeStarReview?.total) || 0;
  const twoStarCount = Number(twoStarReview?.total) || 0;
  const oneStarCount = Number(oneStarReview?.total) || 0;

  const totalCount = fiveStarCount + fourStarCount + threeStarCount + twoStarCount + oneStarCount;

  const starRatingCount = {
    fiveStarCount,
    fourStarCount,
    threeStarCount,
    twoStarCount,
    oneStarCount,
    totalCount
  }

  return starRatingCount;
}

const fetchRecommendedCount = async () => {
  let params = {
    "params[brand]": brandName,
    "params[product]": productName,
    "params[language]": language
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/product_recommendation", reqData);
  const recommendedData = [...response.data.result];
  const positiveRecommended = recommendedData.filter((ele) => Number(ele?.recommendation) === 1);
  const totalRecommended = recommendedData?.length || 0;
  const recommendedCount = positiveRecommended?.length || 0;
  let recommendedPercent = totalRecommended > 0 ? (recommendedCount/totalRecommended) * 100 : 0;
  recommendedPercent = Math.round(recommendedPercent * 10) / 10;
  const recommendations = {
    totalRecommended,
    recommendedCount,
    recommendedPercent
  }
  return recommendations;
}

const postReview = async (reviewParams) => {
  let params = {
    "params[brand]": brandName,
    "params[product]": productName,
    "params[language]": language,
    "params[country]": country,
    "params[recommendation]": reviewParams.recommendation,
    "params[rating]": reviewParams.rating,
    "params[nickname]": reviewParams.nickname,
    "params[email]": reviewParams.email,
    "params[review_title]": reviewParams.reviewTitle,
    "params[review_description]": reviewParams.reviewDesc,
  };
  const reqData = Utility.urlEncodedRequest(params);
  const response = await post("api/v1/add", reqData);
  const reviewAddedStatus = response?.data?.status;
  return reviewAddedStatus;
};

const APIList = {
  getAppParams,
  fetchBrandConfig,
  fetchReviewFields,
  fetchProductRating,
  fetchReviewList,
  fetchStarRatingCount,
  fetchRecommendedCount,
  postReview
};

export default APIList;
