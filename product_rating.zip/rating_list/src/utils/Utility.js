/* eslint-disable import/no-anonymous-default-export */
// import moment from "moment";

export default {
  urlEncodedRequest: (requestData) => {
    const params = new URLSearchParams();
    Object.entries(requestData).map(([key, value]) =>
      params.append(key, value)
    );
    return params;
  },
};
