
import Home from './pages/Home';
import './App.scss';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

function App({ appParams }) {
  const { i18n } = useTranslation();
  
  useEffect(() => {
    const currentLang = window?.drupalSettings?.path?.currentLanguage || 'en';
    i18n.changeLanguage(currentLang);
  }, [i18n]);

  return (
    <div className="rating-list-container">
      <Home
        appParams={appParams}
      >
      </Home>
    </div>

  );
}

export default App;
