import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import HttpApi from "i18next-http-backend";

i18n

    // pass the i18n instance to react-i18next.
    .use(initReactI18next)
    .use(HttpApi)
    // init i18next
    .init({
        debug: true,
        fallbackLng: 'en',

        backend: {
            loadPath: process.env.MIX_PUBLIC_URL + "/locales/{{lng}}/{{ns}}.json"
        }
    });

export default i18n;