import React, { useEffect, useState } from 'react'
import { Rating } from 'react-simple-star-rating'

export default function StarRating({ value, color, emptyColor }) {
    const [rating, setRating] = useState(value); // initial rating value

    useEffect(() => {
        if (rating !== value) {
            setRating(value);
        }
    }, [rating, value]);

    // Catch Rating value
    const handleRating = (rate) => {
        setRating(rate)
    }

    return (
        <div className='star-rating-wrapper'>
            <Rating
                onClick={handleRating}
                ratingValue={rating}
                fillColor={color}
                initialValue={0}
                size={25}
                emptyColor={emptyColor || "transparent"}
                allowHalfIcons
                readonly />
        </div>
    )
}