import React from 'react';
import './StarWithProgressBar.css';
import { StarFill } from "react-bootstrap-icons";

export function StarWithProgressBar({ config, starProgressClicked }) {

    return (

        <div className='d-flex align-items-center'>
            <div className='starProgressView' onClick={() => starProgressClicked(config.value)}>
                <div className="d-flex align-items-center">
                    <span className='starProgressLabel'>{config.value}</span>
                    <StarFill color="#2180d7" size={12} />
                </div>
                {/* <div class="progress w-5" >
                <div class={`progress-bar w-${config.ratedValue}`} role="progressbar" aria-valuenow={config.ratedValue} aria-valuemin="0" aria-valuemax="100">
                </div>
            </div> */}
                <div className="progressView">
                    <progress className="starProgressListing" value={config.ratedValue} max="1"></progress>
                </div>
                <div className='starProgressValue'>{config.count}</div>
            </div>
        </div>

    )
}
