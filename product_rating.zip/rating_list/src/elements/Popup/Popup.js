import React, { useCallback, useEffect, useState } from "react";
import { StarWithProgressBar } from '../StarWithProgressBar/StarWithProgressBar';
import "./Popup.scss";

export default function Popup({ starRatingCount, starProgressClicked }) {

  const initialConfig = {
    fiveStar: {
      value: 5,
      ratedValue: 0,
      count: 0
    },
    fourStar: {
      value: 4,
      ratedValue: 0,
      count: 0
    },
    threeStar: {
      value: 3,
      ratedValue: 0,
      count: 0
    },
    twoStar: {
      value: 2,
      ratedValue: 0,
      count: 0
    },
    oneStar: {
      value: 1,
      ratedValue: 0,
      count: 0
    }
  }
  const [ratingValues, setRatingValues] = useState(initialConfig);

  const getRatingProgressValues = useCallback(() => {
    const config = {
      fiveStar: {
        value: 5,
        ratedValue: starRatingCount?.fiveStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.fiveStarCount
      },
      fourStar: {
        value: 4,
        ratedValue: starRatingCount?.fourStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.fourStarCount
      },
      threeStar: {
        value: 3,
        ratedValue: starRatingCount?.threeStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.threeStarCount
      },
      twoStar: {
        value: 2,
        ratedValue: starRatingCount?.twoStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.twoStarCount
      },
      oneStar: {
        value: 1,
        ratedValue: starRatingCount?.oneStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.oneStarCount
      }
    }
    setRatingValues(config);
  }, [starRatingCount]);

  useEffect(() => {
    if (Number(starRatingCount?.totalCount) > 0) {
      getRatingProgressValues();
    }
  }, [starRatingCount, getRatingProgressValues]);

  return (
    <div className="d-flex flex-column">
      <div>
        <StarWithProgressBar config={ratingValues?.fiveStar} starProgressClicked={starProgressClicked}></StarWithProgressBar>
      </div>
      <div>
        <StarWithProgressBar config={ratingValues?.fourStar} starProgressClicked={starProgressClicked}></StarWithProgressBar>
      </div>
      <div>
        <StarWithProgressBar config={ratingValues?.threeStar} starProgressClicked={starProgressClicked}></StarWithProgressBar>
      </div>
      <div>
        <StarWithProgressBar config={ratingValues?.twoStar} starProgressClicked={starProgressClicked}></StarWithProgressBar>
      </div>
      <div>
        <StarWithProgressBar config={ratingValues?.oneStar} starProgressClicked={starProgressClicked}></StarWithProgressBar>
      </div>
    </div>
  );
}
