import React, { useState } from "react";
import { Container, Row, Col, Button, Form } from "react-bootstrap";
import { Rating } from "react-simple-star-rating";
import { XCircleFill } from "react-bootstrap-icons";
import "./ReviewModal.scss";
import { useTranslation } from "react-i18next";

export default function ReviewModal({
  handleModal,
  postReview,
  fieldList,
  brandConfigValues,
  termsURL,
}) {
  const { t } = useTranslation();

  const [rating, setRating] = useState(0);
  const [recommendation, setRecommendation] = useState("");
  const [title, setReviewTitle] = useState("");
  const [description, setReviewDescription] = useState("");
  const [userNickname, setNickname] = useState("");
  const [userEmail, setEmail] = useState("");
  const [errors, setErrors] = useState({});
  const [isTermsAccepted, setIsTermAccepted] = useState(false);
  const [allowReviewPost, setAllowReviewPost] = useState(true);

  const tooltipArray = [
    t("poor"),
    t("fair"),
    t("average"),
    t("good"),
    t("excellent"),
  ];
  const fillColorArray = [
    "#b43034",
    "#de9500",
    "#ecdb00",
    "#8ac100",
    "#338b2b",
  ];
  // Catch Rating value
  const handleRating = (rate) => {
    setRating(rate / 20);
  };

  const findFormErrors = () => {
    const newErrors = {};
    // name errors
    if (checkFieldAvailability("review_title")) {
      if (!title || title === "") newErrors.name = t("review_title_rqd");
    }
    // recommendation errors

    if (recommendation === "")
      newErrors.recommendation = t("recommendation_mandatory");

    // rating errors

    if (!rating || rating === 0) newErrors.rating = t("rating_rqd");

    // comment errors
    if (checkFieldAvailability("review_description")) {
      if (!description || description === "")
        newErrors.description = t("description_rqd");
    }
    // email errors
    // if (checkFieldAvailability('email')) {
    const pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    if (!userEmail || userEmail === "") newErrors.userEmail = t("email_rqd");
    else if (userEmail.match(pattern) === null)
      newErrors.userEmail = t("email_pttern");
    // }
    // name errors
    // if (checkFieldAvailability('nickname')) {
    if (!userNickname || userNickname === "")
      newErrors.userNickname = t("nickname_rqd");
    // }
    //
    return newErrors;
  };

  const postReviewRating = () => {
    const isConfigValues = brandConfigValues.length > 0 ? true : false;
    if (!isConfigValues) {
      setAllowReviewPost(isConfigValues);
    } else {
      // get our new errors
      const newErrors = findFormErrors();
      // Conditional logic:
      if (Object.keys(newErrors).length > 0) {
        // We got errors!
        setErrors(newErrors);
      } else {
        // No errors! Put any logic here for the form submission!
        const reviewParams = {
          recommendation,
          rating,
          nickname: userNickname,
          email: userEmail,
          reviewTitle: title,
          reviewDesc: description,
        };
        postReview(reviewParams);
      }
    }
  };
  const handleCheckBox = (e) => {
    setIsTermAccepted(e.target.checked);
  };

  const checkFieldAvailability = (fieldName) => {
    return fieldList.find((ele) => ele?.field_name === fieldName);
  };

  const getRecommedBtnClsName = (recommendValue) => {
    let btnClsName = "btn ";
    btnClsName =
      recommendValue === recommendation
        ? btnClsName + "recommendBtnsActive"
        : btnClsName + "recommendBtns";
    return btnClsName;
  };

  const productTitle = window?.drupalSettings?.wsf_analytics?.node?.title || "";
  const pdtImgs = window?.drupalSettings?.wsfamv?.img_data;
  const productImg = pdtImgs && pdtImgs.length > 0 ? pdtImgs[0] : {};
  const imgUrl = productImg?.url || "";

  return (
    <Container>
      <form>
        <Row>
          <Col className="modal-left-content" md={2}>
            <div className="img-keywords">
              <img src={imgUrl} alt="" />
              <p className="productTitle">{productTitle}</p>
            </div>
          </Col>
          <Col className="modal-right-content" md={10}>
            <Row>
              <Col>
                <div className="d-flex justify-content-between">
                  <div className="title py-3">
                    {t("my_review")}
                    {/* for Claritin® Tablets 24-Hour */}
                  </div>
                  <span className="close-btn p-2" onClick={handleModal}>
                    <XCircleFill size={24}></XCircleFill>
                  </span>
                </div>
                <div className="py-3">
                  {t("required_fields_are_marked_with")} *
                </div>
              </Col>
            </Row>
            <Row className="reviewRatingView bordering-top py-3">
              <span className="overallRatingText">{`${t(
                "overall_rating"
              )} (* = ${t("required")})*`}</span>

              <div className="overallStarRating">
                <Rating
                  onClick={handleRating}
                  ratingValue={rating * 20}
                  showTooltip
                  tooltipArray={tooltipArray}
                  fillColorArray={fillColorArray}
                  tooltipDefaultText={t("ratingTooltipDefaultText")}
                  tooltipStyle={{
                    width: "110px",
                    height: "35px",
                    backgroundColor: "#2180d7",
                    padding: "0px 0px",
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                />
              </div>
              {errors && errors.rating && (
                <span className="warning-text">{errors.rating}</span>
              )}
            </Row>

            <Row className="recommend bordering-top py-3">
              <label>{t("recommend_text")}*</label>
              <div
                className="btn-group"
                role="group"
                aria-label="recommend-btn"
              >
                <button
                  type="button"
                  className={getRecommedBtnClsName(1)}
                  onClick={() => setRecommendation(1)}
                >
                  {t("yes")}
                </button>
                <button
                  type="button"
                  className={getRecommedBtnClsName(0)}
                  onClick={() => setRecommendation(0)}
                >
                  {t("no")}
                </button>
              </div>
              {errors && errors.recommendation && (
                <span className="warning-text">{errors.recommendation}</span>
              )}
            </Row>

            {/* {(checkFieldAvailability("nickname") || checkFieldAvailability("email")) ? ( */}
            <Row className="wrapper bordering-top d-flex">
              {/* {checkFieldAvailability("nickname") ? ( */}
              <div className="userFields py-3">
                <label className="mb-2">{t("nickname")}*</label>
                <Form.Control
                  type="text"
                  className="form-control"
                  placeholder={`${t("example")}: bob27`}
                  value={userNickname}
                  onChange={(e) => setNickname(e.target.value)}
                  isInvalid={!!errors.userNickname}
                />
                {errors && errors.userNickname && (
                  <Form.Control.Feedback type="invalid">
                    {errors.userNickname}
                  </Form.Control.Feedback>
                )}
              </div>
              {/* ) : null} */}

              {/* {(checkFieldAvailability("nickname") && checkFieldAvailability("email")) ? ( */}
              <div className="emailDivider" />
              {/* ) : null} */}

              {/* {checkFieldAvailability("email") ? ( */}
              <div className="userFields">
                <div className="py-3">
                  <label className="mb-2">{t("email")}*</label>
                  <Form.Control
                    type="email"
                    className="form-control"
                    placeholder={`${t("example")}: youremail@example.com`}
                    value={userEmail}
                    onChange={(e) => setEmail(e.target.value)}
                    isInvalid={!!errors.userEmail}
                  />
                  {errors && errors.userEmail && (
                    <Form.Control.Feedback type="invalid">
                      {errors.userEmail}
                    </Form.Control.Feedback>
                  )}
                </div>
              </div>
              {/* ) : null} */}
            </Row>
            {/* ) : null} */}

            {checkFieldAvailability("review_title") ? (
              <Row className="bordering-top py-3">
                <Col>
                  <div className="title-field">
                    <label className="mb-2">{t("review_title")}*</label>
                    <Form.Control
                      type="text"
                      onChange={(e) => setReviewTitle(e.target.value)}
                      value={title}
                      placeholder={`${t("example")}: ${t(
                        "review_title_description"
                      )}!`}
                      isInvalid={!!errors.name}
                    />

                    {errors && errors.name && (
                      <Form.Control.Feedback type="invalid">
                        {errors.name}
                      </Form.Control.Feedback>
                    )}
                  </div>
                </Col>
              </Row>
            ) : null}

            {checkFieldAvailability("review_description") ? (
              <Row className="bordering-top py-3">
                <Col>
                  <div className="review-area">
                    <label className="mb-2">{t("review")}*</label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      placeholder={`${t("example")}: ${t(
                        "review_description"
                      )}`}
                      value={description}
                      onChange={(e) => setReviewDescription(e.target.value)}
                      isInvalid={!!errors.description}
                    />
                    {errors && errors.description && (
                      <Form.Control.Feedback type="invalid">
                        {errors.description}
                      </Form.Control.Feedback>
                    )}
                  </div>
                </Col>
              </Row>
            ) : null}

            <Row className="bordering-top py-3">
              <Col>
                <div>
                  <div className="form-check form-check-inline ">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="defaultCheck1"
                      onChange={(e) => handleCheckBox(e)}
                    />
                    <label className="form-check-label" htmlFor="defaultCheck1">
                      {t("agree")}{" "}
                      <a href={termsURL} target="_blank" rel="noreferrer">
                        {t("terms_conditions")}
                      </a>
                    </label>
                  </div>
                </div>
                <div className="py-2">
                  <p>{t("subscription_text")}</p>
                </div>
                {!allowReviewPost ? (
                  <p className="brandConfigError">{t("brand_config_error")}</p>
                ) : null}
                <div className="py-3">
                  <Button
                    onClick={postReviewRating}
                    variant="dark"
                    disabled={!isTermsAccepted}
                    className="postReviewBtn"
                  >
                    {t("post_reviews")}
                  </Button>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </form>
    </Container>
  );
}
