import React from 'react';
import moment from 'moment';
import { Col, Row } from "react-bootstrap";
import StarRating from '../../elements/StarRating/StarRating';
import './ratingReviewListCard.css';

export default function RatingReviewListCard({ reviewItem }) {

    const diff = moment(reviewItem?.create_date, "DD/MM/YYYY HH:mm:ss").fromNow();
    const timeDiff = diff.replace('a ', '1 ');
    return (
        <Row className='reviewList'>
            {reviewItem?.nickname ? (
                <Col xs={3}>
                    <div className='reviewUsername'>
                        {reviewItem?.nickname}
                    </div>
                </Col>
            ) : null}
            <Col xs={9}>
                <div className='d-flex align-items-center'>
                    <StarRating value={`${reviewItem.rating}` * 20} color="#fff200" />
                    <div className='reviewTime'>
                        {`${timeDiff}`}
                    </div>
                </div>
                {reviewItem?.review_title ? (
                    <div className='ratingReviewTitle'>
                        {reviewItem?.review_title}
                    </div>
                ) : null}
                {reviewItem?.review_description ? (
                    <p className='ratingReviewDesc'>
                        {reviewItem?.review_description}
                    </p>
                ) : null}
            </Col>
        </Row>
    );
}