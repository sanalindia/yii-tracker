import React from "react";
import { Container, Button, Row, Col } from "react-bootstrap";
import { CheckCircle } from "react-bootstrap-icons";
import { useTranslation } from "react-i18next";
import "./SuccessModal.scss";

export default function SuccessModal({ closeModal }) {
  const { t } = useTranslation();

  return (
    <Container>
      <Row>
        <Col className="p-2">
          <div>
            <CheckCircle color="green" size="16"></CheckCircle>
            <span className="review-text">{t("review_success_msg")}</span>
          </div>
        </Col>
      </Row>
      <Col className="btn-container">
        <Button variant="link" onClick={closeModal}>
          {t("close")}
        </Button>
      </Col>
    </Container>
  );
}
