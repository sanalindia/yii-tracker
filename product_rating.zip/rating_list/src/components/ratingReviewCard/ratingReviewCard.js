import React from 'react';
import moment from 'moment';
import StarRating from '../../elements/StarRating/StarRating';
import { useTranslation } from "react-i18next";
import './ratingReviewCard.css';

export default function RatingReviewCard({ reviewData, seeMoreFilter }) {
    const { t } = useTranslation();

    let seeMoreText = t('see_more_reviews');
    seeMoreText = seeMoreText.replace('<rating_1>', Number(reviewData.rating) - 1);
    seeMoreText = seeMoreText.replace('<rating_2>', Number(reviewData.rating));
    if (Number(reviewData.rating) === 1) {
        const rating1Text = seeMoreText.split(' 0 ');
        const rating2Text = seeMoreText.split(' 1 ');
        seeMoreText = rating1Text[0] + ' 1 ' + rating2Text[rating2Text.length - 1];
    }

    const username = reviewData?.nickname ? reviewData?.nickname : '';
    const diff = moment(reviewData?.create_date, "DD/MM/YYYY HH:mm:ss").fromNow();
    const timeDiff = diff.replace('a ', '1 ');

    const seeMoreAction = () => {
        seeMoreFilter(Number(reviewData.rating));
    }

    return (
        <div>
            <div className='helpfulReviewTitle'>{t(`${reviewData.title}`)}</div>
            <div className='d-flex align-items-center'>
                <StarRating value={`${reviewData.rating}` * 20} color="#fff200" />
            </div>
            <div className='username'>{`${username} ${timeDiff}`}</div>
            {reviewData?.review_title ? (
                <div className='reviewText'>{`${reviewData?.review_title}`}</div>
            ) : null}
            {reviewData?.review_description ? (
                <div className='reviewDescription'>{`${reviewData?.review_description}`}</div>
            ) : null}

            <div onClick={() => seeMoreAction()} className='seeMore'>{seeMoreText}</div>
        </div>
    )
}