const fs = require('fs-extra');

console.log("Removing previous rating_list build");
fs.removeSync("./artifacts/rating_list");

fs.moveSync("./build", "../artifacts/rating_list/");

console.log("rating_list build folder moved to artifacts/rating_list");