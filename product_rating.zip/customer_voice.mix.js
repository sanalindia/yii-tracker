const mix = require("laravel-mix");

const { MIX_BRAND, MIX_COUNTRY, MIX_LANG } = process.env;

const targetPath = `artifacts/${MIX_BRAND}/${MIX_LANG}/${MIX_COUNTRY}`

mix.js("customerVoice.js", targetPath).setPublicPath(targetPath);