const spawn = require("cross-spawn");
var argv = require('minimist')(process.argv.slice(2));

console.log(argv);

require("dotenv").config({path: `./.env.${argv["env"]}`});

const buildConfigs = require("./config");
const getVariablesConvertedToEnv = function (config) {
    const retObj = {};
    for (const key in config) {
        if (Object.hasOwnProperty.call(config, key)) {
            const value = config[key];
            retObj["MIX_"+ key.toUpperCase()] = value;
        }
    }
    return retObj;
}
for (const config of buildConfigs) {
    const env = Object.assign({}, process.env, getVariablesConvertedToEnv(config));
    spawn.sync("npm", ["run", "package"], {stdio: "inherit", env})
}

