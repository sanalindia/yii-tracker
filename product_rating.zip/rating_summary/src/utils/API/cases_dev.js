import { get } from "./config";

const getAppParams = (data) => { }

const fetchBrandConfig = async () => {
  const response = await get('apiResponse/brandConfig.json');
  const brandConfigs = [...response.data.result];
  const termsURL = brandConfigs.length > 0 ? brandConfigs[0].terms : '';
  const configKey = [];
  brandConfigs.forEach((ele) => {
    configKey.push(ele?.config_key)
  });
  return {
    configKey,
    termsURL
  };
}

const fetchReviewFields = async () => {
  const response = await get('apiResponse/reviewFieldList.json');
  const fieldList = [...response.data.result];
  return fieldList;
}

const fetchProductRating = async () => {
  let ratingList = [];
  const response = await get('apiResponse/overallRating.json');
  ratingList = [...response.data.result];
  const ratingValue = Number(ratingList[0]?.rating);
  const roundedValue = Math.round(ratingValue * 10) / 10;
  return roundedValue;
}

const fetchStarRatingCount = async () => {
  let ratingCount = [];
  const response = await get('apiResponse/starRatingCount.json');
  ratingCount = [...response.data.result];

  const fiveStarReview = ratingCount?.find((ele) => Number(ele.rating) === 5);
  const fourStarReview = ratingCount?.find((ele) => Number(ele.rating) === 4);
  const threeStarReview = ratingCount?.find((ele) => Number(ele.rating) === 3);
  const twoStarReview = ratingCount?.find((ele) => Number(ele.rating) === 2);
  const oneStarReview = ratingCount?.find((ele) => Number(ele.rating) === 1);

  const fiveStarCount = Number(fiveStarReview?.total) || 0;
  const fourStarCount = Number(fourStarReview?.total) || 0;
  const threeStarCount = Number(threeStarReview?.total) || 0;
  const twoStarCount = Number(twoStarReview?.total) || 0;
  const oneStarCount = Number(oneStarReview?.total) || 0;

  const totalCount = fiveStarCount + fourStarCount + threeStarCount + twoStarCount + oneStarCount;

  const starRatingCount = {
    fiveStarCount,
    fourStarCount,
    threeStarCount,
    twoStarCount,
    oneStarCount,
    totalCount
  }

  return starRatingCount;
}

const postReview = async () => {
  const response = await get('apiResponse/postReview.json');
  const reviewAddedStatus = response?.data?.status;
  return reviewAddedStatus;
}

const devAPIList = {
  getAppParams,
  fetchBrandConfig,
  fetchReviewFields,
  fetchProductRating,
  fetchStarRatingCount,
  postReview
};

export default devAPIList;