import React, { useCallback, useEffect, useRef, useState } from "react";
import StarRating from "../components/StarRating/StarRating";
import ReviewModal from "../components/ReviewModal/ReviewModal";
import Popup from "../components/Popup/Popup";
import SuccessModal from "../components/SuccessModal/SuccessModal";
import { Cases } from "../utils/API";
import { OverlayTrigger, Popover, Button, Modal, Tooltip } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import "./Home.css";
import { InfoCircleFill } from "react-bootstrap-icons";

const MAX_MOBILE_SCREEN_WIDTH = 768;

export default function Home({ appParams }) {
  const { t } = useTranslation();

  const [starValue, setStarValue] = useState(0);
  const [starRatingCount, setStarRatingCount] = useState({});
  const [showModal, setModal] = useState(false);
  const [reviewFieldList, setFieldList] = useState([]);
  const [brandConfigValues, setBrandConfigValue] = useState([]);
  const [show, setShow] = useState(false);
  const [isLoading, setLoading] = useState(true);
  const [overlayLoading, setOverlayLoading] = useState(true);
  const [infoOverlayLoading, setInfoOverlayLoading] = useState(true);
  const [successModalLoading, setSuccessModalLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= MAX_MOBILE_SCREEN_WIDTH);
  const [termsURL, setTermsURL] = useState('');
  const [isSuccessModal, setSuccessModal] = useState(false);

  const containerRef = useRef(null);
  const overlayRef = useRef(null);
  const infoOverlayRef = useRef(null);
  const successModalRef = useRef(null);

  const handleOnMouseEnter = () => {
    setShow(true);
  };
  const handleOnMouseLeave = () => {
    setShow(false);
  };

  const postReview = (reviewData) => {
    setModal(false);
    Cases.postReview(reviewData)
      .then((res) => {
        if (res === "success") {
          getReviewRatingDetails();
          setSuccessModal(true);
        }
      })
      .catch((e) => console.log(e));
  };

  const manageFieldList = (list, configValues) => {
    const phaseValues =
      configValues.includes("phase1") && configValues.includes("phase2")
        ? [1, 2]
        : configValues.includes("phase1")
          ? [1]
          : configValues.includes("phase2")
            ? [2]
            : [1];
    const fieldList = list.filter((ele) =>
      phaseValues.includes(Number(ele?.status))
    );
    setFieldList(fieldList);
  };

  const handleWindowSizeChange = useCallback(() => {
    setIsMobile(window.innerWidth <= MAX_MOBILE_SCREEN_WIDTH);
  }, []);

  const getReviewRatingDetails = useCallback(() => {
    Cases.fetchProductRating()
      .then((res) => setStarValue(res))
      .catch((e) => console.log(e));

    Cases.fetchStarRatingCount()
      .then((res) => setStarRatingCount(res))
      .catch((e) => console.log(e));
  }, []);

  useEffect(() => {
    window.addEventListener('resize', handleWindowSizeChange);

    if (isLoading && containerRef && containerRef.current) setLoading(false);

    if (overlayLoading && overlayRef && overlayRef.current) setOverlayLoading(false);

    if (infoOverlayLoading && infoOverlayRef && infoOverlayRef.current) setInfoOverlayLoading(false);

    if (successModalLoading && successModalRef && successModalRef.current) setSuccessModalLoading(false);

    Cases.getAppParams(appParams);

    Cases.fetchBrandConfig()
      .then((configResponse) => {
        const configValues = configResponse?.configKey;

        setBrandConfigValue(configValues);

        setTermsURL(configResponse?.termsURL);

        Cases.fetchReviewFields()
          .then((res) => manageFieldList(res, configValues))
          .catch((e) => console.log(e));
      })
      .catch((e) => console.log(e));

    getReviewRatingDetails();

    return () => {
      window.removeEventListener('resize', handleWindowSizeChange);
    };
  }, [getReviewRatingDetails, appParams, isLoading, overlayLoading, infoOverlayLoading, handleWindowSizeChange, successModalLoading]);

  const handleModal = () => {
    setModal(!showModal);
  };

  const goToReviewList = (actionType) => {
    if (isMobile && actionType === 'starTapped') {
      setShow(true);
    } else {
      var reviewRect = document
        .getElementById("rating_list_parent_element")
        ?.getBoundingClientRect();
      var topPos = reviewRect.top + window.scrollY;
      window.parent.scrollTo(0, topPos);
    }
  };

  const closeSuccessModal = () => {
    setSuccessModal(false);
  };

  const renderTooltip = props => (
    <Tooltip {...props} className="infoTooltip">{t('mobile_info_text')}</Tooltip>
  );

  return (
    <>
      <div className="mainView">
        <div ref={overlayRef} className="starSummaryView">
          <OverlayTrigger
            container={!overlayLoading ? overlayRef.current : null}
            placement="bottom"
            show={show} // Control the show and hide of the popover
            overlay={
              <Popover
                id="popover-positioned-bottom"
                onMouseEnter={handleOnMouseEnter}
                onMouseLeave={handleOnMouseLeave}
                className="summary_overlay"
              >
                <Popup starRatingCount={starRatingCount} goToReviewList={goToReviewList}></Popup>
              </Popover>
            }
          >
            <div
              className="ratingInfoView"
            >
              <div
                onClick={() => goToReviewList('starTapped')}
                onMouseEnter={handleOnMouseEnter}
                onMouseLeave={handleOnMouseLeave}
                className="starRatingView"
              >
                <StarRating
                  value={starValue * 20}
                  reviewCount={starRatingCount?.totalCount}
                />
              </div>
              {isMobile ? (
                <div ref={infoOverlayRef} className="infoOverlayView">
                  <OverlayTrigger
                    placement="bottom"
                    overlay={renderTooltip}
                    container={!infoOverlayLoading ? infoOverlayRef.current : null}
                  >
                    <button
                      className="infoIconBtn"
                    >
                      <InfoCircleFill
                        className="infoIcon"
                      />
                    </button>
                  </OverlayTrigger>
                </div>
              ) : null}
            </div>
          </OverlayTrigger>
        </div>
        <Button
          variant="link"
          onClick={handleModal}
          className="p-2 writeReview"
        >
          {t("write_a_review")}
        </Button>
      </div>

      <div ref={containerRef} className="review-modal-container">
        <Modal
          size="lg"
          show={showModal}
          className="review_modal"
          onHide={() => {
            setModal(false);
          }}
          aria-labelledby="example-modal-sizes-title-lg"
          container={!isLoading ? containerRef.current : null}
        >
          <ReviewModal
            postReview={postReview}
            handleModal={handleModal}
            fieldList={reviewFieldList}
            brandConfigValues={brandConfigValues}
            termsURL={termsURL}
          />
        </Modal>
      </div>

      <div ref={successModalRef} className="successModalView">
        <Modal
          container={!successModalLoading ? successModalRef.current : null}
          show={isSuccessModal}
          onHide={closeSuccessModal}
          size="sm"
          centered>
          <SuccessModal
            closeModal={closeSuccessModal}
          />
        </Modal>
      </div>
    </>
  );
}
