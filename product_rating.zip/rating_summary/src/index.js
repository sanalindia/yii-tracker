import React from 'react';
import ReactDOM from 'react-dom/client';
import './services/i18n';
import './index.css';
import App from './App';
// import reportWebVitals from './reportWebVitals';

const { brand, lang, country } = (window.__configCustomerVoice || {});
console.log("RATING SUMMARY :: Do I know brand, lang & country info ? ", brand, lang, country);

const brandName = brand || window.location.hostname;
const productName = window?.drupalSettings?.wsf_analytics?.node?.title || window.location.pathname;

const language = lang || window?.drupalSettings?.path?.currentLanguage || 'en';

const languageDetails = window?.top?.dataLayer || [];
const countryDetails = languageDetails.find((ele) => ele?.language === language) || {};
const countryName = country || countryDetails?.country || 'US';

const appParams = { brandName, language, country: countryName };

const rootElement = document.querySelectorAll("#rating_summary");
if (rootElement.length > 0) {
  const nodeArray = [...rootElement];
  nodeArray.map((ele, i) => {
    var productID = ele.getAttribute('data-pr-product-id');
    appParams.productName = productID || productName;
    const root = ReactDOM.createRoot(ele);
    
    return root.render(
      <React.StrictMode>
        <App appParams={appParams} key={i} />
      </React.StrictMode>
    );
  })
}

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();
