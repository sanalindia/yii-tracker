import Home from './pages/Home';
import './App.scss';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

function App({ appParams }) {

  const { i18n } = useTranslation();

  useEffect(() => {
    const currentLang = window?.drupalSettings?.path?.currentLanguage || 'en';
    i18n.changeLanguage(currentLang);
  }, [i18n]);


  useEffect(() => {
    console.log("Do I have the product ID from the element ?" + appParams)
  }, [appParams]);

  return (
    <div className="rating-summary-container">
      <Home
        appParams={appParams}
      >
      </Home>
    </div>

  );
}

export default App;
