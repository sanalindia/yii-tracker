import React, { useEffect, useState } from 'react'
import { Rating } from 'react-simple-star-rating'

export default function StarRating({ value, reviewCount }) {
    const [rating, setRating] = useState(value) // initial rating value
    const ratedValue = value / 20;

    useEffect(() => {
        if (rating !== value) {
            setRating(value);
        }
    }, [rating, value]);

    // Catch Rating value
    const handleRating = (rate) => {
        setRating(rate)
    }

    return (
        <div className='star-rating-wrapper'>
            <Rating
                onClick={handleRating}
                ratingValue={rating}
                fillColor='#0093d8'
                initialValue={0}
                // emptyColor="transparent"
                allowHalfIcons
                readonly />
            {ratedValue && <span className='p-2'>{`${ratedValue} (${reviewCount})`}</span>}
        </div>
    )
}