import React, { useCallback, useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { StarWithProgressBar } from '../StarWithProgressBar/StarWithProgressBar';
import "./Popup.scss";
import { useTranslation } from "react-i18next";

export default function Popup({ starRatingCount, goToReviewList }) {
  const { t } = useTranslation();

  const initialConfig = {
    fiveStar: {
      value: 5,
      ratedValue: 0,
      count: 0
    },
    fourStar: {
      value: 4,
      ratedValue: 0,
      count: 0
    },
    threeStar: {
      value: 3,
      ratedValue: 0,
      count: 0
    },
    twoStar: {
      value: 2,
      ratedValue: 0,
      count: 0
    },
    oneStar: {
      value: 1,
      ratedValue: 0,
      count: 0
    }
  }
  const [ratingValues, setRatingValues] = useState(initialConfig);

  let readReviewText = t('read_reviews');
  readReviewText = readReviewText.replace('<review_count>', starRatingCount?.totalCount);

  const getRatingProgressValues = useCallback(() => {
    const config = {
      fiveStar: {
        value: 5,
        ratedValue: starRatingCount?.fiveStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.fiveStarCount
      },
      fourStar: {
        value: 4,
        ratedValue: starRatingCount?.fourStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.fourStarCount
      },
      threeStar: {
        value: 3,
        ratedValue: starRatingCount?.threeStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.threeStarCount
      },
      twoStar: {
        value: 2,
        ratedValue: starRatingCount?.twoStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.twoStarCount
      },
      oneStar: {
        value: 1,
        ratedValue: starRatingCount?.oneStarCount / starRatingCount?.totalCount,
        count: starRatingCount?.oneStarCount
      }
    }

    setRatingValues(config);
  }, [starRatingCount]);

  useEffect(() => {
    if (Number(starRatingCount?.totalCount) > 0) {
      getRatingProgressValues();
    }
  }, [starRatingCount, getRatingProgressValues]);

  return (
    <div className="pt-3 align-items-center">
      <div className="progressBarMainView">
        <StarWithProgressBar config={ratingValues?.fiveStar}></StarWithProgressBar>
        <StarWithProgressBar config={ratingValues?.fourStar}></StarWithProgressBar>
        <StarWithProgressBar config={ratingValues?.threeStar}></StarWithProgressBar>
        <StarWithProgressBar config={ratingValues?.twoStar}></StarWithProgressBar>
        <StarWithProgressBar config={ratingValues?.oneStar}></StarWithProgressBar>
      </div>
      <div className='readReviewView'>
        <Button onClick={goToReviewList} className="readReviewBtn" variant="dark">{readReviewText}</Button>
      </div>

    </div>
  );
}
