import React from 'react';
import { StarFill } from "react-bootstrap-icons";
import './StarWithProgressBar.css';

export function StarWithProgressBar({ config }) {

    return (
        <div className='d-flex'>
            <div className="summaryStarProgressView">
                <div className="d-flex align-items-center">
                    <span className='star-label-summary'>{config.value}</span>
                    <StarFill color="#2180d7" size={12} />
                </div>
                <div className="summaryProgressView" >
                    <progress className="starRatingProgressBar" value={config.ratedValue} max="1"></progress>
                </div>
                <div className='star-label'>{config.count}</div>
            </div>
        </div>

    )
}
