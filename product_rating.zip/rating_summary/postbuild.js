const fs = require('fs-extra');

console.log("Removing previous rating_summary build");
fs.removeSync("./artifacts/rating_summary");

fs.removeSync("../artifacts/rating_summary");

fs.moveSync("./build", "../artifacts/rating_summary/");

console.log("rating_summary build folder moved to artifacts/rating_summary");