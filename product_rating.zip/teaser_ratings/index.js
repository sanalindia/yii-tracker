(function ($) {
  $.fn.teaserRatings = function (options) {
    var BASE_URL = process.env.MIX_PUBLIC_URL;
    // Extend our default options with those provided.
    // Note that the first argument to extend is an empty
    // object – this is to keep from overriding our "defaults" object.
    var opts = $.extend({}, $.fn.teaserRatings.defaults, options);
    function urlEncode(requestData) {
      const params = new URLSearchParams();
      Object.entries(requestData).map(([key, value]) =>
        params.append(key, value)
      );
      return params;
    }

    return this.each(function () {
      var elem = $(this);
      const { brand, lang, country } = window.__configCustomerVoice;
      // Do something to each element here.
      const productName = elem.data("pr-product-id") || elem.data("product-id");
      let params = {
        "params[brand]": brand,
        "params[language]": lang,
        "params[product]": productName || "Bepanthen Tattoo Wasgel",
      };

      let starValueApi =
        window.location.origin + "/api_rating?ep_url=api/v1/product_rating";

      let ratingCountApi=
        window.location.origin +
        "/api_rating?ep_url=api/v1/product_rating_count";

      const reqData = urlEncode(params);
      const ratingValue = fetch(starValueApi, {
        method: "POST",
        body: reqData,
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      })
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const ratingList = [...data.result];
          const ratingValue = Number(ratingList[0]?.rating);
          const value = ratingValue
            ?  Math.round(ratingValue * 10) / 10
            : 0;
          // const convertedValue = value && value <= 5 ? value * 20 : 0;
          return value;
        })
        .catch((err) => {
          // Do something for an error here
        });
      const ratingCount = fetch(ratingCountApi, {
        method: "POST",
        body: reqData,
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      })
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const ratingCount = [...data.result];

          const fiveStarReview = ratingCount?.find(
            (ele) => Number(ele.rating) === 5
          );
          const fourStarReview = ratingCount?.find(
            (ele) => Number(ele.rating) === 4
          );
          const threeStarReview = ratingCount?.find(
            (ele) => Number(ele.rating) === 3
          );
          const twoStarReview = ratingCount?.find(
            (ele) => Number(ele.rating) === 2
          );
          const oneStarReview = ratingCount?.find(
            (ele) => Number(ele.rating) === 1
          );

          const fiveStarCount = Number(fiveStarReview?.total) || 0;
          const fourStarCount = Number(fourStarReview?.total) || 0;
          const threeStarCount = Number(threeStarReview?.total) || 0;
          const twoStarCount = Number(twoStarReview?.total) || 0;
          const oneStarCount = Number(oneStarReview?.total) || 0;

          const totalCount =
            fiveStarCount +
            fourStarCount +
            threeStarCount +
            twoStarCount +
            oneStarCount;

          return totalCount;
        })
        .catch((err) => {
          // Do something for an error here
        });
      Promise.all([ratingValue, ratingCount]).then((values) => {
       
        const [starRating = 0, totalReviewCount = 0] = [...values];
        elem.starRating({
          initialRating: starRating || 0, // some static rating for show
          strokeWidth: 0,
          readOnly: true,
          hoverColor: "#0093d8",
          activeColor: "#0093d8",
          starSize: 25,
        });

        elem.append(
          `<span class='teaser-star-values'>${starRating}(${totalReviewCount})</span>`
        );
      });
    });
  };

  // Plugin defaults – added as a property on our plugin function.
  $.fn.teaserRatings.defaults = {
    foreground: "red",
    background: "yellow",
  };

  // self initialize the plugin already
  $(function () {
    // document ready
    console.log("doc is ready now");
    $(".teaser-reviews").teaserRatings();
  });
})(jQuery);
