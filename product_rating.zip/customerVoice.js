(function () {
    const BASE_URL = process.env.MIX_PUBLIC_URL;
    const brand = process.env.MIX_BRAND;
    const lang = process.env.MIX_LANG;
    const country = process.env.MIX_COUNTRY;

    window.__configCustomerVoice = { brand, lang, country };

    function loadScript(src) {
        let script = document.createElement('script');
        script.src = src;
        script.defer = true;
        script.async = false;
        document.body.append(script);
    }

    function loadCSS(filePath) {
        var link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = filePath;
        document.getElementsByTagName("head")[0].appendChild(link);
    }
    const jsFiles = [`${BASE_URL}/rating_list/index.js`,
    `${BASE_URL}/rating_summary/index.js`,
    `${BASE_URL}/teaser_ratings/index.js`,];
    const cssFiles = [`${BASE_URL}/teaser_ratings/index.css`,];
    for (const scriptFile of jsFiles) {
        loadScript(scriptFile);
    }
    for (const cssFile of cssFiles) {
        loadCSS(cssFile);
    }
})();