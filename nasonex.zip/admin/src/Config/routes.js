import Promotions from "../Pages/Promotions";
import PromotionSubmissions from "../Pages/PromotionSubmissions";

const routes = [
  /* {
    path: "/login",
    component: Login,
    isPrivate: false,
  }, */
  {
    path: "/submissions",
    component: PromotionSubmissions,
    isPrivate: true,
  },
  {
    path: "/",
    component: Promotions,
    isPrivate: true,
  },
  /* {
    path: "/products",
    component: Products,
    isPrivate: true,
  },
  {
    path: "/orders",
    component: Orders,
    isPrivate: true,
  },
  {
    path: "/users",
    component: Users,
    isPrivate: true,
  },
  {
    path: "/",
    component: Dashboard,
    isPrivate: true,
  }, */
];

export default routes;
