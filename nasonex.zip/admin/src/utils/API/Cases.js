import Constants from "../Constants";
import Utility from "../Utility";
import { get, post } from "./Config";
import MockData from "./MockData";

export default {
  loginHCPAdmin: async (requestOption) => {
    const params = new URLSearchParams();
    params.append("email", requestOption.email);
    params.append("password", requestOption.password);
    const response = await post(Constants.domain + "/auth/login", params);
    return response.data;
  },
  logoutHCPAdmin: async () => {
    const response = await get(Constants.domain + "/logout");
    return response.data;
  },
  getPromotions: async () => {
    if (Constants.mockDataRequired) {
      let promotions = [];
      MockData.promotions.forEach((item) => {
        item.created_at = Utility.getDateFromString(item.created_at);
        item.open_at = Utility.getDateFromString(
          item.open_at,
          "YYYY-MM-DD HH:mm:ss"
        );
        item.close_at = Utility.getDateFromString(
          item.close_at,
          "YYYY-MM-DD HH:mm:ss"
        );

        promotions.push(item);
      });
      return promotions;
    }
    const response = await get(Constants.domain + "/promotion/list");
    let promotions = [];
    response.data.forEach((item) => {
      item.created_at = Utility.getDateFromString(item.created_at);
      item.open_at = Utility.getDateFromString(
        item.open_at,
        "YYYY-MM-DD HH:mm:ss"
      );
      item.close_at = Utility.getDateFromString(
        item.close_at,
        "YYYY-MM-DD HH:mm:ss"
      );

      promotions.push(item);
    });
    return promotions;
  },
  getPromotionSubmissions: async (id, requestOption) => {
    if (Constants.mockDataRequired) {
      let promotionSubmissions = [];
      MockData.promotionSubmissions.forEach((item) => {
        if (item.submission_date) {
          item.submission_date = Utility.getDateFromString(
            item.submission_date
          );
        }
        if (item.status === 1) {
          item.status = "Pending";
        } else if (item.status === 2) {
          item.status = "Confirmed";
        } else if (item.status === 3) {
          item.status = "Deleted";
        }
        item.upload_receipt = item.upload_id ? "Y" : "N";
        promotionSubmissions.push(item);
      });
      return promotionSubmissions;
    }
    const reqData = Utility.urlEncodedRequest(requestOption);
    const response = requestOption
      ? await post(`${Constants.domain}/promotion/${id}/submissions`, reqData)
      : await post(`${Constants.domain}/promotion/${id}/submissions`);
    let promotionSubmissions = [];
    response.data.forEach((item) => {
      if (item.submission_date) {
        item.submission_date = Utility.getDateFromString(item.submission_date);
      }
      if (item.status === 1) {
        item.status = "Pending";
      } else if (item.status === 2) {
        item.status = "Confirmed";
      } else if (item.status === 3) {
        item.status = "Deleted";
      }

      item.upload_receipt = item.upload_id ? "Y" : "N";

      promotionSubmissions.push(item);
    });
    return promotionSubmissions;
  },
  addPromotion: async (requestOption) => {
    const reqData = Utility.urlEncodedRequest(requestOption);
    const response = await post(
      Constants.domain + "/promotion/create",
      reqData
    );
    return response.data;
  },
  updatePromotion: async (requestOption) => {
    const params = new URLSearchParams();
    params.append("name", requestOption.name);
    params.append("description", requestOption.description);
    params.append("status", requestOption.status);
    const response = await post(
      `${Constants.domain}/promotion/${requestOption.id}/update`,
      params
    );
    return response.data;
  },
  configPromotion: async (requestOption) => {
    const params = new URLSearchParams();
    params.append(
      "open_at",
      Utility.setDateFromString(requestOption.open_at, "YYYY-MM-DD HH:mm:ss")
    );
    params.append(
      "close_at",
      Utility.setDateFromString(requestOption.close_at, "YYYY-MM-DD HH:mm:ss")
    );
    params.append("status", requestOption.status);
    params.append("promotion_id", requestOption.id);
    params.append("open_tm", requestOption.open_tm);
    params.append("close_tm", requestOption.close_tm);
    params.append("email_from", Constants.EMAIL_FROM);
    const response = await post(
      `${Constants.domain}/promotion/${requestOption.id}/config`,
      params
    );
    return response.data;
  },
  approveOrDeletePromotion: async (submission_id, status,claimAmount,reason) => {
    // const reqData = Utility.urlEncodedRequest(requestOption);
    if (Constants.mockDataRequired) {
      return MockData.approveOrRejectSuccess;
    }
    /*const response = await get(
      `${Constants.domain}/status/${submission_id}/${Constants.ENTITY_SUBMISSIONS}/${status}`
    );*/
    const params = new URLSearchParams();
    params.append("status", status);
    params.append("claim_amount", claimAmount);
    params.append("reason", reason);
    const response = await post(
      `${Constants.domain}/submission/${submission_id}/moderate`,
      params
    );
    return response.data;
  },

  changePassword: async (requestOption) => {
    const reqData = Utility.urlEncodedRequest(requestOption);
    const response = await post(Constants.domain + "/changepassword", reqData);
    return response.data;
  },
};
