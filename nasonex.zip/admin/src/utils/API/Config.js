import axios from "axios";

const baseURL = "https://bsdo4lnzkj.execute-api.eu-west-2.amazonaws.com/api/";

const apiClient = axios.create({ baseURL });

apiClient.interceptors.request.use(
  (request) => {
   /*  if (!request.url.includes("auth/login")) {
      request.headers["x-deco-auth"] = JSON.parse(
        localStorage.getItem("currentUser")
      ).token;
    } */
    return request;
  },
  (error) => {
    console.log("Interceptor Request Error: ", error);
    return Promise.reject(error);
  }
);
apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.log("Interceptor Response Error: ", error);
    // const dispatch = useAuthDispatch();
    // logout(dispatch);
    return Promise.reject(error);
  }
);
const { get, post, put, delete: destroy } = apiClient;

export { get, post, put, destroy };
