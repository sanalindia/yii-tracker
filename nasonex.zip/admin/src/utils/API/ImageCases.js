import { get } from "./ImageConfig"

export default {
    fetchProductImages : async (id) => {
        const response = await get(`jsonapi/node/product?filter[drupal_internal__nid]=${id}&include=field_product_teaser_image`)
        // const response = await get(`json-response/images/${id}.json`)
        return response.data.included[0].attributes.uri.url
    }
}