export default {
    checkTokenStatus : (status) => {
        if(status  === "invalid-token"){
            return false
        }
        return true
    }
}