import axios from "axios";

// const baseURL = window.location.origin;

const baseURL = 'https://prod1f2fn8wb.main-noshield.acsf.baywsf.com/';

const apiClient = axios.create({ baseURL });

const { get, post, put, delete: destroy } = apiClient;

export { get, post, put, destroy };