export default {
  /*domainAuth: "https://prod1f2fn8wb.main-fe.acsf.baywsf.com/hcpsamplesfrontdev?ep_url=",
  domain: "https://prod1f2fn8wb.main-fe.acsf.baywsf.com/hcpsamplesdev?ep_url=",
  domain_local: "https://localhost:1005/api/v1",
  domain_dev: "https://ch-eu-01-exp-elevjap-dev.services.baywsf.com/api/v1",
  domain_prod: "https://ch-eu-01-exp-elevjap.services.baywsf.com/api/v1",*/
  domain: window.location.origin + "/api/v1/front",
  download_domain: window.location.origin + "/promotion/receipt/",
  // download_domain:"https://ch-eu-01-exp-claraau-dev.services.baywsf.com/promotion/receipt/",
  ENTITY: "promotion",
  ENTITY_SUBMISSIONS: "promotionsubmissions",
  EMAIL_FROM: "test@test.com",
  SUBMISSION_APPROVE: 2,
  SUBMISSION_DELETE: 3,
  DEFAULT_PROMOTION_ID: 1,
  mockDataRequired: false,
  PopoverTexts: {
    promotionAdd: "To add new promotion",
    submissionEdit: "To edit Name, Description and Status",
    submissionConfigEdit: "To edit Open At, Close At and Status",
    viewSubmissionDetails: "To view the submission details",
    csvDownload: "To download CSV file of submissions",
  },
  Timezones: {
    AEDT: "AEDT",
    AEST: "AEST",
  },
};
