import moment from "moment";

export default {
  modifyProductType: (data) => {
    var tempObj = {};
    data.map((item) => {
      tempObj[item["id"]] = item.name;
    });
    return tempObj;
  },
  modifyBrandType: (data) => {
    var tempObj = {};
    data.map((item) => {
      tempObj[item["id"]] = item.sitename;
    });
    return tempObj;
  },
  getSubmissionStatusList: () => {
    return [
      { id: 1, status: "Pending" },
      { id: 2, status: "Confirmed" },
      { id: 3, status: "Deleted" },
    ];
  },
  getPromotionStatusList: () => {
    return [
      { id: 0, status: "Closed" },
      { id: 1, status: "Open" },
    ];
  },
  geYesOrNo: (value) => {
    return value == 1 ? "Yes" : "No";
  },
  scrollToModal: (ref) => {
    window.parent.scrollTo(0, ref.current.offsetTop);
  },
  htmlRemovedText: (richText) => {
    let content =
      richText && richText.includes("<sup>")
        ? richText.replaceAll(/<sup.*>.*?<\/sup>/gi, "")
        : richText;
    return content;
  },
  handleAPIError: (error, logout, dispatch, props) => {
    if (
      error &&
      error.response &&
      ((error.response.data &&
        error.response.data.status === "invalid-token") ||
        error.response.status === "401")
    ) {
      /* console.log("error1", error.response.data);
      console.log("error2", error.response.status);
      logout(dispatch);
      props.history.push("/login"); */
    }
  },
  handleAPIValidationError: (error, setApiErrorMessage) => {
    if (
      error &&
      error.response &&
      error.response.data &&
      error.response.data.code === 400 &&
      error.response.data.errors &&
      error.response.data.errors.children &&
      error.response.data.errors.children.name &&
      error.response.data.errors.children.name.errors &&
      error.response.data.errors.children.name.errors.length > 0
    ) {
      setApiErrorMessage(error.response.data.errors.children.name.errors[0]);
    }
  },
  urlEncodedRequest: (requestData) => {
    const params = new URLSearchParams();
    Object.entries(requestData).map(([key, value]) =>
      params.append(key, value)
    );
    return params;
  },
  getDateFromString: (dateString, format = "YYYY-MM-DD") => {
    // console.log(dateString);
    let splitted =
      dateString && dateString.includes("+")
        ? dateString.split("+")[0]
        : dateString;
    let dateVal =
      dateString && dateString.includes("+") ? splitted + "+00:00" : splitted;
    // console.log(dateVal);
    // console.log(moment.utc(dateVal).format(format));
    return dateVal ? moment.utc(dateVal).format(format) : "";
  },
  setDateFromString: (dateString, format = "YYYY-MM-DD") => {
    return dateString ? moment(dateString).format(format) : "";
  },
};
