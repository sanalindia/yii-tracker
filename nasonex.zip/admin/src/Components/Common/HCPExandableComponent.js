import React from "react";
import parse from "html-react-parser";

const HCPExpandableComponent = ({ data }) => (
  <p>{data.content ? parse(data.content) : ""}</p>
);

export default HCPExpandableComponent;
