import React, { useEffect, useRef } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../CSS/Components/hcpModal.scss";
import Utility from "../../utils/Utility";

const HCPEditModal = (props) => {
  const modalRef = useRef(null);

  const updateFeid = (e) => {
    props.updateData(e);
  };

  const updateSelectBox = () => {
    // console.log(document.getElementById("statusBox").value);
    props.updateStatus(document.getElementById("statusBox").value);
  };
  
  const className =
    (props.editData.name === undefined || props.editData.name.length === 0) &&
    props.errorMessage === true;
  const classContent =
    (props.editData.description === undefined ||
      props.editData.description.length === 0) &&
    props.errorMessage === true;

  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
  }, [props.show]);

  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={props.handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit Promotion</Modal.Title>
        </Modal.Header>
        <form
          id={props.editData.id}
          onSubmit={props.submitHandler}
          className="editForm"
        >
          <Modal.Body>
            {props.showSuccessMessage ? (
              <p className="successMsg">
                Promotion has been updated successfully!
              </p>
            ) : (
              <>
                <div>
                  <label htmlFor="name">
                    Promotion Name<span>*</span>
                  </label>
                  {(props.editData.name === undefined ||
                    props.editData.name.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Promotion Name Required</span>
                  ) : null}
                  <input
                    type="text"
                    className={className ? "input-error" : null}
                    name="name"
                    value={props.editData.name}
                    onChange={updateFeid}
                  />
                </div>
                <div>
                  <label htmlFor="description">
                    Description<span>*</span>
                  </label>
                  {(props.editData.description === undefined ||
                    props.editData.description.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Description Required</span>
                  ) : null}
                  <textarea
                    name="description"
                    className={classContent ? "input-error" : null}
                    value={props.editData.description}
                    onChange={updateFeid}
                  ></textarea>
                </div>
                <div>
                  <label htmlFor="status">
                    Status<span>*</span>
                  </label>
                  <select
                    id="statusBox"
                    name="status"
                    onChange={updateSelectBox}
                    value={props.editData.status}
                  >
                    <option value="1">Open</option>
                    <option value="0">Closed</option>
                  </select>
                  {props.apiErrorMessage && (
                    <span className="errorMsg float-none">
                      {props.apiErrorMessage}
                    </span>
                  )}
                </div>
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button
              className="customBtn"
              variant="primary"
              onClick={props.handleClose}
            >
              {props.showSuccessMessage ? "Close" : "Cancel"}
            </Button>
            <Button
              hidden={props.showSuccessMessage}
              className="customBtn"
              type="submit"
              variant="primary"
            >
              Save
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
    </>
  );
};

export default HCPEditModal;
