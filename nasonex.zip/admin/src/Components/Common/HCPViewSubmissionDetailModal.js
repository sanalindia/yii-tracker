import React, { useEffect, useReducer, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../CSS/Components/hcpViewSubmissionDetailModal.scss";
import { logout, useAuthDispatch } from "../../Context";
import Utility from "../../utils/Utility";
import Constants from "../../utils/Constants";

const HCPViewSubmissionDetailModal = (props) => {
  // const [orderDetails, setOrderDetails] = useState([]);
  const dispatch = useAuthDispatch();
  const modalRef = useRef(null);
  const [reason, setReason] = useState('');
  const [claimAmount, setClaimAmount] = useState('');
  const getFormattedLabel = (key) => {
    return key.includes("_") ? key.replaceAll("_", " ") : key;
  };
  const reasonChange = (e) => {
    setReason(e.target.value);
  }
  const claimAmountChange = (e) => {
    setClaimAmount(e.target.value);
  }
  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
    /* if (props.editData.cart_id) {
      Cases.getOrderDeails(props.editData.cart_id)
        .then((response) => {
          setTimeout(() => {
            setOrderDetails(response);
          }, 500);
          console.log("Order Details", response);
        })
        .catch((error) => {
          console.log(error);
          setOrderDetails([]);
          Utility.handleAPIError(error, logout, dispatch, props);
        }); 
    }*/
  }, [props.show]);
  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={props.handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Submission Details</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {Object.entries(props.editData).map(([key, value], index) => {
            return key !== "id" && key !== "status" && key !== "created_at" ? (
              <div key={key} className={key === "upload_id" ? "container user-details-item upload-receipt" : "container user-details-item"}>
                <div className="row">
                  <span className="text-capitalize col-md-4">
                    {key === "upload_id" ? "Receipt" : getFormattedLabel(key)}
                  </span>
                  :
                  <span className="ml-1 col-md-7 text-break">
                    <b>
                      {key === "upload_id" ? (
                        <a
                          href={Constants.download_domain + value}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          Download Receipt
                        </a>
                      ) : key === "is_proof_purchase" ||
                        key === "is_term" ||
                        key === "is_future_promotions" ? (
                        Utility.geYesOrNo(value)
                      ) : (
                        value
                      )}
                    </b>
                  </span>
                </div>
              </div>
            ) : (
              ""
            );
          })}
          {props.editData && props.editData.status === "Pending" ? (
            <>
            <div class="container user-details-item">
              <div class="row">
                <span class="text-capitalize col-md-4">Claim Amount</span>:
                <span class="ml-1 col-md-7 text-break"><input onChange={claimAmountChange} type="text" name="claimAmount" id="claimAmount"/></span>
              </div>
            </div>
            <div class="container user-details-item">
              <div class="row">
                <span class="text-capitalize col-md-4">Reason</span>:
                <span class="ml-1 col-md-7 text-break"><textarea onChange={reasonChange} name="reason" id="reason"></textarea></span>
              </div>
            </div>
        </>
          ):("")}
        </Modal.Body>
        <Modal.Footer>
          {props.editData && props.editData.status === "Pending" ? (
            <>
              <Button
                className="customBtn"
                variant="secondary"
                onClick={() => props.acceptHandler(props.editData,claimAmount,reason)}
              >
                Approve
              </Button>
              <Button
                className="customBtn"
                variant="secondary"
                onClick={() => props.rejectHandler(props.editData,claimAmount,reason)}
              >
                Delete
              </Button>
            </>
          ) : (
            <Button
              className="customBtn"
              variant="secondary"
              onClick={props.handleClose}
            >
              Close
            </Button>
          )}
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default HCPViewSubmissionDetailModal;
