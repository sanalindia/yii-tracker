import React from "react";

const HCPStatusFilter = ({ statusTypeArray, updateListByStatus }) => {
  return (
    <div className="filter-promotions">
      <select onChange={updateListByStatus} id="statusFilter">
        <option value={null}>All</option>
        {statusTypeArray.map((type, index) => {
          return (
            <option value={type.status} key={index}>
              {type.status}
            </option>
          );
        })}
      </select>
    </div>
  );
};

export default HCPStatusFilter;
