import React from "react";

const HCPPromotionFilter = ({ promotionArray, updateListByPromotion }) => {
  return promotionArray && promotionArray.length > 0 ? (
    <div className="filter-promotions">
      <select onChange={updateListByPromotion} id="promotionFilter">
        {/* <option value={-1}>Select Promotion</option> */}
        {promotionArray.map((type, index) => {
          return type.status === 1 ? (
            <option value={type.name} key={type.id}>
              {type.name}
            </option>
          ) : (
            ""
          );
        })}
      </select>
    </div>
  ) : (
    ""
  );
};

export default HCPPromotionFilter;
