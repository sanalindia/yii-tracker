import React from "react";
import DataTable from "react-data-table-component";
import HCPExpandableComponent from "./HCPExandableComponent";
import DataTableExtensions from "react-data-table-component-extensions";
import "react-data-table-component-extensions/dist/index.css";
import "../../CSS/Components/hcpTable.scss";

const HCPTablesComponent = (props) => {
  const customStyles = {
    rows: {
      style: {
        borderTop: "1px solid #ddd",
        minHeight: "auto", // override the row height
      },
    },
    headCells: {
      style: {
        padding: "0px 15px",
        minHeight: "auto",
        backGround: "#f3f3f3",
      },
    },
    cells: {
      style: {
        padding: "12px 0px 12px 10px",
        textAlign: "left",
        maxWidth: "100px",
      },
    },
  };
  //console.log(props)
  return (
    <DataTableExtensions {...props}>
      <DataTable
        defaultSortField={props.defaultSortField}
        defaultSortAsc={props.defaultSortAsc}
        columns={props.columns}
        data={props.data}
        pagination
        theme="solarized"
        expandableRows={!props.notExpandable}
        expandableRowsComponent={<HCPExpandableComponent data={props.data} />}
        customStyles={customStyles}
      />
    </DataTableExtensions>
  );
};

export default HCPTablesComponent;
