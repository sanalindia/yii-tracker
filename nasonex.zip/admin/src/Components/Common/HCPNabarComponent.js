import React, { useState } from "react";
import { useAuthDispatch, logout, useAuthState } from "../../Context";
import { Navbar, Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { FaUserCircle, FaSignOutAlt } from "react-icons/fa";
import "../../CSS/Components/hcpNavigation.scss";
import HCPChangePwdModal from "./HCPChangePwdModal";

const HCPNavbar = (props) => {
  const dispatch = useAuthDispatch();
  const userDetails = useAuthState();
  const [show, setShow] = useState(false);
  const handleLogout = () => {
    logout(dispatch);
    props.history.push("/login");
  };

  const handleClose = () => setShow(false);
  const submitEditHandler = (e) => {
    e.preventDefault();
  };

  const handleShow = () => {
    setShow(true);
  };

  return (
    <div className="NavBar-wrapper">
      <Navbar expand="lg" className="admin-header container mr-0">
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
       {/*  <span className="mobile-user"><FaUserCircle size={18} />{" "}
          {userDetails.user ? userDetails.user.email.split("@")[0] : null}</span>
        <NavLink to="/login" className="nav-link logOutBtn">
          <span onClick={handleLogout}>
            <FaSignOutAlt />
          </span>
        </NavLink> */}
        <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
          <Nav >
          {/*   <NavLink exact to="/" className="nav-link">
              {" "}
              Manage Brand{" "}
            </NavLink>
            <NavLink exact to="/products" className="nav-link">
              {" "}
              Manage Products{" "}
            </NavLink> */}
            <NavLink exact to="/" className="nav-link">
              {" "}
              Manage Promotions{" "}
            </NavLink>
            <NavLink exact to="/submissions" className="nav-link">
              {" "}
              Manage Submissions{" "}
            </NavLink>
           {/*  <NavLink exact to="/users" className="nav-link">
              {" "}
              Manage Users{" "}
            </NavLink> */}
          </Nav>
         {/*  <Nav className="right-nav">
            <p className="nav-link username userProfile">
              {" "}
              <FaUserCircle size={18} />{" "}
              {userDetails.user ? userDetails.user.email.split("@")[0] : null}
            </p>
            <p className="nav-link username cursor-pointer" onClick={handleShow}>
              {" "}
              Change Password
            </p>
            <NavLink to="/login" className="nav-link username">
              <p onClick={handleLogout}>
                <FaSignOutAlt />
              </p>
            </NavLink>
          </Nav> */}
        </Navbar.Collapse>
      </Navbar>
      <HCPChangePwdModal
        show={show}
        handleClose={handleClose}
        userDetails={userDetails}
        submitHandler={submitEditHandler}
      />
    </div>
  );
};

export default HCPNavbar;
