import React from "react";
import Button from "react-bootstrap/Button";
import { FaPlus } from "react-icons/fa";
import { IconContext } from "react-icons";
import "../../CSS/Components/hcpTable.scss";
import "../../CSS/Components/hcpButton.scss";

const HCPAddComponent = (props) => {
  return (
    <>
      <IconContext.Provider value={{ className: "react-icons" }}>
        <Button
          className="addButton customBtn"
          onClick={() => props.addHandler()}
          title={props.title}
        >
          Add <FaPlus />
        </Button>
      </IconContext.Provider>
    </>
  );
};

export default HCPAddComponent;
