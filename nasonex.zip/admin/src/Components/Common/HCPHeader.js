import React from "react";
import "../../CSS/Components/hcpHeader.scss";

function HCPHeader() {
  return (
    <div className="header_container">
      <span className="header_logo_img">
        <img
          src={require("../../Assests/Images/logo-nasonex.png")}
          alt="claratyne"
        ></img>
      </span>
      <span className="header_logo_img">
        <img
          src={require("../../Assests/Images/logo_bayer.png")}
          alt="bayer"
        ></img>
      </span>
    </div>
  );
}

export default HCPHeader;
