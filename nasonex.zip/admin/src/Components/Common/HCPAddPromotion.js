import React, { useEffect, useRef } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../CSS/Components/hcpModal.scss";
import Utility from "../../utils/Utility";
const HCPModal = (props) => {
  const modalRef = useRef(null);

  const updateFeid = (e) => {
    props.updateData(e);
  };

  const className =
    (props.addData.name === undefined || props.addData.name.length === 0) &&
    props.errorMessage === true;
  const classContent =
    (props.addData.description === undefined ||
      props.addData.description.length === 0) &&
    props.errorMessage === true;

  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
  }, [props.show]);

  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={props.handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Promotion</Modal.Title>
        </Modal.Header>
        <form id="addBrand" onSubmit={props.submitHandler} className="addForm">
          <Modal.Body>
            {props.showSuccessMessage ? (
              <p className="successMsg">
                Promotion has been added successfully!
              </p>
            ) : (
              <>
                <div>
                  <label htmlFor="name">
                    Promotion Name<span>*</span>
                  </label>
                  {(props.addData.name === undefined ||
                    props.addData.name.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Promotion Name Required</span>
                  ) : null}
                  <input
                    type="text"
                    name="name"
                    className={className ? "input-error" : null}
                    value={props.addData.name}
                    onChange={updateFeid}
                  />
                </div>
                <div>
                  <label htmlFor="description">
                    Description<span>*</span>
                  </label>
                  {(props.addData.description === undefined ||
                    props.addData.description.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Description Required</span>
                  ) : null}
                  <textarea
                    name="description"
                    className={classContent ? "input-error" : null}
                    value={props.addData.description}
                    onChange={updateFeid}
                  ></textarea>
                  {props.apiErrorMessage && (
                    <span className="errorMsg float-none">
                      {props.apiErrorMessage}
                    </span>
                  )}
                </div>
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button
              className="customBtn"
              variant="primary"
              onClick={props.handleClose}
            >
              {props.showSuccessMessage ? "Close" : "Cancel"}
            </Button>
            <Button
              hidden={props.showSuccessMessage}
              className="customBtn"
              type="submit"
              variant="primary"
            >
              Save
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
    </>
  );
};

export default HCPModal;
