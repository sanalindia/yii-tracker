import React, { useEffect } from "react";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";
import "../../CSS/Components/hcpDateFilter.scss";

const HCPDateFilter = ({
  startDate,
  endDate,
  handleChange,
  placeholderText,
}) => {
  useEffect(() => {
    const dateInput = document.querySelector(
      ".react-datepicker__input-container input"
    );
    if (dateInput) {
      dateInput.readOnly = true;
    }
  }, []);
  return (
    <div className="filter-promotions">
      <DatePicker
        selectsRange={true}
        startDate={startDate}
        endDate={endDate}
        onChange={handleChange}
        isClearable={true}
        placeholderText={placeholderText}
      />
    </div>
  );
};

export default HCPDateFilter;
