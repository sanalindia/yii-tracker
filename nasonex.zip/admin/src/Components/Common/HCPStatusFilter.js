import React from "react";

const HCPStatusFilter = ({ statusTypeArray, updateListByStatus }) => {
  return (
    <div className="filter-promotions">
      <select onChange={updateListByStatus} id="statusFilter">
        <option value={-1}>All</option>
        {statusTypeArray.map((type, index) => {
          return (
            <option value={type.id} key={index}>
              {type.status}
            </option>
          );
        })}
      </select>
    </div>
  );
};

export default HCPStatusFilter;
