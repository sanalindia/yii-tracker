import React, { useEffect, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import Utility from "../../utils/Utility";

const HCPConfirmationModal = (props) => {
  const modalRef = useRef(null);
  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
  }, [props.show]);

  const handleClose = () => {
    props.handleClose();
  };

  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Delete Product</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {props.showSuccessMessage ? (
            <p className="successMsg">Product has been deleted successfully!</p>
          ) : (
            <p>
              Do you want to delete{" "}
              {Utility.htmlRemovedText(props.deleteData?.name)} permanently?
            </p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button
            className="customBtn"
            variant="secondary"
            onClick={handleClose}
          >
            {props.showSuccessMessage ? "Close" : "Cancel"}
          </Button>
          <Button
            className="customBtn"
            variant="primary"
            hidden={props.showSuccessMessage}
            onClick={() => props.submitHandler(props.deleteData)}
          >
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default HCPConfirmationModal;
