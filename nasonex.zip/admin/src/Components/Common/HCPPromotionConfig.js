import React, { useEffect, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../CSS/Components/hcpModal.scss";
import Utility from "../../utils/Utility";
import ReactDatePicker from "react-datepicker";
import Constants from "../../utils/Constants";

const HCPPromotionConfig = (props) => {
  const modalRef = useRef(null);
  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState();

  /* useEffect(() => {
    props.updateData("open_at", startDate);
  }, [startDate]);
  useEffect(() => {
    props.updateData("close_at", endDate);
  }, [endDate]);
 */
  const changeStartDate = (date) => {
    // console.log(date);
    setStartDate(date);
    props.updateData("open_at", date);
  };
  const changeCloseDate = (date) => {
    setEndDate(date);
    props.updateData("close_at", date);
  };

  useEffect(() => {
    // console.log(props.configData);
    if (props.configData) {
      if (props.configData.open_at) {
        setStartDate(new Date(props.configData.open_at));
      }
      if (props.configData.close_at) {
        setEndDate(new Date(props.configData.close_at));
      }
    }
  }, [props.configData]);

  const updateSelectBox = () => {
    console.log(document.getElementById("statusBox").value);
    props.updateStatus(document.getElementById("statusBox").value);
  };

  const className =
    (props.configData.open_at === undefined ||
      props.configData.open_at.length === 0) &&
    props.errorMessage === true;
  const classContent =
    (props.configData.close_at === undefined ||
      props.configData.close_at.length === 0) &&
    props.errorMessage === true;

  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
  }, [props.show]);

  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={props.handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Config Promotion</Modal.Title>
        </Modal.Header>
        <form
          id={props.configData.id}
          onSubmit={props.submitHandler}
          className="editForm"
        >
          <Modal.Body>
            {props.showSuccessMessage ? (
              <p className="successMsg">
                Promotion Config has been updated successfully!
              </p>
            ) : (
              <>
                <div>
                  <label htmlFor="open_at">
                    Start Date<span>*</span>
                  </label>
                  {(props.configData.open_at === undefined ||
                    props.configData.open_at.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Start Date Required</span>
                  ) : null}
                  <ReactDatePicker
                    name="open_at"
                    selected={startDate}
                    onChange={changeStartDate}
                    showTimeSelect
                    timeFormat="h:mm aa"
                    timeIntervals={1}
                    className={className ? "input-error" : null}
                    timeCaption="time"
                    dateFormat="yyyy-MM-dd h:mm aa"
                  />
                </div>
                <div>
                  <label htmlFor="open_tm">
                    Start Date Timezone<span>*</span>
                  </label>
                  <select
                    id="openTmBox"
                    name="open_tm"
                    onChange={props.updateConfigTimezone}
                    value={props.configData.open_tm}
                  >
                    <option value={Constants.Timezones.AEDT}>
                      {Constants.Timezones.AEDT}
                    </option>
                    <option value={Constants.Timezones.AEST}>
                      {Constants.Timezones.AEST}
                    </option>
                  </select>
                </div>
                <div>
                  <label htmlFor="close_at">
                    Close Date<span>*</span>
                  </label>
                  {(props.configData.close_at === undefined ||
                    props.configData.close_at.length === 0) &&
                  props.errorMessage === true ? (
                    <span className="errorMsg">Close Date Required</span>
                  ) : null}
                  <ReactDatePicker
                    name="close_at"
                    selected={endDate}
                    onChange={changeCloseDate}
                    showTimeSelect
                    className={classContent ? "input-error" : null}
                    timeFormat="h:mm aa"
                    timeIntervals={1}
                    timeCaption="time"
                    dateFormat="yyyy-MM-dd h:mm aa"
                  />
                </div>
                <div>
                  <label htmlFor="close_tm">
                    Close Date Timezone<span>*</span>
                  </label>
                  <select
                    id="closeTmBox"
                    name="close_tm"
                    onChange={props.updateConfigTimezone}
                    value={props.configData.close_tm}
                  >
                    <option value={Constants.Timezones.AEDT}>
                      {Constants.Timezones.AEDT}
                    </option>
                    <option value={Constants.Timezones.AEST}>
                      {Constants.Timezones.AEST}
                    </option>
                  </select>
                </div>
                {/* <div>
                  <label htmlFor="status">
                    Status<span>*</span>
                  </label>
                  <select
                    id="statusBox"
                    name="status"
                    onChange={updateSelectBox}
                    value={props.configData.status}
                  >
                    <option value="1">Open</option>
                    <option value="0">Closed</option>
                  </select>
                  {props.apiErrorMessage && (
                    <span className="errorMsg float-none">
                      {props.apiErrorMessage}
                    </span>
                  )}
                </div> */}
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button
              className="customBtn"
              variant="primary"
              onClick={props.handleClose}
            >
              {props.showSuccessMessage ? "Close" : "Cancel"}
            </Button>
            <Button
              hidden={props.showSuccessMessage}
              className="customBtn"
              type="submit"
              variant="primary"
            >
              Save
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
    </>
  );
};

export default HCPPromotionConfig;
