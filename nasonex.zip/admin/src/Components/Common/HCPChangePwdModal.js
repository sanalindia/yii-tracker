import React, { useEffect, useRef, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
import Utility from "../../utils/Utility";
import Cases from "../../utils/API/Cases";
import { logout, useAuthDispatch } from "../../Context";
import PasswordChecklist from "react-password-checklist";

const HCPChangePwdModal = (props) => {
  const modalRef = useRef(null);
  const [isPwdChangeSuccess, setIsPwdChangeSuccess] = useState(false);
  const [isPwdError, setIsPwdError] = useState(true);
  const dispatch = useAuthDispatch();
  const initialState = {
    new_password: "",
    confirm_password: "",
  };
  const [pwdData, setPwdData] = useState(initialState);
  const updateFeid = (e) => {
    setPwdData({ ...pwdData, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    if (
      pwdData.new_password &&
      pwdData.confirm_password &&
      pwdData.new_password === pwdData.confirm_password
    ) {
      setIsPwdError(false);
    } else {
      setIsPwdError(true);
    }
  }, [pwdData]);

  useEffect(() => {
    if (props.show) {
      setTimeout(() => {
        Utility.scrollToModal(modalRef);
      }, 1000);
    }
  }, [props.show]);

  const submitHandler = (e) => {
    e.preventDefault();
    if (!isPwdError) {
      const data = {
        email: props.userDetails.user.email,
        password: pwdData.new_password,
      };
      // console.log(data);
      Cases.changePassword(data)
        .then((data) => {
          // console.log(data);
          setIsPwdChangeSuccess(true);
          setPwdData({ ...initialState });
        })
        .catch((error) => {
          Utility.handleAPIError(error, logout, dispatch, props);
        });
    }
  };
  const handleClose = () => {
    setIsPwdChangeSuccess(false);
    props.handleClose();
  };

  return (
    <>
      <Modal
        ref={modalRef}
        show={props.show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Change Password</Modal.Title>
        </Modal.Header>
        <form onSubmit={submitHandler} className="editForm">
          <Modal.Body>
            {isPwdChangeSuccess ? (
              <p className="successMsg">
                Password has been changed successfully!
              </p>
            ) : (
              <>
                <div>
                  <label htmlFor="new_password">
                    New Password<span>*</span>
                  </label>
                  <input
                    type="password"
                    name="new_password"
                    className="mt-1"
                    value={pwdData.new_password}
                    onChange={updateFeid}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="confirm_password">
                    Confirm New Password<span>*</span>
                  </label>
                  <input
                    type="password"
                    name="confirm_password"
                    className="mt-1"
                    value={pwdData.confirm_password}
                    onChange={updateFeid}
                    required
                  />
                </div>
                <p className="errortext">*All fields are mandatory</p>
                <PasswordChecklist
                  rules={[
                    "length",
                    "specialChar",
                    "number",
                    "capital",
                    "match",
                  ]}
                  minLength={6}
                  value={pwdData.new_password}
                  valueAgain={pwdData.confirm_password}
                  onChange={(isValid) => {
                    if (isValid) {
                      setIsPwdError(false);
                    }
                  }}
                />
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button
              className="customBtn"
              variant="secondary"
              onClick={handleClose}
            >
              {isPwdChangeSuccess ? "Close" : "Cancel"}
            </Button>
            <Button
              hidden={isPwdChangeSuccess}
              className="customBtn"
              type="submit"
              variant="primary"
            >
              Submit
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
    </>
  );
};

export default HCPChangePwdModal;
