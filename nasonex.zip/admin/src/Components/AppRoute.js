import React, { useEffect, useLayoutEffect } from "react";
import { Redirect, Route } from "react-router-dom";
import { withResizeDetector } from "react-resize-detector/build/withPolyfill";
import { useAuthState } from "../Context";

const AppRoutes = ({
  height,
  adminWrapperHeight,
  component: Component,
  path,
  isPrivate,
  ...rest
}) => {
  const userDetails = useAuthState();
  useEffect(() => {
    if (window.parent.document.getElementById("iFrameResizer0")) {
      if (window.parent.document.getElementById("block-breadcrumbs")) {
        window.parent.document.getElementById("block-breadcrumbs").innerHTML =
          "";
      }
      if (window.parent.document.getElementsByClassName("utility-area")[0]) {
        window.parent.document.getElementsByClassName(
          "utility-area"
        )[0].innerHTML = "";
      }
      if (window.parent.document.getElementById("block-chmainmenu")) {
        window.parent.document.getElementById("block-chmainmenu").innerHTML =
          "";
      }
      if (window.parent.document.getElementById("block-footercenter")) {
        window.parent.document.getElementById("block-footercenter").innerHTML =
          "";
      }
    }
  }, []);

  useLayoutEffect(() => {
    setTimeout(() => {
      if (window.parent.document.getElementById("iFrameResizer0")) {
        if (document.getElementById("admin-wrapper")) {
          window.parent.document.getElementById("iFrameResizer0").height =
            document.getElementById("admin-wrapper").offsetHeight;
        }
        window.parent.document.getElementById(
          "iFrameResizer0"
        ).style.verticalAlign = "middle";
      }
    }, 3000);
  }, [height, adminWrapperHeight]);

  return (
    <Route
      path={path}
      render={(props) =>
        isPrivate && !Boolean(userDetails.token) ? (
          // <Redirect to={{ pathname: "/login" }} />
          <Component {...props} />
        ) : (
          <Component {...props} />
        )
      }
      {...rest}
    />
  );
};

export default withResizeDetector(AppRoutes);
