import React, { useCallback, useLayoutEffect } from "react";
import { BrowserRouter as Router, Switch } from "react-router-dom";
import routes from "./Config/routes.js";
import { AuthProvider } from "./Context";
import AppRoute from "./Components/AppRoute";
import "./CSS/style.scss";
import { useResizeDetector } from "react-resize-detector/build/withPolyfill";
import HCPHeader from "./Components/Common/HCPHeader.js";

function App() {
  const onResize = useCallback(() => {
    // console.log("OnResize: ", height);
  }, []);
  const { ref, width, height } = useResizeDetector({ onResize });
  /* useLayoutEffect(() => {
    console.log("Height:", height);
    if (window.parent.document.getElementById("iFrameResizer0")) {
      console.log("Root Height:", document.getElementById("root").offsetHeight);
      window.parent.document.getElementById("iFrameResizer0").height =
        document.getElementById("root").offsetHeight;
      window.parent.document.getElementById(
        "iFrameResizer0"
      ).style.verticalAlign = "middle";
    }
  }, [height]); */
  return (
    <div ref={ref} id="admin-wrapper">
      <HCPHeader />
      <AuthProvider>
        <Router>
          <Switch>
            {routes.map((route) => (
              <AppRoute
                key={route.path}
                path={route.path}
                component={route.component}
                isPrivate={route.isPrivate}
                adminWrapperHeight={height}
              />
            ))}
          </Switch>
        </Router>
      </AuthProvider>
    </div>
  );
}

export default App;
