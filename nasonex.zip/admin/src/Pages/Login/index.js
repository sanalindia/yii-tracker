import React, { useState } from "react";
import "../../CSS/Pages/login.scss";
import { loginUser, useAuthState, useAuthDispatch } from "../../Context";

function Login(props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [validEmail, setValidEmail] = useState(true);
  const [validPassword, setValidPassword] = useState(true);

  const dispatch = useAuthDispatch();
  const { loading, errorMessage } = useAuthState();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (email === "") {
      setValidEmail(false);
    }
    if (password === "") {
      setValidPassword(false);
    } else {
      setValidEmail(true);
      setValidPassword(true);
      try {
        await loginUser(dispatch, { email, password });
        if (!JSON.parse(localStorage.getItem("currentUser")).token) return;
        props.history.push("/");
      } catch (error) {
        console.log(error);
      }
    }
  };
  const emailError = !validEmail ? "input-error" : "";
  const passwordError = !validPassword ? "input-error" : "";
  return (
    <div className="container-fluid login-wrapper">
      <div className="row">
        <div className="col-md-12 col-xs-12">
          <form className="login-form">
            <div>
              <h2>Claratyne Cashback Admin Login</h2>
              {/* <p>Please enter your login information in the fields below.</p> */}
              <div className={emailError + " input_wrapper"}>
                {/* <label htmlFor='email'>Email Address</label> */}
                {!validEmail ? (
                  <span className="invalid-text">Field is Required</span>
                ) : null}
                <input
                  type="text"
                  id="email"
                  value={email}
                  placeholder="Username"
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading}
                />
              </div>
              <div className={passwordError + " input_wrapper"}>
                {/* <label htmlFor='password'>Password</label> */}
                {!validPassword ? (
                  <span className="invalid-text">Field is Required</span>
                ) : null}
                <input
                  type="password"
                  id="password"
                  value={password}
                  placeholder="Password"
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                />
              </div>
            </div>

            <button onClick={handleLogin} disabled={loading}>
              Login
            </button>
            {errorMessage ? (
              <span className="invalid-login">{errorMessage}</span>
            ) : null}
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
