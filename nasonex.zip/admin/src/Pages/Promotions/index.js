import React, { useEffect, useState } from "react";
import HCPNavbar from "../../Components/Common/HCPNabarComponent";
import HCPTablesComponent from "../../Components/Common/HCPTablesComponent";
import HCPAddPromotion from "../../Components/Common/HCPAddPromotion";
import HCPEditPromotion from "../../Components/Common/HCPEditPromotion";
import HCPAddComponent from "../../Components/Common/HCPAddComponent";
import "../../CSS/Pages/promotions.scss";
import Cases from "../../utils/API/Cases";
import { FaBan, FaPencilAlt, FaTools, FaTrashAlt } from "react-icons/fa";
import Button from "react-bootstrap/Button";
import { IconContext } from "react-icons";
import { useAuthDispatch, logout } from "../../Context";
import Utility from "../../utils/Utility";
import HCPStatusFilter from "../../Components/Common/HCPStatusFilter";
import HCPPromotionConfig from "../../Components/Common/HCPPromotionConfig";
import Loader from "../../Components/Common/loader";
import Constants from "../../utils/Constants";

const Promotions = (props) => {
  const [editData, setEditData] = useState({});
  const [addData, setAddData] = useState({});
  const [configData, setConfigData] = useState({});
  const [show, setShow] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [brandList, setBrandList] = useState([]);
  const [initialList, setInitialList] = useState([]);
  const [errorMessage, setErrorMessage] = useState(false);
  const [showAddSuccessMessage, setShowAddSuccessMessage] = useState(false);
  const [showEditSuccessMessage, setShowEditSuccessMessage] = useState(false);
  const [apiErrorMessage, setApiErrorMessage] = useState("");
  const [isPopupClosed, setIsPopupClosed] = useState(false);
  const [isApiLoading, setIsApiLoading] = useState(true);

  const dispatch = useAuthDispatch();

  useEffect(() => {
    if (!brandList.length) {
      setIsApiLoading(true);
      Cases.getPromotions()
        .then((response) => {
          setBrandList(response);
          setInitialList(response);
          setIsApiLoading(false);
          // console.log(response);
        })
        .catch((error) => {
          Utility.handleAPIError(error, logout, dispatch, props);
          setIsApiLoading(false);
        });
    }
  }, [brandList]);

  const setDefaultBrandValue = (value = -1) => {
    if (document.getElementById("statusFilter"))
      document.getElementById("statusFilter").value = value;
  };

  useEffect(() => {
    if (isPopupClosed) {
      // console.log("popup closed");
      setTimeout(() => {
        setDefaultBrandValue();
        setBrandList(initialList);
      }, 100);
    }
  }, [isPopupClosed]);

  const handleClose = () => {
    setShow(false);
    setErrorMessage(false);
    setShowEditSuccessMessage(false);
    setIsPopupClosed(true);
  };
  const handleAddClose = () => {
    setShowAdd(false);
    setErrorMessage(false);
    setShowAddSuccessMessage(false);
    setIsPopupClosed(true);
  };
  const handleCloseConfig = () => {
    setShowConfig(false);
    setErrorMessage(false);
    setShowAddSuccessMessage(false);
    setIsPopupClosed(true);
  };
  const handleShowConfig = () => {
    setShowConfig(true);
    setIsPopupClosed(false);
  };
  const handleShow = () => {
    setShow(true);
    setIsPopupClosed(false);
  };
  const addHandler = () => {
    setApiErrorMessage("");
    setShowAdd(true);
    setIsPopupClosed(false);
  };
  const editHandler = (editData) => {
    setApiErrorMessage("");
    handleShow();
    // console.log(editData);
    setEditData(editData);
  };
  const configHandler = (editData) => {
    setApiErrorMessage("");
    handleShowConfig();
    // console.log("editData",editData);
    let data = editData;
    editData.open_tm = Constants.Timezones.AEDT;
    editData.close_tm = Constants.Timezones.AEDT;
    setConfigData(data);
  };
  const updateAddData = (e) => {
    setErrorMessage(false);
    setAddData({
      ...addData,
      [e.target.name]: e.target.value,
      // upload_id: 0,
      // order_term: 0,
      status: 1,
    });
  };

  const updateConfigData = (name, value) => {
    setErrorMessage(false);
    // console.log(name, value);
    setConfigData({
      ...configData,
      [name]: value,
    });
  };

  const updateEditData = (e) => {
    setErrorMessage(false);
    setEditData({ ...editData, [e.target.name]: e.target.value });
  };
  const updateStatus = (status) => {
    setEditData({ ...editData, status: parseInt(status) });
  };
  const updateConfigStatus = (status) => {
    setConfigData({ ...configData, status: parseInt(status) });
  };
  const updateConfigTimezone = (e) => {
    setConfigData({ ...configData, [e.target.name]: e.target.value });
  };
  const submitAddHandler = (e) => {
    e.preventDefault();
    //console.log(addData)
    if (
      addData.name === undefined ||
      addData.description === undefined ||
      addData.name.length === 0 ||
      addData.description.length === 0
    ) {
      setErrorMessage(true);
    } else {
      Cases.addPromotion(addData)
        .then((data) => {
          // console.log(data);
          setBrandList({ ...brandList, addData });
          setInitialList({ ...initialList, addData });
          //   setShowAdd(false);
          setShowAddSuccessMessage(true);
        })
        .catch((error) => {
          Utility.handleAPIValidationError(error, setApiErrorMessage);
          Utility.handleAPIError(error, logout, dispatch, props);
          setShowAddSuccessMessage(false);
        });
    }
  };

  const submitConfigHandler = (e) => {
    e.preventDefault();
    // console.log(configData);
    if (configData && configData.open_at && configData.close_at) {
      Cases.configPromotion(configData)
        .then((data) => {
          // console.log(data);
          setBrandList({ ...brandList, configData });
          setInitialList({ ...initialList, configData });
          //   setShowAdd(false);
          setShowAddSuccessMessage(true);
        })
        .catch((error) => {
          Utility.handleAPIValidationError(error, setApiErrorMessage);
          Utility.handleAPIError(error, logout, dispatch, props);
          setShowAddSuccessMessage(false);
        });
    } else {
      setErrorMessage(true);
    }
  };

  const updateListByStatus = () => {
    var status = document.getElementById("statusFilter").value;
    // console.log("StatusSel:", status);
    var resultData = [];
    if (status >= 0) {
      resultData = initialList.filter((data) => {
        return data.status + "" === status + "";
      });
      // console.log("StatusSel:", resultData);
      setBrandList(resultData);
    } else {
      setBrandList(initialList);
    }
  };

  const submitEditHandler = (e) => {
    e.preventDefault();

    if (editData.name && editData.description) {
      // console.log("Edit submit", editData);
      Cases.updatePromotion(editData)
        .then((data) => {
          // console.log(data);
          setBrandList({ ...brandList, editData });
          setInitialList({ ...initialList, editData });
          //   setShow(false);
          setShowEditSuccessMessage(true);
        })
        .catch((error) => {
          Utility.handleAPIValidationError(error, setApiErrorMessage);
          Utility.handleAPIError(error, logout, dispatch, props);
          setShowEditSuccessMessage(false);
        });
    } else {
      setErrorMessage(true);
    }
    //console.log(editData)
  };

  const columns = [
    {
      name: "Name",
      selector: "name",
      sortable: true,
    },
    {
      name: "Description",
      selector: "description",
      sortable: true,
    },
    {
      name: "Open At",
      sortable: true,
      cell: (row) => <>{`${row.open_at} ${row.open_tm ? row.open_tm : ""}`}</>,
    },
    {
      name: "Close At",
      sortable: true,
      cell: (row) => (
        <>{`${row.close_at} ${row.close_tm ? row.close_tm : ""}`}</>
      ),
    },
    {
      name: "Status",
      sortable: false,
      cell: (row) => <>{row.status == 1 ? "Open" : "Closed"}</>,
    },
    {
      name: "Actions",
      sortable: false,
      cell: (row) => (
        <>
          <IconContext.Provider value={{ className: "react-icons" }}>
            <Button
              className="dataEdit"
              onClick={() => editHandler(row)}
              title={Constants.PopoverTexts.submissionEdit}
            >
              {" "}
              <FaPencilAlt />{" "}
            </Button>
            <Button
              className="dataEdit"
              onClick={() => configHandler(row)}
              title={Constants.PopoverTexts.submissionConfigEdit}
            >
              {" "}
              <FaTools />{" "}
            </Button>
          </IconContext.Provider>
        </>
      ),
    },
  ];

  return (
    <>
      <HCPNavbar {...props} />
      {/*  <div className="page-banner">
        <h2>Manage Brands</h2>
        <p>
          Brands are added, edited
          <br />
          and other possible opertions related to them can be performed here
        </p>
      </div> */}
      <div className="container-fluid promotionSection">
        <HCPStatusFilter
          statusTypeArray={Utility.getPromotionStatusList()}
          updateListByStatus={updateListByStatus}
        />
        <HCPAddComponent
          addHandler={addHandler}
          title={Constants.PopoverTexts.promotionAdd}
        />
        {isApiLoading ? (
          <Loader />
        ) : (
          <HCPTablesComponent
            data={brandList}
            columns={columns}
            notExpandable={true}
          />
        )}
      </div>
      <HCPPromotionConfig
        show={showConfig}
        handleClose={handleCloseConfig}
        handleShow={handleShowConfig}
        configData={configData}
        updateData={updateConfigData}
        updateStatus={updateConfigStatus}
        updateConfigTimezone={updateConfigTimezone}
        submitHandler={submitConfigHandler}
        showSuccessMessage={showAddSuccessMessage}
        errorMessage={errorMessage}
        apiErrorMessage={apiErrorMessage}
      />
      <HCPAddPromotion
        show={showAdd}
        handleClose={handleAddClose}
        handleShow={addHandler}
        addData={addData}
        updateData={updateAddData}
        submitHandler={submitAddHandler}
        showSuccessMessage={showAddSuccessMessage}
        errorMessage={errorMessage}
        apiErrorMessage={apiErrorMessage}
      />
      <HCPEditPromotion
        show={show}
        handleClose={handleClose}
        handleShow={editHandler}
        editData={editData}
        updateData={updateEditData}
        updateStatus={updateStatus}
        submitHandler={submitEditHandler}
        showSuccessMessage={showEditSuccessMessage}
        errorMessage={errorMessage}
        apiErrorMessage={apiErrorMessage}
      />
    </>
  );
};

export default Promotions;
