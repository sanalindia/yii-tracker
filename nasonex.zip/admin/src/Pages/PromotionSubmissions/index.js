import React, { useEffect, useState } from "react";
import HCPNavbar from "../../Components/Common/HCPNabarComponent";
import HCPTablesComponent from "../../Components/Common/HCPTablesComponent";
import "../../CSS/Pages/promotions.scss";
import "../../CSS/Pages/promotionSubmissions.scss";
import Cases from "../../utils/API/Cases";
import Button from "react-bootstrap/Button";
import HCPViewSubmissionDetailModal from "../../Components/Common/HCPViewSubmissionDetailModal";
import Utility from "../../utils/Utility";
import HCPOrderFilter from "../../Components/Common/HCPOrderFilter";
import HCPDateFilter from "../../Components/Common/HCPDateFilter";
import { logout, useAuthDispatch } from "../../Context";
import { CSVLink } from "react-csv";
import { FaDownload } from "react-icons/fa";
import { IconContext } from "react-icons";
import moment from "moment";
import Constants from "../../utils/Constants";
import HCPPromotionFilter from "../../Components/Common/HCPPromotionFilter";
import Loader from "../../Components/Common/loader";

const PromotionSubmissions = (props) => {
  const [editData, setEditData] = useState({});
  const [show, setShow] = useState(false);
  const [defaultSortAsc, setDefaultSortAsc] = useState(false);
  const [isApiLoading, setIsApiLoading] = useState(true);
  const [submissionList, setSubmissionList] = useState([]);
  const [promotionArray, setPromotionArray] = useState([]);
  const [downloadList, setDownloadList] = useState([]);
  const [initialList, setInitialList] = useState([]);
  const [csvFileName, setCsvFileName] = useState("Order_Details.csv");
  const [statusChanged, setStatusChanged] = useState(false);
  const [promotionFilterChanged, setPromotionFilterChanged] = useState(false);
  const [dateRange, setDateRange] = useState([new Date(), new Date()]);
  const [startDate, endDate] = dateRange;
  const dispatch = useAuthDispatch();
  const [csvHeaders, setCsvHeaders] = useState([
    { label: "Submission ID #", key: "submission_id" },
    { label: "Promotion Name", key: "promotion_name" },
    { label: "First Name", key: "first_name" },
    { label: "Last Name", key: "last_name" },
    { label: "Email", key: "email" },
    { label: "Phone", key: "phone" },
    { label: "Pharmacy Purchased", key: "pharmacy_purchased" },
    { label: "Refund Name", key: "refund_name" },
    { label: "Address", key: "address" },
    { label: "Suburb", key: "suburb" },
    { label: "State", key: "state_name" },
    { label: "Postcode", key: "postcode" },
    { label: "BSB", key: "bsb" },
    { label: "Account Number", key: "account_number" },
    { label: "Receipt Number", key: "receipt_number" },
    { label: "Is Proof Purchase", key: "is_proof_purchase" },
    { label: "Is Term", key: "is_term" },
    { label: "Is Future Promotions", key: "is_future_promotions" },
    { label: "Upload Receipt", key: "upload_receipt" },
    { label: "Status", key: "status" },    
    { label: "Claim Amount", key: "claim_amount" },
    { label: "Reason", key: "reason" },
    { label: "Download Link", key: "download_path"},
    { label: "Submission Date", key: "submission_date" },
  ]);

  /* useEffect(() => {
    console.log("Status change", statusChanged);
    if (statusChanged) {
      setIsApiLoading(true);
      let selectedPromotionId = getPromotionId();
      Cases.getPromotionSubmissions(selectedPromotionId)
        .then((response) => {
          // console.log(response);
          // if (response) {
          let responseData = response && response.length ? response : [];
          setSubmissionList(responseData);
          setDownloadList(responseData);
          setInitialList(responseData);
          setDefaultSortAsc(true);
          setStatusChanged(false);
          setIsApiLoading(false);
          // }
        })
        .catch((error) => {
          Utility.handleAPIError(error, logout, dispatch, props);
          clearList();
          setIsApiLoading(false);
        });
    }
  }, [statusChanged]); */

  const clearList = (data = []) => {
    setSubmissionList(data);
    setDownloadList(data);
    setInitialList(data);
  };

  const handleDateChange = (update) => {
    // console.log("DatChange", update);
    setDateRange(update);
  };

  useEffect(() => {
    getAllData();
  }, [dateRange]);

  const getAllData = (updateInitialList = false) => {
    if (startDate && endDate) {
      // console.log("Dates", startDate, endDate);
      const data = {
        from: moment(new Date(startDate)).format("YYYY-MM-DD"),
        to: moment(new Date(endDate)).format("YYYY-MM-DD"),
      };
      setCsvFileName(`${data.from}_to_${data.to}_Promotion_Details.csv`);
      getDownloadList(data, updateInitialList);
      // getPromotionList(data);
    } else if (!startDate && !endDate) {
      getDownloadList(null, updateInitialList);
      // getPromotionList();
      setCsvFileName("Promotion_Details.csv");
    }
  };
  useEffect(() => {
    // getDownloadList(null, true);
    Cases.getPromotions().then((response) => {
      setPromotionArray(response);
    });
  }, []);
  useEffect(() => {
    if (promotionArray && promotionArray.length > 0) {
      if (document.getElementById("promotionFilter")) {
        let promo = promotionArray.filter(
          (promotion) => promotion.id === Constants.DEFAULT_PROMOTION_ID
        );
        if (promo.length) {
          document.getElementById("promotionFilter").value = promo[0].name;
        }
      }
    }
  }, [promotionArray]);

  const getDownloadList = (request, updateInitialList = false) => {
    setIsApiLoading(true);
    const data = request ? request : "";
    let selectedPromotionId = getPromotionId();
    console.log("PromoID", selectedPromotionId);
    Cases.getPromotionSubmissions(selectedPromotionId, data)
      .then((response) => {
        // console.log("CSV", response);
        // if (response) {
        let responseData = response && response.length ? response : [];
        setDownloadList(responseData);
        setSubmissionList(responseData);
        setIsApiLoading(false);
        if (
          !initialList.length ||
          promotionFilterChanged ||
          updateInitialList
        ) {
          setInitialList(responseData);
          setDefaultSortAsc(true);
        }
        // setPromotionFilterChanged(false);
        // }
      })
      .catch((error) => {
        Utility.handleAPIError(error, logout, dispatch, props);
        clearList();
        setIsApiLoading(false);
      });
  };
  /* const getPromotionList = (request) => {
    const data = request ? request : "";
    Cases.getPromotionSubmissions(selectedPromotionId, data)
      .then((response) => {
        // console.log("getPromotionList", response);
        if (response) {
          setSubmissionList(response);
        }
      })
      .catch((error) => {
        Utility.handleAPIError(error, logout, dispatch, props);
      });
  }; */

  const handleClose = () => setShow(false);

  const handleShow = () => {
    setShow(true);
  };
  const editHandler = (editData) => {
    setEditData(editData);
    handleShow();
  };
  const acceptHandler = (item,claimAmount,reason) => {
    // console.log("acceptHandler", item);
    // let selectedPromotionId = getPromotionId();
    //console.log(claimAmount,reason)
    if (item && item.submission_id) {
      Cases.approveOrDeletePromotion(
        item.submission_id,
        Constants.SUBMISSION_APPROVE,
        claimAmount,
        reason
      )
        .then((response) => {
          // console.log("accept", response);
          // setStatusChanged(true);
          handleClose();
          getAllData(true);
        })
        .catch((error) => {
          Utility.handleAPIError(error, logout, dispatch, props);
        });
    }
  };

  const rejectHandler = (item,claimAmount,reason) => {
    // console.log("rejectHandler", item);
    // let selectedPromotionId = getPromotionId();
    if (item && item.submission_id) {
      Cases.approveOrDeletePromotion(
        item.submission_id,
        Constants.SUBMISSION_DELETE,
        claimAmount,
        reason


      )
        .then((response) => {
          // console.log(response);
          // setStatusChanged(true);
          handleClose();
          getAllData(true);
        })
        .catch((error) => {
          Utility.handleAPIError(error, logout, dispatch, props);
        });
    }
  };

  const updateListByStatus = () => {
    var status = document.getElementById("statusFilter").value;
    // console.log("StatusSel:", status);
    var resultData = [];
    if (status !== "All") {
      resultData = initialList.filter((data) => {
        return data.status === status;
      });

      setSubmissionList(resultData);
    } else {
      setSubmissionList(initialList);
    }
  };
  const getStatusColor = (status) => {
    if (status === "Confirmed") {
      return "green";
    } else if (status === "Deleted") {
      return "blue";
    } else {
      return "red";
    }
  };
  const getPromotionId = () => {
    let promotionName =
      document.getElementById("promotionFilter") &&
      document.getElementById("promotionFilter").value;
    if (promotionName) {
      let selectedPromotion = promotionArray.filter((data) => {
        return data.name === promotionName;
      });
      if (selectedPromotion && selectedPromotion.length > 0) {
        return selectedPromotion[0].id;
      }
    }
    return Constants.DEFAULT_PROMOTION_ID;
  };
  const updateListByPromotion = () => {
    // console.log("promotion filter");
    /* let promotionName = document.getElementById("promotionFilter").value;
    // console.log("promotion change", promotionName, initialList);
    let resultData = [];
    if (promotionName) {
      resultData = initialList.filter((data) => {
        return data.promotion_name === promotionName;
      });
    } else {
      resultData = initialList;
    }
    // console.log("Updated:", resultData);
    setSubmissionList(resultData); */
    setPromotionFilterChanged(true);
  };
  useEffect(() => {
    if (promotionFilterChanged) {
      // console.log("promotion filter useeffect");
      getAllData();
      setPromotionFilterChanged(false);
    }
  }, [promotionFilterChanged]);

  const columns = [
    {
      name: "#ID",
      selector: "submission_id",
      sortable: true,
    },
    {
      name: "First Name",
      selector: "first_name",
      sortable: true,
    },
    {
      name: "Last Name",
      selector: "last_name",
      sortable: true,
    },
    {
      name: "Email",
      selector: "email",
      sortable: true,
    },
    {
      name: "Phone",
      selector: "phone",
      sortable: true,
    },
    /* {
      name: "Pharmacy",
      selector: "pharmacy_purchased",
      sortable: true,
    }, */
    {
      name: "Refund",
      selector: "refund_name",
      sortable: true,
    },
    {
      name: "Date",
      selector: "submission_date",
      sortable: true,
    },
    {
      name: "Status",
      sortable: true,
      cell: (row) => (
        <>
          <span style={{ color: getStatusColor(row.status) }}>
            {row.status}
          </span>
        </>
      ),
    },
    {
      name: "Actions",
      sortable: false,
      cell: (row) => (
        <>
          <Button
            className="customBtn"
            onClick={() => editHandler(row)}
            title={Constants.PopoverTexts.viewSubmissionDetails}
          >
            Details
          </Button>
        </>
      ),
    },
  ];

  return (
    <div className="orders-container">
      <HCPNavbar {...props} />
      {/*  <div className="page-banner">
        <h2>Manage Orders</h2>
        <p>
          Orders can be viewed, approved or rejected <br />
          based upon the availabilty of the products.
        </p>
      </div> */}
      <div className="container-fluid ordersSection">
        <HCPPromotionFilter
          promotionArray={promotionArray}
          updateListByPromotion={updateListByPromotion}
        />
        <HCPOrderFilter
          statusTypeArray={Utility.getSubmissionStatusList()}
          updateListByStatus={updateListByStatus}
        />

        <HCPDateFilter
          startDate={startDate}
          endDate={endDate}
          handleChange={handleDateChange}
          placeholderText="From - To"
        />
        <IconContext.Provider value={{ className: "react-icons" }}>
          <CSVLink
            data={downloadList}
            headers={csvHeaders}
            filename={csvFileName}
            title={Constants.PopoverTexts.csvDownload}
            className="ml-3"
          >
            <FaDownload />
          </CSVLink>
        </IconContext.Provider>
        {isApiLoading ? (
          <Loader />
        ) : (
          <HCPTablesComponent
            // defaultSortField="orderedDate"
            // defaultSortAsc={defaultSortAsc}
            data={submissionList}
            columns={columns}
            notExpandable={true}
          />
        )}
      </div>
      <HCPViewSubmissionDetailModal
        show={show}
        handleClose={handleClose}
        handleShow={editHandler}
        acceptHandler={acceptHandler}
        rejectHandler={rejectHandler}
        editData={editData}
      />
    </div>
  );
};

export default PromotionSubmissions;
