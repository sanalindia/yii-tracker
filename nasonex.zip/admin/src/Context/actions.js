import Cases from "../utils/API/Cases";

export async function loginUser(dispatch, loginPayload) {
	// console.log(JSON.stringify(loginPayload));
	
	try {
		dispatch({ type: 'REQUEST_LOGIN' });
		await Cases.loginHCPAdmin(loginPayload).
		then((data)=>{
			if (data.token) {
				data['user'] = loginPayload; 
				dispatch({ type: 'LOGIN_SUCCESS', payload: data });				
				let userData = data;
				delete userData.user.password;
				localStorage.setItem('currentUser', JSON.stringify(userData));
				
			}
			else{
				dispatch({ type: 'LOGIN_ERROR', error: data.message });
				console.log(data.message);
				
			}
		})
		
	} catch (error) {
		await 
		dispatch({ type: 'LOGIN_ERROR', error: error });
		console.log(error);
	}
}

export async function logout(dispatch) {
	await Cases.logoutHCPAdmin().
	then((res) => {
		dispatch({ type: 'LOGOUT' });
		localStorage.removeItem('currentUser');
		localStorage.removeItem('token');
	})
	
}
