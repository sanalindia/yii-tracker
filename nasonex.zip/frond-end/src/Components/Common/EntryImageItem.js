import React from "react";
import "../../Css/Common/EntryImageItem.scss";

function EntryImageItem({ contentList }) {
  return (
    <div className="entry-image-item-container">
      {contentList.map((content, index) => (
        <div className="entry-image-item-wrapper">
          <span className="image-wrapper">
            <img src={content.src} alt={"icon" + index} />
          </span>
          <span className="image-item-text">{content.text}</span>
        </div>
      ))}
    </div>
  );
}

export default EntryImageItem;
