import React from "react";
import "../../Css/Common/EntryFormInput.scss";
import EntryFormLabel from "./EntryFormLabel";

function EntryFormInput({
  value,
  label,
  name,
  placeholder,
  type,
  onChange,
  required,
  maxLength = 100,
  postLabelText,
}) {
  const handleOnChange = (e) => {
    const { value } = e.target;
    if (!value || (value && value.length <= maxLength)) {
      onChange(e);
    }
  };
  return (
    <div className="form-group entry-form-input-container">
      <EntryFormLabel
        label={label}
        required={required}
        className="entry-form-label-wrapper"
        postLabelText={postLabelText}
      />
      <input
        type={type}
        value={value}
        name={name}
        className="form-control entry-form-input"
        placeholder={placeholder}
        onChange={handleOnChange}
        required={required}
        maxLength={maxLength}
      />
    </div>
  );
}

export default EntryFormInput;
