import React from "react";
import "../../Css/Common/EntryFormDropdown.scss";
import Utils from "../../Utils/Utils";
import EntryFormLabel from "./EntryFormLabel";

function EntryFormDropdown({
  selectData = [],
  value,
  label,
  name,
  onChange,
  required,
  postLabelText,
  maxLength,
  optionNameSelector,
  optionIdSelector,
  optionKeySelector,
}) {
  return (
    <div className="form-group entry-form-dropdown-container">
      <EntryFormLabel
        label={label}
        required={required}
        className="entry-form-label-wrapper"
        postLabelText={postLabelText}
      />
      <select
        name={name}
        value={value}
        className="form-control entry-form-input"
        onChange={onChange}
        required={required}
      >
        <option value=""></option>
        {selectData.map((data, index) => (
          <option
            key={data[optionKeySelector] ? data[optionKeySelector] : index}
            value={data[optionIdSelector]}
          >
            {Utils.trimTextWithLength(data[optionNameSelector], maxLength)}
          </option>
        ))}
      </select>
    </div>
  );
}

export default EntryFormDropdown;
