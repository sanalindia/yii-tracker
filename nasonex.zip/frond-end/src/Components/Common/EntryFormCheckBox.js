import React from "react";
import "../../Css/Common/EntryFormBox.scss";
import EntryFormLabel from "./EntryFormLabel";

function EntryFormCheckBox({
  labelValues = [],
  value,
  name,
  type,
  onChange,
  required,
  postLabelText,
  showRequiredSymbol,
}) {
  return (
    <div className="form-group entry-form-box-container" onChange={onChange}>
      {labelValues.map((labelValue, index) => (
        <div className="entry-form-box-wrapper" key={index}>
          <input
            type={type}
            value={labelValue.value}
            name={labelValue.name ? labelValue.name : name}
            className=""
            defaultChecked={labelValue.value === "1"}
            required={labelValue.required}
          />
          <EntryFormLabel
            label={labelValue.label}
            postLabelText={labelValue.postLabelText}
            className="ml-3"
            required={labelValue.showRequiredSymbol}
          />
        </div>
      ))}
    </div>
  );
}

export default EntryFormCheckBox;
