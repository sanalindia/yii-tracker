import React from "react";
import "../../Css/Common/EntryFormBox.scss";
import EntryFormLabel from "./EntryFormLabel";

function EntryFormBox({
  labelValues = [],
  value,
  name,
  type,
  onChange,
  required,
  postLabelText,
  showRequiredSymbol,
}) {
  return (
    <div className="form-group entry-form-box-container" onChange={onChange}>
      {labelValues.map((labelValue, index) => (
        <div className="entry-form-box-wrapper" key={index}>
          <input
            type={type}
            value={labelValue.id}
            name={name}
            className=""
            required={required}
          />
          <EntryFormLabel
            label={labelValue.description}
            postLabelText={postLabelText}
            className="ml-3"
            // required={required}
          />
        </div>
      ))}
    </div>
  );
}

export default EntryFormBox;
