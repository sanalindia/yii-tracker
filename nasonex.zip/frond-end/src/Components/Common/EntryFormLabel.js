import React from "react";
import "../../Css/Common/EntryFormLabel.scss";

function EntryFormLabel({ label, required, className, postLabelText }) {
  return (
    <>
      {label && (
        <label
          htmlFor="input-field"
          className={
            className ? className + " entry-form-label" : "entry-form-label"
          }
          dangerouslySetInnerHTML={{
            __html: `${label}${
              required ? "<span class='required'>*</span>" : ""
            }${postLabelText ? postLabelText : ":"}`,
          }}
        >
          {/* {label} */}
          {/*  {required && <span className="required">*</span>}
          {postLabelText ? postLabelText : ":"} */}
        </label>
      )}
    </>
  );
}

export default EntryFormLabel;
