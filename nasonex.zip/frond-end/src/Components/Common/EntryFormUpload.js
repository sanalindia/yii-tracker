import React, { useState } from "react";
import "../../Css/Common/EntryFormUpload.scss";
import Constants from "../../Utils/Constants";
import EntryFormLabel from "./EntryFormLabel";

function EntryFormUpload({
  value,
  label,
  name,
  placeholder,
  type,
  onChange,
  required,
  maxLength,
  postLabelText,
}) {
  const [fileName, setFileName] = useState("");
  const handleChange = (e) => {
    if (e.target.value && e.target.files[0]) {
      let fileSize = e.target.files[0].size / 1024;
      console.log(fileSize);
      if (fileSize < Constants.FILE_SIZE) {
        let fileName = e.target.value.split("\\").pop();
        if (
          fileName.includes(".pdf") ||
          fileName.includes(".PDF") ||
          fileName.includes(".jpg") ||
          fileName.includes(".JPG") ||
          fileName.includes(".JPEG")||
          fileName.includes(".jpeg")||
          fileName.includes(".PNG") ||
          fileName.includes(".png")
        ) {
          setFileName(fileName);
          onChange(e);
        } else {
          setFileName(Constants.FILE_TYPE_ERROR);
        }
      } else {
        setFileName(Constants.FILE_SIZE_ERROR);
      }
    }
  };
  return (
    <div className="form-group entry-form-upload-container mt-5 mb-5">
      <div className="entry-form-label-wrapper">
        <EntryFormLabel
          label={label}
          required={required}
          postLabelText={postLabelText}
        />
        <label className="btn browseBtn" htmlFor={name}>
          BROWSE
        </label>
      </div>
      <input
        type={type}
        value={value}
        name={name}
        className="form-control entry-form-input"
        id={name}
        accept=".jpg,application/pdf,.jpeg,.png"
        onChange={handleChange}
        required
        hidden
      />
      <input
        type="text"
        value={fileName}
        onChange={() => {}}
        name={name}
        className={`form-control entry-form-input upload-input${
          fileName === Constants.FILE_SIZE_ERROR ||
          fileName === Constants.FILE_TYPE_ERROR
            ? " file-error-msg"
            : ""
        }`}
        placeholder={placeholder}
        required
      />
    </div>
  );
}

export default EntryFormUpload;
