import React, { useCallback, useEffect, useRef, useState } from "react";
import { Form, Button } from "react-bootstrap";
import EntryFormInput from "./Common/EntryFormInput";
import "../Css/EntryFormComponent.scss";
import EntryFormLabel from "./Common/EntryFormLabel";
import EntryFormBox from "./Common/EntryFormBox";
import EntryFormUpload from "./Common/EntryFormUpload";
import EntryFormDropdown from "./Common/EntryFormDropdown";
import Constants from "../Utils/Constants";
import Utils from "../Utils/Utils";
import EntryFormCheckBox from "./Common/EntryFormCheckBox";
import Cases from "../Utils/Cases";
import { useGoogleReCaptcha } from "react-google-recaptcha-v3";
import MailCases from "../Utils/MailCases";

function EntryFormComponent() {
  const [inputValue, setInputValue] = useState({
    promotion_id: Constants.PROMOTION_ID,
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    pharmacy_purchased: "",
    refund_methods_id: "2",
    address: "",
    suburb: "",
    state_id: "",
    postcode: "",
    bsb: "na",
    account_number: "na",
    receipt_number: "",
    upload_id: 2,
    is_proof_purchase: "",
    is_term: "",
    is_future_promotions: "1",
    status: "1",
  });
  const [uploadInput, setUploadInput] = useState({
    file: "",
    type: "coupon_receipt",
  });
  const [refundMethods, setRefundMethods] = useState([]);
  const [statesList, setStatesList] = useState([]);
  const [claimReasonList, setClaimReasonList] = useState([]);
  const [pharmacyList, setPharmacyList] = useState([]);
  const [stateDetails, setStateDetails] = useState([]);
  const [postalCodeList, setPostalCodeList] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [formValid, setFormValid] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [isSubmitClicked, setIsSubmitClicked] = useState(false);
  const [submitErrorMsg, setSubmitErrorMsg] = useState("");
  const { executeRecaptcha } = useGoogleReCaptcha();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setInputValue((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (value && name === "state_id") {
      Cases.getPostalCodeAndCity(value).then((response) => {
        // console.log("Postal: ", response);
        setStateDetails(response);
        let postalcodes = Utils.removeDuplicateItemByKey(response, "postal");
        setPostalCodeList(postalcodes);
      });
    } else if (name === "postcode") {
      let cities = stateDetails.filter((data) => data.postal === value);
      setCityList(cities);
    }
  };
  const clearErroMsg = () => {
    if (submitErrorMsg !== "") {
      setSubmitErrorMsg("");
    }
  };
  const handleUploadChange = (e) => {
    // console.log(e.target);
    if (e.target.files[0]) {
      // console.log("File:", e.target.files[0]);
      const { files } = e.target;
      console.log("e.target", e.target);
      console.log("files", files);
      setUploadInput((prev) => ({
        ...prev,
        file: files[0],
      }));
    }
  };

  const handleBoxChange = (e) => {
    const { name, value } = e.target;
    setInputValue((prev) => ({
      ...prev,
      [name]: value,
    }));
    // console.log(name, value);
  };
  const handleCheckBoxChange = (e) => {
    const { name, value, checked } = e.target;
    // console.log(name, value, e.target.checked);
    setInputValue((prev) => ({
      ...prev,
      [name]: checked ? "1" : "0",
    }));
  };

  /*  const handleCaptchaChange = (e) => {
    console.log("Captcha", e);
  }; */

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submit", inputValue);
    if (uploadInput.file) {
      setFormValid(true);
      setIsSubmitClicked(true);

      // setCaptchaVerified(true);
      handleReCaptchaVerify();
    }
  };
  const collectionModal = (e) => {
    e.preventDefault();
    alert("Hello");
  };
  const handleReCaptchaVerify = useCallback(async () => {
    if (executeRecaptcha && formValid) {
      const token = await executeRecaptcha("g_recaptcha_response");
      if (token) {
        Cases.verifyCaptcha(token)
          .then((response) => {
            console.log("Verify", response);
            if (response.success === true) {
              if (response.score > 0.4) {
                setCaptchaVerified(true);
              } else {
                setCaptchaVerified(false);
                setSubmitErrorMsg("Captcha validation response as bot user");
                setIsSubmitClicked(false);
              }
            }
          })
          .catch((error) => {
            setIsSubmitClicked(false);
            if (error.message) {
              setSubmitErrorMsg(error.message);
            }
          });
      }
    }
  }, [executeRecaptcha, formValid]);

  useEffect(() => {
    handleReCaptchaVerify();
  }, [handleReCaptchaVerify]);

  useEffect(() => {
    if (captchaVerified && formValid) {
      console.log("uploadInputs", uploadInput);
      Cases.uploadReceipt(uploadInput, true)
        .then(async (response) => {
          if (response.status === "success") {
            setInputValue((prev) => ({
              ...prev,
              upload_id: response.resources.id,
            }));
            inputValue.upload_id = response.resources.id;
            Cases.submitPromotion(inputValue)
              .then(async (response) => {
                console.log("Submitted", response);
                if (response.status === "success") {
                  let lastInsertedId = response.submissions_id;
                  if (inputValue.is_future_promotions === "1") {
                    let statename = statesList.filter(
                      (data) => data.id === parseInt(inputValue.state_id)
                    );
                    console.log("statename", statename);
                    const data = {
                      firstname: inputValue.first_name,
                      lastname: inputValue.last_name,
                      email: inputValue.email,
                      address1: inputValue.address,
                      city: inputValue.suburb,
                      state: statename[0].name,
                      zip: inputValue.postcode,
                      phone: inputValue.phone,
                      orig_reg_date: Utils.getCurrentDateString(),
                      country: "AU",
                      last_mod_date: Utils.getCurrentDateString(),
                    };
                    await MailCases.recipientWrite(data)
                      .then((response) => {
                        console.log("recipientWrite", response);
                        Utils.redirectPage("/thank-you");
                      })
                      .catch((e) => console.log(e));
                    // const optData = {
                    //   email: inputValue.email,
                    //   opt_status: "1",
                    //   opt_date: Utils.getCurrentDateString(),
                    // };
                    // await MailCases.optWrite(optData)
                    //   .then((response) => {
                    //     console.log("optWrite", response);
                    //   })
                    //   .catch((e) => console.log(e));
                    // show thanks page
                  } else {
                    // show thanks page
                    Utils.redirectPage("/thank-you");
                  }
                }
              })
              .catch((error) => {
                setIsSubmitClicked(false);
                if (error.message) {
                  setSubmitErrorMsg(error.message);
                }
              });
          } else {
            setIsSubmitClicked(false);
            if (response.message) {
              setSubmitErrorMsg(response.message);
            }
          }
        })
        .catch((error) => {
          setIsSubmitClicked(false);
          if (error.message) {
            setSubmitErrorMsg(error.message);
          }
        });
    }
  }, [captchaVerified]);

  useEffect(() => {
    // console.log(inputValue);
    clearErroMsg();
    /*if (formValid && captchaVerified && inputValue.upload_id) {
      Cases.submitPromotion(inputValue)
        .then((response) => {
          console.log("Submitted", response);
          if (response.status === "success") {
            // show thanks page
            Utils.redirectPage("/thank-you");
          }
        })
        .catch((error) => {
          setIsSubmitClicked(false);
          if (error.message) {
            setSubmitErrorMsg(error.message);
          }
        });
      if (inputValue.is_future_promotions === "1") {
        const data = {
          firstname: inputValue.first_name,
          lastname: inputValue.last_name,
          email: inputValue.email,
          address1: inputValue.address,
          city: inputValue.suburb,
          state: inputValue.state_id,
          zip: inputValue.postcode,
          phone: inputValue.phone,
          orig_reg_date: Utils.getCurrentDateString(),
          country: "AU",
          last_mod_date: Utils.getCurrentDateString(),
        };
        MailCases.recipientWrite(data)
          .then((response) => {
            console.log("recipientWrite", response);
          })
          .catch((e) => console.log(e));
        const optData = {
          email: inputValue.email,
          opt_status: "1",
          opt_date: Utils.getCurrentDateString(),
        };
        MailCases.optWrite(optData)
          .then((response) => {
            console.log("optWrite", response);
          })
          .catch((e) => console.log(e));
      }
    } */
  }, [inputValue, formValid]);

  useEffect(() => {
    Utils.hideSSPLoader(1000);
    Cases.getRefundMethods().then((response) => {
      setRefundMethods(response);
    });
    Cases.getStates().then((response) => {
      setStatesList(response);
    });
    Cases.getReasons().then((response) => {
      setClaimReasonList(response);
    });
    Cases.getPharmacys().then((response) => {
      setPharmacyList(response);
    });
  }, []);

  useEffect(() => {
    clearErroMsg();
    /*if (uploadInput.file) {
      Cases.uploadReceipt(uploadInput, true)
        .then((response) => {
          if (response.status === "success") {
            setInputValue((prev) => ({
              ...prev,
              upload_id: response.resources.id,
            }));
          } else {
            setIsSubmitClicked(false);
            if (response.message) {
              setSubmitErrorMsg(response.message);
            }
          }
        })
        .catch((error) => {
          setIsSubmitClicked(false);
          if (error.message) {
            setSubmitErrorMsg(error.message);
          }
        });
    }
    */
  }, [uploadInput]);

  return (
    <div>
      <Form className="entryFormContainer" onSubmit={handleSubmit}>
        {/*  <h2 className="entryHeading">ENTRY FORM</h2> */}
        <h5 className="entrySubHeading">Personal Details</h5>
        <EntryFormInput
          type="text"
          value={inputValue.first_name}
          label="First name"
          name="first_name"
          onChange={handleChange}
          required
          maxLength="50"
        />
        <EntryFormInput
          type="text"
          value={inputValue.last_name}
          label="Last name"
          name="last_name"
          onChange={handleChange}
          required
          maxLength="50"
        />
        <EntryFormInput
          type="text"
          value={inputValue.email}
          label="Email address"
          name="email"
          onChange={handleChange}
          required
          maxLength="50"
        />
        <EntryFormInput
          type="number"
          value={inputValue.phone}
          label="Phone number (inc. area code)"
          name="phone"
          onChange={handleChange}
          required
          maxLength="50"
        />
        <h5 className="entrySubHeading mt-5">Reason for claim</h5>
        <EntryFormDropdown
          value={inputValue.claim_reason}
          label="Reason for claim"
          name="claim_reason"
          onChange={handleChange}
          required
          maxLength="50"
          selectData={claimReasonList}
          optionNameSelector="name"
          optionIdSelector="name"
          optionKeySelector="id"
        />
        <h5 className="entrySubHeading mt-5">Refund Details</h5>
        <EntryFormInput
          type="date"
          value={inputValue.purchase_date}
          label="Date of purchase"
          name="purchase_date"
          onChange={handleChange}
          required
        />
        <EntryFormInput
          type="text"
          value={inputValue.purchase_price}
          label="Purchase price"
          name="purchase_price"
          onChange={handleChange}
          required
        />
        <EntryFormDropdown
          value={inputValue.pharmacy_purchased}
          label="Pharmacy where product purchased"
          name="pharmacy_purchased"
          onChange={handleChange}
          required
          maxLength="50"
          selectData={pharmacyList}
          optionNameSelector="name"
          optionIdSelector="name"
          optionKeySelector="id"
        />
        {/* <EntryFormInput
          type="text"
          value={inputValue.pharmacy_purchased}
          label="Pharmacy where product purchased"
          name="pharmacy_purchased"
          onChange={handleChange}
          required
        /> */}
        <EntryFormInput
          type="text"
          value={inputValue.receipt_number}
          label="Receipt Number"
          name="receipt_number"
          onChange={handleChange}
          required
          maxLength="20"
        />
        <EntryFormInput
          type="text"
          value={inputValue.address}
          label="Residential Address"
          name="address"
          onChange={handleChange}
          required
          maxLength="50"
        />
        <EntryFormDropdown
          value={inputValue.state_id}
          label="State"
          name="state_id"
          onChange={handleChange}
          required
          maxLength="10"
          selectData={statesList}
          optionNameSelector="name"
          optionIdSelector="id"
          optionKeySelector="id"
        />
        <EntryFormDropdown
          value={inputValue.postcode}
          label="Postcode"
          name="postcode"
          onChange={handleChange}
          required
          maxLength="10"
          selectData={postalCodeList}
          optionNameSelector="postal"
          optionIdSelector="postal"
          optionKeySelector="id"
        />
        <EntryFormDropdown
          value={inputValue.suburb}
          label="Suburb"
          name="suburb"
          onChange={handleChange}
          required
          maxLength="50"
          selectData={cityList}
          optionNameSelector="city"
          optionIdSelector="city"
          optionKeySelector="id"
        />
        <EntryFormLabel
          label="EFT details (processed within 10 working days of claim receipt):"
          required
          className="mt-5 mb-4"
        />
        {/* <EntryFormBox
          type="radio"
          labelValues={refundMethods}
          value={inputValue.refund_methods_id}
          name="refund_methods_id"
          onChange={handleBoxChange}
          postLabelText=" "
          required
        /> */}
        {/* {inputValue.refund_methods_id === "2" && (
          <> */}
        <EntryFormInput
          type="number"
          value={inputValue.account_number}
          label="Account Number"
          name="account_number"
          onChange={handleChange}
          required
          maxLength="20"
        />
        <EntryFormInput
          type="number"
          value={inputValue.bsb}
          label="BSB"
          name="bsb"
          onChange={handleChange}
          required
          maxLength="8"
        />
        {/*  </>
        )} */}
        <EntryFormUpload
          type="file"
          // value={uploadInput.name}
          label="Upload Receipt"
          name="file"
          onChange={handleUploadChange}
          required
          postLabelText=" "
        />
        <EntryFormCheckBox
          type="checkbox"
          labelValues={[
            {
              label: "I have retained my receipt as proof of purchase",
              value: inputValue.is_proof_purchase,
              name: "is_proof_purchase",
              postLabelText: ".",
              required: true,
              showRequiredSymbol: true,
            },
            {
              label: `I have read and accept the promotions <a href='/cashback-tac' class='text-hyperlink' target='_parent'>Terms and Conditions</a> and I have read the <a class='text-hyperlink' href='javascript:void(0)' onClick='window.parent.document.getElementById("collection-notice").removeAttribute("hidden");'>Collection Notice</a> before providing my personal information and agreed to its terms.`,
              value: inputValue.is_term,
              name: "is_term",
              postLabelText: ".",
              required: true,
              showRequiredSymbol: true,
            },
            {
              label:
                "I would like to hear about future promotions and offers from Bayer Australia Ltd",
              value: inputValue.is_future_promotions,
              name: "is_future_promotions",
              postLabelText: ".",
              required: false,
              showRequiredSymbol: false,
            },
          ]}
          onChange={handleCheckBoxChange}
          postLabelText="."
          required
          showRequiredSymbol
        />
        <div className="mt-5">
          {/* <ReCAPTCHA
            ref={recaptchaRef}
            sitekey={Constants.CAPTCHA_KEY}
            onChange={handleCaptchaChange}
          /> */}
          {/*  <GoogleReCaptchaProvider reCaptchaKey={Constants.CAPTCHA_KEY}>
            <GoogleReCaptcha onVerify={handleCaptchaChange} />
          </GoogleReCaptchaProvider> */}
          {/* <GoogleReCaptcha onVerify={handleCaptchaChange} /> */}
        </div>
        <div className="pt-5 pb-5">
          <Button
            variant="success"
            type="submit"
            className="entry-submit "
            disabled={isSubmitClicked}
          >
            {isSubmitClicked ? "PLEASE WAIT..." : "SUBMIT"}
          </Button>
          {submitErrorMsg && (
            <div className="entry-error-msg mt-2">{submitErrorMsg}</div>
          )}
        </div>
      </Form>
    </div>
  );
}

export default EntryFormComponent;
