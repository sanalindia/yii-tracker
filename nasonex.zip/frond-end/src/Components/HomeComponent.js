import React, { useEffect, useLayoutEffect, useState } from "react";
import EntryFormComponent from "./EntryFormComponent";
import "./../Css/HomeComponent.scss";
import { withResizeDetector } from "react-resize-detector";
import Cases from "../Utils/Cases";
import Constants from "../Utils/Constants";
import Utils from "../Utils/Utils";
import momentTz from "moment-timezone";
import moment from "moment";
import { GoogleReCaptchaProvider } from "react-google-recaptcha-v3";

function HomeComponent({ height, promoWrapperHeight }) {
  const [promoDate, setPromoDate] = useState({ open_at: "", close_at: "" });

  useLayoutEffect(() => {
    setTimeout(() => {
      let wrapperHeight = promoWrapperHeight;
      if (window.parent.document.getElementById("iFrameResizer0")) {
        if (!wrapperHeight && document.getElementById("promoMainWrapper")) {
          wrapperHeight =
            document.getElementById("promoMainWrapper").offsetHeight;
        }
        if (wrapperHeight) {
          window.parent.document.getElementById("iFrameResizer0").height =
            wrapperHeight;
        }
        window.parent.document.getElementById(
          "iFrameResizer0"
        ).style.verticalAlign = "middle";
      }
    }, 3000);
  }, [height, promoWrapperHeight]);
  const promotionClosed = () => {
    Utils.showElement("#block-promotionclosed");
    Utils.hideElement("#block-cashbackpromotionscheme");
  };
  useEffect(() => {
    Cases.getPromotion(Constants.PROMOTION_ID)
      .then((response) => {
        console.log("Promotion:", response);
        if (response && response.length > 0) {
          let promotionList = response.filter((data) => {
            let min = moment.utc(Utils.getFormattedDate(data.open_at));
            let max = moment.utc(Utils.getFormattedDate(data.close_at));
            return (
              /*Utils.isDateBetween(Utils.getCurrentDate(), min, max) && */
              data.status === 1
            );
          });
          console.log("isBetween:", promotionList);
          if (promotionList && promotionList.length > 0) {
            setPromoDate({
              open_at: promotionList[0].open_at,
              close_at: promotionList[0].close_at,
              open_tm: promotionList[0].open_tm,
              close_tm: promotionList[0].close_tm,
            });
            Utils.hideElement("#block-promotionclosed");
            Utils.showElement("#block-cashbackpromotionscheme");
          } else {
            promotionClosed();
          }
        } else {
          promotionClosed();
        }
      })
      .catch((error) => {
        promotionClosed();
      });
  }, []);
  useEffect(() => {
    if (promoDate && promoDate.open_at && promoDate.close_at) {
      // purchase
      /* let purchase_start_date = Utils.getDateFromString(promoDate.open_at);
      let purchase_end_date = Utils.getDateFromString(promoDate.close_at);
      let purchase_start_time = Utils.getTimeFromString(promoDate.open_at);
      let purchase_end_time = Utils.getTimeFromString(promoDate.close_at); */

      // claim
      let claim_start_date = Utils.getDateFromString(promoDate.open_at);
      let claim_end_date = Utils.getDateFromString(promoDate.close_at);
      let claim_start_time = Utils.getTimeFromString(promoDate.open_at);
      let claim_end_time = Utils.getTimeFromString(promoDate.close_at);
      let open_timezone = promoDate.open_tm ? ` ${promoDate.open_tm}` : "";
      let close_timezone = promoDate.close_tm ? ` ${promoDate.close_tm}` : "";
      let separator = " at ";

      console.log("Date:", claim_start_date, claim_end_date);
      // let purchase_start_time_date_zone = `${purchase_start_time} ${purchase_start_date}${open_timezone}`;
      // let purchase_end_time_date_zone = `${purchase_end_time} ${purchase_end_date}${close_timezone}`;
      let claim_close_time_date_zone = `${claim_end_date} ${claim_end_time}${close_timezone}`;
      // let purchase_start_date_at_time_zone = `${purchase_start_date} ${separator} ${purchase_start_time}${open_timezone}`;
      // let purchase_end_date_at_time_zone = `${purchase_end_date} ${separator} ${purchase_end_time}${close_timezone}`;
      let claim_start_date_at_time_zone = `${claim_start_date} ${separator} ${claim_start_time}${open_timezone}`;
      let claim_end_date_at_time_zone = `${claim_end_date} ${separator} ${claim_end_time}${close_timezone}`;

      Utils.changeElementText(
        "span#claim-close-time_date_zone",
        claim_close_time_date_zone
      );
      Utils.changeElementText(
        "span#claim-start-date_time_zone",
        claim_start_date_at_time_zone
      );
      Utils.changeElementText(
        "span#claim-end-date_time_zone",
        claim_end_date_at_time_zone
      );
      /*  Utils.changeElementText("span#purchase-start-date", purchase_start_date);
      Utils.changeElementText("span#purchase-end-date", purchase_end_date);
      Utils.changeElementText(
        "span#purchase-start-time_date_zone",
        purchase_start_time_date_zone
      );
      Utils.changeElementText(
        "span#purchase-end-time_date_zone",
        purchase_end_time_date_zone
      );
      
      Utils.changeElementText(
        "span#purchase-start-date_time_zone",
        purchase_start_date_at_time_zone
      );
      Utils.changeElementText(
        "span#purchase-end-date_time_zone",
        purchase_end_date_at_time_zone
      );
      */
    }
  }, [promoDate]);
  return (
    <div className="entryHomeTabsContainer">
      <GoogleReCaptchaProvider reCaptchaKey={Constants.CAPTCHA_KEY}>
        <EntryFormComponent />
      </GoogleReCaptchaProvider>
    </div>
  );
}

export default withResizeDetector(HomeComponent);
