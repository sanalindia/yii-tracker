import axios from "axios";

const baseURL = "https://www.services.bayer.us";

const apiClient = axios.create({ baseURL });

const { get, post, put, delete: destroy } = apiClient;

export { get, post, put, destroy };
 