import axios from "axios";

const baseURL = window.location.origin;

const apiClient = axios.create({ baseURL });

apiClient.interceptors.request.use(
  (request) => {
    /* if (!request.url.includes("auth/login")) {
      request.headers["x-deco-auth"] = JSON.parse(
        localStorage.getItem("currentUser")
      ).token;
    } */
    return request;
  },
  (error) => {
    console.log("Interceptor Request Error: ", error);
    return Promise.reject(error);
  }
);
apiClient.interceptors.response.use(
  (response) => {
    console.log("header", response);
    return response;
  },
  (error) => {
    console.log("Interceptor Response Error: ", error);
    // const dispatch = useAuthDispatch();
    // logout(dispatch);
    return Promise.reject(error);
  }
);
const { get, post, put, delete: destroy } = apiClient;

export { get, post, put, destroy };
