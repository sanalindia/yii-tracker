import { get, post } from "./Config";
import Constants from "./Constants";
import MockData from "./MockData";
import Utils from "./Utils";

export default {
  getPromotion: async (promoId) => {
    if (Constants.mockRequired) return MockData.promotions;
    const response = await get(
      `${Constants.domain}/promotion/${promoId}/settings`
    );
    return response.data;
  },
  getRefundMethods: async () => {
    if (Constants.mockRequired) return MockData.refundMethods;
    const response = await get(Constants.domain + "/refundmethods/list");
    return response.data;
  },
  getReasons: async () => {
    // if (Constants.mockRequired)
    return MockData.reasonsForClaim;
    // const response = await get(Constants.domain + "/state/list");
    // return response.data;
  },
  getPharmacys: async () => {
    // if (Constants.mockRequired)
    return MockData.pharmacyList;
    // const response = await get(Constants.domain + "/state/list");
    // return response.data;
  },

  getStates: async () => {
    if (Constants.mockRequired) return MockData.states;
    const response = await get(Constants.domain + "/state/list");
    return response.data;
  },
  getPostalCodeAndCity: async (stateId) => {
    if (Constants.mockRequired)
      return MockData.postalCodeList.filter(
        (data) => `${data.state_id}` === stateId
      );
    const response = await get(`${Constants.domain}/state/${stateId}/details`);
    return response.data;
  },
  submitPromotion: async (requestOption) => {
    const reqData = Utils.urlEncodedRequest(requestOption);
    const response = await post(
      Constants.domain + "/promotion/submit",
      reqData
    );
    return response.data;
  },
  uploadReceipt: async (requestOption, isFormData = false) => {
    console.log("requestOption", requestOption);
    const reqData = Utils.urlEncodedRequest(requestOption, isFormData);
    const response = await post(Constants.sfmcApi + "/upload", reqData);
    return response.data;
  },
  verifyCaptcha: async (token) => {
    const reqData = new URLSearchParams();
    reqData.append("g_recaptcha_response", token);
    const response = await post(
      Constants.domain + "/validate/gcaptcha",
      reqData
    );
    return response.data;
  },
};
