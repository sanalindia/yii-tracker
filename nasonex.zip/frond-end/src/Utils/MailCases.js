import { get, post } from "./MailConfig";
import Constants from "./Constants";

export default {
  recipientWrite: async (data) => {
    console.log("data list", data);
    // const params = `<recipient_stage xtkschema="byr:recipient_stage"
    // brand="Claratyne"
    // firstname="${data.firstname}"
    // lastname="${data.lastname}"
    // email="${data.email}"
    //  address1="${data.address1}"
    //  city="${data.city}"
    //  state="${data.state}"
    //  zip="${data.zip}"
    //  phone="${data.phone}"
    //  adobe_source="CLARATYNE_CASHBACK_WEB"
    //  orig_reg_date="${data.orig_reg_date}"
    //  country="${data.country}"
    //  last_mod_date="${data.last_mod_date}" />`;
    // console.log("MailCase: ", params);
    const params = [
      {
        keys: {
          Email: data.email,
        },
        values: {
          Email: data.email,
          FirstName: data.firstname,
          LastName: data.lastname,
          Address: data.address1,
          City: data.city,
          State: data.state,
          Zip: data.zip,
          Country: "AU",
          Brand: "Nasonex",
          DateCreated: data.orig_reg_date,
          Source: "NASONEX_CASHBACK_WEB",
        },
      },
    ];

    // {
    //   ContactKey: data.email,
    //   EventDefinitionKey: "APIEvent-xxx",
    //   EstablishContactKey: true,
    //   Data: {
    //     Email: data.email,
    //     Brand: "Claratyne",
    //     Country: "AU",
    //     DateCreated: data.orig_reg_date,
    //     FirstName: data.firstname,
    //     LastName: data.lastname,
    //     Address: data.address1,
    //     City: data.city,
    //     State: data.state,
    //     Zip: data.zip,
    //   },
    // };
    const config = {
      headers: { "Content-Type": "application/json" },
    };

    const response = await post(
      // "https://www.nasonexallergy.com.au/nasonex_cashback",
      Constants.sfmcApi + "/nasonex_cashback",
      params,
      config
    );
    // const response = await post(`/adobe/api/post`, params, config);
    return response;
  },
  optWrite: async (data) => {
    const params = `<opt_stage xtkschema="byr:opt_stage" brand="Claratyne" email="${data.email}" opt_status="${data.opt_status}" opt_name="Consumer Health Australia" opt_date="${data.opt_date}" adobe_source="CLARATYNE_CASHBACK_WEB" />`;
    const config = {
      headers: { "Content-Type": "application/xml" },
    };
    const response = await post(`/adobe/api/post`, params, config);
    return response;
  },
};
