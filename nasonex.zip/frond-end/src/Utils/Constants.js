var APIURL = window.location.origin + "/nasonexaudev/?ep_url=/front";
var SFMCAPIURL = window.location.origin;
//https://www.claratyne.com.au/cashback
if (window.location.origin.indexOf("nasonexallergy.com.au") !== -1) {
  APIURL = window.location.origin + "/nasonexauprod/?ep_url=/front";
}
export default {
  mockRequired: false,
  PROMOTION_ID: 1,
  FILE_SIZE: 3000,
  FILE_SIZE_ERROR: "File size should be less than 3MB!",
  FILE_TYPE_ERROR: "File type not supported!",
  // CAPTCHA_KEY: "6Lce9s8aAAAAAEP5rv5kNj10qxdyaDtK3xBC3naP",
  CAPTCHA_KEY: "6LeVL90bAAAAAAU_1I_I2GhrjnNgVBNJsr3GMG9A",
  //domain: window.location.origin + "/claratyneaudev/?ep_url=/front",
  //domain_prod: window.location.origin + "/claratyneauprod/?ep_url=/front",
  domain: APIURL,
  sfmcApi: SFMCAPIURL,
};
