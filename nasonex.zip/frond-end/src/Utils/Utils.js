import $ from "jquery";
import moment from "moment";
export default {
  trimTextWithLength: (str, maxLength) => {
    return str && str.length > maxLength
      ? str.substring(0, Math.min(str.length, maxLength))
      : str;
  },
  hideSSPLoader: (timeout = 2000) => {
    setTimeout(() => {
      let element = $("#cashback-form-loader", window.parent.document);
      if (element) {
        element.css("display", "none");
      }
    }, timeout);
  },
  redirectPage: (redirectURL) => {
    window.parent.location.href = redirectURL;
  },
  getStringifiedDate: (date, isMax = false) => {
    let dd = String(date.getDate()).padStart(2, "0"),
      mm = String(date.getMonth() + 1).padStart(2, "0"),
      yyyy = date.getFullYear();
    let time = isMax ? "T23:59:00" : "T00:00:00";
    let stringDate = `${yyyy}-${mm}-${dd}${time}`;
    // console.log(stringDate);
    return stringDate;
  },
  getFormattedDate: (dateString) => {
    let splitted =
      dateString && dateString.includes("+")
        ? dateString.split("+")[0]
        : dateString;
    return dateString && dateString.includes("+")
      ? splitted + "+00:00"
      : splitted;
  },
  getCurrentDate: () => {
    let currentDate = new Date(),
      dd = String(currentDate.getDate()).padStart(2, "0"),
      mm = String(currentDate.getMonth() + 1).padStart(2, "0"),
      yyyy = currentDate.getFullYear(),
      hh = currentDate.getHours(),
      MM = currentDate.getMinutes();

    currentDate = `${yyyy}-${mm}-${dd}T${hh}:${MM}:00+00:00`;
    return currentDate;
    // return moment().toISOString();
    // return moment(new Date("2021-09-03T00:01:00"))
  },
  getCurrentDateString: () => {
    let currentDate = new Date(),
      dd = String(currentDate.getDate()).padStart(2, "0"),
      mm = String(currentDate.getMonth() + 1).padStart(2, "0"),
      yyyy = currentDate.getFullYear();
    // currentDate = `${yyyy}-${mm}-${dd}T00:00:00`;
    currentDate = `${mm}/${dd}/${yyyy}`;
    return currentDate;
  },
  isDateBetween: (date, min, max) => {
    console.log(date, max);
    return moment(date).isBetween(min, max);
  },
  getDateFromString: (dateString, format = "DD/MM/YY") => {
    return moment.utc(dateString).format(format);
  },
  getTimeFromString: (dateString, format = "hh:mm a") => {
    return moment.utc(dateString).format(format);
  },
  changeElementText: (selector, value, timeout = 0) => {
    setTimeout(() => {
      let elSelector = $(selector, window.parent.document);
      if (elSelector) {
        elSelector.map((index, element) => {
          if (element) {
            $(element).text(value);
          }
        });
      }
      /*  let element = $(selector, window.parent.document);
      if (element) {
        element.text(value);
      } */
    }, timeout);
  },
  hideElement: (selector, timeout = 0) => {
    setTimeout(() => {
      let element = $(selector, window.parent.document);
      if (element) {
        element.css("display", "none");
      }
    }, timeout);
  },
  showElement: (selector, timeout = 0) => {
    setTimeout(() => {
      let element = $(selector, window.parent.document);
      if (element) {
        element.css("display", "block");
      }
    }, timeout);
  },
  removeDuplicateItemByKey: (array, key) => {
    return array && array.length > 0
      ? array.reduce(
          (ac, a) => (ac.find((x) => x[key] === a[key]) ? [...ac] : [...ac, a]),
          []
        )
      : array;
  },
  urlEncodedRequest: (requestData, isFormData) => {
    const params = isFormData ? new FormData() : new URLSearchParams();
    Object.entries(requestData).map(([key, value]) =>
      params.append(key, value)
    );
    return params;
  },
  urlEncodedRequest1: (requestData, isFormData) => {
    // const params = isFormData ? new FormData() : new URLSearchParams();
    const params = new URLSearchParams();
    // params.append("type", "coupon_receipt");
    Object.entries(requestData).map(([key, value]) =>
      params.append(key, value)
    );
    return params;
  },
};
