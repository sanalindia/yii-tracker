import React, { useCallback } from "react";
import "./App.css";
import HomeComponent from "./Components/HomeComponent";
import { useResizeDetector } from "react-resize-detector/build/withPolyfill";

function App() {
  const onResize = useCallback(() => {
    console.log("OnResize: ", height);
  }, []);
  const { ref, width, height } = useResizeDetector({ onResize });
  return (
    <div className="App" ref={ref} id="promoMainWrapper">
      <HomeComponent promoWrapperHeight={height} />
    </div>
  );
}

export default App;
