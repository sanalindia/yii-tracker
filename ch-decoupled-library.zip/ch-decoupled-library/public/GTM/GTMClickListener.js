function gtmListener(config) {
  if (!(this instanceof gtmListener)) {
    return new gtmListener(config);
  }
  /**
   * Configuration options possible
   * {
   *  log: true,
   *  pageHasSelections: boolean, // indicate whether page has some selections to be made before user can navigate by click
   *  optionClass: 'common class name for option elements',
   *  selectedClass: 'class name found for selected option elements',
   *  ignoreEventClasses: ['class1', 'class2'], // use this an easy way to ignore some click events
   *  ignoreEventHook: function(event) { // use this fn to ignore some events by returning boolean false
   *    // some expressions
   *    return boolean;
   *  },
   *  getParentElementFromEvent: function(event, gl) { // gl is the instance of the gtmListener
   *    return <parent element from event>;
   *  },
   *  getGTMActionLabelFromEvent: function(event, gl) {
   *   return "eventActionLabel for GTM event"
   *  },
   *  getGTMActionFromEvent: function(event, gl) {
   *   return "eventAction for GTM event"
   *  },
   *  getTextContentFromEventSource: function(e, gl) {
   *  //logic to return text content of event source
   *  }
   * }
   */
  // declare default options
  var gl = this;
  gl.stepCount = 1;


  gl.init = function (config) {

    gl.config = config;
    gl.config.ignoreClasses = gl.config.ignoreClasses || [];
    if (gl.config.optionClass) {
      gl.config.ignoreClasses.push(gl.config.optionClass);
    }
    gl.registerEventListenrs();
  };

  gl.registerEventListenrs = function () {
    gl.log("2. GTM registerEventListenrs", gl.config);
    document.addEventListener("GTM-custom-event", function (event) {
      const gtmEventPayload = {
        eventAction: gl.getGTMActionFromEvent(event),
        eventActionLabel: gl.getGTMActionLabelFromEvent(event),
        eventLabel: gl.getGTMActionLabelFromEvent(event)
      };
      gl.pushGTMEvents(gtmEventPayload);
      console.log('GTM  addEventListener', gl.config.eventName)
    });

    document.addEventListener("click", function (event) {
      gl.log("2.1. GTM isEventFromReliableSource ", event);
      if (gl.isEventFromReliableSource(event)) {
        gl.log("3. GTM isEventFromReliableSource ", event);
        const gtmEventPayload = {
          eventAction: gl.getGTMActionFromEvent(event),
          eventActionLabel: gl.getGTMActionLabelFromEvent(event),
          eventLabel: gl.getGTMActionLabelFromEvent(event)
        };
        gl.pushGTMEvents(gtmEventPayload);
      }
    });
  };

  gl.getGTMActionFromEvent = function (e) {
    gl.log("4. GTM getGTMActionFromEvent");
    let action = "";
    if (typeof gl.config.getGTMActionFromEvent === "function") {
      action = gl.config.getGTMActionFromEvent(e, gl);
    }
    if (!action) {
      if (e.type === "GTM-custom-event") {
        action = `${gl.config.componentName} - Step ${gl.stepCount++} ${e.detail.action}`;
      } else {
        const element = e.target;
        const gtmAction = element.getAttribute("data-gtm-action");
        if (!!gtmAction) {
          return gtmAction;
        }
        const btnText = gl.getTextContentFromEventSource(e);

        if (gl.config.pageHasSelections) { // page has some selections to be made before user can navigate from the page
          gl.log("GTM -action pageHasSelections");
          action = `${gl.config.componentName} - Step ${gl.stepCount++} ${btnText}`;
        } else { // pa
          gl.log("GTM -action pageHasSelections NO");
          action = `${gl.config.componentName} - Step ${gl.stepCount++} Click`;
        }
      }
    }
    gl.log("4. GTM getGTMActionFromEvent action", action);
    return action;
  };

  gl.getGTMActionLabelFromEvent = function (e) {
    gl.log("5. GTM getGTMActionLabelFromEvent");
    let actionLabel = "";
    if (typeof gl.config.getGTMActionLabelFromEvent === "function") {
      actionLabel = gl.config.getGTMActionLabelFromEvent(e, gl);
    }
    if (!actionLabel) {
      if (e.type === "GTM-custom-event") {
        actionLabel = e.detail.actionLabel;
      } else {
        const btnText = gl.getTextContentFromEventSource(e);

        if (gl.config.pageHasSelections) {
          if (!gl.config.selectedClass) {
            throw new Error("Selected Class cannot be Empty when page has selections.");
          }
          const parentElement = gl.getParentElementFromEvent(e);
          gl.log(" 5. GTM parentElement", parentElement);
          const selectedOptions = parentElement.querySelectorAll(
            `.${gl.config.selectedClass}`
          );
          const labels = [];
          for (let i = 0; i < selectedOptions.length; i++) {
            labels.push(selectedOptions[i].getAttribute("data-gtm-label") || selectedOptions[i].textContent);
          }
          gl.log("5. GTM - selected options ", labels);
          actionLabel = labels.join();
        } else {
          gl.log("5. GTM -[Scenario - 1]");
          actionLabel = btnText; // this is when there is only one button on the page [Scenario - 1]
        }
      }
    }
    return actionLabel;
  };
  gl.getTextContentFromEventSource = function (event) {
    if (typeof gl.config.getTextContentFromEventSource === "function") {
      return gl.config.getTextContentFromEventSource(event, gl);
    }
    const element = event.target;
    const gtmActionLabel = element.getAttribute("data-gtm-label");
    if (!!gtmActionLabel) {
      return gtmActionLabel;
    }
    var eventLabel = "";
    if (gl.isButton(element) || gl.isAnchor(element)) {
      eventLabel = element.textContent;
      if (!eventLabel) {
        eventLabel = element.parentElement.textContent;
      }
    } else if (gl.isInputButton(element)) {
      eventLabel = element.value;
    } else if (gl.isCustomBtn(element)) {
      eventLabel = element.getAttribute("data-gtm-label") || element.textContent;
    }
    gl.log("6. GTM -getTextContentFromEventSource ", eventLabel);
    return eventLabel;
  };
  gl.log = function () { return gl.config.log ? console.log.apply(undefined, arguments) : function (msg) { } };
  gl.isButton = function (el) { return el.nodeName === "BUTTON"; };
  gl.isInputButton = function (el) { return (el.nodeName === "INPUT" && (el.type === "button" || el.type === "submit")) };
  gl.isAnchor = function (el) { return el.nodeName === "A" || el.closest("a ") };
  gl.isCustomBtn = function (elem) { return elem.classList.contains("gtm-btn") };
  gl.isElemVisible = function (e) { return (e.offsetWidth > 0 || e.offsetHeight > 0 || e.getClientRects().length > 0) };
  gl.getParentElementFromEvent = function (event) {
    return typeof gl.config.getParentElementFromEvent === "function"
      ? gl.config.getParentElementFromEvent(event, gl)
      : document;
  };
  gl.canEventBeIgnored = function (event) {
    var retFlag = false;
    if (typeof gl.config.ignoreEventHook === "function") {
      retFlag = gl.config.ignoreEventHook(event);
    } else if (gl.config.ignoreClasses && gl.config.ignoreClasses.length) {
      retFlag = gl.config.ignoreClasses.some(cls => (event.target.classList.contains(cls) || event.target.closest(cls)));
      gl.log("GTM canEventBeIgnored", retFlag);
    }
    return !!retFlag;
  };
  gl.hasEvents = function (event) {
    var retFlag = false;
    if (typeof gl.config.includeEventHook === "function") {
      retFlag = gl.config.includeEventHook(event, gl);
    } else if (gl.config.includeClasses && gl.config.includeClasses.length) {
      retFlag = gl.config.includeClasses.some(cls => (event.target.classList.contains(cls) || event.target.closest(`.${gl.config.includeClasses}`)));
      gl.log("GTM hasEvents", retFlag);
    }
    return !!retFlag;
  };
  gl.isEventFromReliableSource = function (event) {
    const evt = event.target;
    gl.log('GTM isEventFromReliableSource hasEvents', (gl.hasEvents(event)))
    gl.log('GTM isEventFromReliableSource n', (gl.isButton(evt) || gl.isAnchor(evt) || gl.isInputButton(evt) || gl.isCustomBtn(evt) || (gl.hasEvents(event))))
    gl.log('GTM canEventBeIgnored ', gl.canEventBeIgnored(event))

    return ((gl.isButton(evt) || gl.isAnchor(evt) || gl.isInputButton(evt) || gl.isCustomBtn(evt) || (gl.hasEvents(event)))
      && (!gl.canEventBeIgnored(event)));
  };
  gl.pushGTMEvents = function (payload) {
    parent.window.dataLayer = parent.window.dataLayer || [];
    parent.window.dataLayer.push({
      event: "gaGenericEvent",
      eventCategory: gl.config.eventCategory
        ? gl.config.eventCategory
        : "CTA",
      ...payload,
    });
    gl.log("GTM datalayer", parent.window.dataLayer);
  };

  gl.init(config);
  return gl;
}