import React from 'react';
import { Row, Col } from 'react-bootstrap';
import DropDown from '../../elements/dropDown/dropDown';
import { useNavigate, useSearchParams } from 'react-router-dom';
import "./filterBar.css";
import { filterDecouple, getDropdownData } from '../../helpers/filterHelper';

const Category_Key = 'Category';
const Country_Key = 'Country';
const Language_Key = 'Language';
const Brand_Key = 'Brands';
const Sort_Key = 'Sort';

const Category_Placeholder = 'Component Category';
const Country_Placeholder = 'Countries Available';
const Language_Placeholder = 'Languages Available';
const Brand_Placeholder = 'Brand';
const Sort_Placeholder = 'Sort';

export default function FilterBar({ decoupleList }) {
  let navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const filterData = (type, value) => {
    const queryParams = Object.fromEntries([...searchParams]);
    const queryString = filterDecouple(type, value, queryParams);
    navigate(queryString);
  }

  const categoryData = getDropdownData(decoupleList, Category_Key);
  const countryData = getDropdownData(decoupleList, Country_Key);
  const languageData = getDropdownData(decoupleList, Language_Key);
  const brandData = getDropdownData(decoupleList, Brand_Key);
  const sortData = [
    { id: 0, title: 'A-Z' },
    { id: 1, title: 'Z-A' },
  ];

  return (
    <Row>
      <Col xs={12} sm={10} md={10} lg={10}>
        <Row>
          <Col xs={12} sm={6} md={6} lg={3}>
            <DropDown
              itemData={categoryData}
              placeHolder={Category_Placeholder}
              itemKey={Category_Key}
              filterData={filterData}
            />
          </Col>
          <Col xs={12} sm={6} md={6} lg={3}>
            <DropDown
              itemData={countryData}
              placeHolder={Country_Placeholder}
              itemKey={Country_Key}
              filterData={filterData}
            />
          </Col>
          <Col xs={12} sm={6} md={6} lg={3}>
            <DropDown
              itemData={languageData}
              placeHolder={Language_Placeholder}
              itemKey={Language_Key}
              filterData={filterData}
            />
          </Col>
          <Col xs={12} sm={6} md={6} lg={3}>
            <DropDown

              itemData={brandData}
              placeHolder={Brand_Placeholder}
              itemKey={Brand_Key}
              filterData={filterData}
            />
          </Col>
        </Row>
      </Col>
      <Col xs={12} sm={2} md={2} lg={2}>
        <DropDown
          itemData={sortData}
          placeHolder={Sort_Placeholder}
          itemKey={Sort_Key}
          filterData={filterData}
        />
      </Col>
    </Row>
  );
}
