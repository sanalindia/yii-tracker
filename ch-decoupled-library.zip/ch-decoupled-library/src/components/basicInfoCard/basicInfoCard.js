import React from "react";
import { Col, Row } from "react-bootstrap";
import { Lightbulb } from "react-bootstrap-icons";
import { Link } from "react-router-dom";
import decoupledLibrary from "../../assets/data/decoupledLibrary.json";
import './basicInfoCard.css';

export default function BasicInfoCard({ decoupleId }) {
  const Language_Title = 'Available Languages';
  const Country_Title = 'Available Countries';

  const decoupled = decoupledLibrary.find(item => String(item?.Id) === String(decoupleId));

  const getLanguageCountryList = (type) => {
    const filterType = type === 'language' ? 'Language' : type === 'country' ? 'Country' : '';
    const decoupledList = decoupledLibrary.filter(item => String(item?.Group_Code) === String(decoupled?.Group_Code));
    const itemList = [];
    decoupledList.forEach((item) => {
      const splitted = item[filterType].split(',');
      splitted.forEach((lang) => {
        const trimmed = lang.trim();
        const capitalize = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        if (capitalize !== ',' && capitalize !== /\s/ && capitalize !== '') {
          if (type === 'language') {
            itemList.push({ Id: item.Id, Language: capitalize, Country: item.Country });
          } else if (type === 'country') {
            itemList.push({ Id: item.Id, Language: item.Language, Country: capitalize });
          }
        }
      });
    });
    itemList.forEach((item, index) => {
      itemList.forEach((ele, i) => {
        if (item[filterType] === ele[filterType] && index !== i) {
          if (type === 'language') {
            item.isMultipleLanguages = true;
          } else if (type === 'country') {
            item.isMultipleCountries = true;
          }
        }
      });
    });
    return itemList;
  }

  const languageList = getLanguageCountryList('language');
  const countryList = getLanguageCountryList('country');

  const decoupleDetails = [{
    title: 'Title',
    value: decoupled?.Name,
    isURL: false,
    isLink: false
  },
  {
    title: 'Usage',
    value: decoupled?.Description,
    isURL: false,
    isLink: false
  },
  {
    title: 'Category',
    value: decoupled?.Category,
    isURL: false,
    isLink: false
  },
  {
    title: Country_Title,
    value: countryList,
    isURL: false,
    isLink: true
  },
  {
    title: Language_Title,
    value: languageList,
    isURL: false,
    isLink: true
  },
  {
    title: 'Brands using',
    value: decoupled?.Brands,
    isURL: false,
    isLink: false
  },
  {
    title: 'Site URL',
    value: decoupled?.Site_path,
    isURL: true,
    isLink: false
  },
  {
    title: 'Prod Deco URL',
    value: decoupled?.Deco_Path,
    isURL: true,
    isLink: false
  },
  {
    title: 'Gitlab',
    value: decoupled?.Git_Path,
    isURL: true,
    isLink: false
  },
  {
    title: 'Technologies',
    value: decoupled?.Technologies_Used,
    isURL: false,
    isLink: false
  },
  {
    title: 'Microservices Involved?',
    value: decoupled?.MSH,
    isURL: false,
    isLink: false
  },
  {
    title: 'Customizable(?)',
    value: decoupled?.Customize,
    isURL: false,
    isLink: false
  },
  {
    title: 'How to Customize',
    value: decoupled?.Customize_Description,
    isURL: false,
    isLink: false
  },
  {
    title: 'Localizable(?)',
    value: decoupled?.Localize,
    isURL: false,
    isLink: false
  },
  {
    title: 'How to Localize',
    value: decoupled?.Localize_Description,
    isURL: false,
    isLink: false
  }
  ];

  const generateDecoupleDetailsURL = (ele) => {
    let urlString = '';
    urlString = `/Details/${ele?.Id}`;
    return urlString;
  }

  const renderLanguageCountryList = (list, type) => {
    const listType = type === Language_Title ? 'language' : type === Country_Title ? 'country' : '';
    return (
      <>
        {list.map((ele, i) => (
          <Link to={generateDecoupleDetailsURL(ele)} className="languageText" key={i}>
            {listType === 'language' ? ele?.isMultipleLanguages ? `${ele?.Language} (${ele?.Country}), ` : `${ele?.Language}, ` : listType === 'country' ? ele?.isMultipleCountries ? `${ele?.Country} (${ele?.Language}), ` : `${ele?.Country}, ` : ''}
          </Link>
        ))}
      </>
    );
  }

  const renderInfoText = (type) => {
    const listType = type === Language_Title ? 'Language' : type === Country_Title ? 'Country' : '';
    return (
      <div className="d-flex mt-2">
        <div className="pe-1">
          <Lightbulb size={18} />
        </div>
        <div className="mt-1">
          <p className="text-muted">
            {`Click on any ${listType} to view corresponding decouple details`}
          </p>
        </div>
      </div>
    );
  }

  return (
    <Row>
      <Col xs={12} md={5}>
        <img
          src={decoupled.Image_URL ? `${decoupled.Image_URL}` : "https://via.placeholder.com/150"}
          width="100%"
          alt="decouple img"
        />
      </Col>
      <Col xs={12} md={7}>
        <table className="table tableStyle" id="tableview" >
          <tbody>
            {decoupleDetails.map((data, index) => (
              <tr key={index}>
                <th scope="row">{data.title}</th>
                <td>
                  {
                    data.isURL ?
                      <a target="_blank" rel="noreferrer" href={data.value}>
                        {data.value}
                      </a>
                      : Array.isArray(data.value) ?
                        renderLanguageCountryList(data.value, data.title)
                        : data.value
                  }
                  {
                    data.isLink ?
                      renderInfoText(data.title)
                      : null
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Col>
    </Row>
  );
}
