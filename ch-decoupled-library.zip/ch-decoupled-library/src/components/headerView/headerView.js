import React from 'react';
import { Col, Row } from "react-bootstrap";
// import { useNavigate, useSearchParams } from 'react-router-dom';
import appLogo from '../../assets/images/logo.png';
import bayerLogo from '../../assets/images/bayer-logo.png';
import "./headerView.css";
// import { filterDecouple, getDropdownData } from '../../helpers/filterHelper';
// import HeaderDropdown from '../../elements/headerDropdown/headerDropdown';
// import { IconButton, TextField } from '@mui/material';
// import SearchIcon from '@mui/icons-material/Search';
// import { Clear } from '@mui/icons-material';

// const Category_Key = 'Category';
// const Language_Key = 'Language';
// const Name_Key = 'Name';

// const Category_Placeholder = 'Component Category';
// const Language_Placeholder = 'Languages Available';

export default function HeaderView() {
  // let navigate = useNavigate();
  // const [searchParams] = useSearchParams();

  // const [searchText, setSearchText] = useState('');
  // const [isSearch, setSearchStatus] = useState(false);

  // let categoryData = [];
  // let languageData = [];

  // if (isFromDetailsPage !== "true") {
  //   categoryData = getDropdownData(decoupleList, Category_Key);
  //   languageData = getDropdownData(decoupleList, Language_Key);
  // }

  // const filterData = (type, value) => {
  //   const queryParams = Object.fromEntries([...searchParams]);
  //   const queryString = filterDecouple(type, value, queryParams);
  //   navigate(queryString);
  // }

  // const searchIconTapped = () => {
  //   setSearchStatus(true);
  //   const queryParams = Object.fromEntries([...searchParams]);
  //   const queryString = filterDecouple(Name_Key, searchText, queryParams);
  //   navigate(queryString);
  // }

  // const clearIconTapped = () => {
  //   setSearchText('');
  //   setSearchStatus(false);
  //   const queryParams = Object.fromEntries([...searchParams]);
  //   const queryString = filterDecouple(Name_Key, '', queryParams);
  //   navigate(queryString);
  // }

  return (
    <>
      <Row>
        <Col xs={8} sm={8} md={6} lg={6} className="d-flex align-items-center">
          <img
            className='appLogo'
            src={appLogo}
            alt=""
          />
        </Col>
        {/* <Col xs={12} sm={6} md={6} lg={8}>
          <Row>
            <Col xs={12} lg={6} className="mt-1">
              {isFromDetailsPage !== "true" ?
                (
                  <Row>
                    <Col xs={12} sm={12} md={6} lg={6}>
                      <HeaderDropdown
                        placeholder={Category_Placeholder}
                        data={categoryData}
                        filterData={filterData}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={6} lg={6}>
                      <HeaderDropdown
                        placeholder={Language_Placeholder}
                        data={languageData}
                        filterData={filterData}
                      />
                    </Col>
                  </Row>
                )
                : null
              }
            </Col>
            <Col xs={12} sm={12} md={12} lg={6} className="d-flex align-items-center justify-content-end mt-3">
              {isFromDetailsPage !== "true" ?
                (
                  <>
                    {isSearch ? (
                      <TextField
                        id="standard-basic"
                        label=""
                        variant="standard"
                        placeholder='Search with title'
                        value={searchText}
                        onChange={(ele) => setSearchText(ele.target.value)}
                        fullWidth
                      />
                    )
                      : null
                    }
                    {searchText !== '' ? (
                      <IconButton
                        size='small'
                        onClick={clearIconTapped}
                      >
                        <Clear fontSize='10px' />
                      </IconButton>
                    )
                      : null}
                    <IconButton
                      onClick={searchIconTapped}
                    >
                      <SearchIcon />
                    </IconButton>
                  </>
                )
                : null
              }
            </Col>
          </Row>
        </Col> */}
        <Col xs={4} sm={4} md={6} lg={6} className="d-flex align-items-center justify-content-end">
          <img
            src={bayerLogo}
            alt=""
          />
        </Col>
      </Row>
      <Row>
        <Col xs={12}>
          <hr className='solid dividerStyle'
          ></hr>
        </Col>
      </Row>
    </>
  );
}