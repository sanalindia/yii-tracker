import React from "react";
import { Badge } from "react-bootstrap";
import { ArrowRight } from "react-bootstrap-icons";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { Link } from "react-router-dom";
import './decoupleList.css';

export default function DecoupleList({ decoupled }) {
  return (
    <>
      <Grid container >
        <Grid item className="main-decouple-list my-3 " xs={12} sm={12} md={12} lg={12}>
          <Card >
            <CardContent >
              <Grid container  spacing={3} >
                <Grid item container md={3}>
                    <CardMedia
                      component="img"
                      height="150"
                      image={
                        decoupled.Image_URL
                          ? `${decoupled.Image_URL}`
                          : "https://via.placeholder.com/150"
                      }
                      alt="Image Missing"
                    />
                 
                </Grid>
                <Grid item md={9} className="action-area">
                    <Badge className="mb-2" bg="primary">
                      {decoupled?.Category}
                    </Badge>
                    <Typography
                      gutterBottom
                      variant="h5"
                      component="div"
                      className="text-left titleText"
                    >
                      <span title={decoupled.Name}>{decoupled.Name}</span>
                    </Typography>
                    <Typography
                      className="my-2 text-left desc-text-list"
                      variant="body2"
                      color="text.secondary"
                    >
                      <span title={decoupled.Description}>
                        {decoupled?.Description}
                      </span>
                    </Typography>
                    <CardActions className="d-flex px-3 py-0 justify-content-end">
                      <Link to={`/Details/${decoupled.Id}`}>
                        <ArrowRight size={30} />
                      </Link>
                    </CardActions>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
     
    </>
  );
}
