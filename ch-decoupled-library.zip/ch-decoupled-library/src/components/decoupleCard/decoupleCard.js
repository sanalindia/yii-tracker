import React from "react";
import { Badge } from "react-bootstrap";
import { ArrowRight } from "react-bootstrap-icons";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
// import Badge from "@mui/material/Badge";
import "./decoupleCard.css";
import { Link } from "react-router-dom";

export default function DecoupleCard({ decoupled }) {
  return (
    <>
      <Grid item xs={12}>
        <Card className="my-3 px-3 pt-3 main-decouple-card h-95 ">
          <Badge className="mb-2" bg="primary">
            {decoupled?.Category}
          </Badge>
          <CardMedia
            component="img"
            height="200"
            image={
              decoupled.Image_URL
                ? `${decoupled.Image_URL}`
                : "https://via.placeholder.com/150"
            }
            alt="Image Missing"
          />
          <CardContent className="pb-0">
            <Typography
              gutterBottom
              variant="h5"
              component="div"
              className="text-center title-text"
            >
              <span title={decoupled.Name}>{decoupled.Name}</span>
            </Typography>
            <Typography
              className="my-2 text-left desc-text"
              variant="body2"
              color="text.secondary"
            >
              <span title={decoupled.Description}>
                {decoupled?.Description}
              </span>
            </Typography>
          </CardContent>
          <CardActions className="d-flex justify-content-end">
            <Link to={`/Details/${decoupled.Id}`}>
              <ArrowRight size={30} />
            </Link>
          </CardActions>
        </Card>
      </Grid>
    </>
  );
}

// <Col>
//   <Card className="my-3">
//     <Card.Body>
//       <Badge className="mb-2" bg="primary">
//         {decoupled.Category}
//       </Badge>
//       <Card.Img src={decoupled.Image_URL ? `${decoupled.Image_URL}` : "https://via.placeholder.com/150"} />
//       <Card.Title className="my-2 text-center">
//         {decoupled.Name}
//       </Card.Title>
//       <Card.Text>
//       {decoupled.Description ? `${decoupled.Description}` : `Some quick example text to build on the card title and make up the
//         bulk of the card's content.`}
//       </Card.Text>
//     </Card.Body>
//     <Card.Footer className="border-0 bg-white text-end">
//       <Link to={"/Details"}>
//         <ArrowRight size={40} />
//       </Link>
//     </Card.Footer>
//   </Card>
// </Col>
//   );
// }
