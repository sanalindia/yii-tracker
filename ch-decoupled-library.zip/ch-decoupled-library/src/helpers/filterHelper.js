const Category_Key = 'Category';
const Country_Key = 'Country';
const Language_Key = 'Language';
const Brand_Key = 'Brands';
const Sort_Key = 'Sort';
const Name_Key = 'Name';

const Category_Placeholder = 'Component Category';
const Country_Placeholder = 'Countries Available';
const Language_Placeholder = 'Languages Available';
const Brand_Placeholder = 'Brand';
const Sort_Placeholder = 'Sort';
const Name_Placeholder = 'Name';

export const getDropdownData = (list, key) => {
  const dataArray = [];
  list.forEach((ele) => {
    const item = ele[key];
    const trimmedItem =
      item.charAt(item.length - 1) === ',' ? item.slice(0, -1) : item;
    if (trimmedItem?.includes(',')) {
      const splittedValue = trimmedItem?.split(',');
      const filteredArray = splittedValue.filter(
        (value) => value !== ',' && value !== /\s/ && value !== ''
      );
      dataArray.push(...filteredArray);
    } else {
      dataArray.push(trimmedItem);
    }
  });
  const removeSpaces = dataArray.map((value) => value.trim());
  const capitalize = removeSpaces.map((value) => {
    const split = value.split(' ');
    const words = split.map((i) => {
      return i.charAt(0).toUpperCase() + i.slice(1);
    });
    return words.join(' ');
  });
  const removeDuplicate = [...new Set(capitalize)];
  const sortArray = removeDuplicate.sort();
  const formattedData = sortArray.map((value, index) => ({
    id: index,
    title: value,
  }));
  return formattedData;
};

export const filterDecouple = (type, value, queryParams) => {
  const key =
    type === Category_Placeholder
      ? Category_Key
      : type === Country_Placeholder
        ? Country_Key
        : type === Language_Placeholder
          ? Language_Key
          : type === Brand_Placeholder
            ? Brand_Key
            : type === Sort_Placeholder
              ? Sort_Key
              : type === Name_Placeholder
                ? Name_Key
              : '';
  const queryString = manageQueryString(key, value, queryParams);
  return queryString;
};

const manageQueryString = (key, value, queryParams) => {
  let queryString = '?';
  Object.keys(queryParams).forEach((ele) => {
    queryString =
      ele !== key ? queryString + `${ele}=${queryParams[ele]}&` : queryString;
  });
  if (value !== '') {
    queryString = queryString + `${key}=${value}&`;
  }
  return queryString;
};