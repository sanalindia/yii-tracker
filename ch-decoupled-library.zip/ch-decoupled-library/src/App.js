import { Routes, Route } from "react-router-dom";
import "./App.css";
import { Container } from "react-bootstrap";
import Home from "./pages/home";
import DetailView from "./pages/details";

function App() {
  return (
    <Container fluid={true}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/details/:id" element={<DetailView />} />
      </Routes>
    </Container>
  );
}

export default App;
