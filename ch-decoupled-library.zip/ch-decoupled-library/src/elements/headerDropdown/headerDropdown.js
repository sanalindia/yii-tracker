import React, { useState } from "react";
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import IconButton from "@mui/material/IconButton";
import { Close } from "@mui/icons-material";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

export default function HeaderDropdown({ placeholder, data, filterData }) {

    const [itemValue, setItemValue] = useState('');

    const handleChange = (event) => {
        setItemValue(event.target.value);
        filterData(placeholder, event.target.value);
    };

    const handleClearClick = () => {
        setItemValue('');
        filterData(placeholder, '');
    };

    return (
        <FormControl variant="standard" sx={{ minWidth: "95%", maxWidth: "95%" }}>
            <InputLabel id="demo-simple-select-standard-label">{placeholder}</InputLabel>

            <Select
                labelId="demo-simple-select-standard-label"
                id="demo-simple-select-standard"
                value={itemValue}
                onChange={handleChange}
                label={placeholder}
                IconComponent={() => (itemValue !== '' ?
                    <IconButton size="small" onClick={handleClearClick}><Close color="#D3D3D3" fontSize="10px" /></IconButton>
                    :
                    <ArrowDropDownIcon color="#D3D3D3" fontSize="10px" />
                )
                }
            >
                {data.map((ele, index) => (
                    <MenuItem key={`dropdown-${index}`} value={ele.title}>{ele.title}</MenuItem>
                ))}
            </Select>
        </FormControl>
    );

}