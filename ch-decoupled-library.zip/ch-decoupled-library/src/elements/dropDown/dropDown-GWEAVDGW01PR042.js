import React from 'react';
import { useSearchParams } from 'react-router-dom';
import {Autocomplete,TextField} from '@mui/material';

const DropDown = React.memo(
  ({ itemData, placeHolder, filterData, itemKey }) => {
    const [searchParams] = useSearchParams();
    const paramValue = searchParams.get([itemKey]) || '';

    const setDefaultValue = () => {
      const paramItem = paramValue.trim();
      const trimmedItem = paramItem.charAt(paramItem.length - 1) === ',' ? paramItem.slice(0, -1) : paramItem;
      const urlData = itemData.find(
          (ele) => String(ele?.title?.toLowerCase()) === String(trimmedItem?.toLowerCase())
        );
      return (urlData?.title ? urlData : '');
    }

    const onDataSelected = (title) => {
      filterData(placeHolder, title);
    };

    const onChangeText = (text,e) => {
      const itemValue = text?.title || '';
      onDataSelected(itemValue);
    };
   console.log('itemData',itemData)
    return (
      <Autocomplete
      disablePortal
      id={itemKey}
      // defaultValue={() => setDefaultValue()}
      options={itemData}
      // sx={{ width: 300 }}
      getOptionLabel={(option) => {
        return option.title || '';
      }}
     onChange={(event, newValue) => {
      onChangeText(newValue);
    }}
      renderInput={(params) => (
        <TextField {...params} label={placeHolder} />
      )}
      isOptionEqualToValue={(option, optionVal) => option.value === optionVal.value}
    />
    );
  }
);

export default DropDown;
