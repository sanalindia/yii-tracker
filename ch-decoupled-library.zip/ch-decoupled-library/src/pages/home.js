import React, { useCallback, useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import DecoupleList from "../components/decoupleList/decoupleList";
import decoupledLibrary from "../assets/data/decoupledLibrary.json";
import FilterBar from "../components/filterBar/filterBar";
import { useSearchParams } from "react-router-dom";
import GridViewIcon from "@mui/icons-material/GridView";
import ViewListIcon from "@mui/icons-material/ViewList";
import DecoupleCard from "../components/decoupleCard/decoupleCard";
import IconButton from "@mui/material/IconButton";
import "./page.css";
import HeaderView from "../components/headerView/headerView";

var _ = require("lodash");

const Home = () => {
  const [searchParams] = useSearchParams();

  const Sort_Key = "Sort";

  const [decoupleList, setDecoupleList] = useState(decoupledLibrary);

  const [viewMode, setViewMode] = useState("GRID");
  const filterDecouples = useCallback((search) => {
    const queryParams = Object.fromEntries([...search]);

    let sort = "";
    if (search.has([Sort_Key])) {
      sort = search.get([Sort_Key]);
      delete queryParams.Sort;
    }
    const filteredList = filterDecoupleData(queryParams);
    let sortedList = [...filteredList];

    // if (Object.keys(queryParams)?.length === 0) {
    sortedList = [...getDecoupleList(sortedList)];
    // }

    if (sort !== "" && sortedList.length > 0) {
      const sortOrder = sort === "Z-A" ? "desc" : "asc";
      sortedList = [..._.orderBy(sortedList, "Name", sortOrder)];
    }

    setDecoupleList(sortedList);
  }, []);

  const filterDecoupleData = (queryParams) => {
    let filterArray = [...decoupledLibrary];
    Object.keys(queryParams).forEach((key) => {
      const dataArray = [];
      const value = queryParams[key];
      const splittedValue = value?.split(",");
      filterArray.forEach((ele) => {
        const item = ele[key];
        const splittedItem = item?.split(",");
        splittedValue.forEach((val) => {
          const index = splittedItem.findIndex((element) => {
            return element.trim().toLowerCase().includes(val.trim().toLowerCase());
          });

          if (index !== -1) {
            dataArray.push(ele);
          }
        });
      });
      filterArray = [...new Set(dataArray)];
    });
    return filterArray;
  };

  const getDecoupleList = (list) => {
    const groupList = list.reduce((r, a) => {
      r[a.Group_Code] = r[a.Group_Code] || [];
      r[a.Group_Code].push(a);
      return r;
    }, {});

    const filteredList = [];
    Object.keys(groupList).forEach((key) => {
      filteredList.push(groupList[key][0]);
    });

    return filteredList;
  };

  useEffect(() => {
    filterDecouples(searchParams);
  }, [searchParams, filterDecouples]);

  useEffect(() => {
    if (window.parent.document.getElementsByTagName("header").length > 0) {
      window.parent.document.getElementsByTagName("header")[0].style.display =
        "none";
    }
  }, []);

  return (
    <>
      <Row className="my-2">
        <Col xs={12}>
          <HeaderView decoupleList={decoupleList} isFromDetailsPage="false" />
        </Col>
      </Row>
      <Row className="my-2">
        <Col xs={12}>
          <FilterBar decoupleList={decoupleList} />
        </Col>
      </Row>
      <Row>
        <Col className="pt-2">
          <h3 className="text-center">
            {`${decoupleList.length} Decoupled Components`}
          </h3>

          <div className="d-flex justify-content-end pt-2 px-3 ">
            <span className="px-2 pt-2">View as </span>
            <span title="Grid View">
              <IconButton
                onClick={() => {
                  setViewMode("GRID");
                }}
              >
                <GridViewIcon className="view-mode" color="primary" />
              </IconButton>
            </span>
            <span title="List View">
              <IconButton
                onClick={() => {
                  setViewMode("LIST");
                }}
              >
                <ViewListIcon className="view-mode" color="primary" />
              </IconButton>
            </span>
          </div>
        </Col>
      </Row>

      <Row xs={1} sm={2} md={3} lg={4} xxl={5}>
        {decoupleList.map((decouple, index) => (
          <React.Fragment key={`card-in-${index}`}>
            {viewMode === "LIST" ? (
              <DecoupleList decoupled={decouple} />
            ) : (
              <DecoupleCard decoupled={decouple} />
            )}
          </React.Fragment>
        ))}
      </Row>
    </>
  );
};

export default Home;
