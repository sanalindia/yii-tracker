import React, { useLayoutEffect } from "react";
import { Accordion } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import BasicInfoCard from "../components/basicInfoCard/basicInfoCard";
import decoupledLibrary from "../assets/data/decoupledLibrary.json";
import { IconButton } from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import HeaderView from "../components/headerView/headerView";

export default function DetailView() {
  const { id } = useParams();
  const decoupled = decoupledLibrary.find(
    (item) => String(item?.Id) === String(id)
  );
  const navigate = useNavigate();

  useLayoutEffect(() => {
    if (window.parent.document.querySelector('footer')) {
      window.parent.document.querySelector('footer').style = "position: relative !important;top: 5rem !important;";
    }
    window.parent.scrollTo(0, 0);
    setTimeout(() => {
      iframeClick();
    }, 5000);

  });

  const generateDecoupleDecoPath = () => {
    const hostURL = window.location.origin;
    const decoPathURL = new URL(decoupled?.Deco_Path);
    const decoupledURL = hostURL + decoPathURL?.pathname + decoPathURL?.hash;
    return decoupledURL;
  };
  const iframeClick = () => {

    let height =
      document.getElementsByClassName("container-fluid")[0].offsetHeight;
    if (document.querySelector('iframe[src*="deco/"]')) {
      if (height < 500) {
        height = height + 1000;
      }
      document.querySelector('iframe[src*="deco/"]').height = height + "px";
      document.querySelector(
        'iframe[src*="deco/"]'
      ).style = `height:${height}px  !important;`;
    }

    if (
      document.querySelector('iframe[src*="deco/new-elevit-journey-elements/"]')
    ) {
      window.parent.document.querySelector(
        'iframe[src*="deco-dev//ch-decoupled-library"]'
      ).height = height + "px";
    }

  };
  const isFunctionalExample =
    decoupled?.Functional_Example.toLowerCase() === "yes";

  return (
    <>
      <div className="mb-4">
        <div className="my-2">
          <div xs={12}>
            <HeaderView decoupleList={{}} isFromDetailsPage="true"/>
          </div>
        </div>
        <IconButton
          aria-label="home"
          onClick={() => navigate("/", { replace: true })}
        >
          <HomeIcon fontSize="large" />
        </IconButton>
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>Basic Informations</Accordion.Header>
            <Accordion.Body>
              <BasicInfoCard decoupleId={id} />
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="1">
            <Accordion.Header>Attachments</Accordion.Header>
            <Accordion.Body>No Attachments found!.</Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="2">
            <Accordion.Header onClick={() => iframeClick()}>
              Functional Example
            </Accordion.Header>
            <Accordion.Body>
              <div>
                {isFunctionalExample ? (
                  <iframe
                    title="decouple loading"
                    src={generateDecoupleDecoPath()}
                    width="100%"
                    key={id}
                  />
                ) : (
                  <div className="d-flex">
                    <IconButton
                      aria-label="newTab"
                      onClick={() =>
                        window.open(decoupled?.Deco_Path, "_blank")
                      }
                    >
                      <OpenInNewIcon />
                    </IconButton>
                    <p className="text-muted mt-3">
                      {`Click on this icon to view the functional example`}
                    </p>
                  </div>
                )}
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </div>
    </>
  );
}
