import * as fs from "fs";
import updateData from "./updateDecoupleLibrary.mjs";

const buttonPressesLogFile = "./Decoupled_Comp_List.xlsx";
var watching = false;
console.log(`Watching for file changes on ${buttonPressesLogFile}`);
function startWatching() {
  fs.watch(buttonPressesLogFile, (event, filename) => {
    if (filename) {
      console.log(`${filename} file Changed`);
      fs.open(buttonPressesLogFile, "r+", function (err, fd) {
        if (err && err.code === "EBUSY") {
          //do nothing till next loop
          console.log("file is currently busy");
        } else if (err && err.code === "ENOENT") {
          console.log(buttonPressesLogFile, "deleted");
        } else {
          if (watching) return;
          watching = true;
          updateData();
          // the timeout is to prevent the script to run twice with short functions
          // the delay can be longer to disable the function for a set time
          setTimeout(() => {
            watching = false;
          }, 500);
        }
      });
    }
  });
}
try {
  startWatching();
} catch (e) {
  console.log(e);
}
process.on("uncaughtException", (err) => {
  console.log(err, "Uncaught Exception thrown");
  // process.exit(1);
});
