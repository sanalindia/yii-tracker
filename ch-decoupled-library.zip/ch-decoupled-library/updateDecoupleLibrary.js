var XLSX = require("xlsx");
var workbook = XLSX.readFile("./Decoupled_Comp_List.xlsx");
var fs = require("fs");
var destPath = "./src/assets/data/";
var sheet_list = workbook.SheetNames;
for (let index = 0; index < sheet_list.length; index++) {
  const sheet_name = sheet_list[index];
  var data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name]);

  // Iterate over array for replacing the keys having space with underscore
  data.forEach((ele, i) => {
    // Iterate over the keys of object
    Object.keys(ele).forEach((key) => {

      // Copy the value
      const val = ele[key];

      const newKey = key.replace(/\s+/g, '_');

      // Remove key-value from object
      delete data[i][key];

      let trimmed = String(val)?.trim();
      trimmed = trimmed.charAt(trimmed.length - 1) === ',' ? trimmed.slice(0, -1) : trimmed;
      if (key === 'Country' || key === 'Category' || key === 'Brands' || key === 'Language') {
        // for capitalising each word
        // trimmed = key !== 'Country' ? trimmed.toLowerCase() : trimmed;
        const words = trimmed.split(/\s/);
        const capitalised = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
        trimmed = capitalised.join(' ');
      } else if (key === 'Name' || key === 'Description' || key === 'MSH') {
        // trimmed = trimmed.toLowerCase();
        trimmed = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      }

      // Add value with new key
      data[i][newKey] = trimmed;
    });
  });
  var jsonFile = `${destPath + sheet_name}.json`;
  fs.writeFileSync(jsonFile, JSON.stringify(data));
  console.log(`File ${jsonFile} updated successfully`);
}
// console.log(XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]));
