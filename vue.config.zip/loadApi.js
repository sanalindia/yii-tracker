const request = require('request');
const fs = require('fs');

const COOKIE = 'NO_CACHE=1; tc_ptid=7lldrvRty47EXQrmewgEAo; tc_ptidexpiry=1665312508182; _hjid=328a6a30-0137-4184-9399-70a2a9d65a27; _ga=GA1.5.815164748.1604503769; _hjMinimizedPolls=498332; OptanonAlertBoxClosed=2020-11-05T12:47:31.058Z; _ga=GA1.1.815164748.1604503769; _gid=GA1.5.33512216.1604968746; _hjTLDTest=1; NO_CACHE=1; _hjIncludedInPageviewSample=1; _ga_JK6901LJRC=GS1.1.1604995891.5.0.1604995891.0; RT="z=1&dm=baywsf.com&si=oa8jtjv212&ss=khbai7ny&sl=0&tt=0"; OptanonConsent=isIABGlobal=false&datestamp=Tue+Nov+10+2020+11%3A12%3A32+GMT%2B0200+(%D0%92%D0%BE%D1%81%D1%82%D0%BE%D1%87%D0%BD%D0%B0%D1%8F+%D0%95%D0%B2%D1%80%D0%BE%D0%BF%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=6.8.0&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0004%3A1&geolocation=%3B&AwaitingReconsent=false; _ga_JK6901LJRC=GS1.5.1604999553.7.1.1604999563.0; __token__=exp=1605092980~acl=*~hmac=3878dcf6d805327cde5dbf1217f992564f153b85c061365771e3e31609fc975d';
const QUIZ_UUID = '047638a4-8103-4e91-b613-a09cd3858a1d';
const DOMAIN = 'https://prodbo27sgjr.main.acsf.baywsf.com';
const PATH = './public/temp';

const url = (
  uuid = QUIZ_UUID, type = 'quiz',
  includes = ['field_quiz_question', 'field_actions', 'field_result']) =>
  `${DOMAIN}/jsonapi/node/${type}/${uuid}?include=${includes.join(
    ',')}`;

const includeMap = {
  'question': ['field_answer', 'field_actions'],
  'answer': ['field_next_question', 'field_result'],
  'result': ['field_actions'],
};

function getIncluded(response) {
  const {included} = JSON.parse(response.body);
  included && included.length &&
  included.filter(i => !i.type.includes('action')).forEach(i => {
    get(i.id, i.type);
  });
}

function get(uuid, type) {
  return new Promise(resolve => {
    const typeName = type.replace('node--', '');
    request({
      url: url(uuid, typeName, includeMap[typeName]),
      method: 'GET',
      headers: {'Cookie': COOKIE},
    }, (error, response) => {
      if (!error && !response.body.errors) {
        getIncluded(response);
        resolve(response.body);
        if (!fs.existsSync(`${PATH}/${typeName}`)) {
          fs.mkdirSync(`${PATH}/${typeName}`);
        }
        fs.writeFile(`${PATH}/${typeName}/${uuid}.json`, response.body,
          function(err) {
            if (err) {
              return console.log(err);
            }
            console.log(`${typeName}, ${uuid}: The file was saved!`);
          });
      } else {
        console.log('err', error || response.body.errors);
      }
    });
  });
}

request({url: url(), method: 'GET', headers: {'Cookie': COOKIE}},
  async (error, response) => {
    if (!error) {
      //console.log(JSON.parse(response.body) );
      fs.writeFile(`${PATH}/quiz.json`, response.body, function(err) {
        if (err) {
          return console.log(err);
        }
        console.log('quiz: The file was saved!');
      });
      const {data} = JSON.parse(response.body);
      /*	if( data.attributes.field_quiz_type === 'linear' ){
          const { id, type } = data.relationships.field_result.data;
          await get(id, type);
        }*/
      getIncluded(response);
    }
  });
