import axios from 'axios';
import {getRequestLang} from '../helpers/getLang';

const instance = axios.create({
  baseURL: window.document.location.origin,
  headers: {
    'Accept': 'application/vnd.api+json',
    'Content-Type': 'application/vnd.api+json',
  },
});

export default {
  getQuiz(uuid) {
    return instance.get(
      `${getRequestLang()}/jsonapi/node/quiz/${uuid}?include=field_quiz_question,field_actions`);
  },
  getQuestion(uuid) {
    return instance.get(
      `${getRequestLang()}/jsonapi/node/question/${uuid}?include=field_answer,field_actions`);
  },
  getResult(uuid) {
    return instance.get(`${getRequestLang()}/jsonapi/node/result/${uuid}?include=field_actions`);
  },
  getAnswer(uuid) {
    return instance.get(
      `${getRequestLang()}/jsonapi/node/result/${uuid}?include=field_next_question,field_result`); //
  },
  getCustomResults() {
    console.log(`Quiz results.json`);
    return instance.get(`${process.env.VUE_APP_PUBLIC_PATH}/results.json`);
  },
};
