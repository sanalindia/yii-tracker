window.dataLayer = window.dataLayer || [];
const EVENT_CATEGORY = 'Period quiz(local)';
const GA_GENERIC_EVENT = 'gaGenericEvent';

const GA_START = {
  event: GA_GENERIC_EVENT,
  eventCategory: EVENT_CATEGORY,
  eventAction: 'Start',
};

const GA_FINISH = {
  event: GA_GENERIC_EVENT,
  eventCategory: EVENT_CATEGORY,
  eventAction: 'Submit successful',
};

const GA_RESULT = {
  event: GA_GENERIC_EVENT,
  eventCategory: EVENT_CATEGORY,
  eventAction: 'Quiz Result',
  eventLabel: '',
};

const GA_ANSWER = {
  event: GA_GENERIC_EVENT,
  eventCategory: EVENT_CATEGORY,
  eventAction: 'Answer Q',
  eventLabel: '',
};

const GA_START_OVER = {
  event: GA_GENERIC_EVENT,
  eventCategory: EVENT_CATEGORY,
  eventAction: 'Start Over',
  eventLabel: '',
};

const pushToGA = event => {
  window.dataLayer.push(event);
};

const GA_HMB_YES = 'HMB YES';
const GA_HMB_NO = 'HMB NO';

export default {
  pushFinish() {
    pushToGA(GA_FINISH);
  },
  pushStartOver() {
    pushToGA(GA_START_OVER);
  },
  pushStart() {
    pushToGA(GA_START);
  },
  /**
   *
   * @param state
   */
  pushResult(state) {
    pushToGA({...GA_RESULT, eventLabel: state ? GA_HMB_YES : GA_HMB_NO});
  },
  /**
   *
   * @param currentQ
   * @param eventLabel
   */
  pushAnswer(currentQ, eventLabel) {
    pushToGA({
      ...GA_ANSWER,
      eventAction: GA_ANSWER.eventAction + currentQ,
      eventLabel,
    });
  },
};