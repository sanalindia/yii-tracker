import devQuizService from './quiz.dev';
import prodQuizService from './quiz.prod';

export default process.env.NODE_ENV === 'production'
  ? prodQuizService
  : devQuizService;