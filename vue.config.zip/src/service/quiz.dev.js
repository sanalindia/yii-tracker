import axios from "axios";

const instance = axios.create();

export default {
  getQuiz(uuid) {
    console.log(`Quiz id: ${uuid}`);
    return instance.get("/temp1/quiz.json");
  },
  getQuestion(uuid) {
    console.log(`Quiz question id: ${uuid}`);
    return instance.get(`/temp1/question/${uuid}.json`);
  },
  getResult(uuid) {
    console.log(`Quiz result id: ${uuid}`);
    return instance.get(`/temp/result/${uuid}.json`); //
  },

  getAnswer(uuid) {
    console.log(`Quiz answer id: ${uuid}`);
    return instance.get(`/temp/answer/${uuid}.json`); //
  },
  getCustomResults() {
    console.log(`Quiz results.json`);
    return instance.get(`${process.env.VUE_APP_PUBLIC_PATH}/results.json`);
  },
};
