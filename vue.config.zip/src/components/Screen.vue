<template>
    <main class="quiz-main">
        <StartScreen
                v-if="screen.type === 'node--quiz'"
                :instruction="screen.field_instruction"
                :actions="screen.actions"
                @on-action-click="onActionClick">
        </StartScreen>
        <Question
                v-if="screen.type === 'node--question'"
                :screen-id="screen.id"
                :title="screen.title"
                :instruction="screen.field_instruction"
                :answers="screen.answers"
                :selected="screen.selected"
                @on-change="onChange"
                @on-action-click="onActionClick"/>
        <Result
                v-if="screen.type === 'node--result'"
                :title="screen.title"
                :instruction="screen.field_instruction"
                :actions="screen.actions"
                @on-action-click="onActionClick">
        </Result>
    </main>
</template>

<script>
  import StartScreen from './StartScreen';
  import Question from './Question';
  import Result from './Result';

  export default {
    name: 'Screen',
    components: {
      StartScreen,
      Question,
      Result,
    },
    props: {
      screen: {
        type: Object,
        default: () => ({
          id: '',
          type: 'node--quiz',
        }),
      },
    },
    methods: {
      onChange($event) {
        this.$emit('on-change', $event);
      },
      onActionClick($event) {
        this.$emit('on-action-click', $event);
      },
    },
  };
</script>

<style scoped>

</style>