<template>
  <div class="quiz-card">
    <div class="quiz-card__main">
      <div
        v-html="$t(content)"
        class="quiz-card__content"/>
      <div class="quiz-card__link-list">
        <a
          v-for="(link, key) in linkList"
          v-html="$t(link.label)"
          :key="'link-' + key"
          :href="$t(link.url)"
          :target="link.target"
          :class="link.className"
          class="quiz-card__link"/>
      </div>
    </div>
    <div
      :class="'quiz-card__aside--' + bgName"
      class="quiz-card__aside"/>
  </div>
</template>

<script>
  export default {
    name: "Card",
    props: {
      content: {
        type: String,
        default: '',
      },
      bgName: {
        type: String,
        default: '',
      },
      linkList: {
        type: Array,
        default: () => [],
      },
    },
  }
</script>

<style scoped>

</style>
