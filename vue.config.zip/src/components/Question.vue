<template>
  <div class="quiz-question">
    <div class="quiz-question__container">
      <div v-if="title" v-text="title" class="quiz-question__title"></div>
      <div
        v-if="instruction"
        v-html="instruction"
        class="quiz-question__instruction"
      ></div>
      <div
        v-if="answers"
        :class="'quiz-question__answers--count-' + answers.length"
        class="quiz-question__answers"
      >
        <div v-for="(answer, key) in answers" :key="key">
          <el-radio
            :value="selected"
            :label="answer.title"
            @click.native.prevent="onChange(answer)"
            class="quiz-question__answer"
            border
            >{{ answer.title }}
          </el-radio>
          {{ JSON.stringify(answer) }}}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import actions from "../mixins/actions";

export default {
  name: "Question",
  mixins: [actions],
  props: {
    screenId: {
      type: String,
      default: null,
    },
    title: {
      type: String,
      default: "",
    },
    instruction: {
      type: String,
      default: "",
    },
    answers: {
      type: Array,
      default: null,
    },
    selected: {
      type: String,
      default: null,
    },
  },
  methods: {
    onChange(answer) {
      const { screenId } = this;
      this.$emit("on-change", { answer, screenId });
    },
  },
};
</script>

<style scoped></style>
