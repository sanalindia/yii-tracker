<template>
    <section
            class="quiz-questions">
        <div class="quiz-questions__container">
            <div class="quiz-questions-header">
                <div class="quiz-questions-header__container">{{ $t("QUESTIONS.HEADER") }}</div>
            </div>
            <agile
                    ref="quiz-question-carousel"
                    v-bind="carouselSetting"
                    @before-change="beforeChange"
                    @after-change="afterChange">
                <slot></slot>
            </agile>
        </div>
    </section>
</template>

<script>
  export default {
    name: 'Questions',
    props: {
      carouselSetting: {
        type: Object,
        default: () => {},
      },
    },
    methods: {
      beforeChange($event) {
        this.$emit('before-change', $event);
      },
      afterChange($event) {
        this.$parent.$emit('slider-update', $event);
      },
    },
  };
</script>

<style scoped>

</style>
