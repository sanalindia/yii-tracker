<template>
  <section class="quiz-result">
    <div class="quiz-result__container">
      <slot name="default"></slot>
      <div
        class="quiz-result__actions">
        <div v-for="(action, key) in actions"
             :key="key">
          <el-button
            type="primary"
            class="quiz-result__action"
            @click="onActionClick($event, action)">{{ action.name }}
          </el-button>
        </div>
        <span
          class="quiz-start-over"
          @click="onActionClick($event, { name: 'START OVER', type: 'start-over'})">{{ $t("START_OVER.BUTTON") }}</span>
      </div>
    </div>
  </section>
</template>

<script>
  import actions from '../mixins/actions';

  export default {
    name: 'Result',
    mixins: [actions],
    props: {
    },
  };
</script>

<style scoped>

</style>
