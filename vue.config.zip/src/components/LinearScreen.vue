<template>
  <main class="quiz-main">
    <transition name="animation">
      <StartScreen
        v-if="screen.type === 'node--quiz'"
        :title="screen.title"
        :instruction="screen.field_instruction"
        :actions="screen.actions"
        @on-action-click="onActionClick">
      </StartScreen>
      <Questions
        v-if="screen.type === 'node--question'"
        :carousel-setting="carouselSetting"
        ref="quiz-questions">
        <Question
          v-for="question in questions"
          :key="'quiz-question-id-' + question.id"
          :screen-id="question.id"
          :title="question.title"
          :instruction="question.field_instruction"
          :answers="question.answers"
          :selected="question.selected"
          @on-change="onChange"
          @on-action-click="onActionClick"/>
      </Questions>
      <Result
        v-if="screen.type === 'node--result'"
        :actions="screen.actions"
        @on-action-click="onActionClick">
        <template v-slot:default>
          <div class="quiz-result-header">
            <div class="quiz-result-header__container">{{ $t("RESULT.HEADER") }}</div>
          </div>
          <img
            :src="ImageOutcomeNegative"
            class="quiz-result__wallpaper"/>
          <div class="quiz-box">
            <div
              v-if="$t(screen.title)"
              v-text="$t(screen.title)"
              class="quiz-result__title"/>
          </div>
          <div
            v-if="$t(screen.field_instruction)"
            v-html="$t(screen.field_instruction)"
            class="quiz-result__instruction"/>
          <Card
            v-if="negativeResultCard"
            :bg-name="negativeResultCard.bgName"
            :content="negativeResultCard.content"
            :link-list="negativeResultCard.linkList"/>
        </template>
      </Result>
      <Result
        v-if="screen.type === 'node--result-ext'"
        :actions="screen.actions"
        @on-action-click="onActionClick">
        <template v-slot:default>
          <div class="quiz-result-header">
            <div class="quiz-result-header__container">{{ $t("RESULT.HEADER") }}</div>
          </div>
          <div class="quiz-box">
            <div class="quiz-droplets">
              <div v-for="(drop, index) in drops" :key="`drop-${index}`">
                <img :src="drop">
              </div>
            </div>
            <div
              v-if="$t(screen.title)"
              v-text="$t(screen.title)"
              class="quiz-result__title"></div>
          </div>
          <div
            v-if="$t(screen.field_instruction)"
            v-html="$t(screen.field_instruction)"
            class="quiz-result__instruction"></div>
          <div class="quiz-box-2">
            <p class="quiz-box-2__title">{{ $t(screen.sub_headline_1.title) }}</p>
            <ul>
              <li v-for="(text, index) in sub_headline_body" :key="`li-${index}`">{{ $t(text) }}</li>
            </ul>
          </div>
          <div class="quiz-result__title quiz-result__title--2">{{ $t(screen.headline_2.title) }}</div>
          <p class="quiz-result__instruction quiz-result__instruction--2">{{ $t(screen.headline_2.body) }}</p>
          <el-collapse class="quiz-collapse">
            <el-collapse-item :title="$t(screen.sub_headline_2.title)">
              <div v-html="$t(screen.sub_headline_2.body)"></div>
            </el-collapse-item>
          </el-collapse>
          <Card
            v-if="positiveResultCard"
            :bg-name="positiveResultCard.bgName"
            :content="positiveResultCard.content"
            :link-list="positiveResultCard.linkList"/>
        </template>
      </Result>
    </transition>
  </main>
</template>

<script>
  import StartScreen from './StartScreen';
  import Question from './Question';
  import Questions from './Questions';
  import Result from './Result';
  import Card from "./Card";
  import IconDrop from '../assets/img/Icon-Drop.svg';
  import IconDropless from '../assets/img/Icon-Dropless.svg';
  import ImageOutcomeNegative from '../assets/img/Image-Outcome-Negative.png';

  const checkCorrect = ({selectedId, field_correct}) => {
    return field_correct.some(item=> item.id === selectedId);
  };

  export default {
    name: 'LinearScreen',
    components: {
      StartScreen,
      Question,
      Questions,
      Result,
      Card,
    },
    props: {
      screen: {
        type: Object,
        default: () => ({
          id: '',
          type: 'node--quiz',
        }),
      },
      questions: {
        type: Array,
        default: () => [],
      },
      screens: {
        type: Array,
        default: () => [],
      },
      positiveResultCard: {
        type: Object,
        default: () => ({}),
      },
      negativeResultCard: {
        type: Object,
        default: () => ({}),
      },
    },
    computed: {
      drops() {
        return this.questions.map(checkCorrect).sort((a, b) => b - a).map(d => d ? IconDrop : IconDropless);
      },
      sub_headline_body() {
        const drops = this.questions.map(checkCorrect);
        return this.screen.sub_headline_1.body.filter((st, id) => drops[id]);
      },
      ImageOutcomeNegative() {
        return ImageOutcomeNegative;
      },
    },
    data() {
      return {
        carouselSetting: {
          infinite: false,
          speed: 1000,
          //@todo disable swipe
          swipeDistance: 99999,
          navButtons: false,
        },
      };
    },
    methods: {
      onChange($event) {
        const currentQ = this.$refs['quiz-questions'].$refs['quiz-question-carousel'].currentSlide + 1;
        this.$emit('on-change', {...$event, currentQ});
        const id = this.questions.findIndex(({id}) => id === $event.answer.next.id);
        (id !== -1) && this.$refs['quiz-questions'].$refs['quiz-question-carousel'].goTo(id);
      },
      onActionClick($event) {
        this.$emit('on-action-click', $event);
      },
    },
  };
</script>

<style scoped>

</style>
