<template>
    <header class="quiz-header">
        <h3 v-html="title" class="quiz-header__title"/>
    </header>
</template>

<script>
  export default {
    name: 'Header',
    props: {
      title: {
        type: String,
        default: '',
      },
    },
  };
</script>

<style scoped>

</style>