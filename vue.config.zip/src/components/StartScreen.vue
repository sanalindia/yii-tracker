<template>
  <section class="quiz-start">
    <div class="quiz-start__wallpaper">
      <div class="bayer-logo">
        <a :href="$t('BAYER_LOGO.URL')" target="_blank">
          <img alt="Home" class="bayer-logo" src="https://www.menstruationscheck.de/sites/g/files/kmftyc1541/files/Logo-Bayer.svg">
        </a>
      </div>
      <div class="quiz-start__container">
        <div
          v-if="title"
          v-text="title"
          class="quiz-start__title"></div>
      </div>
    </div>
    <div class="quiz-start__container">
      <div
        v-if="instruction"
        v-html="instruction"
        class="quiz-start__instruction"></div>
      <div
        v-if="actions"
        class="quiz-start__actions">
        <el-button
          v-for="(action, key) in actions"
          :key="key"
          class="quiz-start__action"
          @click="onActionClick($event, action)">{{ $t('GET_STARTED.BUTTON') }}
        </el-button>
      </div>
    </div>
  </section>
</template>

<script>
  import actions from '../mixins/actions';

  export default {
    name: 'StartScreen',
    mixins: [actions],
    props: {
      title: {
        type: String,
        default: '',
      },
      instruction: {
        type: String,
        default: '',
      },
    },
  };
</script>

<style scoped>

</style>
