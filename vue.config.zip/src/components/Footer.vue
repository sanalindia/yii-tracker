<template>
    <footer class="quiz-footer">
        <ul>
            <li
              v-for="(item, key) in menuItems"
              :key="key">
                <a v-if="item.url" :href="$t(item.url)" v-html="$t(item.label)"/>
                <div v-else v-html="$t(item.label)"/>
            </li>
        </ul>
    </footer>
</template>

<script>
    export default {
        name: "Footer",
        props: {
            menuItems: {
                type: Object,
            },
        }
    }
</script>

<style scoped>

</style>
