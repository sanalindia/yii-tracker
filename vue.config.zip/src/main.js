import 'core-js/stable';
import 'regenerator-runtime/runtime';
import Vue from 'vue';
import App from './App.vue';
import VueAgile from 'vue-agile';
import {Radio, Button, Drawer, Collapse, CollapseItem} from 'element-ui';
import './assets/scss/main.scss';
import { i18n } from './i18n';

Vue.use(Collapse);
Vue.use(CollapseItem);
Vue.use(Radio);
Vue.use(Button);
Vue.use(Drawer);
Vue.use(VueAgile);

Vue.config.productionTip = false;

new Vue({
  i18n,
  render: h => h(App),
}).$mount('#app');
