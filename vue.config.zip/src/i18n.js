import Vue from 'vue';
import axios from 'axios';
import VueI18n from 'vue-i18n';
import {getLang, getCustomLang} from './helpers/getLang';

Vue.use(VueI18n);
const href = process.env.VUE_APP_PUBLIC_PATH;
const lang = getLang();

export const i18n = new VueI18n({
  locale: lang,
  fallbackLocale: 'en',
});

const loadedLanguages = [];

function setI18nLanguage(lang) {
  i18n.locale = lang;
  axios.defaults.headers.common['Accept-Language'] = lang;
  //document.querySelector('html').setAttribute('lang', lang);
  return lang;
}

export async function loadLanguageAsync(lang) {
  const lang_code = getCustomLang() || lang;

  if (loadedLanguages.includes(lang_code)) {
    if (i18n.locale !== lang_code) setI18nLanguage(lang_code);
    return Promise.resolve();
  }

  const {data} = await getLangJSON(lang_code);
  loadedLanguages.push(lang_code);
  i18n.setLocaleMessage(lang_code, data);
  return setI18nLanguage(lang_code);
}

async function getLangJSON(locale) {
  try {
    return await axios.get(`${href}/locales/${locale}.json`)
  } catch (e) {
    console.error(e);
    console.error('JSON file with such translations is missing! Fallback to English.');
    return await axios.get(`${href}/locales/en.json`)
  }
}
