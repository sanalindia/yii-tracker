export default {
  props: {
    actions: {
      type: Array,
      default: null,
    },
  },
  methods: {
    onActionClick($event, action) {
      this.$emit('on-action-click', action);
    },
  },
};