const getConvertedField = (field) => {
  return field && field.processed || '';
};

export default {
  methods: {
    getConvertedField,
    getTextFromHtmlString(htmlString) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlString, 'text/html');
      return doc.documentElement ? doc.documentElement.textContent : htmlString;
    },
    getConvertedIncluded(included = []) {
      return included.reduce((accumulator, {
        id,
        type,
        attributes: {
          title,
          name,
          field_explanation,
          field_instruction,
          field_references,
          field_answer_summary,
        },
        relationships,
      }) => {
        if (type === 'node--question') {
          accumulator.questions.push({
            id,
            type,
            title,
            field_explanation: getConvertedField(field_explanation),
            field_instruction: getConvertedField(field_instruction),
            field_references: getConvertedField(field_references),
            field_correct: relationships.field_correct.data,
            selected: null,
            selectedId: null,
          });
        } else if (type === 'node--answer') {

          const {
            field_next_question: {
              data: field_next_question,
            },
            field_result: {
              data: field_result,
            },
          } = relationships;

          accumulator.answers.push({
            id,
            type,
            title,
            field_answer_summary: this.getTextFromHtmlString(
              getConvertedField(field_answer_summary)),
            next: field_next_question || field_result || {},
          });
        } else if (type === 'taxonomy_term--quiz_action') {
          accumulator.actions.push({
            id,
            type,
            name,
          });
        } else if (type === 'node--result') {
          accumulator.results.push({
            id,
            type,
            name,
          });
        }
        return accumulator;
      }, {
        questions: [],
        actions: [],
        answers: [],
        results: [],
      });
    },
  },
};