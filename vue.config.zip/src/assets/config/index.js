import { v4 as uuidv4 } from 'uuid';

// eslint-disable-next-line no-unused-vars
export const APP_UUID = uuidv4();

export const RESULT_CARDS = {
  APP_STORE_CARD: {
    bgName: 'bg-1',
    content: 'APP_STORE_CARD.CONTENT',
    linkList: [
      {
        label: 'APP_STORE_CARD.LINK_1.LABEL',
        url: 'APP_STORE_CARD.LINK_1.URL',
        className: 'quiz-card__link--image quiz-card__link--g-play',
        target: '_blank',
      },
      {
        label: 'APP_STORE_CARD.LINK_2.LABEL',
        url: 'APP_STORE_CARD.LINK_2.URL',
        className: 'quiz-card__link--image quiz-card__link--a-store',
        target: '_blank',
      },
    ],
  },
  COMPARE_METHODS_CARD: {
    bgName: 'bg-2',
    content: 'COMPARE_METHODS_CARD.CONTENT',
    linkList: [
      {
        label: 'COMPARE_METHODS_CARD.LINK_1.LABEL',
        url: 'COMPARE_METHODS_CARD.LINK_1.URL',
        className: 'quiz-card__link--compare',
        target: '_self',
      }
    ],
  }
};

export const FOOTER_MENU_ITEMS = {
  privacyStatement: {
    label: 'FOOTER.PRIVACY_STATEMENT.LABEL',
    url: 'FOOTER.PRIVACY_STATEMENT.URL',
  },
  conditionsOfUse: {
    label: 'FOOTER.CONDITIONS_OF_USE.LABEL',
    url: 'FOOTER.CONDITIONS_OF_USE.URL',
  },
  imprint: {
    label: 'FOOTER.IMPRINT.LABEL',
    url: 'FOOTER.IMPRINT.URL',
  },
  approvalCode: {
    label: 'FOOTER.APPROVAL_CODE',
  },
};
