<template>
  <div :id="'quiz-app-' + uuid" class="quiz">
    <component
      :is="screenComponentName"
      :screen="screen"
      :screens="screens"
      :questions="questions"
      :positive-result-card="positiveResultCard"
      :negative-result-card="negativeResultCard"
      @on-change="onChange"
      @slider-update="sliderUpdate"
      @on-action-click="onActionClick"
    />
    <Footer :menu-items="quiz.footerMenuItems" :class="footerClass" />
  </div>
</template>

<script>
import Footer from "./components/Footer";
import quizService from "./service/quiz";
import gaService from "./service/ga";
import {
  getQuizId,
  getResultCard,
  getApprovalNumber,
} from "./helpers/getAttributes.js";
import converted from "./mixins/converted";
import { loadLanguageAsync } from "./i18n.js";

import { APP_UUID, FOOTER_MENU_ITEMS } from "./assets/config";

export default {
  name: "App",
  mixins: [converted],
  components: {
    Footer,
    Screen: () => import("./components/Screen"),
    LinearScreen: () => import("./components/LinearScreen"),
  },
  computed: {
    screenComponentName() {
      if (this.quiz.type === "linear") {
        return "LinearScreen";
      }
      return "Screen";
    },
    questions() {
      return this.screens.filter((s) => s.type === "node--question");
    },
    screen() {
      if (this.history.length) {
        const { id, type } = this.history[this.history.length - 1];
        console.log("id", id);
        console.log("type", type);
        console.log(
          "this.screens nxt",
          this.screens.find((s) => s.id === id && s.type === type)
        );
        return (
          this.screens.find((s) => s.id === id && s.type === type) ||
          this.screens[0]
        );
      }
      console.log("this.screens[0]", this.screens[0]);
      return this.screens[0];
    },
    isLastQuestionScreen() {
      const { id: screenId } = this.history[this.history.length - 1];
      const index = this.questions.findIndex(({ id }) => id === screenId);
      return index === this.questions.length - 1;
    },
    footerClass() {
      const type = this.screen && this.screen.type;
      return `footer-quiz--${type}`;
    },
  },
  data() {
    return {
      quiz: {
        headerTitle: "",
        footerContent: "",
        type: "",
        footerMenuItems: FOOTER_MENU_ITEMS,
      },
      uuid: APP_UUID,
      quizId: "",
      screens: [],
      history: [],
      positiveResultCard: null,
      negativeResultCard: null,
    };
  },
  async mounted() {
    await loadLanguageAsync(this.$i18n.locale);
    this.quizId = getQuizId();
    this.positiveResultCard = getResultCard("positive");
    this.negativeResultCard = getResultCard("negative");
    const { quiz, questions, results } = await this.getQuiz(this.quizId);
    this.quiz.type = quiz.field_quiz_type;
    this.quiz.headerTitle = quiz.title;
    this.quiz.footerContent = quiz.field_disclaimer;
    const exposedApprovalNumber = getApprovalNumber();
    if (exposedApprovalNumber) {
      this.quiz.footerMenuItems.approvalCode.label = exposedApprovalNumber;
    }
    const isLinear = quiz.field_quiz_type === "linear";
    const { data: customResults } = await quizService.getCustomResults();

    Promise.all(
      questions.map(async (question, id) => {
        const { answers } = await this.getQuestionAnswersAndActions(
          question.id
        );
        if (isLinear) {
          const next = questions[id + 1]
            ? { id: questions[id + 1].id, type: questions[id + 1].type }
            : { ...results[0] };
          question = {
            ...question,
            answers: answers.map((a) => ({
              ...a,
              next: a.next.id ? a.next : next,
            })),
          };
          return question;
        }
        question = { ...question, answers };
        return question;
      })
    ).then((questions) => {
      this.screens = [quiz, ...questions, ...customResults];
    });
  },
  methods: {
    async getQuiz(uuid) {
      const {
        data: {
          data: {
            id,
            type,
            attributes: {
              title,
              field_quiz_type,
              field_instruction,
              field_disclaimer,
              field_references,
            },
          },
          included,
        },
      } = await quizService.getQuiz(uuid);

      const { questions, actions, results } = this.getConvertedIncluded(
        included
      );

      return {
        quiz: {
          id,
          type,
          title,
          field_quiz_type,
          field_instruction: this.getConvertedField(field_instruction),
          field_disclaimer: this.getConvertedField(field_disclaimer),
          field_references: this.getConvertedField(field_references),
          actions,
        },
        questions,
        results,
      };
    },

    async getQuestionAnswersAndActions(uuid) {
      const {
        data: { included, data },
      } = await quizService.getQuestion(uuid);

      const {
        questions: [question],
      } = this.getConvertedIncluded([data]);

      const { answers } = this.getConvertedIncluded(included);

      return { ...question, answers };
    },

    async getResult(uuid) {
      const {
        data: {
          data: {
            id,
            type,
            attributes: { title, field_instruction },
          },
          included,
        },
      } = await quizService.getResult(uuid);

      const { actions } = this.getConvertedIncluded(included);

      return {
        id,
        type,
        title,
        field_instruction: this.getConvertedField(field_instruction),
        actions,
      };
    },

    getScreen({ id, type }) {
      if (type === "node--question") {
        return this.getQuestionAnswersAndActions(id);
      }
      return this.getResult(id);
    },

    async onChange({ answer, screenId, currentQ = 0 }) {
      console.log("answer", answer);
      console.log("screenId", screenId);
      console.log("currentQ", currentQ);
      gaService.pushAnswer(currentQ, answer.title);
      if (this.isLastQuestionScreen) {
        const checkCorrect = ({ selectedId, field_correct, id }) => {
          if (id === screenId) {
            selectedId = answer.id;
          }
          console.log("field_correct", field_correct);
          console.log("selectedId", selectedId);
          return field_correct.some((item) => item.id === selectedId);
        };
        const isNegative = this.questions.filter(checkCorrect).length < 3;
        //console.log("isNegative", isNegative);
        //console.log("this.questions", this.questions);
        //console.log("checkCorrect", checkCorrect);
        answer.next = isNegative
          ? { id: "negative", type: "node--result" }
          : {
              id: "positive",
              type: "node--result-ext",
            };
        gaService.pushFinish();
        gaService.pushResult(!isNegative);
      }
      this.select(answer, screenId);

      const existScreen = this.screens.find((s) => s.id === answer.next.id);
      console.log("existScreen", existScreen);
      if (!existScreen) {
        alert("not");
        console.log("answer.next", answer.next);
        const screen = await this.getScreen(answer.next);
        this.screens.push(screen);
      }

      this.history.push(answer.next);
    },

    select(answer, screenId) {
      const sc = this.screens.find((s) => s.id === screenId);
      sc.selected = answer.title;
      sc.selectedId = answer.id;
    },

    sliderUpdate(event) {
      const { id: screenId } = this.history[this.history.length - 1];
      const slideIndex = this.questions.findIndex(({ id }) => id === screenId);

      if (event.currentSlide !== slideIndex) {
        this.history.pop();
      }
    },

    onActionClick(action) {
      if (action.type === "start-over") {
        gaService.pushStartOver();
        this.screens = this.screens.map((q) => ({ ...q, selected: "" }));
        this.history = [];
      } else if (action.type === "back") {
        this.history.pop();
        if (!this.history.length) {
          this.screens = this.screens.map((s) => ({ ...s, selected: "" }));
        } else {
          const { id } = this.history[this.history.length - 1];
          this.screens = this.screens.map((s) =>
            s.id === id ? { ...s, selected: "" } : s
          );
        }
      } else {
        gaService.pushStart();
        const { id, type } = this.screens[1];
        this.history.push({
          id,
          type,
        });
      }
    },
  },
};
</script>

<style></style>
