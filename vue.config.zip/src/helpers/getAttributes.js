import {
    APP_UUID,
    RESULT_CARDS
} from '../assets/config';

export function getAttrValue (attr) {
    const app = document.getElementById('quiz-app-' + APP_UUID);
    try {
        return app.closest('.decoupled-app-component').getAttribute(attr);
    } catch (e) {
        console.error(e.message);
        console.error("Decoupled component wrapper should have 'decoupled-app-component' class. Please update Decoupled component to latest version!");
    }
}

export function getQuizId () {
    const attr = 'data-quizid';
    const quizId = getAttrValue(attr);

    if (!quizId) {
        console.error('Please add ' + attr + ' attribute to decoupled component.');
        return process.env.VUE_APP_QUIZ_ID;
    } else {
        return quizId;
    }
}

export function getResultCard (type) {
    const attr = 'data-' + type + '-result-card';
    const resultCard = getAttrValue(attr);

    if(process.env.NODE_ENV === 'production') {
        if (!resultCard || !RESULT_CARDS[resultCard]) {
            console.warn('Value in ' + type + ' result card is null.');
            console.warn('Allowed values for ' + attr + ' attribute is "APP_STORE_CARD" or "COMPARE_METHODS_CARD".');
            return null;
        } else {
            return RESULT_CARDS[resultCard];
        }
    } else if (type === 'positive') {
        return RESULT_CARDS[process.env.VUE_APP_POSITIVE_RESULT_CARD] || null;
    } else if (type === 'negative') {
        return RESULT_CARDS[process.env.VUE_APP_NEGATIVE_RESULT_CARD] || null;
    } else {
        return null;
    }
}

export function getApprovalNumber () {
    const attr = 'data-approval-number';
    const approvalCode = getAttrValue(attr);

    if (!approvalCode) {
        console.error('Please add ' + attr + ' attribute to decoupled component.');
        return '';
    } else {
        return approvalCode;
    }
}
