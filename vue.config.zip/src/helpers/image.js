export default (src) => {

  return process.env.VUE_APP_PUBLIC_PATH + src;
}