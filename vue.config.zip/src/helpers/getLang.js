import {getAttrValue} from "./getAttributes"

export const getLang = () => {
    return document.querySelector('html').getAttribute('lang');
};

export const getCustomLang = () => {
    return getAttrValue('data-custom-locale');
};

export const getRequestLang = () => {
    const pagePath = window.document.location.pathname;
    const langInUrl = pagePath.split('/')[1];
    const langInHtml = getLang();

    return langInUrl !== langInHtml ? '' : langInHtml;
};
