### What is this repository for? ###

Decoupled app 'Period quiz' for #MYCONTRACEPTION
                               
### Local development ###

To start working on this quiz, you need to open the loadApi file 
and replace the values ​​of the 
*  ```COOKIE ```,
*  ```DOMAIN ```,  
*  ```QUIZ_UUID ```,

to the required.

For getting necessary COOKIE please sign in to drupal site open dev tool 
and type in console ```document.cookie```.

DOMAIN is main drupal domain. For example: 'https://prodbo27sgjr.main.acsf.baywsf.com'.

For getting  ```QUIZ_UUID ```. you should go to link '```DOMAIN```/jsonapi/node/quiz/' and find your quiz id in json.

After that, you need to run the command. 

```node loadApi```
 
This command will load the data files necessary for local work into the temp folder.

It is also necessary to check and, if necessary, replace the value of the variables 

*  ```VUE_APP_PUBLIC_PATH ```
*  ```VUE_APP_QUIZ_ID```

In the ./env.local file

For getting VUE_APP_QUIZ_ID you should go to link '```DOMAIN```/jsonapi/node/quiz/' and find your quiz id in json.

After that, you can run the command 

```npm install``` to install necessary node modules

```npm run serve ``` to run local build

### Build ###

Please check and , if necessary, replace the value of the variables 
                 
 *  ```VUE_APP_PUBLIC_PATH```
 *  ```VUE_APP_QUIZ_ID```
                 
In the ./env.production file

For getting VUE_APP_QUIZ_ID you should go to link '```DOMAIN```/jsonapi/node/quiz/' and find your quiz id in json.

After that, you can run the command 

```npm install``` to install necessary node modules

```npm run build ``` to make a build and store to the dist folder

### Customize

Please check and , if necessary, replace the text content 
in the ./public/results.json file.

Please check and , if necessary, replace the value of the variables 
                 
 *  ```APP_STORE_CARD```
 *  ```COMPARE_METHODS_CARD```
 *  ```FOOTER_MENU_ITEMS```
 
 In the ./src/assets/config.js file.
 
 ```APP_STORE_CARD``` is a js object with text content and links for bottom result card.
 
 ```COMPARE_METHODS_CARD``` is a js object with text content and links for bottom result card.
 
  ```FOOTER_MENU_ITEMS``` is js Array of objects with links for bottom menu.
  
  In the ./env.local file you can find variables<br>
 - ```VUE_APP_POSITIVE_RESULT_CARD``` can have values: ```APP_STORE_CARD```, ```COMPARE_METHODS_CARD``` or  ```null``` It will define card for positive result screen.
 
- ```VUE_APP_NEGATIVE_RESULT_CARD``` can have values: ```APP_STORE_CARD```, ```COMPARE_METHODS_CARD``` or  ```null```. It will define card for negative result screen.
 
 The Card block will disappear if set ```null``` on result screen;
 
 ### Attributes parse
 
 Builded and uploaded to deco space app can be configured via attributes.
 Decoupled component in drupal have options to add custom attributes. This attributes is parsed and used inside quiz.
 
 Period quiz can parse next attributes
  
 - ```data-quizid``` - same as with ```VUE_APP_QUIZ_ID```. Example ```data-quizid="047638a4-8103-4e91-b613-a09cd3858a1d"```
  - ```data-custom-locale```. Force way to set locale json. If site have for example english, but still should have localization adjustments ```data-custom-locale="en-za"```
 - ```data-positive-result-card``` - same as with ```VUE_APP_POSITIVE_RESULT_CARD```. Example ```data-positive-result-card="APP_STORE_CARD"```
 - ```data-negative-result-card``` - same as with ```VUE_APP_NEGATIVE_RESULT_CARD```. Example ```data-negative-result-card="COMPARE_METHODS_CARD"```
 - ```data-approval-number```. Will set approval number text in footer. Example: ```data-approval-number="PP-PF-WHC-ALL-0051"```
