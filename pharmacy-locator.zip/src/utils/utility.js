export const keysToArray = (data, keyVal) => {
    
    var flags = [], output = [], l = data.length, i;
    for( i=0; i<l; i++) {
        if( flags[data[i][keyVal]]) continue;
        flags[data[i][keyVal]] = true;
        output.push(data[i][keyVal]);
    }
    return output
}