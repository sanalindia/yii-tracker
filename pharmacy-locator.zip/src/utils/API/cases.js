import { get } from "./config";

export default {
  loadFile: async () => {
    // const response = await get("data/pharmacy_list.csv")
    const response = await get("data/2023_Priorin_Kundenliste_Promo_Frühjahr_new_1111_new.csv")
    const csvToJSON = require("csv-file-to-json")
    const dataInJSON = csvToJSON({ data: response.data })
    // console.log("response", response);
    //  return response
    dataInJSON.shift()
    return dataInJSON

  }
};
