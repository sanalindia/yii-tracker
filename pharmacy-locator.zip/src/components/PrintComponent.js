import React, { useRef, useLayoutEffect } from 'react';
import { useReactToPrint } from 'react-to-print';
import { withResizeDetector } from 'react-resize-detector/build/withPolyfill';

import DataTableContainer from './DataTableContainer';

const PrintComponent = ({ height }) => {
  useLayoutEffect(() => {

    if (window.parent.document.getElementById("iFrameResizer0")) {
      window.parent.document.getElementById("iFrameResizer0").height =
      document.getElementById("mainWrapper").offsetHeight+30;
      window.parent.document.getElementById("iFrameResizer0").style.verticalAlign = "middle";

    }

  }, [height]);
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  return (
    <div ref={componentRef} id="mainWrapper" >
      <DataTableContainer handlePrint={handlePrint} />
    </div>
  );
};

export default withResizeDetector(PrintComponent);