import React, { useEffect, useRef, useState } from "react";
import markerIcon from "../assets/images/icon_map.gif"
import mapMarker from "../assets/images/map-marker.png"
import unselectedMap from "../assets/images/unselected-map.png"

const GMap = (props) => {
  const googleMapRef = useRef(null);
  let googleMap = null;

  // list of the marker object along with icon, title & info
  const markerList = props.mapMarkers;
  const [locatFlag, setLocatFlag] = useState(true);
  const [gMap, setGMap] = useState(null);
  useEffect(() => {
    initMap();
    //googleMap.fitBounds(bounds); // the map to contain all markers
  }, [props]);

  const initMap = () => {
    setLocatFlag(true);
    googleMap = initGoogleMap();
    setGMap(googleMap)
    var bounds = new window.google.maps.LatLngBounds();
    markerList.map(x => {
      const marker = createMarker(x);
      if (x.lat === props.mapData.lat) {
        marker.setIcon({
          url: mapMarker,
          scaledSize: new window.google.maps.Size(40, 45),
          origin: new window.google.maps.Point(0, 0), // origin
          anchor: new window.google.maps.Point(0, 0)
        });
      }
      bounds.extend(marker.position);
    });
  }

  // initialize the google map
  const initGoogleMap = () => {
    return new window.google.maps.Map(googleMapRef.current, {

      center: { lat: props.mapData.lat, lng: props.mapData.lng, },
      // center: { lat: 13.404954, lng: 52.520008 },
      zoom: 13,
      mapTypeId: window.google.maps.MapTypeId.ROADMAP,
      scrollwheel: false,
    });

  };

  // create marker on google map
  const createMarker = markerObj => {
    const marker = new window.google.maps.Marker({
      position: { lat: markerObj.lat, lng: markerObj.lng },
      map: googleMap,
      icon: {
        url: unselectedMap,
        scaledSize: new window.google.maps.Size(40, 45),
        origin: new window.google.maps.Point(0, 0), // origin
        anchor: new window.google.maps.Point(0, 0)
      },
      title: markerObj.title
    });

    const infowindow = new window.google.maps.InfoWindow({
      content: markerObj.info
    });
    marker.addListener("click", () => infowindow.open(googleMap, marker));

    return marker;
  };
  const locat_me = () => {
    setLocatFlag(false);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function (pos) {
        // let lat = -34.6440896;        
        // let lng = -58.3895479;

        let lat = pos.coords.latitude;
        let lng = pos.coords.longitude;
        var me = new window.google.maps.LatLng(lat, lng);
        let myloc = new window.google.maps.InfoWindow({ map: gMap, content: "Estas aquí" });
        myloc.setPosition(me);
        gMap.setOptions({ center: me, zoom: 18 })


      }, function (error) {
        console.log('error', error)
      });
    }
  }
  const reIniteMap = () => {
    initMap();
  }
  return <>
    <div className="locatArea">
      <img src={markerIcon} />
      {locatFlag ? <button onClick={() => locat_me()} className="locateme">ihr standort</button> : <button onClick={reIniteMap} className="locateme" >aktualisierung</button>}
    </div>
    <div ref={googleMapRef} style={{ width: '100%', height: 500 }} />
  </>
};

export default GMap;
