import React, { useEffect, useState } from 'react';
import labelText from '../assets/images/txt_dsc_1.gif'
import submitBtn from '../assets/images/btn_search.gif'
import '../css/components/searchComponent.scss'
import downArrow from '../assets/images/down_arrow.png'

const SearchComponent = ({ wardCountry, tryData, searchData, updateSearchTable }) => {

    const [finalData, setFinalData] = useState([]);
    const [wardValue, setWardValue] = useState("");
    const [tryValue, setTryValue] = useState("");
    const [searchValue, setSearchValue] = useState("");
    const [searchResult, setsearchResult] = useState([]);
    const wardList = wardCountry.map((data, index) => <option value={data} key={index}> {data}</option>)
    const tryList = tryData.map((data, index) => <option value={data} key={index}> {data}</option>)

    useEffect(() => {
        setFinalData(searchData);
    }, [])

    useEffect(() => {
        if (searchResult.length > 0 || wardValue !== "" || tryValue !== "" || searchValue !== "") {
            updateSearchTable(searchResult)
        }
        // updateSearchTable(searchResult);
    }, [searchResult])

    const searchFunction = (e) => {
        var result = finalData;
        e.preventDefault();
        setFinalData(searchData);
        if (tryValue !== "") {
            const resultData = result.filter((data) => {
                return data.try === tryValue
            })

            result = resultData
        }
        if (wardValue !== "") {
            const resultData = result.filter((data) => {
                return data.ward_country === wardValue
            })
            result = resultData
        }

        if (searchValue !== "") {
            var searchValue1 = searchValue.toLowerCase();
            var searchRegex = new RegExp(searchValue, "i")
            // var address;
            const resultData = result.filter((data) => {
                // console.log(data, "data");
                // console.log(searchRegex.test(data.organization_name) || searchRegex.test(data.city), "condition");
                // address = data.street + '' + data.city;
                // console.log("address", address);
                // data.city = address;
                // console.log("data", data);
                return (searchRegex.test(data.organization_name) || searchRegex.test(data.city) || searchRegex.test(data.institution_no) || searchRegex.test(data.account_id) || searchRegex.test(data.street) || searchRegex.test(data.zipcode))
            })
            // console.log("address", address);

            // console.log("data", data);
            result = resultData
            console.log(result, "result");
        }
        setsearchResult(result);
    }

    const selectWard = (e) => {
        setWardValue(e.target.value);
    }

    const selectTry = (e) => {
        setTryValue(e.target.value);
    }

    const setSearchText = (e) => {
        setSearchValue(e.target.value);
    }

    return (

        <>
            <form method="post" onSubmit={searchFunction} className="searchForm">
                <fieldset>
                    <label className="formTopic" >
                        {/* <img src={labelText}  alt="검색" /> */}
                    </label>

                    {/* <select value={tryValue} onChange={selectTry} className="formSelect selectBox">
                            <option value="">-- 시/도 --</option>
                            {tryList}
                        </select> */}


                    {/* <select value={wardValue} onChange={selectWard} className="formSelect selectBox">
                            <option value="">-- 구/군 --</option>
                            { wardList  }
                        </select> */}

                    <input type="text" name="search" onChange={setSearchText} placeholder=' die Postleitzahl' className="searchText" />
                    <button type="submit" name="submit" className="submitBtn">SUCHEN
                        {/* <img src={submitBtn} alt="submitText"/> */}
                    </button>

                </fieldset>

            </form>
        </>
    )
}

export default SearchComponent;