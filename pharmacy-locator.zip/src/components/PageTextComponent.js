import React from 'react';
import '../css/components/pageTextComponent.scss'

const PageTextComponent = () => {
    return(
        <>
            <div className="col-12 textWrapper">
            <h1>Finden Sie eine Apotheke</h1>
            {/*<p className="article-header-intro">엘레뉴<sup>®</sup> 판매처 찾기 서비스 입니다.<br/>
            판매처를 검색해 주세요.<br/>
    <sup>L.KR.MKT.03.2019.10840</sup></p>*/}
        </div>
      </>
    ) 
}

export default PageTextComponent