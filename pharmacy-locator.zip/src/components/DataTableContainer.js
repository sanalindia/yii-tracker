import React, { useEffect, useState, useLayoutEffect, cloneElement } from "react";
import { Cases } from "../utils/API/index";
import DataTable from 'react-data-table-component';
import "./../css/components/datatableConatiner.scss"
import GMap from "./GMap";
import PageTextComponent from "./PageTextComponent";
import { keysToArray } from '../utils/utility.js'
import SearchComponent from "./SearchComponent";
import printIcon from '../assets/images/btn_print.gif'
import btnView from '../assets/images/btn_view.gif'
import productImage from '../assets/images/img_dsc_1.gif'

// API key of the google map
const GOOGLE_MAP_API_KEY = "AIzaSyC7bNIbbnyOq2svz1d_o1q2FS9KxOr8bI0";

// load google map script
const loadGoogleMapScript = callback => {
  if (
    typeof window.google === "object" &&
    typeof window.google.maps === "object"
  ) {
    callback();
  } else {
    const googleMapScript = document.createElement("script");
    googleMapScript.src = `https://maps.googleapis.com/maps/api/js?sensor=true&language=de&key=${GOOGLE_MAP_API_KEY}`;
    window.document.body.appendChild(googleMapScript);
    googleMapScript.addEventListener("load", callback);
  }
};


const DataTableContainer = ({ handlePrint }) => {
  const [loadMap, setLoadMap] = useState(false);
  const [excelData, setExcelData] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [mapData, setMapData] = useState({ lat: "", lng: "", heading: "", info: "" });
  const [wardCountry, setWardCountry] = useState([]);
  const [tryData, setTryData] = useState([]);
  const [pageState, setPageState] = useState(5);
  const [mapMarkers, setMapMarkers] = useState([]);
  const [mapstart, setMapstart] = useState({ lat: parseFloat(52.520008), lng: parseFloat(13.404954) });

  const customStyles = {
    rows: {
      style: {
        borderTop: '1px solid #ddd',
        minHeight: 'auto' // override the row height
      }
    },
    headCells: {
      style: {
        padding: "0px 15px",
        minHeight: 'auto',
        backGround: "#f3f3f3",
        fontSize: "16px",
      }
    },
    cells: {
      style: {
        padding: "12px 0px 12px 10px",
        textAlign: 'left',
        maxWidth: '100px',
        fontSize: "16px",
      },
    },
  };
  const columns = [
    {
      name: 'Name',
      selector: 'organization_name',
      sortable: false
    },
    {
      name: 'Adresse',
      // selector: 'address',
      cell: row => <div>{row.street}, {row.city}</div>,
      sortable: false,
      grow: 3
    },
    {
      name: '',
      sortable: false,
      cell: row => <button className="maplocation" onClick={() => setMapLocation(row)} ><img src={btnView} alt="view Button" /></button>,

    }
  ];

  useEffect(() => {
    Cases.loadFile()
      .then((res) => res)
      .then((fileData) => {
        setExcelData(fileData)
        setTableData(fileData)
        var mapList = []
        for (var i = 0; i < 5; i++) {
          mapList.push({
            lat: parseFloat(fileData[i].lat),
            lng: parseFloat(fileData[i].lng),
            info:
              `<div><h2>${fileData[i].organization_name}</h2><p>${fileData[i].street}</p><p>${fileData[i].city}</p></div>`,
            title: fileData[i].organization_name
          })
        }
        // setMapData(mapstart);
        // setMapstart({ lat: parseFloat(13.404954), long: parseFloat(52.520008) });
        console.log("setMapstart", mapstart)
        setMapMarkers(mapList);
        // let lat = 13.404954;
        // let lng = 52.520008;
        setMapData({ lat: 52.520008, lng: 13.404954, heading: fileData[0].organization_name, info: fileData[0].city });
        // setMapData({ lat: parseFloat(fileData[0].lat), lng: parseFloat(fileData[0].lng), heading: fileData[0].organization_name, info: fileData[0].city });
        setWardCountry(keysToArray(fileData, "ward_country"));
        setTryData(keysToArray(fileData, "try"));
        loadGoogleMapScript(() => {
          setLoadMap(true);
        });
      })
  }, []);

  const setMapLocation = (row) => {
    setMapData({ lat: parseFloat(row.lat), lng: parseFloat(row.lng), heading: row.organization_name, info: row.city });
  }

  const updateSearchTable = (data) => {
    setTableData(data);
    setPageState(5);
  }

  const changePage = (state, row) => {
    var mapList = []

    if (state * 5 >= row) {
      var loop;
      if (row % 10 > 5) {
        loop = row % 10 - 5
      }
      else {

        loop = row % 10
      }
      if (loop === 1) {

        mapList.push(createMapObj({ ...tableData[row - 1] }))
      } else {

        for (let i = (state * 5 - loop - 2); i <= (row); i++) {
          mapList.push(createMapObj({ ...tableData[i] }))
        }
      }
    }
    else if (state * 5 - 5 === 0) {
      for (let i = 0; i < 5; i++) {
        mapList.push(createMapObj({ ...tableData[i] }))
      }
    }
    else if (pageState + 5 === state * 5) {
      for (let i = (pageState + 1); i <= state * 5; i++) {
        mapList.push(createMapObj({ ...tableData[i] }))
      }
    }
    else {
      for (let i = (pageState - 5); i > (state * 5 - 5); i--) {
        mapList.push(createMapObj({ ...tableData[i] }))
      }
    }
    setMapMarkers(mapList)
    setPageState(state * 5)
    setMapData(mapList[0])
  }

  const createMapObj = ({ ...obj }) => {

    return {
      lat: parseFloat(obj.lat),
      lng: parseFloat(obj.lng),
      info:
        `<div><h2>${obj.organization_name}</h2><p>${obj.organization_name}</p></div>`,
      title: obj.organization_name
    }
  }


  switch (true) {
    case excelData?.length > 0:
      return (

        <div className="container article-container">
          <div className="row">
            <PageTextComponent />
          </div>
          <div className="row">
            <div className="col-12 tableContainer">
              {/* <img src={productImage} alt="레덕손 약국 찾기 서비스 입니다. 약국을 검색해 주세요." className="img-fluid titleImage" /> */}
              {(wardCountry.length > 0 && tryData.length > 0) ?
                <SearchComponent
                  wardCountry={wardCountry}
                  tryData={tryData}
                  searchData={excelData}
                  updateSearchTable={updateSearchTable} />
                : null
              }
              {/* <button onClick={handlePrint} className="pdfBtn">
                <img src={printIcon} alt="pdf Icon" />
              </button> */}
              {!loadMap || tableData.length === 0 ? <div className="noResult"><h2>Seite nicht gefunden</h2></div> : <GMap mapData={mapData} mapMarkers={mapMarkers} />}
              <div className="tableWrapper">
                {
                  tableData.length > 0 ?
                    <DataTable
                      columns={columns}
                      data={tableData}
                      noHeader
                      pagination
                      paginationComponentOptions={{ rowsPerPageText: '', rangeSeparatorText: "의" }}
                      paginationPerPage={5}
                      theme="solarized"
                      defaultSortField={""}
                      customStyles={customStyles}
                      onChangePage={changePage}
                    /> : null
                }

              </div>
            </div>
          </div>

        </div>

      )
    default:
      return (<></>)
  }
};
export default DataTableContainer;
