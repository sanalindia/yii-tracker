import React from "react";
import "./App.css";
import "./css/components/style.scss";
/*
 *Component Imports
 */
import PrintComponent from "./components/PrintComponent";

function App() {
  return (
      <PrintComponent />
  );
}

export default App;
