import React, { Component } from "react";

class Breadcrumb extends Component {
  // constructor(props) {}
  render() {
    return (
      <div className="page-header">
        <h3 className="page-title">
          {this.props.projectId} {this.props.pagename}
        </h3>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/home">Home</a>
            </li>
            <li className="breadcrumb-item">
              <a href="/projects">Projects</a>
            </li>
            <li
              className="breadcrumb-item active"
              aria-current="page"
              onClick={(event) => event.preventDefault()}
            >
              {this.props.pagename}
            </li>
          </ol>
        </nav>
      </div>
    );
  }
}

export default Breadcrumb;
