import React, { Component } from "react";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import "./OutlineDropdown.scss";

class OutlineDropdown extends Component {
  // constructor(props) {}
  render() {
    return (
      <div className="outlineDropdownContainer">
        <Dropdown as={ButtonGroup} className="w-100">
          {/* <button
                              type="button"
                              className="btn btn-outline-secondary w-100"
                            >
                              Assign PM
                            </button> */}
          <Dropdown.Toggle
            variant="btn btn-outline-secondary"
            id="dropdownMenuOutlineButton1"
          >
            Dropdown
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>{" "}
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>{" "}
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>{" "}
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>{" "}
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>{" "}
            <Dropdown.Header>Settings</Dropdown.Header>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
            <Dropdown.Divider></Dropdown.Divider>
            <Dropdown.Item>Separated link</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
    );
  }
}

export default OutlineDropdown;
