import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import { withRouter } from "react-router-dom";
import "./polewar.scss";
import Breadcrumb from "../../../shared/Breadcrumb";

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">Edit Item</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="row">
          <div className="col-md-12 grid-margin stretch-card">
            <div className="card d-flex">
              <div className="card-body">
                {/* <h4 className="card-title">Default form</h4>
                <p className="card-description"> Basic form layout </p> */}
                <form className="forms-sample">
                  <div className="col-md-12 d-flex">
                    <div className="col-md-6">
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Sr No</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Item</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Item code</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Quantity</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Unit</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Rate</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Amount</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Type</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Work group</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Remark</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>

                      <button type="submit" className="btn btn-info mr-2">
                        Update
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
      {/* <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer> */}
    </Modal>
  );
}

export class Polewar extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
  };

  editWorkGroup = () => {
    const { history } = this.props;
    // Navigate to a different page
    this.setState({
      modalShow: true,
    });
  };

  render() {
    const { match } = this.props;
    const projectId = match.params.projectId;
    return (
      <div className="polewarContainer">
        <MyVerticallyCenteredModal
          show={this.state.modalShow}
          onHide={() =>
            this.setState({
              modalShow: false,
            })
          }
        />

        <Breadcrumb projectId={projectId} pagename={"Pole war"} />

        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                {/* <h4 className="card-title">Hoverable Table</h4> */}
                <div className="row grid-margin">
                  <div className="col-lg-8 d-flex">
                    <div className="col-lg-8">
                      <div className="search-field d-none d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="table-responsive">
                  <table className="table table-bordered">
                    <thead>
                      <tr>
                        <th>
                          <div className="form-check">
                            <label className="form-check-label text-muted">
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </th>
                        <th>Sr No</th>
                        <th>Pole code</th>
                        <th className="multi-head">
                          Cordinates
                          <tr>
                            <td className="width-7">lat</td>
                            <td className="width-7">lon</td>
                          </tr>
                        </th>
                        <th>Location</th>
                        <th className="multi-head">
                          Existing
                          <tr>
                            <td className="width-7">KSEB pole no</td>
                            <td className="width-7">PSC</td>
                            <td className="width-7">A11</td>
                            <td className="width-7">A12</td>
                            <td className="width-7">A14</td>
                          </tr>
                        </th>
                        <th className="multi-head">
                          Insertion
                          <tr>
                            <td className="width-7">PSC</td>
                            <td className="width-7">A11</td>
                            <td className="width-7">A12</td>
                            <td className="width-7">A14</td>
                          </tr>
                        </th>
                        <th>Span</th>
                        <th>Cumulative span</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td className="multi-head">
                          <tr>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="A Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                          </tr>
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="C Description"
                            size="sm"
                          />
                        </td>
                        <td className="multi-head">
                          <tr>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="A Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                          </tr>
                        </td>
                        <td className="multi-head">
                          <tr>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="A Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                            <td className="width-7">
                              <Form.Control
                                type="text"
                                id="exampleInputUsername1"
                                placeholder="B Description"
                                size="sm"
                              />
                            </td>
                          </tr>
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="C Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="C Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <button type="submit" className="btn btn-info mr-2">
                            ADD
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div className="form-check">
                            <label className="form-check-label text-muted">
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </td>
                        <td>Jacob</td>
                        <td>Photoshop1</td>
                        <td className="multi-head">
                          <tr className="height-4">
                            <td className="width-7">Photoshop21</td>
                            <td className="width-7">Photoshop22</td>
                          </tr>
                        </td>
                        <td>Photoshop3</td>
                        <td className="multi-head">
                          <tr className="height-4">
                            <td className="width-7">Photoshop41</td>
                            <td className="width-7">Photoshop42</td>
                            <td className="width-7">Photoshop43</td>
                            <td className="width-7">Photoshop44</td>
                            <td className="width-7">Photoshop45</td>
                          </tr>
                        </td>
                        <td className="multi-head">
                          <tr className="height-4">
                            <td className="width-7">Photoshop51</td>
                            <td className="width-7">Photoshop52</td>
                            <td className="width-7">Photoshop53</td>
                            <td className="width-7">Photoshop54</td>
                          </tr>
                        </td>
                        <td>Photoshop6</td>
                        <td>Photoshop7</td>

                        <td>
                          <Dropdown>
                            <Dropdown.Toggle variant="" id="dropdown-basic">
                              {/* <BsThreeDotsVertical /> */}
                              <i className="mdi mdi-dots-vertical"></i>
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                              <Dropdown.Item
                                href="#"
                                onClick={this.editWorkGroup}
                              >
                                Edit
                              </Dropdown.Item>
                              <Dropdown.Item href="#">Delete</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </td>
                      </tr>

                      <tr></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(Polewar);
