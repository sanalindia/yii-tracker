import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import { withRouter } from "react-router-dom";
import "./dailyProgressRegister.scss";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Breadcrumb from "../../../shared/Breadcrumb";

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">Edit Item</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="row">
          <div className="col-md-12 grid-margin stretch-card">
            <div className="card d-flex">
              <div className="card-body">
                {/* <h4 className="card-title">Default form</h4>
                <p className="card-description"> Basic form layout </p> */}
                <form className="forms-sample">
                  <div className="col-md-12 d-flex">
                    <div className="col-md-6">
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Sr No</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Item</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Item code</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Quantity</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Unit</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Rate</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">Amount</label>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Type</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Work group</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Remark</label>
                        <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        />
                      </Form.Group>

                      <button type="submit" className="btn btn-info mr-2">
                        Update
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
      {/* <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer> */}
    </Modal>
  );
}

export class DailyProgressRegister extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
  };

  editWorkGroup = () => {
    const { history } = this.props;
    // Navigate to a different page
    this.setState({
      modalShow: true,
    });
  };

  render() {
    const { match } = this.props;
    const projectId = match.params.projectId;
    return (
      <div className="dailyProgressRegisterContainer">
        <MyVerticallyCenteredModal
          show={this.state.modalShow}
          onHide={() =>
            this.setState({
              modalShow: false,
            })
          }
        />

        <Breadcrumb
          projectId={projectId}
          pagename={"Daily progress register"}
        />

        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <Tabs
                  defaultActiveKey="workgroup"
                  id="uncontrolled-tab-example"
                  className="mb-3"
                >
                  <Tab eventKey="workgroup" title="Workgroup">
                    <form className="forms-sample">
                      <div className="col-md-12 d-flex">
                        <div className="col-md-6">
                          <Form.Group>
                            <label htmlFor="exampleInputUsername1">
                              Approved Code
                            </label>
                            <Form.Control
                              type="text"
                              id="exampleInputUsername1"
                              placeholder="Username"
                              size="sm"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputUsername1">
                              Project manager
                            </label>
                            <Form.Control
                              type="text"
                              id="exampleInputUsername1"
                              placeholder="Username"
                              size="sm"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">Site</label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">
                              Contractor
                            </label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">WO No</label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                        </div>
                        <div className="col-md-6">
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">Date</label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputUsername1">
                              Pole start no plan
                            </label>
                            <Form.Control
                              type="text"
                              id="exampleInputUsername1"
                              placeholder="Username"
                              size="sm"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">
                              {" "}
                              Pole end no plan
                            </label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                          <Form.Group>
                            <label htmlFor="exampleInputEmail1">
                              Work group 1
                            </label>
                            <Form.Control
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Email"
                            />
                          </Form.Group>
                          <div className="col-sm-12 pl-md-0 mt-5">
                            <button type="submit" className="btn btn-info mr-2">
                              ADD
                            </button>

                            <button type="submit" className="btn btn-info mr-2">
                              View work register
                            </button>
                            <button type="submit" className="btn btn-info mr-2">
                              Work request
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </Tab>
                  <Tab eventKey="signedIn" title="SignIn">
                    <div className="col-md-12 d-flex">
                      <div className="col-md-7">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">
                            KSEB permit
                          </label>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Username"
                            size="sm"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-md-3  pl-md-0 mt-4 ">
                        <Form.Group>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Username"
                            size="sm"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-md-2 pl-md-0 mt-4 ">
                        <button type="submit" className="btn btn-info mr-2">
                          UPLOAD
                        </button>
                      </div>
                    </div>
                    <div className="col-md-12 d-flex">
                      <div className="col-md-4">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">
                            Number of labours
                          </label>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Username"
                            size="sm"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-md-3">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">
                            Verify Insurance
                          </label>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Username"
                            size="sm"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-md-3">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">
                            Site status
                          </label>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Username"
                            size="sm"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-sm-3 pl-md-0 mt-4">
                        <button type="submit" className="btn btn-info mr-2">
                          APPLY
                        </button>
                      </div>
                    </div>
                    <div className="col-md-12 d-flex justify-content-center">
                      <button type="submit" className="btn btn-info mr-2">
                        Sign-in to daily progress register
                      </button>
                    </div>
                    <form className="forms-sample">
                      <div className="col-md-12 d-flex"></div>
                    </form>
                  </Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                {/* <h4 className="card-title">Hoverable Table</h4> */}
                <div className="row grid-margin">
                  <div className="col-md-6 d-flex">
                    <div className="col-md-7">
                      <label> Work group</label>
                      <Form.Group>
                        <Form.Control
                          type="text"
                          id="exampleInputUsername1"
                          placeholder="Username"
                          size="sm"
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-5 d-flex flex-column align-item-center">
                      <label>(Project manager)</label>
                      <div className="d-flex">
                        <button type="submit" className="btn btn-success mr-2">
                          APPROVE
                        </button>
                        <button type="submit" className="btn btn-danger mr-2">
                          RETURN
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row grid-margin">
                  <div className="col-lg-8 d-flex">
                    <div className="col-lg-8">
                      <div className="search-field d-none d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>Pole. No.</th>
                        <th>Item code</th>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Remark</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <button type="submit" className="btn btn-info mr-2">
                            ADD
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>P001</td>
                        <td></td>
                        <td>Suspension clamp</td>
                        <td>1</td>
                        <td></td>
                        <td>
                          <Dropdown>
                            <Dropdown.Toggle variant="" id="dropdown-basic">
                              {/* <BsThreeDotsVertical /> */}
                              <i className="mdi mdi-dots-vertical"></i>
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                              <Dropdown.Item
                                href="#"
                                onClick={this.editWorkGroup}
                              >
                                Edit
                              </Dropdown.Item>
                              <Dropdown.Item href="#">Delete</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                          {/* <div className="dropdown">
                                <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li><a className="dropdown-item" href="#">Action 1</a></li>
                                    <li><a className="dropdown-item" href="#">Action 2</a></li>
                                    <li><a className="dropdown-item" href="#">Action 3</a></li>
                                </ul>
                            </div> */}
                        </td>
                      </tr>
                      <tr>
                        <td>P001</td>
                        <td></td>
                        <td>Strap</td>
                        <td>0.75m </td>
                        <td>3 rings used due to wider span</td>
                        <td>
                          <Dropdown>
                            <Dropdown.Toggle variant="" id="dropdown-basic">
                              {/* <BsThreeDotsVertical /> */}
                              <i className="mdi mdi-dots-vertical"></i>
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                              <Dropdown.Item
                                href="#"
                                onClick={this.editWorkGroup}
                              >
                                Edit
                              </Dropdown.Item>
                              <Dropdown.Item href="#">Delete</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                          {/* <div className="dropdown">
                                <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li><a className="dropdown-item" href="#">Action 1</a></li>
                                    <li><a className="dropdown-item" href="#">Action 2</a></li>
                                    <li><a className="dropdown-item" href="#">Action 3</a></li>
                                </ul>
                            </div> */}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>Start Pole. No</th>
                        <th>End pole no </th>
                        <th>Phase</th>
                        <th>Item code</th>
                        <th>Item</th>
                        <th>Drum no</th>
                        <th>Start length mark</th>
                        <th>End length mark </th>
                        <th>DAL</th>
                        <th>DML</th>
                        <th>MDCL</th>
                        <th>Used Qty</th>
                        <th>Balance qty</th>
                        <th>Location of balance stock</th>
                        <th>New DML</th>
                        <th>Photo upload</th>
                        <th>Remark</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <button type="submit" className="btn btn-info mr-2">
                            ADD
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>P001</td>
                        <td>P010</td>
                        <td>R</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                          <Dropdown>
                            <Dropdown.Toggle variant="" id="dropdown-basic">
                              {/* <BsThreeDotsVertical /> */}
                              <i className="mdi mdi-dots-vertical"></i>
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                              <Dropdown.Item
                                href="#"
                                onClick={this.editWorkGroup}
                              >
                                Edit
                              </Dropdown.Item>
                              <Dropdown.Item href="#">Delete</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(DailyProgressRegister);
