import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import { Table, Dropdown, Modal, Button, Form } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import Breadcrumb from "../../../shared/Breadcrumb";

function MyVerticallyCenteredModal(props) {
  console.log("edit data ", props.editdata);
  const handleChange = (field, e) => {
    let fields = this.state.fields;
    fields[field] = e.target.value;
    this.setState({ fields });
  };
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Edit Work group
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="row">
          <div className="col-md-12 grid-margin stretch-card">
            <div className="card d-flex">
              <div className="card-body">
                {/* <h4 className="card-title">Default form</h4>
                <p className="card-description"> Basic form layout </p> */}
                <form className="forms-sample">
                  <div className="col-md-12 d-flex">
                    <div className="col-md-12">
                      <Form.Group>
                        <label htmlFor="exampleInputUsername1">
                          Work group
                        </label>
                        <Form.Control
                          type="text"
                          placeholder="Work group"
                          size="lg"
                          // onChange={handleChange.(this, "name")}
                          value={props.editdata.group}
                          name="workgroup"
                        />
                      </Form.Group>
                      <Form.Group>
                        <label htmlFor="exampleInputEmail1">Description</label>
                        <Form.Control
                          type="text"
                          className="form-control"
                          placeholder="Description"
                          name="description"
                        />
                      </Form.Group>
                      <button
                        type="submit"
                        className="btn btn-gradient-primary mr-2"
                      >
                        Update
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export class WorkGroupComponent extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
    dataList: [
      { group: "Excavation", description: "detailing Excavation" },
      { group: "Stringing", description: "detailing Stringing" },
      { group: "Clamping", description: "detailing Clamping" },
    ],
    currentData: {},
  };

  editWorkGroup = (editData) => {
    alert("dd");
    const { history } = this.props;
    this.setState({
      currentData: editData,
    });
    // Navigate to a different page
    this.setState({
      modalShow: true,
    });
  };

  render() {
    const { match } = this.props;
    const projectId = match.params.projectId;
    return (
      <div>
        <MyVerticallyCenteredModal
          show={this.state.modalShow}
          editdata={this.state.currentData}
          onHide={() =>
            this.setState({
              modalShow: false,
            })
          }
        />

        <Breadcrumb projectId={projectId} pagename={"Work group"} />

        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                {/* <h4 className="card-title">Hoverable Table</h4> */}
                <div className="row grid-margin">
                  <div className="col-lg-8 d-flex">
                    <div className="col-lg-8">
                      <div className="search-field d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>
                          <div className="form-check">
                            <label className="form-check-label text-muted">
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </th>
                        <th>Work group</th>
                        <th>Description</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter work group"
                            size="lg"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="lg"
                          />
                        </td>
                        <td>
                          <button type="submit" className="btn btn-info mr-2">
                            ADD
                          </button>
                        </td>
                      </tr>
                      {this.state.dataList.map((data, i) => {
                        return (
                          <tr key={i}>
                            <td>
                              <div className="form-check">
                                <label className="form-check-label text-muted">
                                  <input
                                    type="checkbox"
                                    className="form-check-input"
                                  />
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </td>
                            <td>{data.group}</td>
                            <td>{data.description}</td>
                            <td>
                              <Dropdown>
                                <Dropdown.Toggle variant="" id="dropdown-basic">
                                  {/* <BsThreeDotsVertical /> */}
                                  <i className="mdi mdi-dots-vertical"></i>
                                </Dropdown.Toggle>

                                <Dropdown.Menu>
                                  <Dropdown.Item
                                    href="#"
                                    onClick={() => this.editWorkGroup(data)}
                                  >
                                    Edit
                                  </Dropdown.Item>
                                  <Dropdown.Item href="#">Delete</Dropdown.Item>
                                </Dropdown.Menu>
                              </Dropdown>
                              {/* <div className="dropdown">
                                  <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                      <i className="bi bi-three-dots-vertical"></i>
                                  </button>
                                  <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                      <li><a className="dropdown-item" href="#">Action 1</a></li>
                                      <li><a className="dropdown-item" href="#">Action 2</a></li>
                                      <li><a className="dropdown-item" href="#">Action 3</a></li>
                                  </ul>
                              </div> */}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(WorkGroupComponent);
