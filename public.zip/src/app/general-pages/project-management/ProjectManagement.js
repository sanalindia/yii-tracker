import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import Breadcrumb from "../../shared/Breadcrumb";
import "./ProjectManagement.scss";
import OutlineDropdown from "../../shared/OutlineDropdown/OutlineDropdown";

function MyVerticallyCenteredModal(props) {
  return (
    <div className="projectManagementModal">
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Add new project
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-sm-12 grid-margin stretch-card">
              <div className="card d-flex">
                <div className="card-body modal-body-card">
                  {/* <h4 className="card-title">Default form</h4>
                <p className="card-description"> Basic form layout </p> */}
                  <form className="forms-sample">
                    <div className="col-sm-12 d-flex">
                      <div className="col-sm-6 new-pro-modal-partition">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">
                            Project code
                          </label>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Project code"
                            size="lg"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">
                            Project name
                          </label>
                          <Form.Control
                            type="email"
                            className="form-control"
                            id="exampleInputEmail1"
                            placeholder="Project name"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputPassword1">
                            Assigned PM
                          </label>
                          <OutlineDropdown text="Select PM" />
                          {/* <Form.Control type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" /> */}
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputConfirmPassword1">
                            Year
                          </label>
                          <Form.Control
                            type="password"
                            className="form-control"
                            id="exampleInputConfirmPassword1"
                            placeholder="Year"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">WO value</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            id="exampleInputEmail1"
                            placeholder="WO value"
                          />
                        </Form.Group>
                      </div>

                      <div className="col-sm-6 new-pro-modal-partition">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">Status</label>
                          <OutlineDropdown text="Choose status" />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputPassword1">Client</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            id="exampleInputPassword1"
                            placeholder="Client"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputConfirmPassword1">
                            Location
                          </label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            id="exampleInputConfirmPassword1"
                            placeholder="Location"
                          />
                        </Form.Group>
                        <div className="form-check">
                          <label className="form-check-label text-muted">
                            <input
                              type="checkbox"
                              className="form-check-input"
                            />
                            <i className="input-helper"></i>
                            Remember me
                          </label>
                        </div>
                        <button
                          type="submit"
                          className="btn btn-gradient-primary mr-2"
                        >
                          Submit
                        </button>
                        <button
                          type="button"
                          onClick={props.onHide}
                          className="btn btn-light"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
        {/* <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer> */}
      </Modal>
    </div>
  );
}

export class ProjectManagement extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
    projectsData: [
      {
        projectCode: "PJ 144",
        projectName: "33 KV RDSS",
        year: "2023-2024",
        WOvalue: "20,00,00,000",
        client: "KSEB",
        location: "Kannur",
        status: "Ongoing",
      },
      {
        projectCode: "PJ 151",
        projectName: "11 KV RDSS",
        year: "2023-2024",
        WOvalue: "18,00,00,000",
        client: "KSEB",
        location: "Malapuram",
        status: "Completed",
      },
      {
        projectCode: "PJ 151",
        projectName: "11 KV RDSS",
        year: "2023-2024",
        WOvalue: "18,00,00,000",
        client: "KSEB",
        location: "Malapuram",
        status: "Completed",
      },
      {
        projectCode: "PJ 151",
        projectName: "11 KV RDSS",
        year: "2023-2024",
        WOvalue: "18,00,00,000",
        client: "KSEB",
        location: "Malapuram",
        status: "Completed",
      },
      {
        projectCode: "PJ 151",
        projectName: "11 KV RDSS",
        year: "2023-2024",
        WOvalue: "18,00,00,000",
        client: "KSEB",
        location: "Malapuram",
        status: "Completed",
      },
    ],
  };

  render() {
    return (
      <div className="projectManagementContainer">
        <MyVerticallyCenteredModal
          show={this.state.modalShow}
          onHide={() =>
            this.setState({
              modalShow: false,
            })
          }
        />

        <Breadcrumb projectId={""} pagename={"Project Management"} />
        <div className="row">
          <div className="col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                {/* <h4 className="card-title">Hoverable Table</h4> */}
                <div className="row grid-margin">
                  <div className="col-sm-8 d-flex searcharea">
                    <div className="col-sm-8">
                      <div className="search-field d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                    <div className="col-sm-4 project-dropdown">
                      <Dropdown>
                        <Dropdown.Toggle
                          variant="btn btn-outline-info"
                          id="dropdownMenuOutlineButton1"
                        >
                          All projects
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          {/* <Dropdown.Header>Settings</Dropdown.Header> */}
                          <Dropdown.Item>Action</Dropdown.Item>
                          <Dropdown.Item>Another action</Dropdown.Item>
                          <Dropdown.Item>Something else here</Dropdown.Item>
                          <Dropdown.Divider></Dropdown.Divider>
                          <Dropdown.Item>Separated link</Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                  <div className="col-sm-4 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-gradient-info btn-fw"
                      onClick={() =>
                        this.setState({
                          modalShow: true,
                        })
                      }
                    >
                      Add new project
                    </button>
                  </div>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>Project code</th>
                        <th>Project name</th>
                        <th>WO Value</th>
                        <th>Client</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.projectsData.map((data, i) => {
                        return (
                          <tr key={i}>
                            <td>{data.projectCode}</td>
                            <td>{data.projectName}</td>
                            <td className="text-danger">
                              {data.WOvalue}
                              <i className="mdi mdi-arrow-down"></i>
                            </td>
                            <td>{data.client}</td>
                            <td>{data.location}</td>
                            <td>
                              <label className="badge badge-danger">
                                {data.status}
                              </label>
                            </td>
                            <td>
                              <Dropdown>
                                <Dropdown.Toggle variant="" id="dropdown-basic">
                                  {/* <BsThreeDotsVertical /> */}
                                  <i className="mdi mdi-dots-vertical"></i>
                                </Dropdown.Toggle>

                                <Dropdown.Menu>
                                  <Dropdown.Item href="#">
                                    Project dashboard
                                  </Dropdown.Item>
                                  <Dropdown.Item href="#">
                                    Project summary
                                  </Dropdown.Item>
                                  <Dropdown.Item
                                    href={`/workGroup/${data.projectCode}`}
                                  >
                                    Work group
                                  </Dropdown.Item>
                                  <Dropdown.Item
                                    href={`/bill-of-quantity/${data.projectCode}`}
                                  >
                                    Bill of Quantities
                                  </Dropdown.Item>
                                  <Dropdown.Item href="#">
                                    Tender Details
                                  </Dropdown.Item>
                                  <Dropdown.Item href="#">
                                    Site list
                                  </Dropdown.Item>
                                  <Dropdown.Item
                                    href={`/polewar/${data.projectCode}`}
                                  >
                                    Polewar
                                  </Dropdown.Item>
                                  <Dropdown.Item
                                    href={`/daily-progress-register/${data.projectCode}`}
                                  >
                                    Daily progress register
                                  </Dropdown.Item>
                                  <Dropdown.Item
                                    href={`/work-register/${data.projectCode}`}
                                  >
                                    Work Register
                                  </Dropdown.Item>
                                </Dropdown.Menu>
                              </Dropdown>
                              {/* <div className="dropdown">
                                <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li><a className="dropdown-item" href="#">Action 1</a></li>
                                    <li><a className="dropdown-item" href="#">Action 2</a></li>
                                    <li><a className="dropdown-item" href="#">Action 3</a></li>
                                </ul>
                            </div> */}
                            </td>
                          </tr>
                        );
                      })}

                      {/* <tr>
                        <td>Messsy</td>
                        <td>Flash</td>
                        <td className="text-danger">
                          {" "}
                          21.06% <i className="mdi mdi-arrow-down"></i>
                        </td>
                        <td>KSEB</td>
                        <td>Kannur</td>
                        <td>
                          <label className="badge badge-warning">
                            In progress
                          </label>
                        </td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>John</td>
                        <td>Premier</td>
                        <td className="text-danger">
                          {" "}
                          35.00% <i className="mdi mdi-arrow-down"></i>
                        </td>
                        <td>KSEB</td>
                        <td>Kannur</td>
                        <td>
                          <label className="badge badge-info">Fixed</label>
                        </td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Peter</td>
                        <td>After effects</td>
                        <td className="text-success">
                          {" "}
                          82.00% <i className="mdi mdi-arrow-up"></i>
                        </td>
                        <td>KSEB</td>
                        <td>Kannur</td>
                        <td>
                          <label className="badge badge-success">
                            Completed
                          </label>
                        </td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>Dave</td>
                        <td>53275535</td>
                        <td className="text-success">
                          {" "}
                          98.05% <i className="mdi mdi-arrow-up"></i>
                        </td>
                        <td>KSEB</td>
                        <td>Kannur</td>
                        <td>
                          <label className="badge badge-warning">
                            In progress
                          </label>
                        </td>
                        <td></td>
                      </tr>
                      <tr></tr> */}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProjectManagement;
