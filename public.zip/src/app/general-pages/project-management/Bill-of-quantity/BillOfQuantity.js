import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import { withRouter } from "react-router-dom";
import Breadcrumb from "../../../shared/Breadcrumb";
import OutlineDropdown from "../../../shared/OutlineDropdown/OutlineDropdown";
import "./BillOfQuantity.scss";

function MyVerticallyCenteredModal(props) {
  return (
    <div className="billOfQuantityModal">
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Edit Item
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12 grid-margin stretch-card">
              <div className="card d-flex">
                <div className="card-body modal-body-card">
                  {/* <h4 className="card-title">Default form</h4>
                <p className="card-description"> Basic form layout </p> */}
                  <form className="forms-sample">
                    <div className="col-md-12 d-flex">
                      <div className="col-md-6">
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">Sr No</label>
                          <Form.Control
                            type="text"
                            placeholder="Serial No"
                            size="sm"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">Item</label>
                          <Form.Control
                            type="text"
                            placeholder="Item name"
                            size="sm"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Item code</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            placeholder="Item code"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Quantity</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            placeholder="Quantity"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Unit</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            placeholder="Unit"
                          />
                        </Form.Group>
                      </div>
                      <div className="col-md-6">
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Rate</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            placeholder="Rate"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputUsername1">Amount</label>
                          <Form.Control
                            type="text"
                            placeholder="Amount"
                            size="sm"
                          />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Type</label>
                          <OutlineDropdown text="Select type" />
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Work group</label>
                          <OutlineDropdown text="Select work group" />
                          {/* <Form.Control
                          type="email"
                          className="form-control"
                          id="exampleInputEmail1"
                          placeholder="Email"
                        /> */}
                        </Form.Group>
                        <Form.Group>
                          <label htmlFor="exampleInputEmail1">Remark</label>
                          <Form.Control
                            type="text"
                            className="form-control"
                            placeholder="Remark"
                          />
                        </Form.Group>

                        <button type="submit" className="btn btn-info mr-2">
                          Update
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
        {/* <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer> */}
      </Modal>
    </div>
  );
}

export class BillOfQuantity extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
    itemList: [
      {
        SrNo: "1",
        Item: "120 sqmm cable",
        ItemCode: "",
        Quantity: "36000",
        Unit: "m",
        Rate: "840",
        Amount: "xxx",
        Type: "Turnkey",
        WorkGroup: "",
        Remark: "",
      },
      {
        SrNo: "2",
        Item: "130 sqmm cable",
        ItemCode: "",
        Quantity: "",
        Unit: "",
        Rate: "",
        Amount: "",
        Type: "Item-wise",
        WorkGroup: "",
        Remark: "",
      },
    ],
  };

  editWorkGroup = () => {
    const { history } = this.props;
    // Navigate to a different page
    this.setState({
      modalShow: true,
    });
  };

  render() {
    const { match } = this.props;
    const projectId = match.params.projectId;
    return (
      <div className="billOfQuantityContainer">
        <MyVerticallyCenteredModal
          show={this.state.modalShow}
          onHide={() =>
            this.setState({
              modalShow: false,
            })
          }
        />

        <Breadcrumb projectId={projectId} pagename={"Bill of quantity"} />

        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                {/* <h4 className="card-title">Hoverable Table</h4> */}
                <div className="row grid-margin">
                  <div className="col-lg-8 d-flex searcharea">
                    <div className="col-lg-8">
                      <div className="search-field d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>
                          <div className="form-check">
                            <label className="form-check-label text-muted">
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </th>
                        <th>Sr No</th>
                        <th colSpan={2}>Item</th>
                        <th>Item code</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Rate</th>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Work group</th>
                        <th>Remark</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td colSpan={2}>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          {/* <Form.Control as="select" custom>
                            <option value="1">Option 1</option>
                            <option value="2">Option 2</option>
                            <option value="3">Option 3</option>
                            <option value="4">Option 4</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                            <option value="5">Option 5</option>
                          </Form.Control> */}
                          <Dropdown as={ButtonGroup} size="sm">
                            <Dropdown.Toggle
                              variant="btn btn-secondary dropdown-toggle dropdown-toggle-split"
                              id="dropdownMenuSplitButton4"
                              size="sm"
                            >
                              Toggle Dropdown
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                              <Dropdown.Header>Settings</Dropdown.Header>
                              <Dropdown.Item>Action</Dropdown.Item>
                              <Dropdown.Item>Another action</Dropdown.Item>
                              <Dropdown.Divider></Dropdown.Divider>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                          {/* <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          /> */}
                        </td>
                        <td>
                          <Dropdown as={ButtonGroup} size="sm">
                            <Dropdown.Toggle
                              variant="btn btn-secondary dropdown-toggle dropdown-toggle-split"
                              id="dropdownMenuSplitButton4"
                              size="sm"
                            >
                              Toggle Dropdown
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                              <Dropdown.Header>Settings</Dropdown.Header>
                              <Dropdown.Item>Action</Dropdown.Item>
                              <Dropdown.Item>Another action</Dropdown.Item>
                              <Dropdown.Divider></Dropdown.Divider>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                              <Dropdown.Item>Separated link</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </td>
                        <td>
                          <Form.Control
                            type="text"
                            id="exampleInputUsername1"
                            placeholder="Enter Description"
                            size="sm"
                          />
                        </td>
                        <td>
                          <button type="submit" className="btn btn-info mr-2">
                            ADD
                          </button>
                        </td>
                      </tr>
                      {this.state.itemList.map((data, i) => {
                        return (
                          <tr key={i}>
                            <td>
                              <div className="form-check">
                                <label className="form-check-label text-muted">
                                  <input
                                    type="checkbox"
                                    className="form-check-input"
                                  />
                                  <i className="input-helper"></i>
                                </label>
                              </div>
                            </td>
                            <td>{data.SrNo}</td>
                            <td colSpan={2}>{data.Item}</td>
                            <td>{data.ItemCode}</td>
                            <td>{data.Quantity}</td>
                            <td>{data.Unit}</td>
                            <td>{data.Rate}</td>
                            <td>{data.Amount}</td>
                            <td>{data.Type}</td>
                            <td>{data.WorkGroup}</td>
                            <td>{data.Remark}</td>
                            <td>
                              <Dropdown>
                                <Dropdown.Toggle variant="" id="dropdown-basic">
                                  {/* <BsThreeDotsVertical /> */}
                                  <i className="mdi mdi-dots-vertical"></i>
                                </Dropdown.Toggle>

                                <Dropdown.Menu>
                                  <Dropdown.Item
                                    href="#"
                                    onClick={this.editWorkGroup}
                                  >
                                    Edit
                                  </Dropdown.Item>
                                  <Dropdown.Item href="#">Delete</Dropdown.Item>
                                </Dropdown.Menu>
                              </Dropdown>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(BillOfQuantity);
