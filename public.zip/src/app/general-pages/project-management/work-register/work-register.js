import React, { Component } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import {
  Table,
  Dropdown,
  Modal,
  Button,
  Form,
  ButtonGroup,
} from "react-bootstrap";
import { withRouter } from "react-router-dom";
import "./work-register.scss";
import Breadcrumb from "../../../shared/Breadcrumb";

export class workRegister extends Component {
  // const [modalShow, setModalShow] = useState(false);
  state = {
    modalShow: false,
  };

  editWorkGroup = () => {
    const { history } = this.props;
    // Navigate to a different page
    this.setState({
      modalShow: true,
    });
  };

  render() {
    const { match } = this.props;
    const projectId = match.params.projectId;
    return (
      <div className="workRegisterContainer">
        <Breadcrumb projectId={projectId} pagename={"Work register"} />
        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="row grid-margin">
                  <div className="col-md-10 d-flex">
                    <div className="col-md-7">
                      <div className="search-field d-none d-md-block">
                        <form
                          className="d-flex align-items-center h-100"
                          action="#"
                        >
                          <div className="input-group">
                            <div className="input-group-prepend bg-transparent">
                              <i className="input-group-text border-0 mdi mdi-magnify"></i>
                            </div>
                            <input
                              type="text"
                              className="form-control bg-transparent border-1"
                              placeholder="Search projects"
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                    <div className="col-md-5 d-flex flex-column align-item-center">
                      <div className="d-flex">
                        <button type="submit" className="btn btn-info">
                          Work register report
                        </button>
                        <button type="submit" className="btn btn-link mr-2">
                          Sudhev
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Sr. no.</th>
                        <th>Work code </th>
                        <th>Work Date </th>
                        <th>Site</th>
                        <th>Contractor</th>
                        <th>Work order no</th>
                        <th>Work group 1</th>
                        <th>Work group 2</th>
                        <th>Work group 3</th>
                        <th>Pole begin</th>
                        <th>Pole End</th>
                        <th>Site engg</th>
                        <th>Permit verified </th>
                        <th>Status</th>
                        <th>Action</th>
                        <th>DPR</th>
                        <th>Comment by site engg</th>
                        <th>Comment by manager</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <div className="form-check">
                            <label className="form-check-label text-muted">
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <i className="input-helper"></i>
                            </label>
                          </div>
                        </td>
                        <td>P001</td>
                        <td>P010</td>
                        <td>R</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                          <button
                            type="submit"
                            className="btn btn-info btn-sm mr-2"
                          >
                            Approve
                          </button>
                        </td>
                        <td>
                          <button
                            type="submit"
                            className="btn btn-info btn-sm mr-2"
                          >
                            view
                          </button>
                        </td>
                        <td>
                          <button
                            type="submit"
                            className="btn btn-info btn-sm mr-2"
                          >
                            view
                          </button>
                        </td>
                        <td>
                          <button
                            type="submit"
                            className="btn btn-info btn-sm mr-2"
                          >
                            view
                          </button>
                        </td>
                        <td>
                          <Dropdown>
                            <Dropdown.Toggle variant="" id="dropdown-basic">
                              {/* <BsThreeDotsVertical /> */}
                              <i className="mdi mdi-dots-vertical"></i>
                            </Dropdown.Toggle>

                            <Dropdown.Menu>
                              <Dropdown.Item
                                href="#"
                                onClick={this.editWorkGroup}
                              >
                                Edit
                              </Dropdown.Item>
                              <Dropdown.Item href="#">Delete</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(workRegister);
