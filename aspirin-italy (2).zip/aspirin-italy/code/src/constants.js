export const Constants = {
  q1: "6f9f7f1c-7c91-421b-ac02-a253daa7563f",
  q2: "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
  q3: "a79cca53-edab-4e55-937f-7a11be655a9b",
  q4: "cce5728e-2922-444b-bb3a-d87eeea4d99f",
  q5: "d0e11505-48ed-4d3a-9e5d-b489845b19f0",
  q6: "2ef46d88-9971-40c3-9fef-89d8a45b401a",
  q7: "82d49ade-1e56-40a1-bd16-dd997e1ce1bc",

  questionMappingArray: {
    // "Qual è il sintomo che si vuole trattare?",
    "6f9f7f1c-7c91-421b-ac02-a253daa7563f": {
      // Sintomi di raffreddore e influenza
      "66b6ac2a-3205-4505-8620-d39e35b61139":
        "70f31355-ecc4-4c80-ae96-a4347f5d19b3",
      //Mal di gola
      "b4a09897-4606-41d1-b2cd-bad1e13be4e1":
        "aa71603c-0935-4819-adfa-18110f988efa",
      //Mal di testa o dolore cervicale
      "35923780-c9e1-4b55-bfdd-de0bf217cdd9":
        "be2a84c4-4031-437d-9898-7dee4f2e4dc2",
    },
    //Quanti anni ha la persona con i sintomi?
    "70f31355-ecc4-4c80-ae96-a4347f5d19b3": {
      // Meno di 16 anni
      "f2a07d0b-bece-4e82-90c4-1266645ce0da": "no_products",
      //16 anni o pi
      "98e03874-cfe8-426b-88ff-fd903681b382":
        "66d28607-2c33-44d2-8363-b41e79faf4c0",
    },

    //Quanti anni ha la persona con mal di gola?
    "aa71603c-0935-4819-adfa-18110f988efa": {
      //  Meno di 6 anni
      "079af2a7-ce68-4e14-b7bd-ad7725c9b386": "productSet11",
      //Tra i 6 e 11 anni
      "b416f1dd-3b95-4cb6-95f2-85538dc854fe": "productSet2",
      //Tra i 12 e 17 anni
      "e26a7c79-e278-4926-9365-d8cfeca69c3a":
        "d7e9fe60-6eb9-4718-8d4b-44022af3a26e",
      //18 anni o pi\u00f9
      "68b579ef-5fb9-4317-9a98-0634b8e8848f":
        "e9f40901-c081-4a28-b34c-2a2a775ec1b4",
    },

    //Quanti anni ha la persona con dolore?
    "be2a84c4-4031-437d-9898-7dee4f2e4dc2": {
      // Meno di 16 anni
      "9da2f57f-4d98-4645-9a2d-e62d73db9ab9": "no_products2",
      //16 anni o pi\u00f9
      "2d5ae6e3-8ba9-4d86-b3f5-4d6d473279c8":
        "1ba50a1d-7ec5-4332-bee6-9710a09acdf1",
    },

    //Qual è il sintomo prevalente che prova e che vuol trattare?
    "66d28607-2c33-44d2-8363-b41e79faf4c0": {
      //  Primi sintomi di raffreddore e influenza
      "2aa635cc-83d0-4fa0-ad6a-6da4fc0768d4": "productSet3",
      //Febbre
      "3dfeab93-edef-433d-b38a-f7412fd608eb": "productSet4",
      //Naso congestionato (difficoltà a respirare con il naso)
      "7d41bb7e-128a-4e3d-a6e6-60c162d5d93f": "productSet5",
      //Tosse
      "f6e8655c-49c9-401f-a60b-7fced3fa6f65": "productSet2",
    },

    //Quanto è intenso il mal di gola?
    "d7e9fe60-6eb9-4718-8d4b-44022af3a26e": {
      //Lieve: gola secca, senso di irritazione che quando aumenta induce la tosse
      "1133e4f0-b00f-443e-8705-a6fda8fca2ce": "productSet2",
      //Moderato-intenso: dolore e tosse che possono peggiorare quando si deglutisce
      "f69cd860-9b98-42cd-8571-3dd08c28dcfb": "productSet6",
    },

    //Quanto è intenso il mal di gola?
    "e9f40901-c081-4a28-b34c-2a2a775ec1b4": {
      //Lieve: gola secca, senso di irritazione che quando aumenta induce la tosse
      "3db51d58-467c-4b6b-9adc-2e6b25d4b84b": "productSet2",
      //Moderato-intenso: dolore e tosse che possono peggiorare quando si deglutisce
      "bad2f573-de56-4e1d-81ee-e7d5c6474a5b": "productSet6",
      //Intenso: dolore, bruciore e tosse che peggiorano quando si deglutisce. Sensazione di gola gonfia
      "3cf4732e-c0fa-4008-a0c2-c9114dba312e": "productSet7",
    },

    //Che caratteristiche ha il dolore?
    "1ba50a1d-7ec5-4332-bee6-9710a09acdf1": {
      //Mal di testa lieve: dolore avvolge la testa come un casco, o preme come un peso. Non è forte ma costante, e può durare anche più giorni.
      "8b806aef-851b-4523-b8f4-a1a1fcee42d5": "productSet8",
      //Mal di testa forte: la testa pulsa, il dolore peggiora se si cammina o si fanno lescale. Alle volte ci sono anche fastidio per la luce o per i rumori.
      "195900f5-c824-4a25-a3ea-54037498c63b": "productSet9",
      //Mal di testa forte: la testa pulsa, il dolore peggiora se si cammina o si fanno lescale. Alle volte ci sono anche fastidio per la luce o per i rumori.Dolore cervicale: il dolore parte dal collo e risale lungo la nuca fino ad arrivare alla sommità del capo. Alle volte il dolore si limita al collo e alle spalle.
      "eb8e5615-b06e-43a6-b5a0-5bde1a84a42f": "productSet10",
      //Mal di testa da sinusite: il dolore arriva al viso, dà una sensazione di pressione su occhi, guance e/o naso e può peggiorare se si abbassa la faccia.
      "435fba2e-d260-4b69-bf13-72005d889f49": "productSet9",
      //Il dolore non assomiglia a nessuna delle condizioni descritte.
      "c3178fe0-ee93-4367-8a46-6181c60c7fed": "no_products1",
    },
  },

  ResultMappingArray: {
    // Male
    "7529905e-52ca-40d9-9606-f684bbf616bc": {
      // yes
      "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_1",
      //No
      "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_2",
    },
    //Female
    "433b3af0-eb08-4ca9-a75f-d05c4de5636b": {
      //thrush
      "74d382c1-bbcc-44c7-ad4d-6e149d9cd0a2": {
        //Yes
        "fa32b062-5f44-436e-a874-80b616284271": "Result_3",
        //No
        "5bfd7119-6c64-4391-bff4-c00a8a45a523": {
          //ORAL
          "4211e4d6-ca1e-4440-8e60-bf2af064b67b": {
            //yes
            "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_4",
            //No
            "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_5",
          },
          //VAGINAL
          "8d64b717-3736-4e2d-97b8-7cf36c7ad1da": {
            //EASY INSERT SOFT GEL
            "0f3d0043-5efd-4fd6-ab38-988ba6484fcd": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_3",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_7",
            },
            //SOOTHING VAGINAL CREAM
            "d57b3f8b-b0de-4387-9c21-959cb1ae45a0": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_8",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_9",
            },
            //VAGINAL TABLET
            "2f1dba46-6250-439f-be37-007b735e5627": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_10",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_11",
            },
          },
        },
      },
      //BACTERIAL VAGINOSIS (BV)
      "5046ab7d-b8bb-40be-b131-14ea1f4870e3": {
        //VAGINAL GEL
        "9bc559a5-590c-42cd-96f2-828ee062f83e": "Result_12",
        //VAGINAL PESSARY
        "5d6aedb7-8f70-42dc-87c3-230a236c8b1d": "Result_13",
      },
      //CYSTITIS
      "1c8da33e-35db-4b1b-8179-e5d8e6a25da3": "Result_14",
    },
    // male: {
    //   yes: "Result_1",
    //   no: "Result_2",
    // },
    // female: {
    //   trush: {
    //     yes: "Result_3",
    //     no: {
    //       oral: {
    //         yes: "Result_4",
    //         no: "Result_5",
    //       },
    //       vaginal: {
    //         EASY_INSERT_SOFT_GEL: {
    //           yes: "Result_6",
    //           no: "Result_7",
    //         },
    //         SOOTHING_VAGINAL_CREAM: { yes: "Result_8", no: "Result_9" },
    //         VAGINAL_TABLET: { yes: "Result_10", no: "Result_11" },
    //       },
    //     },
    //   },
    //   BACTERIAL_VAGINOSIS: {
    //     VAGINAL_GEL: "Result_12",
    //     VAGINAL_PESSARY: "Result_13",
    //   },
    //   CYSTITIS: "Result_14",
    // },
  },

  fieldExplanationMapping: {
    "4211e4d6-ca1e-4440-8e60-bf2af064b67b":
      "Whilst the oral capsule will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "2f1dba46-6250-439f-be37-007b735e5627":
      "Whilst the vaginal tablet will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "d57b3f8b-b0de-4387-9c21-959cb1ae45a0":
      "Whilst the vaginal cream will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "0f3d0043-5efd-4fd6-ab38-988ba6484fcd":
      "Whilst the soft gel will treat the infection, itching & external discomfort can be calmed via an external cream.",
  },

  DISCLAIMER:
    "<p>Dieser Online-Test dient ausschliesslich zu Ihrer Information. Der Test ersetzt in keinem Fall eine Beratung durch eine Fachperson, sondern gibt lediglich eine Hilfestellung entsprechend Ihrer subjektiv empfundenen Beschwerden. Ihre Apotheke oder Drogerie wird Sie hierzu gerne beraten. </p>",
  ANSWERS: [2, 1, 3, 2, 1],
  QUESTIONS_COUNT: 5,
  de: {
    correct: "RICHTIG",
    incorrect: "FALSCH",
    question: "Question",
    your_answer: "Ihre Antwort",
    correct_answer: "Richtige Antwort",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },

  fr: {
    correct: "VRAI",
    incorrect: "FAUX",
    question: "Question",
    your_answer: "Votre réponse",
    correct_answer: "Réponse correcte",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },
};
