import Male_Bg from "../assets/Images/male_bg.jpg";
import Male_Tiny from "../assets/Images/male_tiny.jpg";
import Female_bg from "../assets/Images/female_bg.jpg";
import Female_Tiny from "../assets/Images/female_tiny.jpg";
import Female2_bg from "../assets/Images/female2_bg.jpg";
import Female2_Tiny from "../assets/Images/female2_tiny.jpg";
import Female3_bg from "../assets/Images/female3_bg.jpg";
import Female3_Tiny from "../assets/Images/female3_tiny.jpg";

export default {
  fetchResult: (resultType) => {
    let data;
    switch (resultType) {
      case "productSet1": {
        data = [
          {
            productName: "Aspi Gola® Natura Spray",
            image: "aspi_gola_nat_spray_duopack.png",
            description: `A base di estratti vegetali per il trattamento del mal di gola dai primi sintomi. Anche per bambini.`,
            // "A base di estratti vegetali forma un film protettivo e idratante sulla gola per il trattamento del mal di gola dai primi sintomi e della tosse ad esso associata. Aiuta la prevenzione del mal di gola in chi è frequentemente esposto ad irritanti come fumo, freddo e smog, e per questo soffre di mal di gola ricorrenti.",
            link: "/prodotti/aspi-gola-natura-spray/",
            maxHeight: "",
          },
          {
            productName: "Aspi Gola® Natura Bustine Monodose",
            image: "AspiGolaNatura_Bustine.png",
            description:
              "Per il mal di gola dei più piccoli, dai 2 ai 12 anni. Combatte il mal di gola a partire dai primi sintomi e della tosse ad esso associata. A base di estratti vegetali, forma un film protettivo e idratante sulla gola e, per questo, aiuta a proteggere la gola dall’attacco degli agenti irritanti.",
            link: "/prodotti/aspi-gola-natura-bustine-monodose/",
            maxHeight: "",
          },
        ];
        return data;
        break;
      }
      case "productSet2": {
        data = [
          {
            productName: "Aspi Gola® Natura Spray",
            image: "aspi_gola_nat_spray_duopack.png",
            description: `A base di estratti vegetali per il trattamento del mal di gola dai primi sintomi. Anche per bambini.`,
            // "A base di estratti vegetali per il trattamento del mal di gola dai primi sintomi e per la prevenzione in caso di mal di gola ricorrenti. Anche per bambini.",
            link: "/prodotti/aspi-gola-natura-spray/",
            maxHeight: "13rem",
          },
          {
            productName: "Aspi Gola® Natura Bustine Monodose",
            image: "AspiGolaNatura_Bustine.png",
            description:
              "Combatte il mal di gola a partire dai primi sintomi e della tosse ad esso associata. A base di estratti vegetali, forma un film protettivo e idratante sulla gola e, per questo, aiuta a proteggere la gola dall'attacco degli agenti irritanti.",
            link: "/prodotti/aspi-gola-natura-bustine-monodose/",
            maxHeight: "15rem",
          },
        ];
        return data;
        break;
      }
      case "productSet3": {
        data = [
          {
            productName: "Aspirina C",
            image: "BAY_21_PACK_ASPIRINA_C_20C_FRONTALE_NA4.jpg",
            description:
              "Agisce dai primi sintomi influenzali dando un rapido sollievo. Con vitamina C che ha un effetto positivo sul sistema immunitario.",
            link: "/prodotti/aspirina-c/",
            maxHeight: "14rem",
          },
          {
            productName: "Aspirina C Buste",
            image: "aspirina_c_buste_front_0.png",
            description: `Agisce contro <span style="font-family:'BrownLLTT-Bold';">sintomi influenzali e da raffreddamento, febbre e gola infiammata</span>. La vitamina C ha un effetto positivo sul sistema immunitario. All'aroma arancia`,
            link: "/prodotti/aspirina-c-buste/",
            maxHeight: "14rem",
          },
        ];
        return data;
        break;
      }
      case "productSet4": {
        data = [
          {
            productName: "AspirinaACT C",
            image: "aspirina-act_home.jpg",
            description:
              "Combatte la febbre. Con più alto contenuto di vitamina C*, per stimolare il sistema immunitario. <br/><br/><span style='font-size: 0.8rem'> *rispetto ad una compressa di Aspirina C.</span>",
            link: "/prodotti/aspirinaact-c/",
            maxHeight: "18rem",
          },
        ];
        return data;
        break;
      }
      case "productSet5": {
        // ["Pagina consiglio Aspirina Influenza e Naso Chiuso"];
        data = [
          {
            productName: "Aspirina influenza e naso chiuso",
            image: "AspirinaInfluenzaeNasoChiuso.png",
            description:
              "Unico medicinale a base di acido acetilsalicilico e pseudoefedrina, agisce rapidamente sulla congestione nasale mentre combatte febbre e sintomi influenzali.",
            link: "/prodotti/aspirina-influenza-e-naso-chiuso/",
            maxHeight: "16rem",
          },
        ];
        return data;
        break;
      }
      case "productSet6": {
        // [
        //   "Pagina consiglio Aspi Gola pastiglie",
        //   "Pagina consiglio Aspi Gola spray",
        // ];
        data = [
          {
            productName: "Aspi Gola Pastiglie",
            image: "aspigola_pastiglie_productimage.jpg",
            description:
              "A base di flurbiprofene, agisce rapidamente sul mal di gola con un effetto emolliente e lenitivo a partire da 2 minuti. Al gradevole gusto limone e miele.",
            link: "/prodotti/aspi-gola-pastiglie/",
            maxHeight: "11rem",
          },
          {
            productName: "Aspi Gola Spray",
            image: "aspigola_spray_productimage.jpg",
            description:
              "A base di flurbiprofene, agisce rapidamente sul mal di gola. Dona una piacevole sensazione di freschezza grazie all’aroma menta.",
            link: "/prodotti/aspi-gola-spray/",
            maxHeight: "13rem",
          },
        ];
        return data;
        break;
      }
      case "productSet7": {
        //  ["Pagina consiglio AspigolaDOLACT"];
        data = [
          {
            productName: "AspigolaDOLACT",
            image: "aspigola_new_0_0.jpg",
            description:
              "Combatte il mal di gola acuto e intenso. Può iniziare ad agire dopo 5 minuti per un sollievo rapido. Spray a base di 8,75 mg di fluibiprofene per dose.",
            link: "/prodotti/aspigoladolact/",
            maxHeight: "17rem",
          },
        ];
        return data;
        break;
      }
      case "productSet8": {
        // [
        //   "Pagina consiglio Aspirina Dolore e Infiammazione",
        //   "Pagina consiglio Aspirina Granuli",
        // ];
        data = [
          {
            productName: "Aspirina Dolore e Infiammazione",
            image:
              "BAY_20_ASPIRINA_DOLORE_INFIAMMAZIONE_SCATOLE_20_frontale.png",
            description:
              "Grazie alle proprietà analgesiche e antinfiammatorie, combatte mal di testa, dolore cervicale e dolori muscolari. Si assorbe rapidamente, per un'azione rapida sul dolore.",
            link: "/prodotti/aspirina-dolore-infiammazione/",
            maxHeight: "11rem",
          },
          {
            productName: "Aspirina in Granuli",
            image: "aspirina_granuli2.png",
            description:
              "Aspirina in Granuli si scioglie direttamente in bocca, senza bisogno d'acqua. In questo modo è possibile assumerla in ogni situazione quando serve. Al gusto cola",
            link: "/prodotti/aspirina-granuli/",
            maxHeight: "11rem",
          },
        ];
        return data;
        break;
      }
      case "productSet9": {
        //  ["Pagina consiglio AspirinaACT Dolore e Infiammazione"];
        data = [
          {
            productName: "AspirinaACT dolore e infiammazione",
            image: "aspirina-act_desktop_res-Copia.png",
            description:
              "Formulata con l'innovativa tecnologia MICROACTIVE per un'azione veloce contro emicrania, mal di testa e dolori cervicali. Può iniziare ad agire dopo cinque minuti",
            link: "/prodotti/aspirina-act-dolore-infiammazione/",
            maxHeight: "15rem",
          },
        ];
        return data;
        break;
      }
      case "productSet10": {
        // [
        //   "Pagina consiglio Aspirina Dolore e Infiammazione",
        //   "Pagina consiglio Aspirina Granuli",
        //   "Pagina consiglio AspirinaACT Dolore e Infiammazione",
        // ],
        data = [
          {
            productName: "Aspirina Dolore e Infiammazione",
            image:
              "BAY_20_ASPIRINA_DOLORE_INFIAMMAZIONE_SCATOLE_20_frontale.png",
            description:
              "Formulata con innovativa tecnologia MICROACTIVE per un’azione rapida su dolore e infiammazione",
            link: "/prodotti/aspirina-dolore-infiammazione/",
            maxHeight: "9rem",
          },
          {
            productName: "Aspirina in Granuli",
            image: "aspirina_granuli2.png",
            description:
              "Aspirina in Granuli si scioglie direttamente in bocca, senza bisogno d'acqua. In questo modo è possibile assumerla in ogni situazione quando serve. Al gusto cola",
            link: "/prodotti/aspirina-granuli/",
            maxHeight: "9rem",
          },
          {
            productName: "AspirinaACT dolore e infiammazione",
            image: "aspirina-act_desktop_res-Copia.png",
            //Aspirina_ACT_2012_CMP_4_WEB
            description:
              "Formulata con l'innovativa tecnologia MICROACTIVE per un'azione veloce contro emicrania, mal di testa e dolori cervicali. Può iniziare ad agire dopo cinque minuti",
            link: "/prodotti/aspirina-act-dolore-infiammazione/",
            maxHeight: "9rem",
          },
        ];
        return data;
        break;
      }
      case "productSet11": {
        data = [
          {
            productName: "Aspi Gola® Natura Spray",
            image: "aspi_gola_nat_spray_duopack.png",
            description: `A base di estratti vegetali per il trattamento del mal di gola dai primi sintomi. Anche per bambini.`,
            // "A base di estratti vegetali per il trattamento del mal di gola dai primi sintomi e per la prevenzione in caso di mal di gola ricorrenti. Anche per bambini.",
            link: "/prodotti/aspi-gola-natura-spray/",
            maxHeight: "17rem",
          },
          {
            productName: "Aspi Gola®  Natura Junior Bustine Monodose",
            image: "AspiGolaNatura_Bustine_Junior.png",
            description: `Combatte il mal di gola a partire dai primi sintomi e della tosse ad esso associata.
A base di estratti vegetali, forma un film protettivo e idratante sulla gola e, per questo, aiuta a proteggere la gola dall’attacco degli agenti irritanti.`,
            // "Per il mal di gola dei più piccoli, dai 2 ai 12 anni. Combatte il mal di gola a partire dai primi sintomi e dalla tosse ad esso associata.",
            link: "/prodotti/aspi-gola-natura-bustine-monodose/",
            maxHeight: "17rem",
          },
        ];
        return data;
        break;
      }

      // case "Result_14": {
      //   data = {
      //     productDetails: {
      //       productName: "CanesOasis",
      //       productDescription: "Cystitis relief",
      //       buttonText: "BUY NOW",
      //       buyNowUrl: "",
      //       productImage: "CanesOasis_Cystitus-Relief.png",
      //     },
      //     availableProduct: "",
      //     textHead: "",
      //     textDescription:
      //       "CanesOasis contains an active ingredient that reduces the acidity of your urine. This reduction of acidity level helps alleviate the stinging and pain that you experience when you urinate. CanesOasis is a two-day remedy which is quick and easy to use – for each dose you simply dissolve the powder from one sachet into a glass of water and drink. It’s available in great-tasting cranberry flavour. CanesOasis is available at pharmacies and in larger grocery stores. Remember if you suffer from frequent or severe cystitis, visit your doctor who will help you to determine your triggers and advise you on the best way to treat your infection.",
      //     toggleList: [
      //       {
      //         title: "What is it and what is it used for?",
      //         description:
      //           "<p>CanesOasis contains sodium citrate, which is used to relieve discomfort in urinary tract infections such as cystitis, by making the urine less acidic.<br>CanesOasis sachets are used for the relief of the symptoms of cystitis in women. Cystitis is an inflammation of the bladder, which causes painful irritation and an unpleasant burning sensation when passing water.</p>",
      //       },
      //       {
      //         title: "How to take?",
      //         description:
      //           "<p>Mix the contents of the sachet with a (200ml) glass of water and drink immediately. This is a 2-day course of treatment. Adult women: 1 sachet 3 times a day for 2 days, as required. This medicine is not to be used by men or children.<br>Do not exceed the stated dose. If symptoms persist or worsen after the 2-day course is completed, consult your doctor or pharmacist. Do not repeat the treatment without medical advice.</p>",
      //       },
      //       {
      //         title: "Possible side effects",
      //         description:
      //           "<p>Most people do not have any side effects while taking this medicine.<br>However, if you experience any side effects, or anything unusual happens, stop taking the medicine immediately, and see your doctor or pharmacist.</p>",
      //       },
      //       {
      //         title: "Pregnancy and breastfeeding",
      //         description:
      //           "<p>This medicine is not recommended if you are pregnant or breastfeeding. Please see your doctor or pharmacist before taking this medicine.<br>CanesOasis Cystitis Relief contains sodium citrate. Always read the label.</p>",
      //       },
      //     ],
      //     dailyProducts: [
      //       {
      //         title: "Canesfresh Feminine  <b>Wash Soothing Wash Gel </b>",
      //         description:
      //           "This liquid wash was developed for those times when you’re suffering from discomfort around your intimate area, such as when you’re suffering from thrush or vaginal dryness. It has been specially formulated to help soothe your sensitive intimate area and contains glycine, an amino acid known for its calming properties.",
      //         image: "CanesFresh_Feminine Wash.png",
      //       },
      //       {
      //         title: "Canesflor Probiotics<b> for Vaginal Use </b>",
      //         description:
      //           "Canesflor is a convenient vaginal capsule that delivers probiotics, specifically the good bacteria lactobacilli, to the vagina i.e. directly to the source of the infection. This restores the natural environment of your vagina and works to create a protective barrier over your vaginal walls, helping prevent thrush and bacterial vaginosis from recurring. This product is not a medicine.",
      //         image: "Canesflor_Probiotics.png",
      //       },
      //     ],
      //   };
      //   return data;
      //   break;
      // }

      default:
    }
  },
};
