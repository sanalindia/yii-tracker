import React, { useState, useEffect, useRef } from "react";
import "../css/components/resultContainer.scss";
import parse from "html-react-parser";
import { Constants } from "../constants";
// import CommonCards from "./common/commonCards";
import BackButton from "../components/common/BackButton";
import Carousel from "../components/common/carousel";
import result from "../utils/result";
const ResultContainer = ({
  resultNumber,
  loadResult,
  onHomeClick,
  correctAnswersCount,
  lang,
  questionAnswersList,
  backClick,
  backToPreviousPage,
  resultSet,
  display,
  width,
  animationObj,
  setResult,
  restart,
}) => {
  const [resultData, setResultData] = useState();
  const [icon, setIcon] = useState("+");

  useEffect(() => {
    if (resultSet !== "no_products" && resultSet !== "no_products1"&&  resultSet !== "no_products2") {
      resultSet; // productSet1
      let getResult = result.fetchResult(resultSet);
      console.log("resultSet", resultSet);
      console.log("getResult", getResult);
      setResultData(getResult);
    } else {
      setResultData(null);
    }
  }, [resultSet]);
  const leanMore = (resultSet) => {
    document.getElementById("Product__Content").scrollIntoView();
    let getResult = result.fetchResult(resultSet);
    setResultData(getResult);
  };
  const mainTopButtonClick = (link) => {
    window.open(`${link}`, "_parent");
  };

  const handleClick = (e) => {
    let id = e.target.id;
    let getAccordionBody = document
      .getElementsByClassName("Accordion__Container")
      [id].getElementsByClassName("Accordion__Body")[0];
    let getHeader = document
      .getElementsByClassName("Accordion__Container")
      [id].getElementsByClassName("Accordion__Header")[0];
    let isThere = getAccordionBody.classList.contains(`title_${id}`);
    if (isThere) {
      let getTitleClass = document
        .getElementsByClassName("Accordion__Container")
        [id].getElementsByClassName(`title_${id}`)[0];
      getTitleClass.style.display = "none";
      getAccordionBody.classList.remove(`title_${id}`);
      getHeader.getElementsByTagName("span")[0].innerHTML = "+";
    } else {
      getAccordionBody.classList.add(`title_${id}`);
      let getTitleClass = document
        .getElementsByClassName("Accordion__Container")
        [id].getElementsByClassName(`title_${id}`)[0];
      getTitleClass.style.display = "block";
      getHeader.getElementsByTagName("span")[0].innerHTML = "-";
    }
  };
  return (
    <>
      {!resultData ? (
        <>
          <div className="No_Product__Content" id="Product__Content">
            <div className="Product__RecommendationContainer noProductsContainer">
              <div className="Product__Info">
                <div className="react-reveal" style={animationObj}>
                  <div className="Product__ImageContainer">
                    {/* <img src={require(data?.image)} alt="Product" /> */}
                    <img
                      src={require(`../assets/Images/questionImages/no_product.png`)}
                      alt="Product"
                    />
                  </div>
                </div>
              </div>
              <div className="Product__Info" style={{ flexGrow: 1.5 }}>
                <div className="react-reveal" style={animationObj}>
                  <div className="Product__SecondaryTitle noProductDescription">
                    {resultSet === "no_products1"
                      ? parse(`È possibile che il mal di testa provato appartenga a
una forma non comune. Chiedi consiglio al medico curante o a uno specialista su come gestirlo al meglio.`)
                      : resultSet === "no_products"?parse(`Non esistono prodotti della linea Aspirina adatti a trattare i
                  sintomi di influenza o raffreddore in chi ha meno di 16 anni. <br/>
                  Chiedi un consiglio al medico curante o al farmacista su come
                  gestirli al meglio.`):parse(`Non esistono prodotti della linea Aspirina adatti a trattare mal di testa o cervicale in chi ha meno di 16 anni.<br/>
Chiedi un consiglio al medico curante o al farmacista su come gestirli al meglio.`)}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="restartArea">
            <button onClick={restart}> RIPETI IL TEST</button>
          </div>
        </>
      ) : (
        ""
      )}

      {resultData ? (
        <>
          <div className="productMainWrapper">
            {resultData.map((data, i) => {
              return (
                <div className="Product__Content" id="Product__Content">
                  {/* <!--produc data --> */}
                  <div
                    className="Product__RecommendationContainer"
                    style={resultData.length > 2 ? { display: "block" } : {}}
                    // style={{ display: "block" }}
                  >
                    <div className="Product__Info">
                      <div className="react-reveal" style={animationObj}>
                        <div
                          className="Product__ImageContainer"
                          style={
                            resultData.length > 2
                              ? { marginBottom: "2rem" }
                              : {}
                          }
                        >
                          {/* <img src={require(data?.image)} alt="Product" /> */}
                          <img
                            src={require(`../assets/Images/product/new/${data?.image}`)}
                            alt="Product"
                            style={{ maxHeight: data?.maxHeight }}
                          />
                        </div>
                      </div>
                    </div>
                    <div
                      className="Product__Info"
                      style={
                        resultData.length > 2
                          ? {
                              display: "flex",
                              flexDirection: "column",
                              justifyContent: "center",
                              alignItems: "center",
                            }
                          :  resultData.length > 2?{flexFlow:'1.2'} :{}
                      }
                    >
                      <div className="react-reveal" style={animationObj}>
                        <h1
                          className="Product__Title"
                          style={
                            resultData.length > 2
                              ? {
                                  textAlign: "center",
                                  height: "5rem",
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  fontSize: "1.7rem",
                                }
                              : resultData.length === 2
                              ? { fontSize: "1.5rem" }
                              : {}
                          }
                        >
                          {data?.productName}
                        </h1>
                      </div>
                      <div className="react-reveal" style={animationObj}>
                        <div
                          className="Product__SecondaryTitle"
                          style={
                            resultData.length > 2
                              ? {
                                  textAlign: "center",
                                  minHeight: "auto",
                                  padding: "1rem",
                                }
                              : {}
                          }
                        >
                          {parse(data?.description)}
                        </div>
                      </div>
                      <div
                        className="react-reveal Product__FirstButton_Reveal"
                        style={animationObj}
                      >
                        <div
                          className="Product__FirstButton"
                          onClick={() => mainTopButtonClick(data?.link)}
                          style={
                            resultData.length === 2
                              ? {
                                 marginTop:"0"
                                }
                              : {}
                          }
                        >
                          Scopri di più
                          {/* {resultData?.productDetails?.buttonText} */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="restartArea restartArea1">
            <button onClick={restart}> RIPETI IL TEST</button>
          </div>
        </>
      ) : (
        ""
      )}
    </>
  );
};

export default ResultContainer;
