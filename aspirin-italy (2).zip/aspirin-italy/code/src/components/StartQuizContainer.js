import React from "react";
import parse from "html-react-parser";
import Actions from "./common/actions";
import "../css/components/StartQuizContainer.scss";
import ProgressBar from "../components/common/ProgressBar";
import InfoButton from "../components/common/InfoButton";

const StartQuizContainer = ({
  startQuiz,
  quizTitle,
  quizAction = [],
  quizDesc,
  onStartClick,
  progress,
  infoContent,
  titleContent,
  animationObj,
  fromResultScreen,
  quizInstruction,
}) => {
  return (
    <>
      <div className="startArea">
        <img
          // src={require(`../assets/Images/questionImages/Aspy-con-termometro-febbre.png`)}
          src={require(`../assets/Images/questionImages/Aspy_says_hello.png`)}
        />
        <div className="startTextArea">
          <div className="text">
            Trova il prodotto più adatto alle tue esigenze
          </div>
          <button onClick={onStartClick}>INIZIA IL TEST</button>
        </div>
      </div>
      {/* <div className="Start__TitleContainer">
        <div className="react-reveal" style={animationObj}>
          <h1 className="Start__Title">{parse(titleContent)}</h1>
        </div>
      </div>
      <div className="react-reveal" style={animationObj}>
        <div className={["common__Block", "welcomeArea"].join(" ")}>
        
          <div className="react-reveal" style={animationObj}>
            <h2 className="Start__SubTitle">{quizTitle}</h2>
          </div>
          <div className="react-reveal" style={animationObj}>
            <div className="Start__Text">
              {quizDesc ? parse(quizDesc) : " "}
            </div>
          </div>
          <div className="react-reveal" style={animationObj}>
            <div className="common__ButtonContainer">
              {quizAction.length ? (
                <Actions
                  actions={[
                    [
                      "1",
                      quizAction[0].action
                        ? quizAction[0].action
                        : "FIND PRODUCT",
                      "",
                    ],
                  ]}
                  onStartClick={onStartClick}
                />
              ) : (
                " "
              )}
            </div>
          </div>
        </div>
      </div> */}
    </>
  );
};
export default StartQuizContainer;
