import React from "react";
import "../../css/components/actionButton.scss";
import arrowIcon from "../../assets/Icons/right-arrow-red.png";

const ProgressBar = ({ progress }) => {
  return (
    <div className="react-reveal">
      <div className="ProgressBar__Container">
        <div
          width={progress}
          style={{ width: `${progress}%` }}
          className="ProgressBar__Bar"
        ></div>
      </div>
    </div>
  );
};

export default ProgressBar;
