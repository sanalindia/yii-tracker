import React, { useState, useEffect } from "react";
import Utility from "../../utils/utility";
import "../../css/components/radioGroup.scss";

const RadioGroup = ({
  inputValues,
  choices,
  updateChoices,
  updateChoicesIndex,
  choicesIndex,
  stepNumber,
}) => {
  const options = inputValues[1];
  const qID = inputValues[0].id;

  const [selected, setSelected] = useState();

  useEffect(() => {
    if (choices[qID]) {
      setSelected(choices[qID]);
    }
  }, [choices, qID]);

  const handleChange = (event, index) => {
    setSelected(event.target.id);
    updateChoices({ ...choices, [qID]: event.target.id });
    updateChoicesIndex({ ...choicesIndex, [stepNumber]: index + 1 });
  };

  return (
    <div className="optionQuestion">
      {options.length
        ? options.map((option, index) => {
            return (
              <label key={index}>
                <input
                  type="radio"
                  id={option[0]}
                  key={option[0]}
                  name="radioGroup"
                  ordernumber={index}
                  value={option[1]}
                  checked={option[0] === selected}
                  onChange={(event) => handleChange(event, index)}
                />
                <span className="labelText">{option[1]}</span>
                <span className="checkmark"></span>
              </label>
            );
          })
        : ""}
    </div>
  );
};

export default RadioGroup;
