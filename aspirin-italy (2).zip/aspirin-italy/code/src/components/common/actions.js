import React from "react";
import "../../css/components/actionButton.scss";
import arrowIcon from "../../assets/Icons/right-arrow-red.png";
import $ from "jquery";
const Actions = ({
  actions,
  onNext,
  onStartClick,
  selected,
  step,
  choicesIndex,
  multiplechoices,
  options,
  questionData,
  toButton,
}) => {
  const actionsList = options ? options : actions;
  const qID = questionData ? questionData.id : 0;
  console.log("actionsList", actionsList);
  const handleChange = (e) => {
    console.log("target id  ", e.target.id);
    console.log("this", this);

    //onNext(qID, e);
    toButton(qID, e);
  };
  // $(".common__Button").click(function (e) {
  //   console.log("this1", this);
  //   var $target = $(e.target);
  //   if (!$target.is(":radio")) {
  //     $(this).find("input:radio:NOT(:checked)").prop("checked", true);
  //   }
  // });

  return actionsList.length
    ? actionsList.map((action, index) => {
        return (
          // <label>
          //   <input
          //     type="radio"
          //     id="0176f139-b460-4ca3-981a-f895ae64764d"
          //     name="radioGroup"
          //     ordernumber="1"
          //     value="Een heftig en constant branderig gevoel en jeuk in en rondom je vagina"
          //   />
          //   <span class="labelText">
          //     Een heftig en constant branderig gevoel en jeuk in en rondom je
          //     vagina
          //   </span>
          //   <span class="checkmark"></span>
          // </label>
          <label className="common__Button" key={index}>
            <input
              id={action[0]}
              type="radio"
              name={`step${step}`}
              onClick={action[0] !== "1" ? handleChange : onStartClick}
            />
            <span className="labelText">{action[1]}</span>
            <span className="checkmark"></span>
          </label>

          // <button
          //   id={action}
          //   className={
          //     action === "Próxima Pregunta" || action === "Finalizar"
          //       ? "action-btn next-btn" :(action !== "LET'S GET STARTED" ?"action-btn next-btn" :"action-btn start-btn")

          //   }
          //   onClick={
          //     action !== "LET'S GET STARTED" ? onNext : onStartClick
          //   }
          //   key={action}
          //   disabled={
          //     action === "Próxima Pregunta" || action === "Finalizar" || (action === "YES" && (step === 1 || step === 2))
          //       ? !selected
          //       : false
          //   }
          // >
          //   {action} {action === "LET'S GET STARTED" ? (<span><img alt = "arrow" src={arrowIcon} /></span>) :  null}
          // </button>
        );
      })
    : "";
};

export default Actions;
