export const Constants = {
  q1: "848be697-4122-496a-b9bc-81a29be677d7",
  q2: "1b12fb45-2c79-42dd-87ae-09d6dbaf93e9",
  q3: "a79cca53-edab-4e55-937f-7a11be655a9b",
  q4: "cce5728e-2922-444b-bb3a-d87eeea4d99f",
  q5: "d0e11505-48ed-4d3a-9e5d-b489845b19f0",
  q6: "2ef46d88-9971-40c3-9fef-89d8a45b401a",
  q7: "82d49ade-1e56-40a1-bd16-dd997e1ce1bc",

  questionMappingArray: {
    // "Qual è il sintomo che si vuole trattare?",
    "848be697-4122-496a-b9bc-81a29be677d7": {
      // Sintomi di raffreddore e influenza
      "21047c61-ed02-4f12-a9ba-3e0b183daf5e":
        "688f81c0-3a9d-41c5-b2fb-8cd75e2ce5ea",
      //Mal di gola
      "e3f9d90f-7b49-4a82-b9b8-cf37d52f035e":
        "fa06a6e8-ed29-44bc-812e-1a6add427c40",
      //Mal di testa o dolore cervicale
      "02827f6e-6ca3-476d-8adb-6619d4ac4862":
        "6d114685-0dee-45c1-a906-686bc5d0e220",
    },
    //Quanti anni ha la persona con i sintomi?
    "688f81c0-3a9d-41c5-b2fb-8cd75e2ce5ea": {
      // Meno di 16 anni
      "6080fc9a-0f89-472e-9d4e-0279d70aa3cc": "no_products",
      //16 anni o pi
      "9a202a34-705d-46cb-8eb9-2d283c6e8a8d":
        "59ed2949-6982-49cf-8c94-527d33824b0f",
    },

    //Quanti anni ha la persona con mal di gola?
    "fa06a6e8-ed29-44bc-812e-1a6add427c40": {
      //  Meno di 6 anni
      "65ebf05d-8ccc-4496-a1a4-14d150ecbffb": "productSet11",
      //Tra i 6 e 11 anni
      "d6e07a33-cae8-4db5-a0bd-66336bb3afb4": "productSet2",
      //Tra i 12 e 17 anni
      "90385c8b-e682-4f80-b1b4-bf2c88f9b74b":
        "1ddfe1ee-8656-4bce-8aba-7219928a539f",
      //18 anni o pi\u00f9
      "18eb8c83-2525-474f-851a-57e0e1643896":
        "2af69368-b9a8-4f97-bc75-5c1bb99f43a1",
    },

    //Quanti anni ha la persona con dolore?
    "6d114685-0dee-45c1-a906-686bc5d0e220": {
      // Meno di 16 anni
      "b216a0d2-768e-45ad-9e4e-e5c16ec9f0ab": "no_products2",
      //16 anni o pi\u00f9
      "a554b3fe-1e7a-4cbd-a051-83c66ef16f38":
        "c800cb5f-ce7d-445c-92f3-2d5fed250af5",
    },

    //Qual è il sintomo prevalente che prova e che vuol trattare?
    "59ed2949-6982-49cf-8c94-527d33824b0f": {
      //  Primi sintomi di raffreddore e influenza
      "37a77f2c-6e36-4132-9bcd-1d04338d5810": "productSet3",
      //Febbre
      "d03b8752-069b-4277-8942-0245d40b8bdf": "productSet4",
      //Naso congestionato (difficoltà a respirare con il naso)
      "ad5bdf6f-5f7b-43e3-bb54-21cb76544e35": "productSet5",
      //Tosse
      "d5c293c7-e457-4fa8-8403-6ee9c865ce68": "productSet2",
    },

    //Quanto è intenso il mal di gola?
    "1ddfe1ee-8656-4bce-8aba-7219928a539f": {
      //Lieve: gola secca, senso di irritazione che quando aumenta induce la tosse
      "d184b71c-262b-42a8-bdac-0cf2b3849a40": "productSet2",
      //Moderato-intenso: dolore e tosse che possono peggiorare quando si deglutisce
      "bfa0e4fe-dbe1-41ff-90b8-02121a7f16dc": "productSet6",
    },

    //Quanto è intenso il mal di gola?
    "2af69368-b9a8-4f97-bc75-5c1bb99f43a1": {
      //Lieve: gola secca, senso di irritazione che quando aumenta induce la tosse
      "1fd47985-1521-4bd2-8c15-fcd40368bdf0": "productSet2",
      //Moderato-intenso: dolore e tosse che possono peggiorare quando si deglutisce
      "c51cbc3e-bc70-44a3-b829-3e9c7ffda984": "productSet6",
      //Intenso: dolore, bruciore e tosse che peggiorano quando si deglutisce. Sensazione di gola gonfia
      "ccacccc6-6ffc-4fd1-bcb0-78c7e2200a47": "productSet7",
    },

    //Che caratteristiche ha il dolore?
    "c800cb5f-ce7d-445c-92f3-2d5fed250af5": {
      //Mal di testa lieve: dolore avvolge la testa come un casco, o preme come un peso. Non è forte ma costante, e può durare anche più giorni.
      "1c9f6a7d-7bea-4e26-84e3-013e4b82d5ce": "productSet8",
      //Mal di testa forte: la testa pulsa, il dolore peggiora se si cammina o si fanno lescale. Alle volte ci sono anche fastidio per la luce o per i rumori.
      "3c8fa271-6779-4a4a-b412-752a2bacbdad": "productSet9",
      //Mal di testa forte: la testa pulsa, il dolore peggiora se si cammina o si fanno lescale. Alle volte ci sono anche fastidio per la luce o per i rumori.Dolore cervicale: il dolore parte dal collo e risale lungo la nuca fino ad arrivare alla sommità del capo. Alle volte il dolore si limita al collo e alle spalle.
      "823c1698-5ff0-4902-909b-b4b0c7e4633f": "productSet10",
      //Mal di testa da sinusite: il dolore arriva al viso, dà una sensazione di pressione su occhi, guance e/o naso e può peggiorare se si abbassa la faccia.
      "b184d2e5-4a34-4bf5-93f7-4b614dfcfa55": "productSet9",
      //Il dolore non assomiglia a nessuna delle condizioni descritte.
      "4c650e7d-3a7b-425a-9302-763a36e5c1f8": "no_products1",
    },
  },

  ResultMappingArray: {
    // Male
    "7529905e-52ca-40d9-9606-f684bbf616bc": {
      // yes
      "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_1",
      //No
      "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_2",
    },
    //Female
    "433b3af0-eb08-4ca9-a75f-d05c4de5636b": {
      //thrush
      "74d382c1-bbcc-44c7-ad4d-6e149d9cd0a2": {
        //Yes
        "fa32b062-5f44-436e-a874-80b616284271": "Result_3",
        //No
        "5bfd7119-6c64-4391-bff4-c00a8a45a523": {
          //ORAL
          "4211e4d6-ca1e-4440-8e60-bf2af064b67b": {
            //yes
            "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_4",
            //No
            "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_5",
          },
          //VAGINAL
          "8d64b717-3736-4e2d-97b8-7cf36c7ad1da": {
            //EASY INSERT SOFT GEL
            "0f3d0043-5efd-4fd6-ab38-988ba6484fcd": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_3",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_7",
            },
            //SOOTHING VAGINAL CREAM
            "d57b3f8b-b0de-4387-9c21-959cb1ae45a0": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_8",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_9",
            },
            //VAGINAL TABLET
            "2f1dba46-6250-439f-be37-007b735e5627": {
              //yes
              "a3c4ca5a-637f-44a8-b0d9-e59ef53e00a6": "Result_10",
              //No
              "c00c2f96-d2d5-40c0-911a-aee59a5d3199": "Result_11",
            },
          },
        },
      },
      //BACTERIAL VAGINOSIS (BV)
      "5046ab7d-b8bb-40be-b131-14ea1f4870e3": {
        //VAGINAL GEL
        "9bc559a5-590c-42cd-96f2-828ee062f83e": "Result_12",
        //VAGINAL PESSARY
        "5d6aedb7-8f70-42dc-87c3-230a236c8b1d": "Result_13",
      },
      //CYSTITIS
      "1c8da33e-35db-4b1b-8179-e5d8e6a25da3": "Result_14",
    },
    // male: {
    //   yes: "Result_1",
    //   no: "Result_2",
    // },
    // female: {
    //   trush: {
    //     yes: "Result_3",
    //     no: {
    //       oral: {
    //         yes: "Result_4",
    //         no: "Result_5",
    //       },
    //       vaginal: {
    //         EASY_INSERT_SOFT_GEL: {
    //           yes: "Result_6",
    //           no: "Result_7",
    //         },
    //         SOOTHING_VAGINAL_CREAM: { yes: "Result_8", no: "Result_9" },
    //         VAGINAL_TABLET: { yes: "Result_10", no: "Result_11" },
    //       },
    //     },
    //   },
    //   BACTERIAL_VAGINOSIS: {
    //     VAGINAL_GEL: "Result_12",
    //     VAGINAL_PESSARY: "Result_13",
    //   },
    //   CYSTITIS: "Result_14",
    // },
  },

  fieldExplanationMapping: {
    "4211e4d6-ca1e-4440-8e60-bf2af064b67b":
      "Whilst the oral capsule will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "2f1dba46-6250-439f-be37-007b735e5627":
      "Whilst the vaginal tablet will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "d57b3f8b-b0de-4387-9c21-959cb1ae45a0":
      "Whilst the vaginal cream will treat the infection, itching & external discomfort can be calmed via an external cream.",
    "0f3d0043-5efd-4fd6-ab38-988ba6484fcd":
      "Whilst the soft gel will treat the infection, itching & external discomfort can be calmed via an external cream.",
  },

  DISCLAIMER:
    "<p>Dieser Online-Test dient ausschliesslich zu Ihrer Information. Der Test ersetzt in keinem Fall eine Beratung durch eine Fachperson, sondern gibt lediglich eine Hilfestellung entsprechend Ihrer subjektiv empfundenen Beschwerden. Ihre Apotheke oder Drogerie wird Sie hierzu gerne beraten. </p>",
  ANSWERS: [2, 1, 3, 2, 1],
  QUESTIONS_COUNT: 5,
  de: {
    correct: "RICHTIG",
    incorrect: "FALSCH",
    question: "Question",
    your_answer: "Ihre Antwort",
    correct_answer: "Richtige Antwort",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },

  fr: {
    correct: "VRAI",
    incorrect: "FAUX",
    question: "Question",
    your_answer: "Votre réponse",
    correct_answer: "Réponse correcte",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },
};
