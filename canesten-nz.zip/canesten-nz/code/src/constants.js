export const Constants = {
  DISCLAIMER:
    "<p>Dieser Online-Test dient ausschliesslich zu Ihrer Information. Der Test ersetzt in keinem Fall eine Beratung durch eine Fachperson, sondern gibt lediglich eine Hilfestellung entsprechend Ihrer subjektiv empfundenen Beschwerden. Ihre Apotheke oder Drogerie wird Sie hierzu gerne beraten. </p>",
  ANSWERS: [2, 1, 3, 2, 1],
  QUESTIONS_COUNT: 5,
  de: {
    correct: "RICHTIG",
    incorrect: "FALSCH",
    question: "Question",
    your_answer: "Ihre Antwort",
    correct_answer: "Richtige Antwort",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },

  fr: {
    correct: "VRAI",
    incorrect: "FAUX",
    question: "Question",
    your_answer: "Votre réponse",
    correct_answer: "Réponse correcte",
    count_text1: " ",
    count_text2: " ",
    count_text3: " ",
  },
};
