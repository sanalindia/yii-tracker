export const Constants = {
  DECLARATION:
    "Durch Anklicken der Checkbox willigen Sie ein, dass die Bayer Vital GmbH, Ihnen Informationen zum Produkt, in Abhängigkeit Ihrer Interessen, direkt per Email zukommen lässt. Sie können Ihre Einwilligung jederzeit mit zukünftiger Wirkung widerrufen. Richten Sie Ihren Widerruf bitte an Bayer Vital GmbH, Datenschutz, Gebäude K56, 51368 Leverkusen oder an Datenschutz-BV@bayer.com. Weitere Informationen zur Verwendung Ihrer personenbezogenen Daten finden Sie in unserer Datenschutzerklärung. Darüber hinaus enthält jede der oben beschriebenen elektronischen Informationen, die Sie von uns erhalten, die Möglichkeit, Ihre Einwilligung durch einfaches Klicken auf einen entsprechenden Link zu widerrufen.",
  // BASE_URL: "https://www.services.bayer.us/"
  BASE_URL: window.location.origin + "/",
};
