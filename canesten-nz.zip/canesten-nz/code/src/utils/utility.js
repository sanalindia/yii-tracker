import { Constants } from "../constants";

export default {
  jsonStringToObj: (s) => {
    s = s.replace(/(\r\n|\n|\r)/gm, "");
    var span = document.createElement("span");
    span.innerHTML = s;
    s = span.textContent || span.innerText;
    s = s.trim();
    s = JSON.parse(s);
    return s;
  },
  questionIndex: (id, q) => {
    var index;
    var filteredObj = q.find(function (item, i) {
      if (item.id === id) {
        index = i;
      }
    });
    return index;
  },
  optionIndex: (id, o) => {
    var index;
    for (let i = 0; i < o.length; i++) {
      if (o[i][0] === id) {
        index = i;
      }
    }
    return index;
  },
  rightAnswersCount: (choiceIndex) => {
    let count = 0;
    Constants.ANSWERS.map((answer, index) => {
      if (choiceIndex[index + 1] === answer) {
        count = count + 1;
      }
    });
    return count;
  },
};
