import axios from "axios";

const baseURL = window.location.origin;

const apiClient = axios.create({ baseURL });

const { get, post, put, delete: destroy } = apiClient;

export { get, post, put, destroy };
