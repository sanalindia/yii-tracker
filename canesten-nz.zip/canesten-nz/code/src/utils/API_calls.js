import { post } from "./axios_config";

export default {
  postRecepient: async (data, product) => {
    let currentDate = new Date(),
      dd = String(currentDate.getDate()).padStart(2, "0"),
      mm = String(currentDate.getMonth() + 1).padStart(2, "0"),
      yyyy = currentDate.getFullYear();
    currentDate = `${mm}-${dd}-${yyyy}`;

    // currentDate = `${yyyy}-${mm}-${dd}T00:00:00`;
    // `<recipient_stage xtkschema="byr:recipient_stage" brand="Priorin" email="${data.e_mail}" adobe_source="PRIORIN_WEB" orig_reg_date="${currentDate}" product="${data.Priorin}" country="DE" last_mod_date="${currentDate}" />`;
    // var xmlBodyStr = `<recipient_stage xtkschema="byr:recipient_stage" brand="Canesten" firstname="${data.firstname}" lastname="${data.lastname}"  email="${data.email}" adobe_source="CANESTEN_WEB" orig_reg_date="${currentDate}" product="${product}" country="NZ" last_mod_date="${currentDate}" />`;
    // console.log(`recepeint request body - ${xmlBodyStr}`);
    // let config = {
    //   headers: { "Content-Type": "text/xml" },
    // };

    let bodyData = {
      To: {
        Address: data.email,
        SubscriberKey: data.email,
        ContactAttributes: {
          SubscriberAttributes: {
            SubscriberKey: data.email,
            EmailAddress: data.email,
            Brand: "Canesten",
            CreatedDate: currentDate,
            Country: "NZ",
            FirstName: data.firstname,
            LastName: data.lastname,
            Product: product,
            PrivacyFlag: true,
            CollectionNoticeFlag: true,
          },
        },
      },
    };

    let config = {
      headers: { "Content-Type": "text/json" },
    };

    // let response = await post("/adobe/api/post", xmlBodyStr, config);
    let response = await post("/canesten_ssa_nz", bodyData, config);
    return response.data.responseStatus;
  },

  postOptIn: async (data, product) => {
    //   let currentDate = new Date(),
    //     dd = String(currentDate.getDate()).padStart(2, "0"),
    //     mm = String(currentDate.getMonth() + 1).padStart(2, "0"),
    //     yyyy = currentDate.getFullYear();
    //   currentDate = `${yyyy}-${mm}-${dd}T00:00:00`;
    //   // var xmlBodyStr = `<opt_stage xtkschema="byr:opt_stage" brand="Priorin" email="${data.e_mail}" opt_status="1" opt_name="Weekly Priorin Newsletter" opt_date="${currentDate}" adobe_source="PRIORIN_WEB" />`;
    //   var xmlBodyStr = `<opt_stage xtkschema="byr:opt_stage" brand="Canesten" firstname="${data.firstname}" lastname="${data.lastname}" email="${data.email}" opt_status="1" opt_name="Consumer Health New Zealand" opt_date="${currentDate}" adobe_source="CANESTEN_WEB" />`;
    //   console.log(`OptIn request body - ${xmlBodyStr}`);
    //   let config = {
    //     headers: { "Content-Type": "text/xml" },
    //   };
    //   let response = await post("/adobe/api/post", xmlBodyStr, config);
    //   return response.data.responseStatus;
  },
};
