import utility from "./utility";

export default {
  getResult: (choiceIndex) => {
    let resultNumber;
    if (utility.rightAnswersCount(choiceIndex) > 3) {
      resultNumber = 2;
    } else {
      resultNumber = 1;
    }

    return resultNumber;
  },
};
