import React from "react";
import parse from "html-react-parser";
import Actions from "./common/actions";
import "../css/components/quizContainer.scss";
import startImage from "../assets/Images/bannerImage.png";
import resultImage from "../assets/Images/resultBannerImage.jpg";
import { Constants } from "../constants";

const StartQuizContainer = ({
  startQuiz,
  quizTitle,
  quizAction = [],
  quizDesc,
  onStartClick,
  fromResultScreen,
  quizInstruction,
}) => {
  
  return (
    <>
      <div className="quizContainer container startContainer">
        <div className="row">
          <div className="leftImage col-lg-6">
            <img src={fromResultScreen ? resultImage : startImage} />
          </div>
          <div className="rightSide col-lg-6">
            <div className="quizHeader">
              <h1>
                {quizTitle}
                {/* <span className="title-divider"></span> */}
              </h1>
              <div className={fromResultScreen ? "result_desc" : ""}>
                {quizDesc ? parse(quizDesc) : " "}
              </div>
              {quizAction.length ? (
                <Actions
                  actions={Array.of(quizAction[0].action)}
                  onStartClick={onStartClick}
                />
              ) : (
                " "
              )}
            </div>
          </div>
        </div>
      </div>
      {/*typeof quizInstruction !== "undefined" && quizInstruction != "" ? (
        <div class="quizInstruction">{parse(quizInstruction)}</div>
      ) : (
        ""
      )*/}
    </>
  );
};
export default StartQuizContainer;
