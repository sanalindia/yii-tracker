import React, { useState, useEffect, useRef } from "react";
import "../css/components/resultContainer.scss";
import StartQuizContainer from "./StartQuizContainer";
import parse from "html-react-parser";
import { Constants } from "../constants";
import CommonCards from "./common/commonCards";
import EmailFormCard from "./common/EmailFormCard";
import MultipleProducts from "./common/MultipleProducts";
import OneInternal from "../assets/Pdf/Symptom-Checker-Result-v3-No_One-Day_Internal.pdf";
import OneOral from "../assets/Pdf/Symptom-Checker-Result-v3-No_One-Day_Oral.pdf";
import ThreeDay from "../assets/Pdf/Symptom-Checker-Result-v3-No_3-Days.pdf";
import SixDay from "../assets/Pdf/Symptom-Checker-Result-v3-No_6-Days.pdf";
const ResultContainer = ({
  resultNumber,
  loadResult,
  onHomeClick,
  correctAnswersCount,
  lang,
  questionAnswersList,
  backClick,
  setResult,
}) => {
  const [rowItems, setRowItems] = useState([]);
  const [selectedTab, setSelectedTab] = useState("oral");
  const shareUrl = "https://www.canesten.ch/";
  const myRef = useRef(null);

  useEffect(() => {
    let cardItem = [];
    let rowItems = [];
    let quizText = {
      questionCountText:
        lang === "fr" ? Constants.fr.question : Constants.de.question,
      resultCardText1:
        lang === "fr" ? Constants.fr.your_answer : Constants.de.your_answer,
      resultCardText2:
        lang === "fr"
          ? Constants.fr.correct_answer
          : Constants.de.correct_answer,
    };
    questionAnswersList.forEach((data, i) => {
      cardItem.push(
        <CommonCards
          number={i + 1}
          question={data.question.title}
          correctOPT={data.correctAnswer}
          selection={data.selectedAnswer}
          quizText={quizText}
        />
      );
    });
    for (var j = 0; j < cardItem.length; j = j + 3) {
      rowItems.push(
        <div className="row" key={j}>
          {cardItem[j]}
          {cardItem[j + 1]}
          {cardItem[j + 2]}
        </div>
      );
    }
    setRowItems(rowItems);
  }, []);

  const getParsedDescription = "Text";
  const handleClick = (e, tab) => {
    setSelectedTab(tab);
  };
  const scrollToView = () => {
    myRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const onClickBack = (e) => {
    backClick();
  };
  return resultNumber == 1 ? (
    <div className="resultContainer">
      <StartQuizContainer
        quizTitle={loadResult[0][0]}
        quizDesc={loadResult[0][1]}
        fromResultScreen={true}
      />
      <div className="result_bottom_main_div">
        <span className="result_bottom_span">
          <span className="result_count_header" ref={myRef}>
            1 Day Treatment Options
          </span>

          <div className="result_share">
            <div className="result_content">
              A convenient single dose, with the same efficacy as 3- and 6-day
              treatments
            </div>
          </div>
          <div className="productsTabContainer">
            <div>
              <button
                className="oralTreat"
                onClick={(e) => handleClick(e, "oral")}
                style={
                  selectedTab === "oral"
                    ? {
                        background: "#c30e2e",
                        border: "1px solid #c30e2e",
                        color: "#fff",
                      }
                    : {
                        background: "#f7f7f7",
                        border: "1px solid #424448",
                        color: "#424448",
                      }
                }
              >
                Oral Treatment
              </button>
              <button
                className="oralTreat"
                onClick={(e) => handleClick(e, "internal")}
                style={
                  selectedTab === "internal"
                    ? {
                        background: "#c30e2e",
                        border: "1px solid #c30e2e",
                        color: "#fff",
                      }
                    : {
                        background: "#f7f7f7",
                        border: "1px solid #424448",
                        color: "#424448",
                      }
                }
              >
                Internal Treatment
              </button>
            </div>
            <div className="tabDivider"></div>
          </div>
          <MultipleProducts
            selectedTab={selectedTab}
            resultNumber={resultNumber}
            handleClick={handleClick}
            scrollToView={scrollToView}
          />
          <EmailFormCard
            downloadPdf={selectedTab === "oral" ? OneOral : OneInternal}
            filename={
              selectedTab === "oral"
                ? "Symptom-Checker-Result-v3-No_One-Day_Oral.pdf"
                : "Symptom-Checker-Result-v3-No_One-Day_Internal.pdf"
            }
            product={"Canesten1"}
          />
        </span>
        <div className="backButtonArea">
          <button onClick={onClickBack}>
            <span class="left-arrow"></span>
            BACK
          </button>
        </div>
      </div>
    </div>
  ) : (
    <div className="resultContainer">
      <StartQuizContainer
        quizTitle={loadResult[0][0]}
        quizDesc={loadResult[0][1]}
        fromResultScreen={true}
      />
      <div className="result_bottom_main_div">
        <span className="result_bottom_span">
          {resultNumber == 2 ? (
            <span className="result_count_header" ref={myRef}>
              3 Day Treatment Options
            </span>
          ) : (
            <span className="result_count_header" ref={myRef}>
              6 Day Treatment Options
            </span>
          )}

          <div className="result_share">
            {resultNumber == 2 ? (
              <div className="result_content">
                Feel the product take effect during treatment
              </div>
            ) : (
              <div className="result_content">
                For those who prefer to treat for longer, or who experience
                repeat episodes of thrush.
              </div>
            )}
          </div>

          <MultipleProducts
            selectedTab={selectedTab}
            resultNumber={resultNumber}
            scrollToView={scrollToView}
            setResult={setResult}
          />
          <EmailFormCard
            downloadPdf={resultNumber == 2 ? ThreeDay : SixDay}
            filename={
              resultNumber == 2
                ? "Symptom-Checker-Result-v3-No_3-Days.pdf"
                : "Symptom-Checker-Result-v3-No_6-Days.pdf"
            }
            product={resultNumber == 2 ? "Canesten3" : "Canesten6"}
          />
        </span>
        <div className="backButtonArea">
          <button onClick={onClickBack}>
            <span class="left-arrow"></span>
            BACK
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultContainer;
