import React, { useEffect, useState, useLayoutEffect } from "react";
import { Cases } from "../utils/API/index";
import axios from "axios";
import Loader from "./common/loader";
import StartQuizContainer from "./StartQuizContainer";
import QuestionCard from "./common/QuestionCard";
import { Constants } from "../constants";
import Utility from "../utils/utility";
import ResultContainer from "./ResultContainer";
import "../css/components/quizContainer.scss";
import isMobileDevice from "responsive-react";
import Result from "../utils/result";
import { withResizeDetector } from "react-resize-detector/build/withPolyfill";
import "../css/components/quizContainer.scss";
import utility from "../utils/utility";
import "../css/components/Nothrushsymptoms.scss";
const Nothrushsymptoms = ({ backClick, closeClick }) => {
  const onClickBack = (e) => {
    backClick();
  };
  const onCloseClick = (e) => {
    closeClick();
  };
  return (
    <div className="end_quiz__container">
      <h1 className="title">No thrush symptoms</h1>
      <div className="description">
        You have selected a symptom which is not commonly associated with
        thrush. These symptoms may indicate a different type of infection.
        <br />
        <br />
        Please talk to your doctor for further advice.
      </div>
      <div className="buttonArea">
        <button className="back_button" onClick={onClickBack}>
          <span className="left-arrow"></span>
          Back
        </button>
        <button className="close_button" onClick={onCloseClick}>
          Close
        </button>
      </div>
    </div>
  );
};
export default withResizeDetector(Nothrushsymptoms);
