import React, { useState, useEffect } from "react";
import downloadPdf from "../../assets/Pdf/Symptom-Checker-Result-v3-What-Thrush.pdf";
import axios from "axios";
import { API_Call } from "../../utils/API_index";

const useForm = (initialValues, validate) => {
  const [inputs, setInputs] = useState(initialValues);
  const [errors, setErrors] = useState({});

  // useEffect(() => {
  //   if (Object.keys(errors).length === 0) {
  //     callback();
  //   }
  // }, [errors]);

  const handleSubmit = (event, checked, product, setSuccess) => {
    event.preventDefault();

    const validationErrors = validate(inputs);
    const noErrors = Object.keys(validationErrors).length === 0;
    setErrors(validationErrors);
    if (noErrors) {
      if (!checked) {
        alert("Please accept terms and conditions");
        return;
      }
      // console.log("Authenticated", inputs);
      // console.log("product", product);
      axios
        .all([
          API_Call.postRecepient(inputs, product),
          API_Call.postOptIn(inputs, product),
        ])
        .then(
          axios.spread((...responses) => {
            const recepientStatus = responses[0];
            const optInStatus = responses[1];

            // console.log(
            //   `recepient status - ${recepientStatus} | opt In Status - ${optInStatus}`
            // );

            if (recepientStatus === "SUCCESS" && optInStatus === "SUCCESS") {
              setSuccess(true);
              setInputs({ firstname: "", lastname: "", email: "" });
            } else {
              alert("We've encountered an Issue. please try again");
            }
          })
        )
        .catch((errors) => {
          alert("We've encountered an Issue. please try again");
        });

      // console.log("pdf", downloadPdf);
      // let uploadFile = new File(
      //   [downloadPdf],
      //   "Symptom-Checker-Result-v3-What-Thrush.pdf",
      //   {
      //     type: "application/pdf",
      //     lastModified: Date.now(),
      //   }
      // );
      // console.log("uploadFile", uploadFile);
    } else {
      console.log("errors try again", validationErrors);
    }
  };

  const handleInputChange = (event) => {
    event.persist();
    setInputs((inputs) => ({
      ...inputs,
      [event.target.name]: event.target.value,
    }));
  };

  return {
    handleSubmit,
    handleInputChange,
    inputs,
    errors,
  };
};

export default useForm;
