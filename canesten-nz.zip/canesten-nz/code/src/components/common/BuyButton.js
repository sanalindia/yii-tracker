import React, { useState, useEffect, useRef } from "react";
import "../../css/components/BuyButton.scss";
const BuyButton = ({ buttonList }) => {
  const [open, setOpen] = useState(false);
  const [buttonString, setButtonString] = useState("");

  useEffect(() => {
    const buttonStr = Object.keys(buttonList).map((key) => {
      let img = require(`../../assets/Images/${key}.png`);
      return (
        <div class="retailer-information ">
          <a
            href={buttonList[key]}
            target="_blank"
            title={key.replace("-", " ")}
          >
            <span class="retailer-icon">
              <img alt={key.replace("-", " ")} src={img} />
            </span>
          </a>
        </div>
      );
    });
    setButtonString(buttonStr);
  }, []);
  const handleClick = (e, i) => {
    let tempOpen = open == true ? false : true;

    setOpen(tempOpen);
  };

  return (
    <>
      <button class="buttonBuynow" onClick={handleClick}>
        Buy Now
        {open == true ? (
          <span className="down-arrow"></span>
        ) : (
          <span className="down-arrow"></span>
        )}
      </button>
      {open == true ? (
        <div class="dropdown active-dropdown">{buttonString}</div>
      ) : (
        ""
      )}
    </>
  );
};
export default BuyButton;
