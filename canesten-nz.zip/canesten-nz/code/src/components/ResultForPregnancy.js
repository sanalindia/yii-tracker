import React, { useState, useEffect } from "react";
import "../css/components/ResultForPregnancy.scss";
import StartQuizContainer from "./StartQuizContainer";
import parse from "html-react-parser";
import { Constants } from "../constants";
import CommonCards from "./common/commonCards";
import EmailFormCard from "./common/EmailFormCard";
import SingleProduct from "./common/SingleProduct";
import SixDay from "../assets/Pdf/Symptom-Checker-Result-v3-No_6-Days.pdf";

const ResultForPregnancy = ({
  resultNumber,
  loadResult,
  onHomeClick,
  correctAnswersCount,
  lang,
  questionAnswersList,
  backClick,
}) => {
  useEffect(() => {}, []);

  const onClickBack = (e) => {
    backClick();
  };
  return (
    <div className="resultPregnancyContainer">
      <StartQuizContainer
        quizTitle={loadResult[0][0]}
        quizDesc={loadResult[0][1]}
        fromResultScreen={true}
      />
      <div className="result_bottom_main_div">
        <span className="result_bottom_span">
          <span className="result_count_header">
            Are you pregnant (or think you might be) or breastfeeding?
            {/* You
            answered {correctAnswersCount} out of {Constants.QUESTIONS_COUNT}{" "}
            questions correctly! */}
          </span>
          {/* <span className="result-divider"></span> */}
          <div className="result_share">
            <div className="result_content">
              Thrush is more common in pregnant women compared to those who are
              not pregnant, as higher estrogen levels increase the chance of
              developing vaginal thrush.
            </div>
            <div className="result_content">
              Canesten intravaginal preparations are the treatment of choice in
              the 2nd and 3rd trimester of pregnancy. These products are
              effective at treating thrush in pregnancy, and longer course may
              be required i.e. 6 days.
            </div>
            <div className="result_content">
              Vaginal pessaries are the preferable choice as they can be
              inserted without the use of an applicator.
            </div>
            <div className="result_content">
              Vaginal pessaries and creams are most conveniently used at night
              just before going to bed. Wearing a sanitary page overnight may
              help with any leaking medication.
            </div>
            <div className="result_content">
              If experiencing thrush in pregnancy it is recommended you seek
              medical advice
            </div>
          </div>
          <SingleProduct />
          <EmailFormCard
            downloadPdf={SixDay}
            filename={"Symptom-Checker-Result-v3-No_6-Days.pdf"}
            product={"Canesten6"}
          />
        </span>
        <div className="backButtonArea">
          <button onClick={onClickBack}>
            <span class="left-arrow"></span>
            BACK
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultForPregnancy;
