import React, { useEffect, useState, useLayoutEffect } from "react";
import { Cases } from "../utils/API/index";
import axios from "axios";
import Loader from "./common/loader";
import StartQuizContainer from "./StartQuizContainer";
import QuestionCard from "./common/QuestionCard";
import { Constants } from "../constants";
import Utility from "../utils/utility";
import ResultContainer from "./ResultContainer";
import "../css/components/quizContainer.scss";
import isMobileDevice from "responsive-react";
import Result from "../utils/result";
import { withResizeDetector } from "react-resize-detector/build/withPolyfill";
import "../css/components/quizContainer.scss";
import utility from "../utils/utility";
import "../css/components/RecurrentThrush.scss";
const RecurrentThrush = ({ backClick, closeClick }) => {
  const onClickBack = (e) => {
    backClick();
  };
  const onCloseClick = (e) => {
    closeClick();
  };
  return (
    <div className="end_quiz__container">
      <h1 className="title">Recurrent thrush / Unsuccessful treatment</h1>
      <div className="description">
        Experiencing thrush more than 4 times in 12 months is a recurrent
        condition. This requires specialty advice from your doctor, who may
        advise a treatment regime.
        <br />
        <br />
        There may be a reason your previous treatment was unsuccessful and your
        doctor will be able to advise.
      </div>
      <div className="buttonArea">
        <button className="back_button" onClick={onClickBack}>
          <span className="left-arrow"></span>
          Back
        </button>
        <button className="close_button" onClick={onCloseClick}>
          Close
        </button>
      </div>
    </div>
  );
};
export default withResizeDetector(RecurrentThrush);
