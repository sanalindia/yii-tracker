import { Injectable } from '@angular/core';
declare let ga: Function; // Declare ga as a function

@Injectable({
  providedIn: 'root'
})
export class GoogleAnalyticsService {

  constructor() { }

  public eventEmitter(eventCategory: string, eventAction: string, eventLabel: string = null, eventValue: number = null, gtmId: string = 'GTM-NXKPZWJ') {
    ga('create', gtmId, 'auto');  // Change the UA-ID to the one you got from Google Analytics
    ga('send', 'event', {eventCategory, eventLabel, eventAction, eventValue });
    }

}
