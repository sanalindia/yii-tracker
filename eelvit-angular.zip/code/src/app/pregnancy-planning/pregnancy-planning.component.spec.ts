import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PregnancyPlanningComponent } from './pregnancy-planning.component';

describe('PregnancyPlanningComponent', () => {
  let component: PregnancyPlanningComponent;
  let fixture: ComponentFixture<PregnancyPlanningComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PregnancyPlanningComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PregnancyPlanningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
