import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { Router } from '@angular/router';
import { StateService } from '../shared/services/state/state.service';

@Component({
  selector: 'app-pregnancy-planning',
  templateUrl: './pregnancy-planning.component.html',
  styleUrls: ['./pregnancy-planning.component.scss']
})
export class PregnancyPlanningComponent implements OnInit, AfterViewChecked {

  userType: string;
  isOnceLoadingDone: boolean;

  constructor( private stateService: StateService, private router: Router ) {}

  ngOnInit() {
    localStorage.setItem('anonymousFlowType', 'anonymousPlanningPregnancy');
    this.isOnceLoadingDone = false;
    this.userType = localStorage.getItem('userType');
    localStorage.setItem('journeyStageIndex', '1');
    if (this.userType === 'LoggedIn') {
    } else {
      this.stateService.changeUsertype('anonymous');
    }
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
      this.stateService.setIframeHeight('iFrameResizer0');
      this.isOnceLoadingDone = true;
     }
  }

}
