import { Component, OnInit, OnDestroy, HostListener, AfterViewChecked } from '@angular/core';
import { StateService } from '../shared/services/state/state.service';

@Component({
  selector: 'app-calendar-parent',
  templateUrl: './calendar-parent.component.html',
  styleUrls: ['./calendar-parent.component.scss']
})
export class CalendarParentComponent implements OnInit, AfterViewChecked, OnDestroy {

  saveJourney = true;
  isOnceLoadingDone: boolean;


  constructor( private stateService: StateService ) {
  }

  ngOnInit() {
    this.isOnceLoadingDone = false;
    localStorage.setItem('anonymousFlowType', 'LoggedInPlanningPregnancy');
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
      this.stateService.setIframeHeight('iFrameResizer0');
      this.isOnceLoadingDone = true;
    }
  }

  ngOnDestroy(): void {
  }
}
