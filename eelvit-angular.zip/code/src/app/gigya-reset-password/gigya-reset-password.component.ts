import { Component, OnInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { StateService } from '../shared/services/state/state.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
declare let gigya: any;

@Component({
  selector: 'app-gigya-reset-password',
  templateUrl: './gigya-reset-password.component.html',
  styleUrls: ['./gigya-reset-password.component.scss']
})
export class GigyaResetPasswordComponent implements OnInit, AfterViewChecked, OnDestroy {

  isOnceLoadingDone: boolean;
  countryCode: string;
  isGigyaScriptLoadedInstance: any;

  constructor(private stateService: StateService, private router: Router, private translateService: TranslateService) { }

  ngOnInit() {
    this.isOnceLoadingDone = false;
    this.countryCode = localStorage.getItem('gigyaLangDefault') || 'en';
    const iframeLocationDetails = this.stateService.getIframeLocationDetails('iFrameResizer0');
    if (iframeLocationDetails && iframeLocationDetails.pathname && iframeLocationDetails.pathname.length > 1 && iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2') && iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').indexOf('_') == -1) {
      this.countryCode = iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').toLowerCase();
      const langParamFromAssembly = window.parent.location.pathname.split('/')[1];
      if (langParamFromAssembly && langParamFromAssembly.indexOf('deco') != -1) { // (Without assembly integration) language code will be stored in case of checking angular URL directly
        this.countryCode = localStorage.getItem('gigyaLangDecoupled');
      }
    } else if(iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').indexOf('_') != -1) { // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
      const langParamFromAssembly = window.parent.location.pathname.split('/')[1];
      if (langParamFromAssembly && langParamFromAssembly.indexOf('deco') == -1) { // (With assembly integration) Assembly URL will have language code langugae in case of dual language
        this.countryCode = langParamFromAssembly.toLowerCase();
      } else if(langParamFromAssembly.indexOf('deco') != -1) { // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
        this.countryCode = localStorage.getItem('gigyaLangDecoupled');
      } else { // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
        this.countryCode = iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').split('_')[0].toLowerCase();
      }
    }
    this.translateService.get('HOME').subscribe((translated) => {
      this.countryCode = translated.LANGUAGE_CODE || this.countryCode;
      this.callGigyaScreen(translated.GIGYA_SCREEN_ID.RESET_PASSWORD, translated.GIGYA_SCREEN_SET_ID.RESET_PASSWORD);
    });
  }

  /* This method waits until gigya defined and loads gigya screen */
  callGigyaScreen(resetPassowrdScreenID: string, resetPassowrdScreenSetID: string) {
    this.isGigyaScriptLoadedInstance = this.stateService.isGigyaScriptLoaded.subscribe((flag: boolean) => {
      if (flag) {
        gigya.accounts.showScreenSet({screenSet: (resetPassowrdScreenSetID || 'bayer-RegistrationLogin'), startScreen: (resetPassowrdScreenID || 'bayer-reset-password-screen'), lang: this.countryCode, containerID: 'resetpassword-container', onAfterSubmit: this.onAfterSubmit.bind(this) });
      }
    });
  }

  public onAfterSubmit(obj) {
    if (obj.response && obj.response.status !== 'FAIL') { }
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
      this.stateService.setIframeHeight('iFrameResizer0');
      this.isOnceLoadingDone = true;
    }
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
    if (this.isGigyaScriptLoadedInstance) {
      this.isGigyaScriptLoadedInstance.unsubscribe();
    }
  }

}
