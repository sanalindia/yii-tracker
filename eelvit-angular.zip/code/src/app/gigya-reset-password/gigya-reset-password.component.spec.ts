import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GigyaResetPasswordComponent } from './gigya-reset-password.component';

describe('GigyaResetPasswordComponent', () => {
  let component: GigyaResetPasswordComponent;
  let fixture: ComponentFixture<GigyaResetPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GigyaResetPasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GigyaResetPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
