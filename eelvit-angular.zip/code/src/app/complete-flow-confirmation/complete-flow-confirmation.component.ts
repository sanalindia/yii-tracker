import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { StateService } from '../shared/services/state/state.service';

@Component({
  selector: 'app-complete-flow-confirmation',
  templateUrl: './complete-flow-confirmation.component.html',
  styleUrls: ['./complete-flow-confirmation.component.scss']
})
export class CompleteFlowConfirmationComponent implements OnInit {

  showLogin = false;
  saveSuccess = false;
  userType: string;
  loginError = false;
  loggedInUserName: string;
  profileData: any;
  isOkButtonVisible: boolean;

  constructor(private router: Router,  private stateService: StateService, private translateService: TranslateService) { }

  ngOnInit() {
    this.loggedInUserName = '';
    this.isOkButtonVisible = false;
    this.userType = localStorage.getItem('userType');
    if (this.userType === 'LoggedIn') {
      this.profileData = JSON.parse(localStorage.getItem('profile'));
      this.loggedInUserName = this.profileData.firstName;
    }
    this.translateService.get('HOME.COMPLETE_FLOW').subscribe((translated) => {
      if (translated.IS_OK_BUTTON_VISIBLE && translated.IS_OK_BUTTON_VISIBLE === true) {
        this.isOkButtonVisible = true;
      } else {
        this.isOkButtonVisible = false;
      }
    });
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location) {
      this.stateService.setIframeHeight('iFrameResizer0');
      }
  }

  saveJourney() {
    this.saveSuccess = true;
  }

  notNowClick() {
    this.router.navigate(['/calendar']);
  }

  /* Go to planning page when user click on flow complete button only on Bulgarian website */
  goToAnonymoysPage() {
    this.router.navigate(['/planning']);
  }

}
