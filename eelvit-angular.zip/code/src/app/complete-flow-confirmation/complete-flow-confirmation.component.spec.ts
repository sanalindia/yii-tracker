import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteFlowConfirmationComponent } from './complete-flow-confirmation.component';

describe('CompleteFlowConfirmationComponent', () => {
  let component: CompleteFlowConfirmationComponent;
  let fixture: ComponentFixture<CompleteFlowConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteFlowConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteFlowConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
