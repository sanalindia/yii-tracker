import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WelcomeExperienceOrganicComponent } from './welcome-experience-organic.component';

describe('WelcomeExperienceOrganicComponent', () => {
  let component: WelcomeExperienceOrganicComponent;
  let fixture: ComponentFixture<WelcomeExperienceOrganicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WelcomeExperienceOrganicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeExperienceOrganicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
