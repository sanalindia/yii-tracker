import { Component, OnInit, AfterViewChecked } from "@angular/core";
import { DrupalJsonapiService } from "../shared/services/drupal-jsonapi/drupal-jsonapi.service";
import { GoogleAnalyticsService } from "../google-analytics.service";
import { NavigationExtras, Router } from "@angular/router";
import { StateService } from "../shared/services/state/state.service";
import { ActivatedRoute } from "@angular/router";

declare var gsap: any;
declare var ScrollTrigger: any;
declare var DrawSVGPlugin: any;
export interface buttonInterface {
  text: string;
  url: string;
}
@Component({
  selector: "app-welcome-experience-organic",
  templateUrl: "./welcome-experience-organic.component.html",
  styleUrls: ["./welcome-experience-organic.component.scss"],
})
export class WelcomeExperienceOrganicComponent
  implements OnInit, AfterViewChecked
{
  isOnceLoadingDone: boolean;
  isServiceResponseComplete: boolean;
  frame1Text1: string;
  frame1Text2: string;
  frame1Text3: string;
  frame2Text1: string;
  frame3Text1: string;
  frame4Text1: string;
  frame5Text1: string;
  frame5Text2: string;
  frame5Text3: string;
  button1: buttonInterface;
  button2: buttonInterface;
  allImagesData: object;
  // ifr = window.parent.document.querySelector(
  //   "#iFrameResizer0"
  // ) as HTMLIFrameElement;
  ifr = window.parent.document.querySelector(
    'iframe[src*="deco/new-elevit-journey-elements"]'
  ) as HTMLIFrameElement;
  iframeParent = window.parent.document.querySelector(
    ".decoupled-component"
  ) as HTMLIFrameElement;
  headerval =
    (window.parent.document.querySelector("header") &&
      window.parent.document.querySelector("header").offsetHeight) ||
    100;
  footerVal =
    (window.parent.document.querySelector("footer") &&
      window.parent.document.querySelector("footer").offsetHeight) ||
    0;

  constructor(
    private drupalJsonapiService: DrupalJsonapiService,
    public googleAnalyticsService: GoogleAnalyticsService,
    private router: Router,
    private stateService: StateService,
    private route: ActivatedRoute

  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
       if (params.lang.toLowerCase() === "vi") {
        document.getElementsByTagName('body')[0].classList.add('custom_class_font_remove');
       }
    });
    this.isOnceLoadingDone = this.isServiceResponseComplete = false;
    this.frame1Text1 =
      this.frame1Text2 =
      this.frame1Text3 =
      this.frame2Text1 =
      this.frame3Text1 =
      this.frame4Text1 =
      this.frame5Text1 =
      this.frame5Text2 =
      this.frame5Text3 =
        "";
    this.button1 = { text: "", url: "" };
    this.button2 = { text: "", url: "" };
    this.allImagesData = {};
    document.getElementById("loading").style.display = "block";
    let allImagesString = "",
      imagecount = 1;
    this.drupalJsonapiService
      .getElevitEveryBeginningData("WelcomeExperienceOrganic")
      .subscribe(
        (response: any) => {
          if (
            response &&
            response.included &&
            response.included[0] &&
            response.included[0].attributes &&
            response.included[0].attributes.json_values &&
            JSON.parse(response.included[0].attributes.json_values) &&
            JSON.parse(response.included[0].attributes.json_values).model
          ) {
            const responsedata = JSON.parse(
              response.included[0].attributes.json_values
            ).model;
            Object.entries(responsedata).forEach((value) => {
              Object.entries(value[1]).forEach((val) => {
                if (val[1].text) {
                  let element = document.createElement("div");
                  element.innerHTML = val[1].text;
                  for (let drupalEntityElement of Array.from(
                    element.getElementsByTagName("drupal-entity")
                  )) {
                    allImagesString +=
                      "&filter[name-filter][condition][value][" +
                      imagecount++ +
                      "]=" +
                      drupalEntityElement.getAttribute("data-entity-uuid");
                  }
                  if (
                    element.getElementsByTagName("strong") &&
                    element.getElementsByTagName("strong")[0] &&
                    element.getElementsByTagName("strong")[0].innerHTML
                  ) {
                    let frameLabel =
                      element.getElementsByTagName("strong")[0].innerHTML;
                    let frameNumber = frameLabel.match(/\d+/)
                      ? parseInt(frameLabel.match(/\d+/)[0], 10)
                      : 0;
                    switch (frameNumber) {
                      case 1:
                        this.frame1Text1 =
                          element.getElementsByTagName("span")[0].innerHTML;
                        break;
                      case 2:
                        this.frame2Text1 =
                          element.getElementsByTagName("span")[0].innerHTML;
                        break;
                      case 3:
                        this.frame3Text1 =
                          element.getElementsByTagName("span")[0].innerHTML;
                        break;
                      case 4:
                        this.frame4Text1 =
                          element.getElementsByTagName("span")[0].innerHTML;
                        break;
                      case 5:
                        this.frame5Text1 =
                          element.getElementsByTagName("span")[0].innerHTML;
                        this.frame5Text2 =
                          element.getElementsByTagName("span")[1].innerHTML;
                        this.button1 = {
                          text: element.getElementsByTagName("a")[0].innerHTML,
                          url: element.getElementsByTagName("a")[0].href,
                        };
                        this.button2 = {
                          text: element.getElementsByTagName("a")[1].innerHTML,
                          url: element.getElementsByTagName("a")[1].href,
                        };
                        this.frame5Text3 =
                          element.getElementsByTagName("span")[2].innerHTML;
                        break;
                      default: // case 0 or SVG image
                    }
                  }
                }
              });
            });

            let allImagesData = {};
            this.drupalJsonapiService
              .getElevitEveryBeginningImageData(allImagesString)
              .subscribe(
                (imageResponse: any) => {
                  document.getElementById("loading").style.display = "none";
                  imageResponse.included.forEach((imageData, index) => {
                    allImagesData[imageData.attributes.filename] = {
                      url: imageData.attributes.uri.url,
                      alt: imageResponse.data[index].relationships.image.data
                        .meta.alt,
                    };
                  });
                  let svgImageNames = Object.keys(allImagesData).filter(
                    (value) => value.indexOf("svg") != -1
                  );
                  if (
                    Object.keys(allImagesData)
                      .filter((value) => value.indexOf("svg") != -1)[0]
                      .indexOf("mobile") != -1
                  ) {
                    svgImageNames.reverse();
                  }
                  svgImageNames.forEach((svgImageName, index) => {
                    if (allImagesData[svgImageName].url) {
                      let xmlhttp = new XMLHttpRequest();
                      xmlhttp.open(
                        "GET",
                        window.location.origin +
                          allImagesData[svgImageName].url,
                        false
                      );
                      xmlhttp.setRequestHeader("X-PINGOTHER", "pingpong");
                      xmlhttp.setRequestHeader(
                        "Content-Type",
                        "application/xml"
                      );
                      xmlhttp.setRequestHeader(
                        "Access-Control-Allow-Origin",
                        "*"
                      );
                      xmlhttp.send();
                      !index
                        ? (document.getElementsByClassName(
                            "desktop"
                          )[0].innerHTML = xmlhttp.responseText)
                        : (document.getElementsByClassName(
                            "mobile"
                          )[0].innerHTML = xmlhttp.responseText);
                    }
                  });

                  this.allImagesData = allImagesData;
                  this.isServiceResponseComplete = true;
                },
                () => {
                  const navigationExtras: NavigationExtras = {
                    state: { data: "No image data fetched. Please try again." },
                  };
                  this.router.navigate(["user-message"], navigationExtras);
                  document.getElementById("loading").style.display = "none";
                }
              );
          }
        },
        () => {
          const navigationExtras: NavigationExtras = {
            state: { data: "No data fetched. Please try again." },
          };
          this.router.navigate(["user-message"], navigationExtras);
          document.getElementById("loading").style.display = "none";
        }
      );
    gsap.registerPlugin(ScrollTrigger, DrawSVGPlugin);
  }

  /* 1. This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded
    2. SVG animation */
  ngAfterViewChecked() {
    if (!this.isOnceLoadingDone && this.isServiceResponseComplete) {
      this.isOnceLoadingDone = true;
      if (this.ifr && this.iframeParent) {
        let style = `top:${this.headerval}px;position:fixed;width:100%;height:100%;bottom:0px;overflow-y:auto !important;-webkit-overflow-scrolling:touch !important;`;
        this.iframeParent.setAttribute("style", style);
        this.ifr.style.position = "absolute";
        this.ifr.style.height = "100%";
        this.ifr.style.width = "100%";
        this.gsapAnimateOnScroll();
        this.heightAdjustments();
        this.ifr.onload = () => {
          this.heightAdjustments();
        };
        window.parent.onscroll = () => {
          this.scrollParent();
        };
      }
    }
  }

  /* This function sets iframe (decoupled-component class block), section02 and footer height */
  heightAdjustments() {
    window.parent.document.body.style.height =
      this.ifr.contentWindow.document.body.offsetHeight +
      parseInt(this.iframeParent.style.top) +
      parseInt(this.iframeParent.style.bottom) -
      this.footerVal +
      "px";
    let header = window.parent.document.querySelector("header");
    let footer = window.parent.document.querySelector("footer");
    let section02 = this.ifr.contentWindow.document.querySelector(
      "#section02"
    ) as HTMLDivElement;
    if (header && window.innerWidth < 500) {
      header.style.position = "fixed";
    }
    if (footer) {
      let additionalHeight = 0;
      if (window.innerWidth < 500) {
        additionalHeight = 200;
      }
      footer.style.position = "absolute";
      footer.style.top = section02.offsetHeight + additionalHeight + "px";
      footer.style.width = "100%";
    }
    section02.style.height = section02.offsetHeight + this.footerVal + "px";
  }

  /* set the style properties to enable assembly page to scroll */
  scrollParent() {
    if (window.parent.pageYOffset < this.headerval) {
      this.iframeParent.style.top =
        this.headerval - window.parent.pageYOffset + "px";
    } else if (window.parent.pageYOffset >= this.headerval) {
      this.iframeParent.style.top = "0";
    }
    this.ifr.contentWindow.document.documentElement.scrollTop =
      window.parent.pageYOffset;
    this.ifr.contentWindow.document.body.scrollTop = window.parent.pageYOffset; // Google Chrome, Safari, documents without valid doctype
  }

  /* This function animate svg on scroll */
  gsapAnimateOnScroll() {
    setTimeout(() => {
      ScrollTrigger.defaults({
        toggleActions: "play pause resume reset",
        scrub: true,
      });
      let duration = 0.5;
      setInterval(() => {
        duration = duration + 1;
      }, 500);
      ScrollTrigger.matchMedia({
        // desktop
        "(min-width: 768px)": () => {
          // setup animations and ScrollTriggers for screens over 800px wide (desktop) here...
          // ScrollTriggers will be reverted/killed when the media query doesn't match anymore.
          gsap
            .timeline({
              scrollTrigger: {
                trigger: "#section01",
                start: "top top",
                scrub: true,
                end: "bottom +=100%",
              },
            })
            .fromTo(
              ".desktop .cls-0",
              { drawSVG: "100% 100% live" },
              { duration: 1, drawSVG: "0% 100% live" }
            )
            .to("#section02", { y: "-=100", duration: 0.1 }, 0.1)
            .to("#section02", { y: "-=100", duration: 0.1 }, 0.2)
            .to("#section02", { y: "-=100", duration: 0.1 }, 0.5)
            .to("#section02", { y: "+=100", duration: 0.1 }, 0.6)
            .to("#section02", { y: "+=100", duration: 0.1 }, 0.7)
            .to("#section02", { duration: 0.01 }, 0.71)
            .to("#section02", { duration: 0.01 }, 0.72)
            .to("#section02", { duration: 0.01 }, 0.73)
            .to("#section02", { duration: 0.01 }, 0.74)
            .to("#section02", { duration: 0.01 }, 0.75)
            .to("#section02", { duration: 0.01 }, 0.76)
            .to("#section02", { duration: 0.01 }, 0.77)
            .to("#section02", { duration: 0.01 }, 0.78)
            .to("#section02", { duration: 0.01 }, 0.79)
            .to("#section02", { y: "+=100", duration: 0.78 }, 0.8);
          // Animation for opacity
          const boxes = gsap.utils.toArray(".animation");
          let top = ["180px top", "230px top", "300px top", "302px top"];
          let bottom = ["280px", "330px", "400px", "402px"];
          boxes.forEach((box, index) => {
            const anim = gsap.fromTo(
              box,
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            );
            ScrollTrigger.create({
              trigger: ".first_container",
              animation: anim,
              id: box.classList[0],
              start: top[index],
              end: bottom[index],
            });
          });
          ScrollTrigger.create({
            trigger: ".first_container",
            animation: gsap.fromTo(
              ".second_txt_cont",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
            start: "150px top",
            end: "250px",
          });
          ScrollTrigger.create({
            trigger: ".bubble-3",
            animation: gsap.fromTo(
              ".third_txt",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
            start: "-250 top",
          });
          ScrollTrigger.create({
            trigger: ".third-image-foreground",
            animation: gsap.fromTo(
              ".third_animation",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
            start: "-150 top",
            bottom: "100px",
          });
          const sixthAnimationLogoBoxes = gsap.utils.toArray(
            ".sixth-animation-logo"
          );
          let animationTop = [
            "-250px top",
            "-150px top",
            "-50px top",
            "-50px top",
            "-50px top",
            "50px top",
            "150px top",
            "250px top",
          ];
          let animationBottom = [
            "-150px",
            "-50px",
            "50px",
            "50px",
            "50px",
            "150px",
            "250px",
            "350px",
          ];
          if (this.stateService.isTablet()) {
            animationTop = [
              "-950px top",
              "-850px top",
              "-700px top",
              "-700px top",
              "-700px top",
              "-650px top",
              "-550px top",
              "-450px top",
            ];
            animationBottom = [
              "-850px",
              "-750px",
              "-600px",
              "-600px",
              "-600px",
              "-550px",
              "-450px",
              "-350px",
            ];
          }
          if (screen.width > 2500) {
            animationTop = [
              "-1050px top",
              "-950px top",
              "-800px top",
              "-800px top",
              "-800px top",
              "-750px top",
              "-650px top",
              "-550px top",
            ];
            animationBottom = [
              "-950px",
              "-850px",
              "-700px",
              "-700px",
              "-700px",
              "-650px",
              "-550px",
              "-450px",
            ];
          }
          sixthAnimationLogoBoxes.forEach((box, index) => {
            const anim = gsap.fromTo(
              box,
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            );
            ScrollTrigger.create({
              trigger: ".sixth_container",
              animation: anim,
              id: box.classList[0],
              start: animationTop[index],
              end: animationBottom[index],
            });
          });
          ScrollTrigger.create({
            trigger: ".third_container",
            animation: gsap.fromTo(
              ".btn_container",
              { autoAlpha: 1 },
              { duration: 0.5, autoAlpha: 0 }
            ),
            start: "-500 top",
            end: "-300px",
          });
        },
        // mobile
        "(max-width: 767px)": () => {
          // Any ScrollTriggers created inside these functions are segregated and get
          // reverted/killed when the media query doesn't match anymore.
          gsap
            .timeline({
              scrollTrigger: {
                trigger: "#section01",
                start: "top top",
                end: "bottom +=100%",
              },
            })
            .fromTo(
              ".mobile .cls-1",
              { drawSVG: "100% 100% live" },
              { duration: 1, drawSVG: "0% 100% live" }
            )
            .to("#section02", { y: "+=100", duration: 0.1 }, 0)
            .to("#section02", { y: "-=100", duration: 0.1 }, 0.1)
            .to("#section02", { y: "-=100", duration: 0.05 }, 0.2)
            .to("#section02", { y: "-=100", duration: 0.05 }, 0.3)
            .to("#section02", { y: "-=100", duration: 0.05 }, 0.5)
            .to("#section02", { y: "+=100", duration: 0.1 }, 0.6)
            .to("#section02", { y: "+=100", duration: 0.1 }, 0.7)
            .to("#section02", { duration: 0.01 }, 0.71)
            .to("#section02", { duration: 0.01 }, 0.72)
            .to("#section02", { duration: 0.01 }, 0.73)
            .to("#section02", { duration: 0.01 }, 0.74)
            .to("#section02", { duration: 0.01 }, 0.75)
            .to("#section02", { duration: 0.01 }, 0.76)
            .to("#section02", { duration: 0.01 }, 0.77)
            .to("#section02", { duration: 0.01 }, 0.78)
            .to("#section02", { duration: 0.01 }, 0.79)
            .to("#section02", { y: "+=100", duration: 0.73 }, 0.8);
          // Animation for opacity
          const boxes = gsap.utils.toArray(".animation");
          let top = ["250px top", "300px top", "450 top", "550px top"];
          let bottom = ["350px", "400px", "550px", "650px"];
          boxes.forEach((box, index) => {
            const anim = gsap.fromTo(
              box,
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            );
            ScrollTrigger.create({
              trigger: ".first_container",
              animation: anim,
              id: box.classList[0],
              start: top[index],
              end: bottom[index],
            });
          });
          ScrollTrigger.create({
            trigger: ".first_container",
            animation: gsap.fromTo(
              ".second_txt_cont",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
            start: "400px top",
            end: "500px",
          });
          ScrollTrigger.create({
            trigger: ".bubble-3",
            animation: gsap.fromTo(
              ".third_txt",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
            start: "-125px top",
          });
          ScrollTrigger.create({
            trigger: ".third_txt",
            start: "-120px top",
            end: "20px",
            animation: gsap.fromTo(
              ".fourth_txt",
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            ),
          });
          const sixthAnimationLogoBoxes = gsap.utils.toArray(
            ".sixth-animation-logo"
          );
          let animationTop = [
            "-350px top",
            "-250px top",
            "-50px top",
            "0px top",
            "50px top",
            "150px top",
            "250px top",
            "350px top",
          ];
          let animationBottom = [
            "-250px",
            "-150px",
            "50px",
            "100px",
            "150px",
            "250px",
            "350px",
            "450px",
          ];
          sixthAnimationLogoBoxes.forEach((box, index) => {
            const anim = gsap.fromTo(
              box,
              { autoAlpha: 0 },
              { duration: 0.5, autoAlpha: 1 }
            );
            ScrollTrigger.create({
              trigger: ".sixth_container",
              animation: anim,
              id: box.classList[0],
              start: animationTop[index],
              end: animationBottom[index],
            });
          });
          ScrollTrigger.create({
            trigger: ".third_container",
            animation: gsap.fromTo(
              ".btn_container",
              { autoAlpha: 1 },
              { duration: 0.5, autoAlpha: 0 }
            ),
            start: "-650 top",
            end: "-450px",
          });
        },
        // all
        all: () => {
          // ScrollTriggers created here aren't associated with a particular media query,
          // so they persist.
        },
      });
    });
  }

  /* trigger button GTM */
  buttonGTM(text: string, url: string) {
    this.googleAnalyticsService.eventEmitter(
      "CTA",
      text,
      "Welcome Experience Organic",
      0,
      "GTM-W3F7855"
    );
    if (url) {
      window.open(url, "_top");
    }
  }
}
