import { Component, OnInit, Renderer2, Inject } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { NavigationExtras, Router } from "@angular/router";
import { DOCUMENT } from "@angular/common";
import * as moment from "moment";
import { StateService } from "./shared/services/state/state.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit {
  title = "elevit-elements-project";
  isLiveEnvironment: boolean;
  lang: string;

  constructor(
    public translate: TranslateService,
    private router: Router,
    private renderer2: Renderer2,
    @Inject(DOCUMENT) private _document,
    private stateService: StateService
  ) {
    this.isLiveEnvironment = false;
    const iframeLocationDetails =
      this.stateService.getIframeLocationDetails("iFrameResizer0");
    // Below condition to exclude EEB routes from running Gigya script, loading lang code, custromized months moment library, i18n live configiration and to stop translaiton files laoding
    let routePathToExcludeGigyaScriptLoad = [
      "welcomeExperienceOrganic",
      "welcomeExperiencePurchase",
      "eebOnlyCounter",
      "user-message",
      "everybeginning",
    ];
    let isEEBRelatedPage = false;
    routePathToExcludeGigyaScriptLoad.forEach((routePath) => {
      if (iframeLocationDetails.hash.indexOf(routePath) !== -1) {
        isEEBRelatedPage = true;
      }
    });
    if (!isEEBRelatedPage) {
      this.lang = "";
      localStorage.setItem("gigyaLangDecoupled", "");
      let lang = "",
        url = "";
      if (
        iframeLocationDetails &&
        iframeLocationDetails.pathname &&
        iframeLocationDetails.pathname.length > 1 &&
        iframeLocationDetails.hash.replace(
          /(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/,
          "$2"
        ) &&
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") == -1
      ) {
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") != -1
        ) {
          // (Without assembly integration) language code will be stored in case of checking angular URL directly
          localStorage.setItem(
            "gigyaLangDecoupled",
            iframeLocationDetails.hash
              .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
              .toLowerCase()
          );
        }
        lang = iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .toLowerCase();
        this.isLiveEnvironment =
          iframeLocationDetails.pathname.split("/")[1] == "deco";
        // This below code is written to test dev credentials into master branch(deco space)
        if (
          iframeLocationDetails.hash
            .replace(/(.*env=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
            .toLowerCase() === "dev"
        ) {
          this.isLiveEnvironment = false;
        }
        url = `/${
          iframeLocationDetails.pathname.split("/")[1]
        }/new-elevit-journey-elements/dist/assets/i18n/${lang}.json`;
      } else if (
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") != -1
      ) {
        // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") == -1
        ) {
          // (With assembly integration) Assembly URL will have language code langugae in case of dual language
          lang = langParamFromAssembly.toLowerCase();
          this.isLiveEnvironment =
            iframeLocationDetails.pathname.split("/")[1] == "deco";
        } else if (langParamFromAssembly.indexOf("deco") != -1) {
          // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
          let selectedLang = prompt("Please enter your language code", "");
          if (selectedLang != null) {
            localStorage.setItem("gigyaLangDecoupled", selectedLang);
          } else {
            localStorage.setItem(
              "gigyaLangDecoupled",
              iframeLocationDetails.hash
                .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
                .split("_")[0]
                .toLowerCase()
            );
          }
          lang = selectedLang;
          this.isLiveEnvironment =
            iframeLocationDetails.pathname.split("/")[1] == "deco";
        } else {
          // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
          lang = iframeLocationDetails.hash
            .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
            .split("_")[0]
            .toLowerCase();
          this.isLiveEnvironment =
            iframeLocationDetails.pathname.split("/")[1] == "deco";
        }
        url = `/${
          iframeLocationDetails.pathname.split("/")[1]
        }/new-elevit-journey-elements/dist/assets/i18n/${lang}.json`;
      } else {
        // Default en lang will be selected in case of all the conditions failure and to check code locally this block will be used
        lang = "en";
        localStorage.setItem("gigyaLangDefault", lang.toLowerCase());
        url = `assets/i18n/${lang.toLowerCase()}.json`;
      }
      const navigationExtras: NavigationExtras = {
        state: { data: "Page could not be loaded. Please try again later." },
      };
      let translateObs;
      if (lang.length <= 5 && this.isFileExists(url)) {
        translate.addLangs([lang]);
        translate.setDefaultLang(lang);
        this.lang = lang;
        translate.use(lang).subscribe({
          error: (err) => {
            this.router.navigate(["user-message"], navigationExtras);
          },
        });
        translateObs = this.translate.get("HOME");
      } else {
        this.router.navigate(["user-message"], navigationExtras);
      }
      translateObs &&
        translateObs.subscribe((translated) => {
          const gigyaApiKey = this.isLiveEnvironment
            ? translated.GIGYA_API_KEY.PROD
            : translated.GIGYA_API_KEY.DEV;
          moment.locale("moment_lang_locale_i18n");
          moment.updateLocale("moment_lang_locale_i18n", {
            months: translated.CALENDAR_PROPERTIES._monthsFull,
            monthsShort: translated.CALENDAR_PROPERTIES._monthsShort,
            weekdaysShort: translated.CALENDAR_PROPERTIES._weekdaysShort,
          });
          let script = this.renderer2.createElement("script");
          script.type = "text/javascript";
          script.lang = "javascript";
          script.src = `https://cdns.gigya.com/js/gigya.js?apikey=${gigyaApiKey}`;
          script.onload = () => {
            this.stateService.updateGigyaScriptLoadedFlag(true);
          };
          this.renderer2.appendChild(this._document.body, script);
        });
    }
  }

  ngOnInit() {}

  /* return true if language file exists */
  public isFileExists(url: string) {
    const xhr = new XMLHttpRequest();
    xhr.open("HEAD", url, false);
    xhr.send();
    return xhr.status !== 404 && xhr.status !== 403;
  }

  onActivate(scrollTemplate: HTMLElement) {
    if (
      !scrollTemplate.getElementsByTagName("app-vitamin-only-counter").length
    ) {
      scrollTemplate.scrollIntoView();
    } else {
      document.body.style.backgroundColor = "#da87bb";
    }
  }
}
