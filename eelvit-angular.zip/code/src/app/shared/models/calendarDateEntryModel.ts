export class CalendarDateEntryType {
    calendarDate: string;
    calendarEntry: CalendarDateEntryValue;
}

class CalendarDateEntryValue {
    bodyBasalTemp?: string;
    mucusState?: string;
    intercourse?: string;
    notes?: string;
}

export class SelectedInterCourse {
    label: string;
    value: string;
}
