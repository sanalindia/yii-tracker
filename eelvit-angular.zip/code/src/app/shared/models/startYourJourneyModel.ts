// import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
export class StartYourJourneyModel {
    constructor(
        public pregnantStageIndex: number
      ) { }
}


export const journeyParams: StartYourJourneyModel = {
    pregnantStageIndex: 1
};
