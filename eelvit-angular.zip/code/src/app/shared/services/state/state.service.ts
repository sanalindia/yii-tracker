import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { NgbCalendar } from "@ng-bootstrap/ng-bootstrap";
declare let ga: Function; // Declare ga as a function

@Injectable({
  providedIn: "root",
})
export class StateService {
  initData = {
    userType: "",
    pregnantStage: "",
    pregnancyPlanningOptions: {},
    profile: {},
  };

  localData: any;
  profileData: any;

  private pregnantStage = new BehaviorSubject<number>(undefined);
  pregnantStageIndex = this.pregnantStage.asObservable();

  private selectedUserType = new BehaviorSubject<string>("");
  userType = this.selectedUserType.asObservable();

  private monthNumberSub = new BehaviorSubject<number>(undefined);
  calendarCurrentMonthNumber = this.monthNumberSub.asObservable();

  private gigyaScriptLoaded = new BehaviorSubject<boolean>(false);
  isGigyaScriptLoaded = this.gigyaScriptLoaded.asObservable();

  constructor(public calendar: NgbCalendar) {}

  /* Save Pregnancy Stage Index: 0/1/2 */
  changePregnantStageIndex(pregnantStageIndex: number) {
    this.pregnantStage.next(pregnantStageIndex);
  }

  /* Save Month Number to show calendar month in accordian for mobile mode */
  updateMonthNumber(calendarCurrentMonthNumber: number) {
    this.monthNumberSub.next(calendarCurrentMonthNumber);
  }

  /* Save User Type value:
  1. Anonymous
  2. LoggedIn */
  changeUsertype(userType: string) {
    this.selectedUserType.next(userType);
    localStorage.setItem("userType", userType);
  }

  /* check if gigya script is loaded or not */
  updateGigyaScriptLoadedFlag(isGigyaScriptLoaded: boolean) {
    this.gigyaScriptLoaded.next(isGigyaScriptLoaded);
  }

  // Load data from LocalStorage
  public preloadData(data) {
    this.localData = data;
  }

  public setLoggedInUser(res) {
    const profile = {
      ...res.response.profile,
      UID: res.response.UID,
      Screen: res.screen,
    };
    const data = { ...this.localData, profile };
    localStorage.setItem("profile", JSON.stringify(profile));
    this.profile(profile);
  }

  public profile(user) {
    if (user) {
      this.profileData = { ...user };
    }
    return this.profileData;
  }

  /* This function is for setting iframe height inside Elevit Assembly equals to Decoupled component page */
  public setIframeHeight(id, classNameforContentHeight = "") {
    // const ifrm = window.parent.document.getElementById(id) as HTMLIFrameElement;
    const ifrm = window.parent.document.querySelector(
      'iframe[src*="deco/new-elevit-journey-elements"]'
    ) as HTMLIFrameElement;
    const doc =
      ifrm &&
      (ifrm.contentDocument
        ? ifrm.contentDocument
        : ifrm.contentWindow.document);
    if (ifrm && doc) {
      ifrm.style.visibility = "hidden";
      setTimeout(() => {
        if (classNameforContentHeight) {
          ifrm.style.height =
            (document.getElementsByClassName(classNameforContentHeight)[0]
              .scrollHeight || 100) + "px";
        } else {
          if (
            document.getElementsByClassName("iframe-dom-class") &&
            (document.getElementsByClassName("iframe-dom-class")[1] ||
              document.getElementsByClassName("iframe-dom-class")[0])
          ) {
            if (document.getElementsByClassName("iframe-dom-class")[1]) {
              ifrm.style.height =
                (document.getElementsByClassName("iframe-dom-class")[1]
                  .scrollHeight || 100) + "px";
            } else {
              ifrm.style.height =
                (document.getElementsByClassName("iframe-dom-class")[0]
                  .scrollHeight || 100) + "px";
            }
          } else {
            ifrm.style.height = doc.body.scrollHeight + "px";
          }
        }
      }, 1000);
      ifrm.style.visibility = "visible";
    }
  }

  public getIframeLocationDetails(id) {
    // const ifrm = window.parent.document.getElementById(id) as HTMLIFrameElement;
    const ifrm = window.parent.document.querySelector(
      'iframe[src*="deco/new-elevit-journey-elements"]'
    ) as HTMLIFrameElement;

    const contentWindow = ifrm && ifrm.contentWindow;
    if (contentWindow && contentWindow.location) {
      if (contentWindow.location.hash.indexOf("lang=") == -1) {
        contentWindow.location.hash =
          contentWindow.location.hash +
          "?lang=" +
          ifrm.src.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2");
      }
      return contentWindow.location;
    } else {
      return window.parent.location;
    }
  }

  /* detect if app is running in IOS device or not */
  public isIOS() {
    return ![
      "Win32",
      "OS/2",
      "Pocket PC",
      "Windows",
      "Win16",
      "WinCE",
    ].includes(navigator.platform);
  }

  /* detect if app is running in Tablet device or not */
  public isTablet() {
    return /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(
      navigator.userAgent.toLowerCase()
    );
  }
}
