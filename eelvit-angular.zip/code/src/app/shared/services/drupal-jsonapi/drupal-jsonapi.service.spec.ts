import { TestBed } from '@angular/core/testing';

import { DrupalJsonapiService } from './drupal-jsonapi.service';

describe('DrupalJsonapiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DrupalJsonapiService = TestBed.get(DrupalJsonapiService);
    expect(service).toBeTruthy();
  });
});
