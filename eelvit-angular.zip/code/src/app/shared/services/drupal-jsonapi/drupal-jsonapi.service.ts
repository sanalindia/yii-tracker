import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DrupalJsonapiService {

  reqHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*'
  });

  constructor( private http: HttpClient ) { }

  /* This method is for getting whole page content response from drupal jsonapi service */
  public getElevitEveryBeginningData(EEBpageType) {
    // EEBpageType value could be WelcomeExperiencePurchase or WelcomeExperienceOrganic
    return this.http.get(`/jsonapi/node/page?filter[title]=${EEBpageType}&include=field_layout`, {
      headers: this.reqHeaders
    });
  }

  /* This method is for getting whole page content response from drupal jsonapi service */
  public getElevitEveryBeginningImageData(allImagesString) {
    let EEBImageurl = '/jsonapi/media/image/?filter[name-filter][condition][path]=id&filter[name-filter][condition][operator]=IN' + allImagesString + '&include=image';
    return this.http.get(EEBImageurl, {
      headers: this.reqHeaders
    });
  }

}
