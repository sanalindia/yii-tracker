import { TestBed } from '@angular/core/testing';

import { AdobeSoapService } from './adobe-soap.service';

describe('AdobeSoapService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdobeSoapService = TestBed.get(AdobeSoapService);
    expect(service).toBeTruthy();
  });
});
