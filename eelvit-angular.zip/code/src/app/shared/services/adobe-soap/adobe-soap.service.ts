import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
} from "@angular/common/http";
import * as moment from "moment";
import { TranslateService } from "@ngx-translate/core";
import { StateService } from "../state/state.service";

@Injectable({
  providedIn: "root",
})
export class AdobeSoapService {
  profileData: any;
  gigyaid: string;
  readURL: string;
  writeURL: string;
  countryCode: string;
  specialCountryCode: string;
  specialLanguageCode: string;

  // reqHeaders = new HttpHeaders({
  //   "Content-Type": "application/xml",
  //   Accept: "application/xml",
  //   "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  //   "Access-Control-Allow-Origin": "*",
  //   "Access-Control-Allow-Headers": "*",
  // });

  reqHeaders = new HttpHeaders({
    "Content-Type": "application/x-www-form-urlencoded",
    Accept: "application/json",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
  });

  reqHeaders1 = new HttpHeaders({
    "Content-Type": "application/json",
    Accept: "application/json",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
  });

  constructor(
    private http: HttpClient,
    public translateService: TranslateService,
    private stateService: StateService
  ) {
    let isLiveEnvironment = false;
    this.countryCode = localStorage.getItem("gigyaLangDefault")
      ? localStorage.getItem("gigyaLangDefault").toUpperCase()
      : "EN";
    this.specialCountryCode = "";
    this.specialLanguageCode = "";
    const iframeLocationDetails =
      this.stateService.getIframeLocationDetails("iFrameResizer0");
    if (
      iframeLocationDetails &&
      iframeLocationDetails.pathname &&
      iframeLocationDetails.pathname.length > 1 &&
      iframeLocationDetails.hash.replace(
        /(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/,
        "$2"
      ) &&
      iframeLocationDetails.hash
        .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
        .indexOf("_") == -1
    ) {
      this.countryCode = iframeLocationDetails.hash
        .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
        .toUpperCase();
      isLiveEnvironment =
        iframeLocationDetails.pathname.split("/")[1] == "deco";
      const langParamFromAssembly =
        window.parent.location.pathname.split("/")[1];
      if (
        langParamFromAssembly &&
        langParamFromAssembly.indexOf("deco") != -1
      ) {
        // (Without assembly integration) language code will be stored in case of checking angular URL directly
        this.countryCode = localStorage
          .getItem("gigyaLangDecoupled")
          .toUpperCase();
      }
    } else if (
      iframeLocationDetails.hash
        .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
        .indexOf("_") != -1
    ) {
      // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
      const langParamFromAssembly =
        window.parent.location.pathname.split("/")[1];
      if (
        langParamFromAssembly &&
        langParamFromAssembly.indexOf("deco") == -1
      ) {
        // (With assembly integration) Assembly URL will have language code langugae in case of dual language
        this.countryCode = langParamFromAssembly.toUpperCase();
        isLiveEnvironment =
          iframeLocationDetails.pathname.split("/")[1] == "deco";
      } else if (langParamFromAssembly.indexOf("deco") != -1) {
        // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
        this.countryCode = localStorage
          .getItem("gigyaLangDecoupled")
          .toUpperCase();
        isLiveEnvironment =
          iframeLocationDetails.pathname.split("/")[1] == "deco";
      } else {
        // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
        this.countryCode = iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .split("_")[0]
          .toUpperCase();
        isLiveEnvironment =
          iframeLocationDetails.pathname.split("/")[1] == "deco";
      }
    }
    this.translateService.get("HOME").subscribe((translated) => {
      let serviceURL = "https://stage.services.bayer.us/adobe/api/";
      if (translated.SERVICE_URL) {
        serviceURL = isLiveEnvironment
          ? translated.SERVICE_URL.PROD
          : translated.SERVICE_URL.DEV;
      }
      this.readURL = serviceURL + "get";
      this.writeURL = serviceURL + "post";
      this.specialCountryCode = translated.COUNTRY_CODE || "";
      this.specialLanguageCode = translated.LANGUAGE_CODE || "";
    });
  }

  public getUserData(gigyaid: string) {
    let requestData = {
      request: {
        attributes: [
          {
            key: "DE_Master_Elevit_User.GigyaVerified",
          },
        ],
      },
      conditionSet: {
        operator: "And",
        conditionSets: [],
        conditions: [
          {
            attribute: {
              key: "DE_Master_Elevit_User.SubscriberKey",
            },
            operator: "Equals",
            value: {
              items: [gigyaid],
            },
          },
        ],
      },
    };
    return this.http.post("/getdata", requestData, {
      headers: this.reqHeaders1,
    });
  }

  public getUserNewsLetterData(gigyaid: string) {
    let requestData = {
      request: {
        attributes: [
          {
            key: "DE_Master_Elevit_User.NewsletterFlag",
          },
        ],
      },
      conditionSet: {
        operator: "And",
        conditionSets: [],
        conditions: [
          {
            attribute: {
              key: "DE_Master_Elevit_User.SubscriberKey",
            },
            operator: "Equals",
            value: {
              items: [gigyaid],
            },
          },
        ],
      },
    };
    return this.http.post("/getdata", requestData, {
      headers: this.reqHeaders1,
    });
  }

  /* This method is for setting User Profile Service.(Rcp Write) */
  public setUserProfile(
    profile,
    gigyaid: string,
    gigyaverified: string,
    weeklyPregnancyEmailCheckboxConsent: boolean,
    privacyPolicyCheckboxConsent: boolean,
    collectionNoticeCheckboxConsent: boolean
  ) {
    //   weeklyPregnancyEmailCheckboxConsent: number,
    // privacyPolicyCheckboxConsent: number,
    // collectionNoticeCheckboxConsent: number
    // gigyaverified expected values 1 or 0. 1 means email is verified and 0 is not verified.
    const finalCountryCode = this.specialCountryCode
      ? this.specialCountryCode.toUpperCase()
      : this.countryCode.toUpperCase();
    const finalLanguageCode = this.specialLanguageCode
      ? this.specialLanguageCode.toUpperCase()
      : this.countryCode.toUpperCase();

    //sfmc code
    let requestData = [
      {
        keys: {
          SubscriberKey: gigyaid,
        },
        values: {
          SubscriberKey: gigyaid,
          FirstName: profile.firstName,
          LastName: profile.lastName,
          Email: profile.email,
          Brand: "Elevit",
          Country: finalCountryCode,
          Language: finalLanguageCode,
          // CreatedDate: moment().format("MM/DD/YYYY"),
          PrivacyFlag: privacyPolicyCheckboxConsent,
          CollectionNoticeFlag: collectionNoticeCheckboxConsent,
          GigyaVerified: gigyaverified, //"1",
          Source: `Elevit_${finalCountryCode}_WEB`,
          NewsletterFlag: weeklyPregnancyEmailCheckboxConsent,
        },
      },
    ];
    return this.http.post("/cu_user", requestData, {
      headers: this.reqHeaders1,
    });

    //sfmc end

    // const body =
    //   `<recipient_stage xtkschema="byr:recipient_stage" brand="Elevit" gigyaid="${gigyaid}" ` +
    //   `firstname="${profile.firstName}" lastname="${profile.lastName}" email="${
    //     profile.email
    //   }" gigyaverified="${gigyaverified}" adobe_source="${
    //     "ELEVIT" +
    //     (finalCountryCode ? "_" + finalCountryCode + "_" : "_") +
    //     "WEB"
    //   }" country="${finalCountryCode}" language="${finalLanguageCode}" last_mod_date="${moment().format()}" />`;
    // return this.http.post(this.writeURL, body, {
    //   headers: this.reqHeaders,
    // });
  }

  /* This method is for setting User Profile Service.(Rcp Write) */
  public setWelcomeUserProfile(
    profile,
    gigyaid: string,
    gigyaverified: string,
    weeklyPregnancyEmailCheckboxConsent: boolean,
    privacyPolicyCheckboxConsent: boolean,
    collectionNoticeCheckboxConsent: boolean
  ) {
    //   weeklyPregnancyEmailCheckboxConsent: number,
    // privacyPolicyCheckboxConsent: number,
    // collectionNoticeCheckboxConsent: number
    // gigyaverified expected values 1 or 0. 1 means email is verified and 0 is not verified.
    const finalCountryCode = this.specialCountryCode
      ? this.specialCountryCode.toUpperCase()
      : this.countryCode.toUpperCase();
    const finalLanguageCode = this.specialLanguageCode
      ? this.specialLanguageCode.toUpperCase()
      : this.countryCode.toUpperCase();

    //sfmc code
    let requestData = {
      ContactKey: gigyaid,
      EventDefinitionKey: "APIEvent-0e2c3cc0-6224-e26b-a9be-3b8321f0af65", //"APIEvent-cfa2aadf-56fe-540d-4066-abf9545adee8",
      EstablishContactKey: true,

      Data: {
        SubscriberKey: gigyaid,
        FirstName: profile.firstName,
        LastName: profile.lastName,
        Email: profile.email,
        Brand: "Elevit",
        Country: finalCountryCode,
        Language: finalLanguageCode,
        CreatedDate: moment().format("MM/DD/YYYY"),
        PrivacyFlag: privacyPolicyCheckboxConsent,
        CollectionNoticeFlag: collectionNoticeCheckboxConsent,
        GigyaVerified: gigyaverified, //"1",
        Source: `Elevit_${finalCountryCode}_WEB`,
        NewsletterFlag: weeklyPregnancyEmailCheckboxConsent,
      },
    };

    return this.http.post("/cu_welcome_user", requestData, {
      headers: this.reqHeaders1,
    });
  }

  /* This method is for setting User Content via checkbox Service.(Opt Write) */
  // public setConsentCheckbox(profile, opt_name: string, opt_status: boolean) {
  //   console.log("opt_name", opt_name);
  //   console.log("opt_status", opt_status);
  //   const finalCountryCode = this.specialCountryCode
  //     ? this.specialCountryCode.toUpperCase()
  //     : this.countryCode.toUpperCase();
  //   const body =
  //     `<opt_stage xtkschema="byr:opt_stage" brand="Elevit" email="${profile.email}" ` +
  //     `firstname="${profile.firstName}" opt_status="${
  //       opt_status || "0"
  //     }" opt_name="${opt_name}" opt_date="${moment().format()}" adobe_source="${
  //       "ELEVIT" +
  //       (finalCountryCode ? "_" + finalCountryCode + "_" : "_") +
  //       "WEB"
  //     }" />`;
  //   return this.http.post(this.writeURL, body, {
  //     headers: this.reqHeaders,
  //   });
  // }

  /* This method is for setting User Profile selection Service.(Cycle Write) */
  public setProfileSelection(requestProfile) {
    this.profileData = JSON.parse(localStorage.getItem("profile"));
    if (this.profileData) {
      this.gigyaid = this.profileData.UID;
    }

    //sfmc code
    let requestData = [
      {
        keys: {
          SubscriberKey: this.gigyaid,
          Stage: requestProfile.stage ? parseInt(requestProfile.stage) : 0,
        },
        values: {
          Cycle: requestProfile.cycle ? parseInt(requestProfile.cycle) : 0,
          BabysAge: requestProfile.babysage
            ? parseInt(requestProfile.babysage)
            : 0,
          PregnancyWeek: requestProfile.pregnancyweek
            ? parseInt(requestProfile.pregnancyweek)
            : 0,
          LastPeriodDate: requestProfile.last_period_date, //"01/10/2022 12:00:00 AM",
          PregnancyDate: requestProfile.pregnancydate, //"01/10/2022 12:00:00 AM",
          DateCreated: moment().format(), //"01/10/2022 12:00:00 AM",
          // GigyaID: this.gigyaid,
          // Stage: requestProfile.stage,
        },
      },
    ];

    return this.http.post("/cu_cycle", requestData, {
      headers: this.reqHeaders1,
    });
    // sfmc end

    // const body =
    //   `<elevitcycledetail_stage xtkschema="byr:elevitcycledetail_stage" gigyaid="${this.gigyaid}" ` +
    //   `cycle="${requestProfile.cycle}" last_period_date="${requestProfile.last_period_date}" pregnancydate="${requestProfile.pregnancydate}" ` +
    //   `pregnancyweek="${requestProfile.pregnancyweek}" stage="${
    //     requestProfile.stage
    //   }" babysage="${
    //     requestProfile.babysage
    //   }" created_date="${moment().format()}" />`;
    // return this.http.post(this.writeURL, body, {
    //   headers: this.reqHeaders,
    // });
  }

  /* This method is for getting User Profile selection Service.(Cycle Read) */
  public getProfileSelection() {
    this.profileData = JSON.parse(localStorage.getItem("profile"));
    if (this.profileData) {
      this.gigyaid = this.profileData.UID;
    }

    ///sfmc code update
    let requestData = {
      request: {
        attributes: [
          {
            key: "DE_Master_Elevit_CycleDetail.SubscriberKey",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.BabysAge",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.PregnancyWeek",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.Stage",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.LastPeriodDate",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.PregnancyDate",
          },
          {
            key: "DE_Master_Elevit_CycleDetail.Cycle",
          },
        ],
      },
      conditionSet: {
        operator: "And",
        conditionSets: [],
        conditions: [
          {
            attribute: {
              key: "DE_Master_Elevit_CycleDetail.SubscriberKey",
            },
            operator: "Equals",
            value: {
              items: [this.gigyaid],
            },
          },
        ],
      },
    };
    return this.http.post("/getdata", requestData, {
      headers: this.reqHeaders1,
    });

    //end sfmc

    // const body =
    //   '<queryDef operation="get" schema="byr:elevitcycledetail" xtkschema="xtk:queryDef">' +
    //   "<select>" +
    //   '<node expr="@id" />' +
    //   '<node expr="@gigyaid" />' +
    //   '<node expr="@babysage" />' +
    //   '<node expr="@cycle" />' +
    //   '<node expr="@last_period_date" />' +
    //   '<node expr="@pregnancydate" />' +
    //   '<node expr="@pregnancyweek" />' +
    //   '<node expr="@stage" />' +
    //   "</select>" +
    //   "<where>" +
    //   `<condition expr="@gigyaid='${this.gigyaid}'" />` +
    //   "</where>" +
    //   "</queryDef>";
    // return this.http.post(this.readURL, body, {
    //   headers: this.reqHeaders,
    // });
  }

  /* This method is for setting User Profile selection Service.(Entry Write) */
  public setCalendarDatesInformation(
    entrydate: string,
    basebodytemp: string,
    sexualintercourse: string,
    mucusstate: string,
    gigyaid: string,
    notes: string
  ) {
    entrydate = entrydate.replace(/\s/g, "");
    //sfmc code
    let requestData = [
      {
        keys: {
          SubscriberKey: gigyaid,
          EntryDate: entrydate, //"01/10/2022 12:00:00 AM",
        },
        values: {
          BaseBodyTemp: basebodytemp, //"25",
          MucusState: mucusstate, //"1",
          SexualInterCourse: sexualintercourse, //"1",
          Notes: notes, //"Pregnant",
          DateCreated: moment().format(), //"01/10/2022 12:00:00 AM",
        },
      },
    ];

    return this.http.post("/cu_entry", requestData, {
      headers: this.reqHeaders1,
    });
    // sfmc end

    // const body =
    //   `<elevitentrydetail_stage xtkschema="byr:elevitentrydetail_stage" gigyaid="${gigyaid}" ` +
    //   `created_date="${moment().format()}" basebodytemp="${basebodytemp}" mucusstate="${mucusstate}" sexualintercourse="${sexualintercourse}" entrydate="${entrydate}" notes="${notes}" />`;
    // return this.http.post(this.writeURL, body, {
    //   headers: this.reqHeaders,
    // });
  }

  /* This method is for getting User Profile selection Service.(Entry Read) */
  public getCalendarDatesInformation(gigyaid: string) {
    ///sfmc code update
    let requestData = {
      request: {
        attributes: [
          {
            key: "DE_Master_Elevit_EntryDetail.SubscriberKey",
          },
          {
            key: "DE_Master_Elevit_EntryDetail.BaseBodyTemp",
          },
          {
            key: "DE_Master_Elevit_EntryDetail.MucusState",
          },
          {
            key: "DE_Master_Elevit_EntryDetail.Sexualintercourse",
          },
          {
            key: "DE_Master_Elevit_EntryDetail.Notes",
          },
          {
            key: "DE_Master_Elevit_EntryDetail.EntryDate",
          },
        ],
      },
      conditionSet: {
        operator: "And",
        conditionSets: [],
        conditions: [
          {
            attribute: {
              key: "DE_Master_Elevit_EntryDetail.SubscriberKey",
            },
            operator: "Equals",
            value: {
              items: [gigyaid],
            },
          },
        ],
      },
    };

    return this.http.post("/getdata", requestData, {
      headers: this.reqHeaders1,
    });

    //end sfmc

    // const body =
    //   '<queryDef operation="select" schema="byr:elevitentrydetail" xtkschema="xtk:queryDef">' +
    //   "<select>" +
    //   '<node expr="@id" />' +
    //   '<node expr="@cycledetailid" />' +
    //   '<node expr="@basebodytemp" />' +
    //   '<node expr="@mucusstate" />' +
    //   '<node expr="@sexualintercourse" />' +
    //   '<node expr="@entrydate" />' +
    //   '<node expr="@notes" />' +
    //   "</select>" +
    //   "<where>" +
    //   `<condition expr="@gigyaid='${gigyaid}'" />` +
    //   "</where>" +
    //   "</queryDef>";
    // return this.http.post(this.readURL, body, {
    //   headers: this.reqHeaders,
    // });
  }
}
