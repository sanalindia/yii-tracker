import { TestBed } from '@angular/core/testing';

import { NgbcDatepickerI18nService } from './ngbc-datepicker-i18n.service';

describe('NgbcDatepickerI18nService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NgbcDatepickerI18nService = TestBed.get(NgbcDatepickerI18nService);
    expect(service).toBeTruthy();
  });
});
