import {Injectable} from '@angular/core';
import {NgbDatepickerI18n, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';


// Define custom service providing the months and weekdays translations
@Injectable()
export class NgbcDatepickerI18nService extends NgbDatepickerI18n {
  calendarProperties: any;
  constructor( private translateService: TranslateService ) {
    super();
    this.translateService.get('HOME.CALENDAR_PROPERTIES').subscribe((translated) => {
      this.calendarProperties = translated;
    });
  }

  getWeekdayShortName(weekday: number): string {
    return this.calendarProperties ? this.calendarProperties._weekdaysShort[weekday - 1] : '';
  }
  getWeekdayFullName(weekday: number): string {
    return this.calendarProperties ? this.calendarProperties._weekdaysFull[weekday - 1] : '';
  }
  getMonthShortName(month: number): string {
    return this.calendarProperties ? this.calendarProperties._monthsShort[month - 1] : '';
  }
  getMonthFullName(month: number): string {
    return this.calendarProperties ? this.calendarProperties._monthsFull[month - 1] : '';
  }

  getDayAriaLabel(date: NgbDateStruct): string {
    return `${date.day}-${date.month}-${date.year}`;
  }
}
