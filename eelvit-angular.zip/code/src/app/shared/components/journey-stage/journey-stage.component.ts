import { Component, OnInit, OnDestroy } from "@angular/core";
import { NavigationExtras, Router } from "@angular/router";
import { AdobeSoapService } from "../../../shared/services/adobe-soap/adobe-soap.service";
import {
  NgbDate,
  NgbCalendar,
  NgbDateStruct,
  NgbModalConfig,
  NgbModal,
} from "@ng-bootstrap/ng-bootstrap";
import { TranslateService } from "@ngx-translate/core";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { LocalStorage } from "@ngx-pwa/local-storage";
import { HttpErrorResponse } from "@angular/common/http";
import { StateService } from "../../services/state/state.service";

@Component({
  selector: "app-journey-stage",
  templateUrl: "./journey-stage.component.html",
  providers: [NgbModalConfig, NgbModal],
  styleUrls: ["./journey-stage.component.scss"],
})
export class JourneyStageComponent implements OnInit, OnDestroy {
  pregnancyPlanning$: Observable<number>;
  PregnancyPlanningReducer: any;
  public pregnantStageIndex: any;
  public isPregnantStage = false;
  public periodFirstDate: NgbDate;
  selectedCycleIndex: any;
  selectedPregnantweeksIndex: any;
  selectedBabyAgeIndex: number;
  userTypeInstance: any;
  userType: string;
  noOfCycleList: string[];
  noOfPregnancyWeeksList: string[];
  JumpTagWeekName: string;
  startDate: NgbDate;
  currentDate: NgbDate;
  dateDiff: number;
  dateErrorMsg = false;
  week1or2ErrorMsg = false;
  pregnancyweek: number;
  pregnantStages: string[];
  pregnantStagesEng: string[];
  profile: any;
  screen: string;
  loginScreenID: string;
  registerScreenID: string;
  selectedPregnantweekNumber: string;

  ChangeSelectedStage(selectedDropdown: string, pregnantStageIndex: number) {
    this.selectedCycleIndex =
      this.selectedPregnantweeksIndex =
      this.selectedBabyAgeIndex =
        undefined;
    this.selectedPregnantweekNumber = undefined;
    this[selectedDropdown] = pregnantStageIndex;
    if (selectedDropdown === "pregnantStageIndex") {
      this.periodFirstDate = undefined;
      this.selectedCycleIndex = undefined;
      this.selectedPregnantweeksIndex = undefined;
    }
    if (
      selectedDropdown === "selectedPregnantweeksIndex" &&
      this.selectedPregnantweeksIndex != -1
    ) {
      this.selectedPregnantweekNumber = this.noOfPregnancyWeeksList[
        this.selectedPregnantweeksIndex
      ].replace(/[^\d]/g, "");
    }
    this.store.dispatch({
      type: "SELECT_PREGNANTSTAGEINDEX",
      payload: pregnantStageIndex,
    });
    localStorage.setItem("journeyStageIndex", this.pregnantStageIndex);
  }

  constructor(
    config: NgbModalConfig,
    private router: Router,
    private adobeSoapService: AdobeSoapService,
    private translateService: TranslateService,
    private store: Store<any>,
    private localStorage: LocalStorage,
    public calendar: NgbCalendar,
    private modalService: NgbModal,
    private stateService: StateService
  ) {
    this.pregnancyPlanning$ = store.select("PregnancyPlanningReducer");
  }

  ngOnInit() {
    this.userType = localStorage.getItem("userType");
    if (
      localStorage.getItem("journeyStageIndex") !== null &&
      localStorage.getItem("journeyStageIndex") !== ""
    ) {
      this.pregnantStageIndex = parseInt(
        localStorage.getItem("journeyStageIndex")
      );
    }
    this.translateService.get("HOME").subscribe((translated) => {
      if (translated.LOGIN && translated.LOGIN.MAINTAINANCE_MESSAGE) {
        const navigationExtras: NavigationExtras = {
          state: { data: translated.LOGIN.MAINTAINANCE_MESSAGE },
        };
        this.router.navigate(["user-message"], navigationExtras);
      }
      this.pregnantStages = translated.PREGNANTSTAGES;
      this.pregnantStagesEng = translated.PREGNANTSTAGES_ENG;
      this.noOfCycleList = translated.NOOFCYCLELIST;
      this.noOfPregnancyWeeksList = translated.NOOFPREGNANTWEEKS;
      this.JumpTagWeekName = translated.JUMP_TAG_WEEK_NAME;
      this.loginScreenID =
        translated.GIGYA_SCREEN_ID.LOGIN || "bayer-login-nosc";
      this.registerScreenID =
        translated.GIGYA_SCREEN_ID.REGISTER || "bayer-register-nosc";
    });
    if (this.userType == "LoggedIn") {
      this.profile = JSON.parse(localStorage.getItem("profile"));
      this.screen = this.profile.Screen;
      if (
        localStorage.getItem("journeyStageIndex") !== null &&
        localStorage.getItem("journeyStageIndex") !== ""
      ) {
        this.isPregnantStage = true;
        this.pregnantStageIndex = parseInt(
          localStorage.getItem("journeyStageIndex")
        );
      }
      if (this.pregnantStageIndex != undefined) {
        this.isPregnantStage = true;
      }
      setTimeout(() => {
        this.adobeSoapService.getProfileSelection().subscribe(
          (data: any) => {
            // console.log("get cycle data", data);

            document.getElementById("loading").style.display = "none";
            if (data && data.items.length > 0) {
              const responseData = data.items[data.items.length - 1]["values"];
              let cycleVal = responseData.filter((val) => val.name === "Cycle");
              let StageVal = responseData.filter((val) => val.name === "Stage");
              let LastPeriodDateVal = responseData.filter(
                (val) => val.name === "LastPeriodDate"
              );

              // const responseStage =
              //   this.pregnantStagesEng.indexOf(StageVal[0].value) != -1
              //     ? this.pregnantStagesEng.indexOf(StageVal[0].value)
              //     : this.pregnantStages.indexOf(StageVal[0].value);
              const responseStage = parseInt(StageVal[0].value) === 2 ? 0 : 1;

              if (responseStage !== undefined) {
                this.isPregnantStage = true;
                if (
                  localStorage.getItem("anonymousFlowType") !==
                  "anonymousPlanningPregnancy"
                ) {
                  localStorage.setItem(
                    "journeyStageIndex",
                    responseStage.toString()
                  );
                  this.pregnantStageIndex = responseStage;
                }
              }
              if (this.pregnantStageIndex == 0 && responseStage === 0) {
                const lastPeriodDate = new Date(
                  LastPeriodDateVal[0].value.replace(/ AM/g, "")
                );
                if (lastPeriodDate.toJSON()) {
                  this.periodFirstDateSelection({
                    day: lastPeriodDate.getUTCDate(),
                    month: lastPeriodDate.getUTCMonth() + 1,
                    year: lastPeriodDate.getUTCFullYear(),
                  });
                }
                const responseCycle: string = cycleVal[0].value;
                if (responseCycle) {
                  const noOfCycleList = this.noOfCycleList;
                  let regCycle = new RegExp(`^${responseCycle}`);
                  if (this.JumpTagWeekName === "Nedelje") {
                    regCycle = new RegExp(`${responseCycle}`);
                  }
                  const selectedCycleIndex = noOfCycleList.findIndex((value) =>
                    regCycle.test(value)
                  );
                  // const selectedCycleIndex = noOfCycleList.findIndex((value) =>
                  //   new RegExp(`^${responseCycle}`).test(value)
                  // );
                  if (
                    selectedCycleIndex != null &&
                    selectedCycleIndex != undefined
                  ) {
                    this.selectedCycleIndex = selectedCycleIndex;
                  }
                }
              } else if (this.pregnantStageIndex == 1 && responseStage === 1) {
                const lastPeriodDate = new Date(
                  LastPeriodDateVal[0].value.replace(/ AM/g, "")
                  // LastPeriodDateVal[0].value.replace(/ /g, "T")
                );
                if (lastPeriodDate.toJSON()) {
                  this.periodFirstDateSelection({
                    day: lastPeriodDate.getUTCDate(),
                    month: lastPeriodDate.getUTCMonth() + 1,
                    year: lastPeriodDate.getUTCFullYear(),
                  });
                }
                const responsePregnancyWeek: string =
                  this.pregnancyweek.toString();
                if (responsePregnancyWeek) {
                  let responsePregnancyWeekRegex = new RegExp(
                    ` ${responsePregnancyWeek}$`
                  );
                  if (this.JumpTagWeekName === "Nedelje") {
                    responsePregnancyWeekRegex = new RegExp(
                      `${responsePregnancyWeek}`
                    );
                  }

                  // const responsePregnancyWeekRegex = new RegExp(
                  //   ` ${responsePregnancyWeek}$`
                  // );
                  const selectedPregnantweeksIndex =
                    this.noOfPregnancyWeeksList.findIndex((value) =>
                      responsePregnancyWeekRegex.test(value)
                    );
                  if (selectedPregnantweeksIndex === -1) {
                    this.selectedPregnantweeksIndex = undefined;
                  } else {
                    this.selectedPregnantweeksIndex =
                      selectedPregnantweeksIndex;
                    this.selectedPregnantweekNumber =
                      this.noOfPregnancyWeeksList[
                        selectedPregnantweeksIndex
                      ].replace(/[^\d]/g, "");
                  }
                }
              }
              if (
                localStorage.getItem("displayedWeekNumber") &&
                responseStage === 1
              ) {
                localStorage.setItem(
                  "journeyStageIndex",
                  this.pregnantStageIndex || 1
                );
                this.router.navigate(["/calendar"]);
              }
            }
            // if (
            //   data &&
            //   data.responseStatus === "SUCCESS" &&
            //   data.output &&
            //   data.output.elevitcycledetail
            // ) {
            //   console.log("1111");
            //   const responseData = data.output.elevitcycledetail;
            //   const responseStage =
            //     this.pregnantStagesEng.indexOf(responseData["@stage"]) != -1
            //       ? this.pregnantStagesEng.indexOf(responseData["@stage"])
            //       : this.pregnantStages.indexOf(responseData["@stage"]);
            //   if (responseStage !== -1) {
            //     this.isPregnantStage = true;
            //     if (
            //       localStorage.getItem("anonymousFlowType") !==
            //       "anonymousPlanningPregnancy"
            //     ) {
            //       localStorage.setItem(
            //         "journeyStageIndex",
            //         responseStage.toString()
            //       );
            //       this.pregnantStageIndex = responseStage;
            //     }
            //   }
            //   if (this.pregnantStageIndex == 0 && responseStage === 0) {
            //     const lastPeriodDate = new Date(
            //       responseData["@last_period_date"].replace(/ /g, "T")
            //     );
            //     if (lastPeriodDate.toJSON()) {
            //       this.periodFirstDateSelection({
            //         day: lastPeriodDate.getUTCDate(),
            //         month: lastPeriodDate.getUTCMonth() + 1,
            //         year: lastPeriodDate.getUTCFullYear(),
            //       });
            //     }
            //     const responseCycle: string = responseData["@cycle"];
            //     if (responseCycle) {
            //       const noOfCycleList = this.noOfCycleList;
            //       let regCycle = new RegExp(`^${responseCycle}`);
            //       if (this.JumpTagWeekName === "Nedelje") {
            //         regCycle = new RegExp(`${responseCycle}`);
            //       }
            //       const selectedCycleIndex = noOfCycleList.findIndex((value) =>
            //         regCycle.test(value)
            //       );
            //       // const selectedCycleIndex = noOfCycleList.findIndex((value) =>
            //       //   new RegExp(`^${responseCycle}`).test(value)
            //       // );
            //       if (
            //         selectedCycleIndex != null &&
            //         selectedCycleIndex != undefined
            //       ) {
            //         this.selectedCycleIndex = selectedCycleIndex;
            //       }
            //     }
            //   } else if (this.pregnantStageIndex == 1 && responseStage === 1) {
            //     const lastPeriodDate = new Date(
            //       responseData["@last_period_date"].replace(/ /g, "T")
            //     );
            //     if (lastPeriodDate.toJSON()) {
            //       this.periodFirstDateSelection({
            //         day: lastPeriodDate.getUTCDate(),
            //         month: lastPeriodDate.getUTCMonth() + 1,
            //         year: lastPeriodDate.getUTCFullYear(),
            //       });
            //     }
            //     const responsePregnancyWeek: string =
            //       this.pregnancyweek.toString();
            //     if (responsePregnancyWeek) {
            //       let responsePregnancyWeekRegex = new RegExp(
            //         ` ${responsePregnancyWeek}$`
            //       );
            //       if (this.JumpTagWeekName === "Nedelje") {
            //         responsePregnancyWeekRegex = new RegExp(
            //           `${responsePregnancyWeek}`
            //         );
            //       }

            //       // const responsePregnancyWeekRegex = new RegExp(
            //       //   ` ${responsePregnancyWeek}$`
            //       // );
            //       const selectedPregnantweeksIndex =
            //         this.noOfPregnancyWeeksList.findIndex((value) =>
            //           responsePregnancyWeekRegex.test(value)
            //         );
            //       if (selectedPregnantweeksIndex === -1) {
            //         this.selectedPregnantweeksIndex = undefined;
            //       } else {
            //         this.selectedPregnantweeksIndex =
            //           selectedPregnantweeksIndex;
            //         this.selectedPregnantweekNumber =
            //           this.noOfPregnancyWeeksList[
            //             selectedPregnantweeksIndex
            //           ].replace(/[^\d]/g, "");
            //       }
            //     }
            //   }
            //   if (
            //     localStorage.getItem("displayedWeekNumber") &&
            //     responseStage === 1
            //   ) {
            //     localStorage.setItem(
            //       "journeyStageIndex",
            //       this.pregnantStageIndex || 1
            //     );
            //     this.router.navigate(["/calendar"]);
            //   }
            // }
            if (
              this.pregnantStageIndex == 0 &&
              this.periodFirstDate &&
              this.selectedCycleIndex != undefined
            ) {
              localStorage.setItem(
                "lastPeriodDate",
                JSON.stringify(this.periodFirstDate)
              );
              if (this.noOfCycleList && this.selectedCycleIndex != undefined) {
                localStorage.setItem(
                  "periodCycleDuration",
                  this.noOfCycleList[this.selectedCycleIndex].replace(
                    /[^\d]/g,
                    ""
                  )
                );
              }
            }
            if (this.pregnantStageIndex == 1 && this.periodFirstDate) {
              localStorage.removeItem("lastPeriodDate");
              localStorage.setItem(
                "lastPeriodDate",
                JSON.stringify(this.periodFirstDate)
              );
            }
          },
          (error: HttpErrorResponse) => {
            console.log("error cycle", error);

            document.getElementById("loading").style.display = "none";
          }
        );
      }, 500);
    }
  }

  /* start journey on clicking on next button */
  public startJourney() {
    this.store.dispatch({
      type: "SELECT_LAST_PERIOD_DATE",
      payload: this.periodFirstDate,
    });

    this.store.dispatch({
      type: "SELECT_PREGNANT_WEEK_INDEX",
      payload: this.selectedPregnantweeksIndex,
    });

    if (this.noOfCycleList && this.selectedCycleIndex !== undefined) {
      this.store.dispatch({
        type: "SELECT_CYCLE_DURATION",
        payload: this.noOfCycleList[this.selectedCycleIndex],
      });
    } else {
      this.store.dispatch({
        type: "SELECT_CYCLE_DURATION",
        payload: undefined,
      });
    }

    localStorage.setItem("journeyStageIndex", this.pregnantStageIndex);
    if (
      this.pregnantStageIndex == 0 &&
      this.periodFirstDate &&
      this.selectedCycleIndex != undefined
    ) {
      localStorage.setItem(
        "lastPeriodDate",
        JSON.stringify(this.periodFirstDate)
      );
      if (this.noOfCycleList && this.selectedCycleIndex != undefined) {
        localStorage.setItem(
          "periodCycleDuration",
          this.noOfCycleList[this.selectedCycleIndex].replace(/[^\d]/g, "")
        );
      }
    }

    if (this.pregnantStageIndex == 1 && this.periodFirstDate) {
      localStorage.removeItem("lastPeriodDate");
      localStorage.setItem(
        "lastPeriodDate",
        JSON.stringify(this.periodFirstDate)
      );
    }

    if (this.userType != "LoggedIn") {
      if (this.isPregnantStage) {
        this.router.navigate(["/calendar"]);
      } else {
        if (this.pregnantStageIndex) {
          this.router.navigate(["/pregnancy"]);
        } else {
          this.router.navigate(["/planning"]);
        }
      }
    } else {
      if (!this.isPregnantStage) {
        this.isPregnantStage = true;
        return;
      }
      const profile = JSON.parse(localStorage.getItem("profile"));
      const screen = profile.Screen;
      if (
        (screen == this.registerScreenID ||
          screen == this.loginScreenID ||
          screen == "bayer-forgot-password-screen") &&
        this.periodFirstDate != undefined
      ) {
        const lastPeriodDate: NgbDateStruct = JSON.parse(
          localStorage.getItem("lastPeriodDate")
        );
        let response_last_period_date = "";
        if (lastPeriodDate.month && lastPeriodDate.day) {
          response_last_period_date =
            (lastPeriodDate.month.toString().length === 1
              ? "0" + lastPeriodDate.month
              : lastPeriodDate.month) +
            "/" +
            (lastPeriodDate.day.toString().length === 1
              ? "0" + lastPeriodDate.day
              : lastPeriodDate.day) +
            "/" +
            lastPeriodDate.year;
          // response_last_period_date =
          //   lastPeriodDate.year +
          //   "-" +
          //   (lastPeriodDate.month.toString().length === 1
          //     ? "0" + lastPeriodDate.month
          //     : lastPeriodDate.month) +
          //   "-" +
          //   (lastPeriodDate.day.toString().length === 1
          //     ? "0" + lastPeriodDate.day
          //     : lastPeriodDate.day);
        }
        let requestCycle = "",
          requestPregnancyWeek = "";
        if (this.pregnantStageIndex == 0) {
          requestCycle = this.noOfCycleList[this.selectedCycleIndex].replace(
            /[^\d]/g,
            ""
          );
        } else if (
          this.pregnantStageIndex == 1 &&
          this.selectedPregnantweeksIndex != undefined &&
          this.selectedPregnantweeksIndex != "-1"
        ) {
          requestPregnancyWeek = this.noOfPregnancyWeeksList[
            this.selectedPregnantweeksIndex
          ].replace(/[^\d]/g, "");
        }
        const requestProfile = {
          cycle: this.pregnantStageIndex == 0 ? requestCycle : "",
          last_period_date: response_last_period_date,
          pregnancydate:
            this.pregnantStageIndex == 1 ? response_last_period_date : "",
          pregnancyweek:
            this.pregnantStageIndex == 1 ? this.calcCurrentPregnancyWeek() : "",
          stage: this.pregnantStageIndex == 0 ? 2 : 1,

          // stage:
          //   this.pregnantStagesEng[this.pregnantStageIndex] != undefined
          //     ? this.pregnantStagesEng[this.pregnantStageIndex]
          //     : this.pregnantStages[this.pregnantStageIndex],

          babysage: "",
        };
        this.adobeSoapService.setProfileSelection(requestProfile).subscribe(
          (data) => {
            if (this.periodFirstDate === undefined) {
              this.isPregnantStage = true;
              if (
                localStorage.getItem("journeyStageIndex") !== null &&
                localStorage.getItem("journeyStageIndex") !== ""
              ) {
                this.pregnantStageIndex = parseInt(
                  localStorage.getItem("journeyStageIndex")
                );
              }
              this.router.navigate(["/journey"]);
            } else {
              this.router.navigate(["/calendar"]);
              this.modalService.dismissAll();
            }
          },
          () => {}
        );
      } else if (
        screen == this.registerScreenID &&
        this.periodFirstDate == undefined
      ) {
        this.isPregnantStage = true;
        if (
          localStorage.getItem("journeyStageIndex") !== null &&
          localStorage.getItem("journeyStageIndex") !== ""
        ) {
          this.pregnantStageIndex = parseInt(
            localStorage.getItem("journeyStageIndex")
          );
        }
        this.router.navigate(["/journey"]);
      }
    }
  }

  /* Show popup for calculated week confirmation only for "I'm Pregnant" flow */
  public openModal(content) {
    localStorage.setItem("journeyStageIndex", this.pregnantStageIndex);
    if (!this.isPregnantStage) {
      this.isPregnantStage = true;
      return;
    }
    if (
      this.selectedPregnantweeksIndex &&
      this.noOfPregnancyWeeksList[this.selectedPregnantweeksIndex] &&
      +this.noOfPregnancyWeeksList[this.selectedPregnantweeksIndex].replace(
        /[^\d]/g,
        ""
      ) == this.calcCurrentPregnancyWeek()
    ) {
      this.startJourney();
      return;
    }
    this.modalService.open(content, { centered: true });
  }

  handlePreviousClick() {
    this.isPregnantStage = false;
    if (
      localStorage.getItem("journeyStageIndex") !== null &&
      localStorage.getItem("journeyStageIndex") !== ""
    ) {
      this.pregnantStageIndex = parseInt(
        localStorage.getItem("journeyStageIndex")
      );
    }
  }

  isNextEnabled() {
    if (!this.isPregnantStage) {
      return this.pregnantStageIndex != undefined;
    } else {
      return (
        (this.pregnantStageIndex == 0 &&
          this.periodFirstDate &&
          this.selectedCycleIndex != undefined) ||
        (this.pregnantStageIndex == 1 &&
          this.periodFirstDate &&
          this.dateDiff > 13) ||
        (this.pregnantStageIndex == 2 &&
          this.selectedBabyAgeIndex !== undefined)
      );
    }
  }

  getCycleData() {
    this.noOfCycleList.forEach((value, index) => {
      if (value.indexOf("28") != -1) {
        this.selectedCycleIndex = index;
      }
    });
  }

  periodFirstDateSelection(date) {
    localStorage.setItem("lastPeriodDate", JSON.stringify(date));
    this.periodFirstDate = date;
    this.startDate = date;
    this.currentDate = this.calendar.getToday();
    this.dateDiff = this.calcDaysDiff();
    if (this.dateDiff < 0) {
      this.dateErrorMsg = true;
    } else {
      this.dateErrorMsg = false;
    }
    this.pregnancyweek = this.calcCurrentPregnancyWeek();
    this.selectedPregnantweeksIndex = this.pregnancyweek - 1;
    this.selectedPregnantweekNumber = this.noOfPregnancyWeeksList[
      this.selectedPregnantweeksIndex
    ].replace(/[^\d]/g, "");
  }

  /* This function will be called when user select any date from datepicker */
  datepickerSelection(date) {
    localStorage.setItem("lastPeriodDate", JSON.stringify(date));
    this.periodFirstDate = date;
    this.startDate = date;
    this.currentDate = this.calendar.getToday();
    this.dateDiff = this.calcDaysDiff();
    if (this.dateDiff < 0) {
      this.dateErrorMsg = true;
    } else {
      this.dateErrorMsg = false;
    }
    if (this.dateDiff >= 0 && this.dateDiff <= 13) {
      this.week1or2ErrorMsg = true;
    } else {
      this.week1or2ErrorMsg = false;
    }
  }

  /* Modify ngbdate format to date time timestamp */
  private createDateFromNgbDate(ngbDate: NgbDate): Date {
    const date: Date = new Date(
      Date.UTC(ngbDate.year, ngbDate.month - 1, ngbDate.day)
    );
    return date;
  }

  private calcDaysDiff(): number {
    const fromDate: Date = this.createDateFromNgbDate(this.currentDate);
    const toDate: Date = this.createDateFromNgbDate(this.periodFirstDate);
    const daysDiff = Math.floor(
      (<any>fromDate - <any>toDate) / (1000 * 60 * 60 * 24)
    );
    return daysDiff;
  }

  /* Caluclate current pregnancy week from last period date */
  public calcCurrentPregnancyWeek(): number {
    const fromDate: Date = this.createDateFromNgbDate(this.periodFirstDate);
    const toDate: Date = this.createDateFromNgbDate(this.currentDate);
    const pregnancyWeek = Math.floor(
      Math.abs(<any>fromDate - <any>toDate) / (7 * 1000 * 60 * 60 * 24)
    );

    return pregnancyWeek + 1;
  }

  ngOnDestroy(): void {}
}
