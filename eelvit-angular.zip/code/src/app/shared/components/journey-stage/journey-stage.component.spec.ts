import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JourneyStageComponent } from './journey-stage.component';

describe('JourneyStageComponent', () => {
  let component: JourneyStageComponent;
  let fixture: ComponentFixture<JourneyStageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JourneyStageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JourneyStageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
