import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { StateService } from '../../services/state/state.service';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
  selector: 'app-typical-ovulation-cycle',
  templateUrl: './typical-ovulation-cycle.component.html',
  styleUrls: ['./typical-ovulation-cycle.component.scss']
})
export class TypicalOvulationCycleComponent implements OnInit {
  pregnancyPlanning$: Observable<number>;
  PregnancyPlanningReducer: any;
  pregnantStageIndex: any;
  stateServiceInstance: any;
  anonymousData: any;
  trimesterIndex: number;
  constructor(private translateService: TranslateService, private stateService: StateService, private store: Store<any>) { }

  ngOnInit() {
    this.pregnantStageIndex = localStorage.getItem('journeyStageIndex');
    this.translateService.get('HOME.ANONYMOUS').subscribe((translated: string) => {
      this.anonymousData = this.translateService.instant('HOME.ANONYMOUS')[this.pregnantStageIndex || 0];
    });
    this.trimesterIndex = 0;
  }

  /* To change Trimenter Label('The First Trimester', 'The Second Trimester', 'The Third Trimester') with week dropdown change only for Anonymous "I'm Pregnant" flow */
  changeTrimesterLabel(selectedweek) {
    let selectedWeekNumber = +selectedweek.replace(/[^\d]/g, '');
    if (selectedWeekNumber >= 3  && selectedWeekNumber <= 12) {
      this.trimesterIndex = 0;
    } else if (selectedWeekNumber >= 13  && selectedWeekNumber <= 27) {
      this.trimesterIndex = 1;
    } else if (selectedWeekNumber >= 28  && selectedWeekNumber <= 40) {
      this.trimesterIndex = 2;
    } else {
      this.trimesterIndex = 0;
    }
  }

}
