import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypicalOvulationCycleComponent } from './typical-ovulation-cycle.component';

describe('TypicalOvulationCycleComponent', () => {
  let component: TypicalOvulationCycleComponent;
  let fixture: ComponentFixture<TypicalOvulationCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypicalOvulationCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypicalOvulationCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
