import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PregnancyCalendarComponent } from './pregnancy-calendar.component';

describe('PregnancyCalendarComponent', () => {
  let component: PregnancyCalendarComponent;
  let fixture: ComponentFixture<PregnancyCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PregnancyCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PregnancyCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
