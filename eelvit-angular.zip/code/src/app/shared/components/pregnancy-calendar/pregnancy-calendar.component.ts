import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnDestroy,
  AfterViewInit,
  ElementRef,
} from "@angular/core";
import {
  NgbDate,
  NgbCalendar,
  NgbDatepickerI18n,
  NgbDatepicker,
  NgbModal,
  NgbActiveModal,
} from "@ng-bootstrap/ng-bootstrap";
import { TranslateService } from "@ngx-translate/core";
import { StateService } from "../../services/state/state.service";
import {
  CalendarDateEntryType,
  SelectedInterCourse,
} from "../../models/calendarDateEntryModel";
import { Observable, forkJoin } from "rxjs";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import { Router } from "@angular/router";
import * as moment from "moment";
import { AdobeSoapService } from "../../../shared/services/adobe-soap/adobe-soap.service";
import { HttpErrorResponse } from "@angular/common/http";

@Component({
  selector: "app-pregnancy-calendar",
  templateUrl: "./pregnancy-calendar.component.html",
  styleUrls: ["./pregnancy-calendar.component.scss"],
})
export class PregnancyCalendarComponent
  implements OnInit, OnDestroy, AfterViewInit
{
  pregnantStageIndex: any;
  pregnantStageIndexInstance: any;
  pregnancyPlanningOptionsInstance: any;
  duedate: string;
  pregnancyWeek: number;
  calendarModel: any;

  fromDate: NgbDate;
  toDate: NgbDate;
  currentMonth: number;
  currentYear: number;
  firstDayOfCycleMarkedDate: NgbDate;
  ovulationMarkedDate: NgbDate;
  ovulationInsideMarkedDate1: NgbDate;
  ovulationInsideMarkedDate2: NgbDate;
  intercourseMarkedDate: NgbDate;
  calendarJsonData: any;
  noOfcycle: number;
  selectedDate: NgbDate;
  selectedBodyBasalTempIndex: number;
  selectedBodyBasalTemp: string;
  bodyBasalTempList: string[];
  selectedMucusStateIndex: number;
  selectedMucusState: string;
  mucusStateList: string[];
  selectedIntercourse: SelectedInterCourse;
  notes: string;
  intercourseList: SelectedInterCourse[];
  calendarDateEntries: CalendarDateEntryType[];
  isDateSavedForQuestions: boolean;
  isShowQuestions: boolean;
  calendarMinDate: { year: number; month: number; day: number };
  calendarMaxDate: { year: number; month: number; day: number };
  dateDiff: number;
  currentDate: NgbDate;
  lastPeriodDate: NgbDate;
  userdueDate: NgbDate;
  congratsMsg = true;
  profileData: any;
  userName: string;
  gigyaScreen: string;
  trimesterValue: string;
  trimesterValueArray: string[];
  getNextLMPDate: NgbDate;
  getmonthdiff: number;
  nextMnthOvulationMarkedDate: NgbDate;
  displaySubHeader: number;
  getdurationcycleContent: number;
  getOvulationDate: number;
  nextDateOfOvulation: number;

  pregnancyPlanning$: Observable<any>;
  private planningStateSubscription: Subscription;
  PregnancyPlanningReducer: any;
  currentPopupNodeID: string;

  @ViewChild("calendarRef", { static: true }) calendarRef: NgbDatepicker;

  constructor(
    public calendar: NgbCalendar,
    public i18n: NgbDatepickerI18n,
    private translateService: TranslateService,
    private stateService: StateService,
    private modalService: NgbModal,
    private store: Store<any>,
    private router: Router,
    private adobeSoapService: AdobeSoapService
  ) {
    this.duedate = "";
    this.pregnancyWeek = 0;
    this.isDateSavedForQuestions = false;
    this.isShowQuestions = false;
    // inital value initialization
    this.currentMonth = calendar.getToday().month;
    this.stateService.updateMonthNumber(this.currentMonth);
    this.currentYear = calendar.getToday().year;
    this.currentDate = calendar.getToday();
    this.calendarDateEntries = [];
    this.pregnantStageIndex = localStorage.getItem("journeyStageIndex");
    if (localStorage.getItem("periodCycleDuration")) {
      this.noOfcycle = parseInt(
        localStorage.getItem("periodCycleDuration"),
        10
      );
    }
    if (JSON.parse(localStorage.getItem("lastPeriodDate"))) {
      this.userdueDate = calendar.getNext(
        JSON.parse(localStorage.getItem("lastPeriodDate")),
        "d",
        280
      );
    }
    this.calendarMinDate = { year: 1970, month: 1, day: 1 };
    this.calendarMaxDate = { year: this.currentYear + 5, month: 12, day: 31 };
    this.profileData = JSON.parse(localStorage.getItem("profile"));

    if (this.pregnantStageIndex !== undefined) {
      if (
        this.noOfcycle &&
        JSON.parse(localStorage.getItem("lastPeriodDate")) &&
        this.pregnantStageIndex == 0
      ) {
        this.firstDayOfCycleMarkedDate = JSON.parse(
          localStorage.getItem("lastPeriodDate")
        );
        this.ovulationMarkedDate = this.calendar.getNext(
          this.firstDayOfCycleMarkedDate,
          "d",
          this.noOfcycle - 14
        );
        this.getNextLMPDate = this.calendar.getNext(
          this.firstDayOfCycleMarkedDate,
          "d",
          this.getmonthdiff * this.noOfcycle
        );
        this.fromDate = this.calendar.getNext(
          this.ovulationMarkedDate,
          "d",
          -3
        );
        this.ovulationInsideMarkedDate1 = this.calendar.getNext(
          this.ovulationMarkedDate,
          "d",
          -2
        );
        this.ovulationInsideMarkedDate2 = this.calendar.getNext(
          this.ovulationMarkedDate,
          "d",
          -1
        );
        this.toDate = this.ovulationMarkedDate;
        this.nextMnthOvulationMarkedDate = this.calendar.getNext(
          this.firstDayOfCycleMarkedDate,
          "d",
          this.getmonthdiff * this.noOfcycle - 14
        );
      }
      if (this.pregnantStageIndex == 1) {
        this.pregnancyWeek = this.calcCurrentPregnancyWeek();
        if (this.profileData) {
          this.userName = this.profileData.firstName;
          this.gigyaScreen = this.profileData.Screen;
        }
        localStorage.setItem(
          "pregnancyWeek",
          JSON.stringify(this.pregnancyWeek)
        );
      }
      if (this.pregnantStageIndex == 0 && this.profileData) {
        this.userName = this.profileData.firstName;
      }
    }
    this.pregnancyPlanning$ = store.select("PregnancyPlanningReducer");
  }

  ngOnInit() {
    this.translateService.get("HOME").subscribe((translated) => {
      this.calendarJsonData = translated.CALENDAR[this.pregnantStageIndex || 0];
      this.bodyBasalTempList = translated.BODYBASALTEMPLIST;
      this.mucusStateList = translated.MUCUSSTATELIST;
      this.intercourseList = translated.INTERCOURSELIST;
      this.trimesterValueArray = translated.TRIMESTER_NUMBER;
      if (
        this.pregnantStageIndex !== undefined &&
        this.pregnantStageIndex == 1
      ) {
        this.trimesterValue = this.calcTrimesterfromWeek();
        this.getduedate(this.calendarJsonData.TITLE[2]);
      }
    });
    // tslint:disable-next-line: triple-equals
    if (this.pregnantStageIndex == 0) {
      this.dateDiff = this.calcDaysDiff();
      this.getmonthdiff = this.getMonthsdiff();
      this.getdurationcycleContent = this.checkMenstruationStage();
      this.getOvulationDate = this.datesDiff();
      this.nextDateOfOvulation = this.getOvulationDate + 1;
      this.getNextLMPDate = this.calendar.getNext(
        this.firstDayOfCycleMarkedDate,
        "d",
        this.getmonthdiff * this.noOfcycle
      );
      localStorage.setItem(
        "OvulationDay",
        JSON.stringify(this.getOvulationDate)
      );
      this.displaySubtitleContent();
    }
    if (
      this.profileData &&
      this.profileData.UID &&
      this.pregnantStageIndex == 0
    ) {
      setTimeout(() => {
        this.adobeSoapService
          .getCalendarDatesInformation(this.profileData.UID)
          .subscribe(
            (data: any) => {
              // console.log("get entry details", data);

              if (data && data.items.length > 0) {
                const responseData = data.items;

                responseData.forEach((value) => {
                  let eachData = value["values"];

                  let entrydateVal = eachData.filter(
                    (val) => val.name === "EntryDate"
                  );
                  let BaseBodyTempVal = eachData.filter(
                    (val) => val.name === "BaseBodyTemp"
                  );
                  let MucusStateVal = eachData.filter(
                    (val) => val.name === "MucusState"
                  );
                  let SexualintercourseVal = eachData.filter(
                    (val) => val.name === "Sexualintercourse"
                  );

                  let NotesVal = eachData.filter((val) => val.name === "Notes");
                  let formatSexualInterCourse = SexualintercourseVal[0].value;
                  if (SexualintercourseVal[0].value === "True") {
                    formatSexualInterCourse = 1;
                  } else if (SexualintercourseVal[0].value === "False") {
                    formatSexualInterCourse = 0;
                  }
                  this.calendarDateEntries.push({
                    calendarDate: entrydateVal[0].value.slice(0, 9),
                    calendarEntry: {
                      bodyBasalTemp: BaseBodyTempVal[0].value || undefined,
                      mucusState: MucusStateVal[0].value || undefined,
                      intercourse: formatSexualInterCourse || undefined,
                      notes: NotesVal[0].value || undefined,
                    },
                  });
                });
              }
              ///////// old code
              // if (
              //   data &&
              //   data.responseStatus === "SUCCESS" &&
              //   data.output &&
              //   data.output["elevitentrydetail-collection"] &&
              //   data.output["elevitentrydetail-collection"].elevitentrydetail
              // ) {
              //   const responseData =
              //     data.output["elevitentrydetail-collection"].elevitentrydetail;
              //   if (responseData.constructor.name === "Object") {
              //     this.calendarDateEntries.push({
              //       calendarDate:
              //         responseData["@entrydate"].slice(0, 10) + "T00:00:00",
              //       calendarEntry: {
              //         bodyBasalTemp: responseData["@basebodytemp"] || undefined,
              //         mucusState: responseData["@mucusstate"] || undefined,
              //         intercourse:
              //           responseData["@sexualintercourse"] || undefined,
              //         notes: responseData["@notes"] || undefined,
              //       },
              //     });
              //   } else {
              //     responseData.forEach((value) => {
              //       this.calendarDateEntries.push({
              //         calendarDate:
              //           value["@entrydate"].slice(0, 10) + "T00:00:00",
              //         calendarEntry: {
              //           bodyBasalTemp: value["@basebodytemp"] || undefined,
              //           mucusState: value["@mucusstate"] || undefined,
              //           intercourse: value["@sexualintercourse"] || undefined,
              //           notes: value["@notes"] || undefined,
              //         },
              //       });
              //     });
              //   }
              // }
              //////
            },
            (error: HttpErrorResponse) => {
              console.log("error entry details", error);
            }
          );
      }, 500);
    }
  }

  ngAfterViewInit() {}

  /* this method is called when user click save your journey in accordian screen to save calendar entries */
  setCalendarDatesInformation() {
    const setCalendarDatesInformation$ = [];
    let gigyaid = "";
    if (this.profileData && this.profileData.UID) {
      gigyaid = this.profileData.UID;
    }
    if (gigyaid) {
      this.calendarDateEntries.forEach((value) => {
        if (typeof value.calendarEntry.intercourse === "number") {
          setCalendarDatesInformation$.push(
            this.adobeSoapService.setCalendarDatesInformation(
              value.calendarDate,
              value.calendarEntry.bodyBasalTemp || "",
              value.calendarEntry.intercourse,
              value.calendarEntry.mucusState || "",
              gigyaid,
              value.calendarEntry.notes || ""
            )
          );
        }
      });
      if (
        this.profileData &&
        this.profileData.UID &&
        setCalendarDatesInformation$ &&
        setCalendarDatesInformation$.length !== 0
      ) {
        const setCalendarDatesInformations$ = forkJoin(
          setCalendarDatesInformation$
        );
        setCalendarDatesInformations$.subscribe(
          (data) => {
            this.router.navigate(["/complete-journey"]);
          },
          (error: HttpErrorResponse) => {}
        );
      } else {
        this.router.navigate(["/complete-journey"]);
      }
    }
  }

  /* change/update model value on changing any dropdown */
  ChangeSelectedValue(selectedModel: string, selectedModelValue: number) {
    this[selectedModel] = selectedModelValue;
  }

  /* returns index of date passed in calendarDateEntries List if not available returns -1 */
  getCalendardateEntriesindex(date: any) {
    const selectedDate =
      date.year +
      "-" +
      (date.month.toString().length === 1 ? "0" + date.month : date.month) +
      "-" +
      (date.day.toString().length === 1 ? "0" + date.day : date.day) +
      "T00:00:00";
    return this.calendarDateEntries.findIndex(
      (value) => value.calendarDate === selectedDate
    );
  }

  /* When user click save button for any question related to date */
  saveCalendarEntry() {
    const selectedDate =
      (this.selectedDate.month.toString().length === 1
        ? "0" + this.selectedDate.month
        : this.selectedDate.month) +
      "-" +
      (this.selectedDate.day.toString().length === 1
        ? "0" + this.selectedDate.day
        : this.selectedDate.day) +
      "-" +
      this.selectedDate.year;
    // const selectedDate =
    //   this.selectedDate.year +
    //   "-" +
    //   (this.selectedDate.month.toString().length === 1
    //     ? "0" + this.selectedDate.month
    //     : this.selectedDate.month) +
    //   "-" +
    //   (this.selectedDate.day.toString().length === 1
    //     ? "0" + this.selectedDate.day
    //     : this.selectedDate.day) +
    //   "T00:00:00";

    const calendarDateEntryIndex = this.getCalendardateEntriesindex(
      this.selectedDate
    );
    const bodyBasalTemp =
      this.selectedBodyBasalTempIndex !== undefined
        ? this.bodyBasalTempList[this.selectedBodyBasalTempIndex]
        : undefined;
    const mucusState =
      this.selectedMucusStateIndex !== undefined
        ? this.mucusStateList[this.selectedMucusStateIndex]
        : undefined;
    const intercourse = this.selectedIntercourse
      ? this.selectedIntercourse.value
      : undefined;
    const notes = this.notes ? this.notes : undefined;
    if (calendarDateEntryIndex === -1) {
      /* In case of new Entry to save */
      this.calendarDateEntries.push({
        calendarDate: selectedDate,
        calendarEntry: {
          bodyBasalTemp,
          mucusState,
          intercourse,
          notes,
        },
      });
    } else {
      /* In case of ond Entry to Overridden */
      this.calendarDateEntries[calendarDateEntryIndex] = {
        calendarDate: selectedDate,
        calendarEntry: {
          bodyBasalTemp,
          mucusState,
          intercourse,
          notes,
        },
      };
    }
    this.isShowQuestions = false;
    this.stateService.setIframeHeight("iFrameResizer0");
  }

  /* returns true of date on calendar is selected date */
  isSelectedDate(date: NgbDate) {
    console.log("date", date);
    console.log("this.selectedDate", this.selectedDate);
    if (!this.selectedDate) {
      return false;
    }
    console.log(
      "return ",
      date.year === this.selectedDate.year &&
        date.month === this.selectedDate.month &&
        date.day === this.selectedDate.day
    );
    return (
      date.year === this.selectedDate.year &&
      date.month === this.selectedDate.month &&
      date.day === this.selectedDate.day
    );
  }

  /* if two dates are having difference in multiple of cycle number */
  isCycleDifference(date1: NgbDate, date2: NgbDate) {
    if (!date1 || !date2) {
      return false;
    }
    const date1MS = new Date(date1.year, date1.month - 1, date1.day).getTime();
    const date2MS = new Date(date2.year, date2.month - 1, date2.day).getTime();
    return Number.isInteger(
      (date1MS - date2MS) / (1000 * 60 * 60 * 24 * this.noOfcycle)
    );
  }

  /* called on dateSelect on click date via mouse or keyboard */
  onDateSelection(date: NgbDate) {
    if (this.pregnantStageIndex != 0) {
      return;
    }
    this.selectedDate = date;
    this.isDateSavedForQuestions = false;
    this.isShowQuestions = true;
    this.selectedBodyBasalTemp = this.selectedMucusState = undefined;
    this.selectedIntercourse = null;
    this.notes = null;
    this.selectedMucusStateIndex = undefined;
    this.selectedBodyBasalTempIndex = 0;
    const calendarDateEntryIndex = this.getCalendardateEntriesindex(
      this.selectedDate
    );
    let selectedDateEntry: CalendarDateEntryType;
    if (calendarDateEntryIndex !== -1) {
      this.isDateSavedForQuestions = true;
      selectedDateEntry = this.calendarDateEntries[calendarDateEntryIndex];
      const calendarEntry = selectedDateEntry.calendarEntry;
      this.selectedBodyBasalTempIndex = calendarEntry.bodyBasalTemp
        ? this.bodyBasalTempList.indexOf(calendarEntry.bodyBasalTemp)
        : undefined;
      this.selectedMucusStateIndex = calendarEntry.mucusState
        ? this.mucusStateList.indexOf(calendarEntry.mucusState)
        : undefined;
      this.selectedIntercourse = calendarEntry.intercourse
        ? this.intercourseList.find(
            (val) => val.value === selectedDateEntry.calendarEntry.intercourse
          )
        : null;
      this.notes = calendarEntry.notes ? calendarEntry.notes : undefined;
    }
    this.stateService.setIframeHeight("iFrameResizer0");
  }

  /* called on visible month changes */
  navigateOnMonthChange(event): void {
    this.currentMonth = event.next.month;
    this.currentYear = event.next.year;
  }

  /* returns true if date is first date of cycle */
  isFirstDayOfCycleMarked(date: NgbDate) {
    return this.isCycleDifference(date, this.firstDayOfCycleMarkedDate);
  }

  /* returns true if date is  ovulation marked */
  isOvulationMarked(date: NgbDate) {
    return this.isCycleDifference(date, this.ovulationMarkedDate);
  }

  /* returns true if any date related question answered for Body Basel Temp / Mucus state / Intercourse */
  isQuestionsMarkedSave(date: NgbDate) {
    return this.getCalendardateEntriesindex(date) !== -1;
  }

  /* returns true if date is ovulation start date  */
  isStartDate(date: NgbDate) {
    return this.isCycleDifference(date, this.fromDate);
  }

  /* returns true if date is ovulation end date */
  isEndDate(date: NgbDate) {
    return this.isCycleDifference(date, this.toDate);
  }

  /* returns true if date is first intermediate date between ovulation start date and ovulation end date */
  isOvulationInsideMarkedDate1(date: NgbDate) {
    return this.isCycleDifference(date, this.ovulationInsideMarkedDate1);
  }

  /* returns true if date is second intermediate date between ovulation start date and ovulation end date */
  isOvulationInsideMarkedDate2(date: NgbDate) {
    return this.isCycleDifference(date, this.ovulationInsideMarkedDate2);
  }

  /* returns true if date is between ovulation start date and ovulation end date including */
  isRange(date: NgbDate) {
    return (
      this.isCycleDifference(date, this.fromDate) ||
      this.isCycleDifference(date, this.toDate) ||
      this.isCycleDifference(date, this.ovulationInsideMarkedDate1) ||
      this.isCycleDifference(date, this.ovulationInsideMarkedDate2)
    );
  }

  /* returns true if date is not part of current month */
  isNotCurrentMonth(date: NgbDate) {
    return date.month !== this.currentMonth;
  }

  /* returns true if date is last day of week */
  isLastDayOfWeek(date: NgbDate) {
    return moment(`${date.year}-${date.month}-${date.day}`).isoWeekday() === 6;
  }

  /* returns true if date is today date */
  isTodayDate(date: NgbDate) {
    const today = this.calendar.getToday();
    return (
      date.year === today.year &&
      date.month === today.month &&
      date.day === today.day
    );
  }

  /* navigate to other month on click on back or next arrow */
  navigateMonth(navigateNumber: number): void {
    const { state, calendar } = this.calendarRef;
    const navigatedNextDate = calendar.getNext(
      state.firstDate,
      "m",
      navigateNumber
    );
    if (
      navigatedNextDate.year < this.calendarMinDate.year ||
      (this.calendarMaxDate &&
        navigatedNextDate.year > this.calendarMaxDate.year)
    ) {
      return;
    }
    this.calendarRef.navigateTo(navigatedNextDate);
    this.currentMonth = this.calendar.getNext(
      state.firstDate,
      "m",
      navigateNumber
    ).month;
  }

  /* Open CalendarPopup on calendar icon click */
  openCalendarPopup(event) {
    const calendarModalRef = this.modalService.open(
      CalendarPopupModelContentComponent
    );
    calendarModalRef.componentInstance.calendarJsonData = this.calendarJsonData;
    calendarModalRef.componentInstance.pregnantStageIndex =
      this.pregnantStageIndex;
    calendarModalRef.componentInstance.isDateSavedForQuestions =
      this.isDateSavedForQuestions;
    calendarModalRef.componentInstance.isShowQuestions = this.isShowQuestions;
    calendarModalRef.componentInstance.selectedDate = this.selectedDate;
    calendarModalRef.componentInstance.currentMonth = this.currentMonth;
    calendarModalRef.componentInstance.currentYear = this.currentYear;
    calendarModalRef.componentInstance.currentDate = this.currentDate;
    calendarModalRef.componentInstance.calendarDateEntries =
      this.calendarDateEntries;
    calendarModalRef.componentInstance.bodyBasalTempList =
      this.bodyBasalTempList;
    calendarModalRef.componentInstance.mucusStateList = this.mucusStateList;
    calendarModalRef.componentInstance.intercourseList = this.intercourseList;
    calendarModalRef.componentInstance.selectedIntercourse =
      this.selectedIntercourse;
    calendarModalRef.componentInstance.notes = this.notes;
    calendarModalRef.componentInstance.selectedBodyBasalTempIndex =
      this.selectedBodyBasalTempIndex;
    calendarModalRef.componentInstance.selectedBodyBasalTemp =
      this.selectedBodyBasalTemp;
    calendarModalRef.componentInstance.selectedMucusStateIndex =
      this.selectedMucusStateIndex;
    calendarModalRef.componentInstance.selectedMucusState =
      this.selectedMucusState;
    calendarModalRef.componentInstance.firstDayOfCycleMarkedDate =
      this.firstDayOfCycleMarkedDate;
    calendarModalRef.componentInstance.ovulationMarkedDate =
      this.ovulationMarkedDate;
    calendarModalRef.componentInstance.fromDate = this.fromDate;
    calendarModalRef.componentInstance.toDate = this.toDate;
    calendarModalRef.componentInstance.ovulationInsideMarkedDate1 =
      this.ovulationInsideMarkedDate1;
    calendarModalRef.componentInstance.ovulationInsideMarkedDate2 =
      this.ovulationInsideMarkedDate2;
    calendarModalRef.componentInstance.noOfcycle = this.noOfcycle;
    calendarModalRef.componentInstance.calendarMinDate = this.calendarMinDate;
    calendarModalRef.componentInstance.calendarMaxDate = this.calendarMaxDate;
    calendarModalRef.componentInstance.ChangeSelectedValue =
      this.ChangeSelectedValue;
    calendarModalRef.componentInstance.saveCalendarEntry =
      this.saveCalendarEntry;
    calendarModalRef.componentInstance.isSelectedDate = this.isSelectedDate;
    calendarModalRef.componentInstance.isCycleDifference =
      this.isCycleDifference;
    calendarModalRef.componentInstance.onDateSelection = this.onDateSelection;
    calendarModalRef.componentInstance.navigateOnMonthChange =
      this.navigateOnMonthChange;
    calendarModalRef.componentInstance.isFirstDayOfCycleMarked =
      this.isFirstDayOfCycleMarked;
    calendarModalRef.componentInstance.isOvulationMarked =
      this.isOvulationMarked;
    calendarModalRef.componentInstance.isQuestionsMarkedSave =
      this.isQuestionsMarkedSave;
    calendarModalRef.componentInstance.isStartDate = this.isStartDate;
    calendarModalRef.componentInstance.isEndDate = this.isEndDate;
    calendarModalRef.componentInstance.isOvulationInsideMarkedDate1 =
      this.isOvulationInsideMarkedDate1;
    calendarModalRef.componentInstance.isOvulationInsideMarkedDate2 =
      this.isOvulationInsideMarkedDate2;
    calendarModalRef.componentInstance.isRange = this.isRange;
    calendarModalRef.componentInstance.isNotCurrentMonth =
      this.isNotCurrentMonth;
    calendarModalRef.componentInstance.isLastDayOfWeek = this.isLastDayOfWeek;
    calendarModalRef.componentInstance.isTodayDate = this.isTodayDate;
    calendarModalRef.componentInstance.navigateMonth = this.navigateMonth;
    calendarModalRef.componentInstance.getCalendardateEntriesindex =
      this.getCalendardateEntriesindex;

    if (
      event &&
      event.currentTarget &&
      event.currentTarget.parentNode &&
      event.currentTarget.parentNode.parentNode &&
      event.currentTarget.parentNode.parentNode.parentNode &&
      event.currentTarget.parentNode.parentNode.parentNode.id
    ) {
      calendarModalRef.componentInstance.currentPopupNodeID =
        event.currentTarget.parentNode.parentNode.parentNode.id;
    }

    calendarModalRef.result.then(
      (result) => {
        this.stateService.setIframeHeight("iFrameResizer0");
      },
      (reason: object) => {
        for (const objEntry in reason) {
          if (reason.hasOwnProperty(objEntry)) {
            this[objEntry] = reason[objEntry];
          }
        }
        this.calendarRef.navigateTo({
          year: this.currentYear,
          month: this.currentMonth,
        });
        this.stateService.setIframeHeight("iFrameResizer0");
        if (this.currentPopupNodeID) {
          setTimeout(() => {
            const currentAccordianElement = document.getElementById(
              this.currentPopupNodeID
            ) as HTMLElement;
            currentAccordianElement.scrollIntoView();
          }, 1000);
        }
      }
    );
    this.stateService.updateMonthNumber(this.currentMonth);
  }

  /* Modify ngbdate format to date time timestamp */
  private createDateFromNgbDate(ngbDate: NgbDate): Date {
    if (ngbDate && ngbDate != null) {
      const date: Date = new Date(
        Date.UTC(ngbDate.year, ngbDate.month - 1, ngbDate.day)
      );
      return date;
    }
  }

  /* Caluclate the difference between current date and last period date */
  private calcDaysDiff(): number {
    const fromDate: Date = this.createDateFromNgbDate(
      this.firstDayOfCycleMarkedDate
    );
    const toDate: Date = this.createDateFromNgbDate(this.currentDate);
    // tslint:disable-next-line: no-angle-bracket-type-assertion
    const daysDiff = Math.floor(
      Math.abs(<any>fromDate - <any>toDate) / (1000 * 60 * 60 * 24)
    );
    return daysDiff;
  }

  private datesDiff(): number {
    const fromDate: Date = this.createDateFromNgbDate(
      this.firstDayOfCycleMarkedDate
    );
    const toDate: Date = this.createDateFromNgbDate(this.ovulationMarkedDate);
    // tslint:disable-next-line: no-angle-bracket-type-assertion
    const daysDiff = Math.floor(
      Math.abs(<any>fromDate - <any>toDate) / (1000 * 60 * 60 * 24)
    );
    return daysDiff;
  }

  /* Caluclate difference of current month and LMP month */
  getMonthsdiff() {
    if (this.firstDayOfCycleMarkedDate) {
      const LMPMonth = this.firstDayOfCycleMarkedDate.month;
      // tslint:disable-next-line: triple-equals
      if (this.currentMonth == LMPMonth) {
        return 1;
      } else {
        return this.currentMonth - LMPMonth + 1;
      }
    }
  }

  /* Switch JSON title data based on last period date selected */
  checkMenstruationStage() {
    if (this.noOfcycle < 23) {
      if (
        this.isFirstDayOfCycleMarked(this.currentDate) ||
        this.dateDiff % this.noOfcycle <= 2
      ) {
        return 0;
      } else if (
        this.dateDiff % this.noOfcycle > 2 &&
        this.currentDate.before(this.fromDate)
      ) {
        return 1;
      } else if (this.isRange(this.currentDate)) {
        return 2;
      } else if (
        !this.isRange(this.currentDate) &&
        this.currentDate.before(this.getNextLMPDate)
      ) {
        return 3;
      } else {
        return 1;
      }
    } else if (this.noOfcycle > 22 && this.noOfcycle < 27) {
      if (
        this.isFirstDayOfCycleMarked(this.currentDate) ||
        this.dateDiff % this.noOfcycle <= 3
      ) {
        return 0;
      } else if (
        this.dateDiff % this.noOfcycle > 3 &&
        this.currentDate.before(this.fromDate)
      ) {
        return 1;
      } else if (this.isRange(this.currentDate)) {
        return 2;
      } else if (
        !this.isRange(this.currentDate) &&
        this.currentDate.before(this.getNextLMPDate)
      ) {
        return 3;
      } else {
        return 1;
      }
    } else {
      if (
        this.isFirstDayOfCycleMarked(this.currentDate) ||
        this.dateDiff % this.noOfcycle <= 5
      ) {
        return 0;
      } else if (
        this.dateDiff % this.noOfcycle > 5 &&
        this.currentDate.before(this.fromDate)
      ) {
        return 1;
      } else if (this.isRange(this.currentDate)) {
        return 2;
      } else if (
        !this.isRange(this.currentDate) &&
        this.currentDate.before(this.getNextLMPDate)
      ) {
        return 3;
      } else {
        return 1;
      }
    }
  }

  /* Switch JSON subheader data based on last period date selected */
  displaySubtitleContent() {
    const content = this.checkMenstruationStage();
    if (content === 0 || content === 3) {
      this.displaySubHeader = 0;
      return 0;
    } else if (content === 1 || content === 2) {
      this.displaySubHeader = 1;
      return 1;
    }
  }

  /* Caluclate due date from last perio date */
  getduedate(dateFormat) {
    if (this.userdueDate) {
      setTimeout(() => {
        let duedateMonth = moment(this.userdueDate.month, "M").format("MMM");
        let duedateMonthFull = moment(this.userdueDate.month, "M").format(
          "MMMM"
        );
        if (dateFormat == "dateFormatDE" || dateFormat == "dateFormatSR") {
          this.duedate =
            this.userdueDate.day +
            ". " +
            duedateMonth +
            " " +
            this.userdueDate.year;
        } else if (dateFormat == "dateFormatVI") {
          this.duedate =
            this.userdueDate.day +
            " " +
            duedateMonth.toLowerCase() +
            " năm " +
            this.userdueDate.year;
        } else if (dateFormat == "dateFormatES") {
          this.duedate =
            this.userdueDate.day +
            " de " +
            duedateMonthFull.toLowerCase() +
            " de " +
            this.userdueDate.year;
        } else if (dateFormat == "dateFormatESMX") {
          this.duedate =
            this.userdueDate.day +
            " " +
            duedateMonth +
            ", " +
            this.userdueDate.year;
        } else {
          this.duedate =
            duedateMonth +
            " " +
            this.userdueDate.day +
            ", " +
            this.userdueDate.year;
        }
      }, 500);
    }
  }

  /* Caluclate current pregnancy week from last period date */
  private calcCurrentPregnancyWeek(): number {
    const fromDate: Date = this.createDateFromNgbDate(
      JSON.parse(localStorage.getItem("lastPeriodDate"))
    );
    const toDate: Date = this.createDateFromNgbDate(this.currentDate);
    const pregnancyWeek = Math.floor(
      Math.abs(<any>fromDate - <any>toDate) / (7 * 1000 * 60 * 60 * 24)
    );
    return pregnancyWeek + 1;
  }

  /* Redirect to journey Page if user clicks on recalculate link */
  public getPregnancyWeek() {
    this.router.navigate(["./journey"]);
  }

  /* Calculate Trimester from week */
  public calcTrimesterfromWeek() {
    if (this.pregnancyWeek <= 12) {
      return this.trimesterValueArray[0];
    } else if (this.pregnancyWeek >= 13 && this.pregnancyWeek <= 27) {
      return this.trimesterValueArray[1];
    } else {
      return this.trimesterValueArray[2];
    }
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
    if (this.pregnancyPlanningOptionsInstance) {
      this.pregnancyPlanningOptionsInstance.unsubscribe();
    }
  }
}

@Component({
  selector: "app-calendar-popup-modal-content",
  template: `
    <div
      class="d-block d-sm-none modal-body"
      (window:resize)="onResizeWindow($event, activeModal)"
    >
      <div class="calendar-popup-container pb-0">
        <div
          class="primary-background-color iframe-dom-class"
          #scrollPopupTemplate
        >
          <div class="py-3 calendar-popup-content">
            <div
              class="text-body mw-50 d-inline-block"
              id="calendar-basic-title"
              *ngIf="pregnantStageIndex == 0"
            >
              {{ "HOME.CALENDAR_MOBILE_INSTRUCTION" | translate }}
            </div>
            <span
              class="primary-text-color float-right px-2"
              (click)="closeCalendarPopupModel(activeModal)"
            >
              <img
                src="assets/elevit_icons/cross.svg"
                width="40px"
                height="40px"
              />
            </span>
          </div>
          <div class="calendar-popup-content">
            <ngb-datepicker
              #calendarRef
              [(ngModel)]="calendarModel"
              class="custom-activity-calendar py-2 mw-100"
              (dateSelect)="onDateSelection($event)"
              (navigate)="navigateOnMonthChange($event)"
              displayMonths="1"
              navigation="none"
              firstDayOfWeek="7"
              [showWeekNumbers]="false"
              [dayTemplate]="customDateTemplate"
              outsideDays="visible"
              [minDate]="calendarMinDate"
              [maxDate]="calendarMaxDate"
            >
              <ng-template ngbDatepickerContent>
                <div *ngFor="let month of calendarRef.state.months">
                  <div class="p-1 serif-default pb-3">
                    {{ i18n.getMonthFullName(month.month) }} {{ month.year }}
                  </div>
                  <ngb-datepicker-month
                    class="rounded"
                    [month]="month"
                  ></ngb-datepicker-month>
                </div>
              </ng-template>
            </ngb-datepicker>
          </div>
          <div
            class="serif-small pt-4 primary-text-color calendar-popup-content"
          >
            <a (click)="navigateMonth(-1)"
              ><i class="fa fa-angle-left" aria-hidden="true"></i
              ><span class="pl-3">{{
                i18n.getMonthFullName(currentMonth - 1 || 12)
              }}</span></a
            >
            <a
              class="float-right primary-text-color"
              (click)="navigateMonth(1)"
            >
              <span class="pr-3">{{
                i18n.getMonthFullName(
                  currentMonth + 1 === 13 ? 1 : currentMonth + 1
                )
              }}</span>
              <i class="fa fa-angle-right" aria-hidden="true"></i>
            </a>
          </div>
          <hr class="horizontal-line my-3" />
          <div
            class="container-fluid main-container p-0 calendar-popup-content"
          >
            <div class="row">
              <div class="col-lg-10 col-md-10 col-xs-12 col-sm-12">
                <div [hidden]="!selectedDate || !isShowQuestions">
                  <div class="serif-small primary-text-pink">
                    {{ "HOME.BODYBASALTEMPLISTHEADING" | translate }}
                  </div>
                  <div
                    ngbDropdown
                    class="bayer-dropdown"
                    #goToBodyBasalTempDrop="ngbDropdown"
                  >
                    <button
                      class="btn p-0 text-body text-left"
                      id="selectBodyBasalTemp"
                      [ngClass]="{
                        'stage-dropdown':
                          selectedBodyBasalTempIndex === undefined
                      }"
                      ngbDropdownAnchor
                      (click)="goToBodyBasalTempDrop.open()"
                    >
                      {{
                        selectedBodyBasalTempIndex === undefined
                          ? ("HOME.BODYBASALTEMPLISTPLACEHOLDER" | translate)
                          : bodyBasalTempList[selectedBodyBasalTempIndex] +
                            ("HOME.TAGS.DEGREE" | translate)
                      }}
                      <img
                        class="downdown-arrow"
                        src="assets/elevit_icons/up.svg"
                      />
                    </button>
                    <hr class="horizontal-line" />
                    <div
                      ngbDropdownMenu
                      aria-labelledby="bodyBasalTemp"
                      class="dropdown-scroll"
                      id="goToBodyBasalTempDropdown"
                    >
                      <button
                        ngbDropdownItem
                        class="text-body pb-3"
                        *ngFor="
                          let selectedBodyBasalTemp of bodyBasalTempList;
                          index as i
                        "
                        (click)="
                          ChangeSelectedValue('selectedBodyBasalTempIndex', i);
                          goToBodyBasalTempDrop.close()
                        "
                      >
                        <span>{{
                          selectedBodyBasalTemp +
                            ("HOME.TAGS.DEGREE" | translate)
                        }}</span>
                      </button>
                    </div>
                  </div>
                  <div class="serif-small primary-text-pink">
                    {{ "HOME.MUCUSSTATELISTHEADING" | translate }}
                  </div>
                  <div
                    ngbDropdown
                    class="bayer-dropdown"
                    #goToMucusStateDrop="ngbDropdown"
                  >
                    <button
                      class="btn p-0 text-body text-left"
                      id="selectMucusState"
                      [ngClass]="{
                        'stage-dropdown': selectedMucusStateIndex === undefined
                      }"
                      ngbDropdownAnchor
                      (click)="goToMucusStateDrop.open()"
                    >
                      {{
                        selectedMucusStateIndex !== undefined
                          ? ("HOME.MUCUSSTATELIST" | translate)[
                              selectedMucusStateIndex
                            ]
                          : ("HOME.MUCUSSTATELISTPLACEHOLDER" | translate)
                      }}
                      <img
                        class="downdown-arrow"
                        src="assets/elevit_icons/up.svg"
                      />
                    </button>
                    <hr class="horizontal-line" />
                    <div
                      ngbDropdownMenu
                      aria-labelledby="mucusState"
                      class="dropdown-scroll overflow-hidden"
                      id="goToMucusStateDropdown"
                    >
                      <button
                        ngbDropdownItem
                        class="text-body pb-3"
                        (click)="selectedMucusStateIndex = undefined"
                      >
                        {{ "HOME.TAGS.SELECT" | translate }}
                      </button>
                      <button
                        ngbDropdownItem
                        class="text-body pb-3"
                        *ngFor="
                          let selectedMucusState of mucusStateList;
                          index as i
                        "
                        (click)="
                          ChangeSelectedValue('selectedMucusStateIndex', i);
                          goToMucusStateDrop.close()
                        "
                      >
                        <span>{{ selectedMucusState }}</span>
                      </button>
                    </div>
                  </div>
                  <div>
                    <span class="mr-4 primary-text-pink serif-small">{{
                      "HOME.INTERCOURSEHEADING" | translate
                    }}</span>
                    <label
                      class="radio-label mr-2 text-body"
                      *ngFor="
                        let selectedIntercourseObj of intercourseList;
                        index as i
                      "
                    >
                      <input
                        type="radio"
                        name="intercourse-radio1"
                        [(ngModel)]="selectedIntercourse"
                        [value]="selectedIntercourseObj"
                      />
                      <span class="mr-2">
                        <img
                          src="assets/elevit_icons/tick.svg"
                          width="22px"
                          height="22px"
                          *ngIf="
                            selectedIntercourse &&
                            selectedIntercourse.value ===
                              selectedIntercourseObj.value
                          "
                        />
                      </span>
                      {{ selectedIntercourseObj.label }}
                    </label>
                  </div>
                  <div class="form-group py-4 serif-small primary-text-pink">
                    <label for="comment">{{
                      "HOME.CALENDAR_NOTES.HEADING" | translate
                    }}</label>
                    <textarea
                      #textbox
                      (change)="notes = textbox.value"
                      class="form-control serif-small "
                      maxlength="500"
                      [(ngModel)]="notes"
                      rows="5"
                      placeholder="{{
                        'HOME.CALENDAR_NOTES.PLACEHOLDER' | translate
                      }}"
                    ></textarea>
                  </div>
                  <div class="button-content pt-1 subheader text-center">
                    <button
                      type="button"
                      (click)="saveCalendarEntry()"
                      *ngIf="!isDateSavedForQuestions"
                      class="btn btn-primary lozenge_outlined px-4 serif-small primary-background-pink"
                    >
                      {{ "HOME.TAGS.SAVE" | translate }}
                    </button>
                    <button
                      type="button"
                      (click)="saveCalendarEntry()"
                      *ngIf="isDateSavedForQuestions"
                      class="btn btn-primary lozenge_outlined px-4 serif-small primary-background-pink"
                    >
                      {{ "HOME.TAGS.OVERRIDE" | translate }}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <hr
            class="my-3 horizontal-line"
            [hidden]="!selectedDate || !isShowQuestions"
          />
          <div class="main-container pt-0 calendar-popup-content">
            <ul class="small-text pb-2" *ngIf="pregnantStageIndex == 0">
              <li>{{ calendarJsonData.STATE[0] }}</li>
              <li>{{ calendarJsonData.STATE[1] }}</li>
              <li>{{ calendarJsonData.STATE[2] }}</li>
              <li>{{ calendarJsonData.STATE[3] }}</li>
            </ul>
            <div class="small-text pb-4">
              {{ calendarJsonData.INSTRUCTION }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <ng-template #customDateTemplate let-date>
      <span
        class="custom-day"
        [ngClass]="{
          'first-day-of-cycle-marked': isFirstDayOfCycleMarked(date),
          'ovulation-marked': isOvulationMarked(date),
          'start-date': isStartDate(date),
          'end-date': isEndDate(date),
          'ovulation-inside-marked-date1': isOvulationInsideMarkedDate1(date),
          'ovulation-inside-marked-date2': isOvulationInsideMarkedDate2(date),
          range: isRange(date),
          'text-muted outside': isNotCurrentMonth(date),
          'last-day-of-week': isLastDayOfWeek(date),
          'primary-text-color': isTodayDate(date)
        }"
      >
        {{ isSelectedDate(date) ? "&nbsp;" : date.day }}
      </span>
      <div
        [ngClass]="{
          'intercourse-baseltemp-mucus': isQuestionsMarkedSave(date),
          'selected-date': isSelectedDate(date),
          'ovulation_or_first-day-of-cycle-marked':
            isOvulationMarked(date) || isFirstDayOfCycleMarked(date),
          'selected-date-muted': isNotCurrentMonth(date)
        }"
      >
        {{ isSelectedDate(date) ? date.day : "&nbsp;" }}
      </div>
    </ng-template>
  `,
  styleUrls: ["./pregnancy-calendar.component.scss"],
})
export class CalendarPopupModelContentComponent
  implements OnInit, AfterViewInit
{
  @ViewChild("calendarRef", { static: true }) calendarRef: NgbDatepicker;
  @Input() public calendarJsonData;
  @Input() public pregnantStageIndex;
  @Input() public isDateSavedForQuestions;
  @Input() public isShowQuestions;
  @Input() public selectedDate;
  @Input() public currentMonth;
  @Input() public currentYear;
  @Input() public currentDate;
  @Input() public calendarDateEntries;
  @Input() public bodyBasalTempList;
  @Input() public mucusStateList;
  @Input() public intercourseList;
  @Input() public selectedIntercourse;
  @Input() public notes;
  @Input() public selectedBodyBasalTempIndex;
  @Input() public selectedBodyBasalTemp;
  @Input() public selectedMucusStateIndex;
  @Input() public selectedMucusState;
  @Input() public firstDayOfCycleMarkedDate;
  @Input() public ovulationMarkedDate;
  @Input() public fromDate;
  @Input() public toDate;
  @Input() public ovulationInsideMarkedDate1;
  @Input() public ovulationInsideMarkedDate2;
  @Input() public noOfcycle;
  @Input() public calendarMinDate;
  @Input() public calendarMaxDate;
  @Input() public currentPopupNodeID;

  //prod issue fix
  @Input() public navigateMonth;
  @Input() public navigateOnMonthChange;
  @Input() public onDateSelection;
  @Input() public calendarModel;
  @Input() public isSelectedDate;
  @Input() public isNotCurrentMonth;
  @Input() public isFirstDayOfCycleMarked;
  @Input() public isOvulationMarked;
  @Input() public isQuestionsMarkedSave;
  @Input() public isTodayDate;
  @Input() public isLastDayOfWeek;
  @Input() public isRange;
  @Input() public isOvulationInsideMarkedDate2;
  @Input() public isOvulationInsideMarkedDate1;
  @Input() public isEndDate;
  @Input() public isStartDate;
  @Input() public saveCalendarEntry;
  @Input() public ChangeSelectedValue;
  @ViewChild("scrollPopupTemplate", { static: false })
  scrollPopupTemplate: ElementRef;

  constructor(
    public calendar: NgbCalendar,
    public i18n: NgbDatepickerI18n,
    private translateService: TranslateService,
    public activeModal: NgbActiveModal,
    private stateService: StateService,
    private store: Store<any>
  ) {}

  ngOnInit() {
    this.calendarRef.navigateTo({
      year: this.currentYear,
      month: this.currentMonth,
    });
    this.translateService.get("HOME").subscribe((translated: string) => {
      this.calendarJsonData =
        this.translateService.instant("HOME.CALENDAR")[
          this.pregnantStageIndex || 0
        ];
      this.bodyBasalTempList = this.translateService.instant(
        "HOME.BODYBASALTEMPLIST"
      );
      this.mucusStateList = this.translateService.instant(
        "HOME.MUCUSSTATELIST"
      );
      this.intercourseList = this.translateService.instant(
        "HOME.INTERCOURSELIST"
      );
    });
  }

  ngAfterViewInit() {
    this.stateService.setIframeHeight("iFrameResizer0");
    setTimeout(() => {
      // this.scrollPopupTemplate.nativeElement.scrollIntoView();
      // const ifrm = window.parent.document.getElementById(
      //   "iFrameResizer0"
      // ) as HTMLIFrameElement;
      const ifrm = window.parent.document.querySelector(
        'iframe[src*="deco/new-elevit-journey-elements"]'
      ) as HTMLIFrameElement;
      if (
        window.navigator.userAgent.toLowerCase().indexOf("iPad") === -1 &&
        window.navigator.userAgent.toLowerCase().indexOf("iPhone") === -1 &&
        window.navigator.userAgent.toLowerCase().indexOf("iPod") === -1
      ) {
        ifrm.scrollIntoView();
      } else {
        ifrm.scrollTop = 0;
      }
    }, 1000);
  }

  /* On Window resize close calendar popup if it is open because of unavalability of calendar popup for desktop mode */
  onResizeWindow(event, CalendarModal) {
    if (event.target.innerWidth >= 576) {
      this.stateService.updateMonthNumber(this.currentMonth);
      CalendarModal.dismiss(this.returnValuesfromCalendarPopup());
      this.stateService.setIframeHeight("iFrameResizer0");
    }
  }

  /* on clicking on close calendar popup */
  closeCalendarPopupModel(CalendarModal) {
    this.stateService.updateMonthNumber(this.currentMonth);
    CalendarModal.dismiss(this.returnValuesfromCalendarPopup());
  }

  /* return values to main calendar component to scyn data with calendar popup */
  returnValuesfromCalendarPopup(): object {
    return {
      calendarJsonData: this.calendarJsonData,
      pregnantStageIndex: this.pregnantStageIndex,
      isDateSavedForQuestions: this.isDateSavedForQuestions,
      isShowQuestions: this.isShowQuestions,
      selectedDate: this.selectedDate,
      currentMonth: this.currentMonth,
      currentYear: this.currentYear,
      currentDate: this.currentDate,
      calendarDateEntries: this.calendarDateEntries,
      bodyBasalTempList: this.bodyBasalTempList,
      mucusStateList: this.mucusStateList,
      intercourseList: this.intercourseList,
      selectedIntercourse: this.selectedIntercourse,
      notes: this.notes,
      selectedBodyBasalTempIndex: this.selectedBodyBasalTempIndex,
      selectedBodyBasalTemp: this.selectedBodyBasalTemp,
      selectedMucusStateIndex: this.selectedMucusStateIndex,
      selectedMucusState: this.selectedMucusState,
      firstDayOfCycleMarkedDate: this.firstDayOfCycleMarkedDate,
      ovulationMarkedDate: this.ovulationMarkedDate,
      fromDate: this.fromDate,
      toDate: this.toDate,
      ovulationInsideMarkedDate1: this.ovulationInsideMarkedDate1,
      ovulationInsideMarkedDate2: this.ovulationInsideMarkedDate2,
      currentPopupNodeID: this.currentPopupNodeID,
    };
  }
}
