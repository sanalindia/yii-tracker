import { Component, ViewChild, Output, EventEmitter, Input, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { NgbDate, NgbCalendar, NgbDatepickerConfig, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  // tslint:disable-next-line: no-host-metadata-property
  host: {
    '(document:click)': 'closeDatepickerOnClick($event)',
  },
  styleUrls: ['../../journey-stage/journey-stage.component.scss', './date-picker.component.scss']
})
export class DatePickerComponent implements OnChanges {

  hoveredDate: NgbDate;
  fromDate: NgbDate;
  toDate: NgbDate;
  currentMonth: number;
  calendar: NgbCalendar;
  showDatepickerHeader: boolean;
  @ViewChild('dp', { static: true }) datepicker: any;
  selectedCycleIndex: number;
  formatedPeriodFirstDate: string;
  ngbDate: NgbDate;
  @Output() periodFirstDateValue = new EventEmitter<any>();
  @Input() startDate: NgbDate;
  @Input() periodFirstDate: NgbDateStruct;
  @Input() placeholder = 'Select Date';
  datePickerModel: any;
  autoClose: boolean | 'inside' | 'outside' = false;
  monthNames: string[];

  // tslint:disable-next-line: variable-name
  constructor(private _eref: ElementRef, private config: NgbDatepickerConfig, private translateService: TranslateService) {
    const current = new Date();
    config.minDate = { year: 1970, month: 1, day: 1};
    config.outsideDays = 'hidden';
    this.translateService.get('HOME.CALENDAR_PROPERTIES').subscribe((translated) => {
      this.monthNames = translated._monthsFull;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.periodFirstDate && changes.periodFirstDate.currentValue) {
      const periodFirstDate = new Date(changes.periodFirstDate.currentValue);
      if (periodFirstDate.toJSON()) {
        this.periodFirstDate = { day: periodFirstDate.getUTCDate(), month: periodFirstDate.getUTCMonth() + 1, year: periodFirstDate.getUTCFullYear()};
      }
      const month = this.monthNames;
      const day = (this.periodFirstDate.day < 10) ? '0' + this.periodFirstDate.day : this.periodFirstDate.day;
      this.formatedPeriodFirstDate = `${day} ${month[this.periodFirstDate.month - 1]} ${this.periodFirstDate.year}`;
      this.periodFirstDateValue.emit(this.periodFirstDate);
      this.showDatepickerHeader = false;
    }
  }

  /**
   * datepicker open method
   */
  onDateSelection() {
    this.showDatepickerHeader = true;
  }

  /**
   * checking datepicker closing
   */
  closedDatepicker() {
    this.showDatepickerHeader = false;
  }

  /**
   * @param date on selection of date and send selected date to jouney stage page
   * convert month into MMMM format
   */
  selectedDate(date: NgbDate) {
    const month = this.monthNames;
    const day = (date.day < 10) ? '0' + date.day : date.day;
    this.ngbDate = date;
    this.formatedPeriodFirstDate = `${day} ${month[date.month - 1]} ${date.year}`;
    this.periodFirstDateValue.emit(date);
    this.showDatepickerHeader = false;
  }

  // Hiding datepicker when clicked outside the datepicker
  closeDatepickerOnClick(event) {
    if (!this._eref.nativeElement.contains(event.target)) {
      this.showDatepickerHeader = false;
    }
  }

}
