import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PregnancyAccordianListComponent } from './pregnancy-accordian-list.component';

describe('PregnancyAccordianListComponent', () => {
  let component: PregnancyAccordianListComponent;
  let fixture: ComponentFixture<PregnancyAccordianListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PregnancyAccordianListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PregnancyAccordianListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
