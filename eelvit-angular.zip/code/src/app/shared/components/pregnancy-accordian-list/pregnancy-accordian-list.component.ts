import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, AfterViewChecked, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { StateService } from '../../services/state/state.service';
import { NgbDatepickerI18n, NgbAccordion, NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { GoogleAnalyticsService } from '../../../google-analytics.service';
import { TranslateService } from '@ngx-translate/core';
declare var $: any;

@Component({
  selector: 'app-pregnancy-accordian-list',
  templateUrl: './pregnancy-accordian-list.component.html',
  styleUrls: ['./pregnancy-accordian-list.component.scss']
})
export class PregnancyAccordianListComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('acc', {static: false}) accordionComponent: NgbAccordion;
  @ViewChild('tabs', {static: false}) private tabs: NgbTabset;

  constructor(private router: Router, private stateService: StateService, public i18n: NgbDatepickerI18n,
              public googleAnalyticsService: GoogleAnalyticsService, private translateService: TranslateService, private changeDetectorRef: ChangeDetectorRef) {
                this.translateService.get('HOME.ANONYMOUS').subscribe((translated) => {
                  const pregnantStageIndex = localStorage.getItem('journeyStageIndex');
                  this.anonymousData = translated[pregnantStageIndex || 0];
                });
                this.activeIds = [];
                this.selectedTab = '';
                this.tabName1 = '';
                this.tabName2 = '';
  }
  pregnantStageIndex: any;
  stateServiceInstance: any;
  @Input() saveJourney: string;
  @Input() calendarIconShow: boolean;
  currentMonth: number;
  calendarMonthNumbernstance: any;
  pregnancyWeek: any;
  ovulationDate: number;
  noOfCycle: number;
  userType: string;
  anonymousData: any;
  displayedWeekIndex: number;
  displayedWeek: string;
  accordianList: any[];
  activeIds: string[];
  selectedTab: string;
  tabCheckFlag: boolean;
  isOnceLoadingDone: boolean;
  itemImg: string;
  itemAlt: string;
  wkDropdownPostDisplay: string;
  tabName1: string;
  tabName2: string;
  gaTagsText: any;
  relatedAccordianData: string[];
  relatedAccordianDataHeading: string;
  isAnonymousPlanningToPregnancyRediret: boolean;
  packageInformationLeaflet: any;
  loadedImageCount: number;

  /* To open the calendar popup from accordian calendar icon */
  @Output() openCalendarPopupEvent = new EventEmitter();

  /* To change Trimenter Label('The First Trimester', 'The Second Trimester', 'The Third Trimester') with week dropdown change only for Anonymous "I'm Pregnant" flow */
  @Output() changeTrimesterLabelEvent = new EventEmitter();

  /* To call setCalendarDatesInformation service to save calendar date entries */
  @Output() saveYourJourneyEvent = new EventEmitter();
  openCalendarPopup($event) {
    this.openCalendarPopupEvent.emit($event);
  }

  ngOnInit() {
    this.pregnantStageIndex = localStorage.getItem('journeyStageIndex');
    this.isOnceLoadingDone = false;
    this.wkDropdownPostDisplay = '';
    this.accordianList = [];
    this.loadedImageCount = 0;
    this.tabCheckFlag = false;
    if (this.pregnantStageIndex == '1') {
      this.pregnancyWeek = localStorage.getItem('pregnancyWeek');
    } else {
      this.pregnancyWeek = '';
    }
    this.ovulationDate = parseInt(localStorage.getItem('OvulationDay'), 10);
    this.noOfCycle = parseInt(localStorage.getItem('periodCycleDuration'), 10);
    this.userType = localStorage.getItem('userType');
    this.calendarMonthNumbernstance = this.stateService.calendarCurrentMonthNumber.subscribe((index: number) => {
      this.currentMonth = index;
    });
    this.translateService.get('HOME').subscribe((translated) => {
      this.accordianList = translated.ANONYMOUS_LIST.DATA[this.saveJourney ? 'SAVE_JOURNEY' : 'PERSONALIZE_JOURNEY'][this.checkPregnantStageCycle(this.pregnantStageIndex)];
      this.tabName1 = translated.ANONYMOUS_LIST.DATA.PERSONALIZE_JOURNEY.CYCLE2[0].tab[0].role;
      this.tabName2 = translated.ANONYMOUS_LIST.DATA.PERSONALIZE_JOURNEY.CYCLE2[0].tab[1].role;
      this.wkDropdownPostDisplay = translated.WK_DROPDOWN_POST_DISPLAY || '';
      this.gaTagsText = {};
      this.gaTagsText.PERSONALISE_YOUR_JOURNEY = translated.TAGS.PERSONALISE_YOUR_JOURNEY;
      this.gaTagsText.SAVE_YOUR_JOURNEY = translated.TAGS.SAVE_YOUR_JOURNEY;
      this.gaTagsText.CTA = translated.TAGS.CTA;
      this.gaTagsText.ACCORDION = translated.TAGS.ACCORDION;
      this.gaTagsText.CLOSE = translated.TAGS.CLOSE;
      this.gaTagsText.OPEN = translated.TAGS.OPEN;
      this.gaTagsText.TAB = translated.TAGS.TAB;
      this.gaTagsText.CLICK = translated.TAGS.CLICK;
      this.gaTagsText.PREGNANCY_CALENDAR = translated.TAGS.PREGNANCY_CALENDAR;
      this.gaTagsText.PLANNING_CALENDAR = translated.TAGS.PLANNING_CALENDAR;
      this.isAnonymousPlanningToPregnancyRediret = false;
      this.packageInformationLeaflet = translated.PACKAGE_INFORMATION_LEAFLET;
      if (translated.FLAGS) {
        this.isAnonymousPlanningToPregnancyRediret = translated.FLAGS.ANONYMOUS_PLANNING_TO_PREGNANCY_REDIRECT;
      }
      this.selectedTab = this.tabName1.split(' ').join('');
      if (this.pregnantStageIndex == undefined) {
        this.router.navigate(['/save']);
      }
      
      if (this.pregnantStageIndex == '0') {
        if (localStorage.getItem('anonymousFlowType') === 'LoggedInPlanningPregnancy') {
          if ((!this.userType || this.userType == 'anonymous')) {
            this.router.navigate(['/save']);
          }
        }
      }
      if (this.pregnantStageIndex == '1') {
        this.displayedWeekIndex = 0;
        this.accordianList.forEach((value, key) => {
          if (value.startDay == this.pregnancyWeek) {
            this.displayedWeekIndex = key;
          }
          this.activeIds.push(`journey-${key}`);
        });
        const weekSearchJumpTagRegex = new RegExp(('#' + translated.JUMP_TAG_WEEK_NAME).toLowerCase(), '');
        const hashURL = decodeURI(window.parent.location.hash);
        if (localStorage.getItem('anonymousFlowType') === 'LoggedInPlanningPregnancy') {
          if (weekSearchJumpTagRegex.test(hashURL) && hashURL.match(/(\d+)/) && hashURL.match(/(\d+)/)[0] &&
            (+hashURL.match(/(\d+)/)[0] >=3) && (+hashURL.match(/(\d+)/)[0] <=40) && localStorage.getItem('displayedWeekNumber')) {
              if (this.pregnancyWeek && this.userType === 'LoggedIn'){
              this.accordianList.forEach((value, key) => {
                if (value.startDay == hashURL.match(/(\d+)/)[0]) {
                  this.displayedWeekIndex = key;
                }
              });
            } else {
              this.router.navigate(['/save']);
            }
          }
        }
        if (localStorage.getItem('anonymousFlowType') === 'anonymousPlanningPregnancy') {
          if (weekSearchJumpTagRegex.test(hashURL) && hashURL.match(/(\d+)/) && hashURL.match(/(\d+)/)[0] &&
            (+hashURL.match(/(\d+)/)[0] >=3) && (+hashURL.match(/(\d+)/)[0] <=40)) {
              const displayedWeekNumber = hashURL.match(/(\d+)/)[0];
              localStorage.setItem('displayedWeekNumber', displayedWeekNumber);
              if (this.userType === 'anonymous'){
              this.accordianList.forEach((value, key) => {
                if (value.startDay == hashURL.match(/(\d+)/)[0]) {
                  this.displayedWeekIndex = key;
                }
              });
              this.changeTrimesterLabelEvent.emit(hashURL.match(/(\d+)/)[0]);
            } else {
              this.router.navigate(['/calendar']);
            }
          } else {
            if (this.userType === 'anonymous'){

            } else {
              this.router.navigate(['/save']);
            }
          }
          if (localStorage.getItem('displayedWeekNumber')) {
            this.accordianList.forEach((value, key) => {
              if (value.startDay == localStorage.getItem('displayedWeekNumber')) {
                this.displayedWeekIndex = key;
              }
            });
          }
        }
        this.displayedWeek = this.accordianList[this.displayedWeekIndex].period + ' ' + this.accordianList[this.displayedWeekIndex].startDay;
        this.itemImgChange();
      }
    });
  }

  ngAfterViewChecked() {
    if (((window.location !== window.parent.location) || localStorage.getItem('gigyaLangDefault')) && (!this.isOnceLoadingDone)) {
      setTimeout (() => {
        if (this.tabs && !this.tabCheckFlag && localStorage.getItem('displayedWeekNumber')) {
          const tabName2Regex = new RegExp(this.tabName2.split(' ').join(''), ''); // Example /YourBaby/
          const hashURL = decodeURI(window.parent.location.hash);
          if (hashURL.match(tabName2Regex)) {
            this.tabs.select(this.tabName2.split(' ').join(''));
          } else {
            this.tabs.select(this.tabName1.split(' ').join(''));
          }
          this.changeDetectorRef.detectChanges();
          this.tabCheckFlag = true;
          this.itemImgChange();
          localStorage.removeItem('displayedWeekNumber');
        }
        this.stateService.setIframeHeight('iFrameResizer0');
        this.isOnceLoadingDone = true;
        setTimeout (() => {
          this.stateService.setIframeHeight('iFrameResizer0');
          setTimeout (() => {
            this.stateService.setIframeHeight('iFrameResizer0');
          }, 1000);
        }, 1000);
      }, 150);
     }
  }

  /* To change image on accordion description according to week and tab */
  itemImgChange(): void {
    const displayedWeek = (this.displayedWeek || '').replace(/[^\d]/g, ''), selectedTab = this.selectedTab || '';
    this.accordianList.forEach(value => {
      if (value.startDay == displayedWeek) {
        value.tab.forEach(val => {
          if (val.role.split(' ').join('') == selectedTab) {
            this.itemImg = val.img;
            this.itemAlt = val.alt || '';
          }
        });
        if (value.tab[0].role.split(' ').join('') == selectedTab) {
          this.relatedAccordianData  = value.accordianData;
          this.relatedAccordianDataHeading = value.accordianDataHeading;
        } else {
          this.relatedAccordianData  = value.accordianData1 || value.accordianData;
          this.relatedAccordianDataHeading  = value.accordianDataHeading1 || value.accordianDataHeading;
        }
      }
    });
  }

  /* called when user click on Accordion '+' or '-' symbol */
  toggle(id:string, i: number): void {
    let activeIds: any = [];
    if (this.accordionComponent && this.accordionComponent.activeIds) {
      activeIds = this.accordionComponent.activeIds;
    }
    this.accordionComponent.toggle(id);
    if (this.pregnantStageIndex == '1') {
      if (activeIds.indexOf(id) != -1) {
        activeIds.splice(activeIds.indexOf(id), 1);
      } else {
        activeIds.push(id);
      }
      this.activeIds = activeIds;
    }
  }

  /* called when user click on My Body/My Baby Tab */
  onTabChange(event) {
    this.selectedTab = event.nextId;
    this.itemImgChange();
    this.stateService.setIframeHeight('iFrameResizer0');
  }

  /* called when Product image loads fully */
  onProductImageLoad() {
    if(this.loadedImageCount <= 2) {
      this.loadedImageCount = this.loadedImageCount + 1;
    }
    if(this.loadedImageCount === 2) {
      setTimeout (() => {
        this.loadedImageCount = 3;
        this.stateService.setIframeHeight('iFrameResizer0');
      }, 500);
    }
  }

  /* called when user click on 'Personalise your Journey' button */
  personaliseJourney() {
    this.stateService.changeUsertype('anonymous');

    /* Personalise your Journey button section GTM analytics data layer creation */
    let title = '';
    if (typeof(this.anonymousData.TITLE) == 'string') {
      title  = this.anonymousData.TITLE;
    } else {
      title  = this.anonymousData.TITLE[this.getTrimesterIndex(this.displayedWeek)];
    }
    this.googleAnalyticsService.eventEmitter(this.gaTagsText.CTA, this.gaTagsText.PERSONALISE_YOUR_JOURNEY, title, 0);
    if (this.isAnonymousPlanningToPregnancyRediret) {
      this.router.navigate(['/pregnancy']);
    } else{
      this.router.navigate(['/save']);
    }
  }

  /* called when user click on 'Save your Journey' button to save calendar entries */
  confirmJourney() {
    /* Save Your Journey button section GTM analytics data layer creation */
    if(this.pregnantStageIndex == '1') {
      this.googleAnalyticsService.eventEmitter(this.gaTagsText.CTA, this.gaTagsText.SAVE_YOUR_JOURNEY, this.gaTagsText.PREGNANCY_CALENDAR, 0);
    } else {
      this.googleAnalyticsService.eventEmitter(this.gaTagsText.CTA, this.gaTagsText.SAVE_YOUR_JOURNEY, this.gaTagsText.PLANNING_CALENDAR, 0);
    }
    this.saveYourJourneyEvent.emit(null);
  }

  /* To know Trimenter number('The First Trimester', 'The Second Trimester', 'The Third Trimester') with week dropdown change only for Anonymous "I'm Pregnant" flow */
  getTrimesterIndex(selectedweek) {
    let selectedWeekNumber = +selectedweek.replace(/[^\d]/g, '');
    if (selectedWeekNumber >= 3  && selectedWeekNumber <= 12) {
      return 0;
    } else if (selectedWeekNumber >= 13  && selectedWeekNumber <= 27) {
      return 1;
    } else if (selectedWeekNumber >= 28  && selectedWeekNumber <= 40) {
      return 2;
    } else {
      return 0;
    }
  }

  /**
   * To switch json based on pregnantStageIndex
   */
  checkPregnantStageCycle(pregnantStageIndex) {
    let cycle = 'CYCLE1';
    switch (this.pregnantStageIndex) {
      case '0': cycle = 'CYCLE1'; break;
      case '1': cycle = 'CYCLE2'; break;
    }
    return cycle;
  }

  /* Accordian section GTM analytics data layer creation */
  accordionGTM(action, item) {
    let label = `${item.period} `;
    if (item.startDay) {label = label + `${item.startDay}`; }
    if (item.endDay) {label = label + ` to ${item.period} ${item.endDay}`; }
    if (item.startDay === 14 && this.userType === 'LoggedIn' && this.pregnantStageIndex === '0') {label = `${item.period} ${this.ovulationDate} to ${item.period} ${this.ovulationDate + 1}`; }
    if (item.startDay === 28 && this.userType === 'LoggedIn' && this.pregnantStageIndex === '0') {label = `${item.period} ${this.noOfCycle}`; }
    this.googleAnalyticsService.eventEmitter(this.gaTagsText.ACCORDION, (action == 'Open' ? this.gaTagsText.OPEN : this.gaTagsText.CLOSE) , `${label}`, 0);
    this.stateService.setIframeHeight('iFrameResizer0');
  }

  /* Tab section GTM analytics data layer creation */
  tabGTM(role, item) {
    let label = `${item.period} ${item.startDay}`;
    if (item.startDay && item.endDay) {label = label + ` to ${item.period} ${item.endDay}`; }
    this.googleAnalyticsService.eventEmitter(this.gaTagsText.TAB, (this.gaTagsText.CLICK + role), `${label}`, 0);
  }

  /* Navigate to Previous week on click on Back button only for I'm Pregnant Flow */
  goToPreviousWeek() {
    this.displayedWeekIndex = this.displayedWeekIndex - 1;
    this.displayedWeek = this.accordianList[this.displayedWeekIndex].period + ' ' + this.accordianList[this.displayedWeekIndex].startDay;
    this.changeTrimesterLabelEvent.emit(this.displayedWeek);
    this.itemImgChange();
    this.stateService.setIframeHeight('iFrameResizer0');
  }

  /* Navigate to Next week on click on Next button only for I'm Pregnant Flow */
  goToNextWeek() {
    this.displayedWeekIndex = this.displayedWeekIndex + 1;
    this.displayedWeek = this.accordianList[this.displayedWeekIndex].period + ' ' + this.accordianList[this.displayedWeekIndex].startDay;
    this.changeTrimesterLabelEvent.emit(this.displayedWeek);
    this.itemImgChange();
    this.stateService.setIframeHeight('iFrameResizer0');
  }

  /* Navigate to Specific week on select on dropdown only for I'm Pregnant Flow */
  changeGoToWeek(displayedweek, i: number) {
    this.displayedWeekIndex = i;
    this.displayedWeek = displayedweek;
    this.changeTrimesterLabelEvent.emit(this.displayedWeek);
    this.itemImgChange();
    this.stateService.setIframeHeight('iFrameResizer0');
  }

  /* Hide Panels for other then current week only for I'm Pregnant Flow */
  hidePanelsForNotCurretnWeek(weekIndex) {
    return this.pregnantStageIndex == 1 && weekIndex != this.displayedWeekIndex;
  }

  /* navigation to outer link */
  navigation(href) {
    window.open(window.location.origin + href, '_blank');
  }

  /* Navigate to Top of the page only for I'm Pregnant Flow */
  scrollTop() {
    const currentAccordianElement = document.getElementById('goToWeek') as HTMLElement;
    if (window.navigator.userAgent.toLowerCase().indexOf('iPad') === -1 && window.navigator.userAgent.toLowerCase().indexOf('iPhone') === -1 && window.navigator.userAgent.toLowerCase().indexOf('iPod') === -1) {
      currentAccordianElement.scrollIntoView();
    } else {
      currentAccordianElement.scrollTop = 0;
    }
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
    this.calendarMonthNumbernstance.unsubscribe();
  }

}
