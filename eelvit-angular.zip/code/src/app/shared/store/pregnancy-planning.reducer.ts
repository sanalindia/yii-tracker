import { CalendarDateEntryType } from '../models/calendarDateEntryModel';

export class PayloadObject {
    pregnantStageIndex: any;
    periodFirstDate: any;
    noOfcycle: any;
    calendarDateEntries: CalendarDateEntryType[];
}
export function PregnancyPlanningReducer(state = [], action) {
  switch (action.type) {
    case 'SELECT_PREGNANTSTAGEINDEX':
      return [...state, action.payload];
    case 'SELECT_LAST_PERIOD_DATE':
      return [...state, action.payload];
    case 'SELECT_CYCLE_DURATION':
      return [...state, action.payload];
    case 'SELECT_PREGNANT_WEEK_INDEX':
      return [...state, action.payload];
    case 'SELECT_CALENDAR_DATE_ENTRIES':
      return [...state, action.payload];
    default:
      return state;
  }
};
