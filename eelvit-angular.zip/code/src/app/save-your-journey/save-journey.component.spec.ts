import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SaveJourneyComponent } from './save-journey.component';


describe('SaveJourneyComponent', () => {
  let component: SaveJourneyComponent;
  let fixture: ComponentFixture<SaveJourneyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveJourneyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveJourneyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
