import {
  Component,
  OnInit,
  NgZone,
  AfterViewChecked,
  OnDestroy,
} from "@angular/core";
import { NavigationExtras, Router } from "@angular/router";
import { StateService } from "../shared/services/state/state.service";
import { AdobeSoapService } from "../shared/services/adobe-soap/adobe-soap.service";
import { forkJoin } from "rxjs";
import { TranslateService } from "@ngx-translate/core";

declare let gigya: any;
@Component({
  selector: "app-save-your-journey",
  templateUrl: "./save-journey.component.html",
  styleUrls: [
    "../landing-page/landing-page.component.scss",
    "../shared/components/journey-stage/journey-stage.component.scss",
    "./save-journey.component.scss",
  ],
})
export class SaveJourneyComponent
  implements OnInit, AfterViewChecked, OnDestroy
{
  showLogin = false;
  saveSuccess = false;
  userType: string;
  loggedInUserName: string;
  profileData: any;
  isOnceLoadingDone: boolean;
  loginMessagesObj: any;
  countryCode: string;
  isGigyaScriptLoadedInstance: any;
  loginScreenID: string;
  registerScreenID: string;
  loginScreenSetID: string;

  constructor(
    private router: Router,
    private stateService: StateService,
    private adobeSoapService: AdobeSoapService,
    private ngZone: NgZone,
    private translateService: TranslateService
  ) {}

  public singupValidate(obj) {
    if (obj.response) {
      this.ngZone.run(() => {
        if (
          obj.screen == this.loginScreenID &&
          obj.response.statusMessage != "Account Pending Verification" &&
          obj.response.errorMessage != "Account Pending Verification" &&
          obj.response.status !== "FAIL"
        ) {
          document.getElementById("loading").style.display = "block";
          let weeklyPregnancyEmailCheckboxConsent: boolean,
            privacyPolicyCheckboxConsent: boolean,
            collectionNoticeCheckboxConsent: boolean;
          Object.keys(obj.response.preferences).forEach((value) => {
            if (value.indexOf("ElevitEmailNotif") !== -1) {
              weeklyPregnancyEmailCheckboxConsent = obj.response.preferences[
                value
              ].isConsentGranted
                ? true //"1"
                : false; //"0";
            } else if (value.indexOf("terms") !== -1) {
              if (value.indexOf("ElevitPrivPolicy") !== -1) {
                privacyPolicyCheckboxConsent = obj.response.preferences[value]
                  .isConsentGranted
                  ? true //"1"
                  : false; //"0";
              } else if (value.indexOf("ElevitCollectionNotice") !== -1) {
                collectionNoticeCheckboxConsent = obj.response.preferences[
                  value
                ].isConsentGranted
                  ? true //"1"
                  : false; //"0";
              }
            }
          });

          this.adobeSoapService.getUserData(obj.response.UID).subscribe(
            (data: any) => {
              console.log("user rep data", data);
              if (data && data.items.length > 0) {
                const responseData =
                  data.items[data.items.length - 1]["values"];
                let gigyaverified = responseData.filter(
                  (val) => val.name === "GigyaVerified"
                );
                console.log(
                  "gigyaverified value type",
                  typeof gigyaverified[0].value
                );
                console.log("gigyaverified[0].value", gigyaverified[0].value);
                if (gigyaverified[0].value === "0") {
                  this.adobeSoapService
                    .setWelcomeUserProfile(
                      obj.profile,
                      obj.response.UID,
                      "1",
                      weeklyPregnancyEmailCheckboxConsent,
                      privacyPolicyCheckboxConsent,
                      collectionNoticeCheckboxConsent
                    )
                    .subscribe(
                      (data) => {
                        this.showLogin = false;
                        this.stateService.changeUsertype("LoggedIn");
                        this.stateService.setLoggedInUser(obj);
                        this.router.navigate(["/journey"]);
                      },
                      () => {
                        document.getElementById("loading").style.display =
                          "none";
                        alert(this.loginMessagesObj.LOGIN_SAVE_FAIL_MESSAGE);
                      }
                    );
                } else {
                  this.showLogin = false;
                  this.stateService.changeUsertype("LoggedIn");
                  this.stateService.setLoggedInUser(obj);
                  this.router.navigate(["/journey"]);
                }
              } else {
                this.adobeSoapService
                  .setWelcomeUserProfile(
                    obj.profile,
                    obj.response.UID,
                    "1",
                    weeklyPregnancyEmailCheckboxConsent,
                    privacyPolicyCheckboxConsent,
                    collectionNoticeCheckboxConsent
                  )
                  .subscribe(
                    (data) => {
                      this.showLogin = false;
                      this.stateService.changeUsertype("LoggedIn");
                      this.stateService.setLoggedInUser(obj);
                      this.router.navigate(["/journey"]);
                    },
                    () => {
                      document.getElementById("loading").style.display = "none";
                      alert(this.loginMessagesObj.LOGIN_SAVE_FAIL_MESSAGE);
                    }
                  );
              }
            },
            (error) => {}
          );

          // this.adobeSoapService
          //   .setWelcomeUserProfile(
          //     obj.profile,
          //     obj.response.UID,
          //     "1",
          //     weeklyPregnancyEmailCheckboxConsent,
          //     privacyPolicyCheckboxConsent,
          //     collectionNoticeCheckboxConsent
          //   )
          //   .subscribe(
          //     (resp) => {
          //       console.log("welcome user", resp);
          //     },
          //     (error) => {}
          //   );
        } else if (
          obj.screen == this.registerScreenID &&
          obj.response.statusMessage == "Account Pending Verification" &&
          obj.response.errorMessage == "Account Pending Verification"
        ) {
          this.showLogin = false;
          if (
            obj.profile.firstName &&
            obj.profile.email &&
            obj.response.UID &&
            obj.response.preferences &&
            obj.response.preferences.terms &&
            Object.keys(obj.response.preferences) &&
            Object.keys(obj.response.preferences).length >= 1
          ) {
            let weeklyPregnancyEmailCheckboxConsent: boolean,
              privacyPolicyCheckboxConsent: boolean,
              collectionNoticeCheckboxConsent: boolean;
            Object.keys(obj.response.preferences).forEach((value) => {
              if (value.indexOf("ElevitEmailNotif") !== -1) {
                weeklyPregnancyEmailCheckboxConsent = obj.response.preferences[
                  value
                ].isConsentGranted
                  ? true //"1"
                  : false; //"0";
              } else if (value.indexOf("terms") !== -1) {
                Object.keys(obj.response.preferences.terms).forEach((val) => {
                  if (val.indexOf("ElevitPrivPolicy") !== -1) {
                    privacyPolicyCheckboxConsent = obj.response.preferences
                      .terms[val].isConsentGranted
                      ? true //"1"
                      : false; //"0";
                  } else if (val.indexOf("ElevitCollectionNotice") !== -1) {
                    collectionNoticeCheckboxConsent = obj.response.preferences
                      .terms[val].isConsentGranted
                      ? true //"1"
                      : false; //"0";
                  }
                });
              }
            });
            obj.response.preferences.terms[
              Object.keys(obj.response.preferences.terms)[0]
            ].isConsentGranted;
            // const allProfileServices$ = forkJoin(
            //   this.adobeSoapService.setUserProfile(
            //     obj.profile,
            //     obj.response.UID,
            //     "0",
            //     weeklyPregnancyEmailCheckboxConsent,
            //     privacyPolicyCheckboxConsent,
            //     collectionNoticeCheckboxConsent
            //   )
            //   // .subscribe(
            //   //   (resp) => {
            //   //     console.log("welcome user", resp);
            //   //   },
            //   //   (error) => {}
            //   // );

            //   // this.adobeSoapService.setConsentCheckbox(
            //   //   obj.profile,
            //   //   "Weekly Pregnancy Email",
            //   //   weeklyPregnancyEmailCheckboxConsent
            //   // ),
            //   // this.adobeSoapService.setConsentCheckbox(
            //   //   obj.profile,
            //   //   "Privacy Policy",
            //   //   privacyPolicyCheckboxConsent
            //   // ),
            //   // this.adobeSoapService.setConsentCheckbox(
            //   //   obj.profile,
            //   //   "Collection Notice",
            //   //   collectionNoticeCheckboxConsent
            //   // )
            // );
            // allProfileServices$.subscribe(
            //   (data) => {},
            //   () => {
            //     alert(this.loginMessagesObj.REGISTRATION_SAVE_FAIL_MESSAGE);
            //   }
            // );
          } else {
            alert(this.loginMessagesObj.GIGYA_RESPONSE_ERROR);
          }
        }
      });
    }
  }

  /* This method called after gigya screen change/load for setting content heigth equals to Iframe height */
  onAfterScreenLoad() {
    this.stateService.setIframeHeight("iFrameResizer0");
  }

  /* This method called after gigya screen login success to capture First Login field at gigya end */
  firstLoginHandler(eventObj) {
    let application = location.hostname,
      date = new Date(),
      apps = eventObj.data.bc_accessApplications,
      json_obj,
      timestamp = date.toISOString();
    if (!apps) {
      // if application list empty, create new json object
      json_obj = {
        hostname: application,
        firstLogin: timestamp,
        lastLogin: timestamp,
      };
      apps = [JSON.stringify(json_obj)];
    } else {
      let isNewApp = true,
        appIndex;
      // is app new or already in the apps list?
      for (var i = 0; i < apps.length; i++) {
        // search for app in the array
        let host = JSON.parse(apps[i]).hostname;
        if (host == application) {
          isNewApp = false;
          appIndex = i;
          break;
        }
      }
      if (isNewApp) {
        // app is new -> new entry in array
        json_obj = {
          hostname: application,
          firstLogin: timestamp,
          lastLogin: timestamp,
        };
        apps.push(JSON.stringify(json_obj));
      } else {
        // app is already in array, actualize timestamp in lastLogin
        json_obj = JSON.parse(apps[appIndex]);
        json_obj.lastLogin = timestamp;
        apps[appIndex] = JSON.stringify(json_obj);
      }
    }
    // update apps list on server
    gigya.accounts.setAccountInfo({ data: { bc_accessApplications: apps } });
  }

  ngOnInit() {
    this.userType = localStorage.getItem("userType");
    this.isOnceLoadingDone = false;
    if (!this.userType || this.userType === "anonymous") {
      this.countryCode = localStorage.getItem("gigyaLangDefault") || "en";
      const iframeLocationDetails =
        this.stateService.getIframeLocationDetails("iFrameResizer0");
      if (
        iframeLocationDetails &&
        iframeLocationDetails.pathname &&
        iframeLocationDetails.pathname.length > 1 &&
        iframeLocationDetails.hash.replace(
          /(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/,
          "$2"
        ) &&
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") == -1
      ) {
        this.countryCode = iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .toLowerCase();
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") != -1
        ) {
          // (Without assembly integration) language code will be stored in case of checking angular URL directly
          this.countryCode = localStorage.getItem("gigyaLangDecoupled");
        }
      } else if (
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") != -1
      ) {
        // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") == -1
        ) {
          // (With assembly integration) Assembly URL will have language code langugae in case of dual language
          this.countryCode = langParamFromAssembly.toLowerCase();
        } else if (langParamFromAssembly.indexOf("deco") != -1) {
          // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
          this.countryCode = localStorage.getItem("gigyaLangDecoupled");
        } else {
          // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
          this.countryCode = iframeLocationDetails.hash
            .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
            .split("_")[0]
            .toLowerCase();
        }
      }
    } else if (this.userType === "LoggedIn") {
      this.router.navigate(["journey"]);
    }
    this.translateService.get("HOME").subscribe((translated) => {
      if (translated.LOGIN && translated.LOGIN.MAINTAINANCE_MESSAGE) {
        const navigationExtras: NavigationExtras = {
          state: { data: translated.LOGIN.MAINTAINANCE_MESSAGE },
        };
        this.router.navigate(["user-message"], navigationExtras);
      }
      this.loginMessagesObj = translated.LOGIN;
      this.loginScreenID = translated.GIGYA_SCREEN_ID
        ? translated.GIGYA_SCREEN_ID.LOGIN
        : "bayer-login-nosc";
      this.registerScreenID = translated.GIGYA_SCREEN_ID
        ? translated.GIGYA_SCREEN_ID.REGISTER
        : "bayer-register-nosc";
      this.loginScreenSetID = translated.GIGYA_SCREEN_SET_ID
        ? translated.GIGYA_SCREEN_SET_ID.LOGIN
        : "bayer-RegistrationLogin";
      this.countryCode = translated.LANGUAGE_CODE || this.countryCode;
      if (!this.userType || this.userType === "anonymous") {
        this.callGigyaScreen();
      }
    });
  }

  /* This method waits until gigya defined and loads gigya screen */
  callGigyaScreen() {
    setTimeout(() => {
      this.isGigyaScriptLoadedInstance =
        this.stateService.isGigyaScriptLoaded.subscribe(
          (flag: boolean) => {
            if (flag) {
              gigya.accounts.showScreenSet({
                screenSet: this.loginScreenSetID || "bayer-RegistrationLogin",
                startScreen: this.loginScreenID || "bayer-login-nosc",
                lang: this.countryCode,
                containerID: "login-container",
                onAfterSubmit: this.singupValidate.bind(this),
                onAfterScreenLoad: this.onAfterScreenLoad.bind(this),
              });
              gigya.accounts.addEventHandlers({
                onLogin: this.firstLoginHandler.bind(this),
              });
            }
          },
          (error) => console.log("error data", error)
        );
    });
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && !this.isOnceLoadingDone) {
      this.stateService.setIframeHeight("iFrameResizer0");
      this.isOnceLoadingDone = true;
    }
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
    if (this.isGigyaScriptLoadedInstance) {
      this.isGigyaScriptLoadedInstance.unsubscribe();
    }
  }
}
