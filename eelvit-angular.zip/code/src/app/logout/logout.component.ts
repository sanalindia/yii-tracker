import { Component, OnInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { StateService } from '../shared/services/state/state.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

declare let gigya: any;
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit, AfterViewChecked, OnDestroy {

    logoutMsg: string;
    isOnceLoadingDone: boolean;
    logoutMessagesObj: any;
    countryCode: string;
    isGigyaScriptLoadedInstance: any;

    constructor(private localStorage: LocalStorage, private stateService: StateService, private router: Router, private translateService: TranslateService) { }

    ngOnInit() {
        const profile = JSON.parse(localStorage.getItem('profile'));
        this.isOnceLoadingDone = false;
        this.logoutMessagesObj = {};
        if (profile && profile.UID) {
            const uid: string = profile.UID;
            this.countryCode = localStorage.getItem('gigyaLangDefault') || 'en';
            const iframeLocationDetails = this.stateService.getIframeLocationDetails('iFrameResizer0');
            if (iframeLocationDetails && iframeLocationDetails.pathname && iframeLocationDetails.pathname.length > 1 && iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2') && iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').indexOf('_') == -1) {
                this.countryCode = iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').toLowerCase();
                const langParamFromAssembly = window.parent.location.pathname.split('/')[1];
                if (langParamFromAssembly && langParamFromAssembly.indexOf('deco') != -1) { // (Without assembly integration) language code will be stored in case of checking angular URL directly
                this.countryCode = localStorage.getItem('gigyaLangDecoupled');
                }
            } else if(iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').indexOf('_') != -1) { // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
                const langParamFromAssembly = window.parent.location.pathname.split('/')[1];
                if (langParamFromAssembly && langParamFromAssembly.indexOf('deco') == -1) { // (With assembly integration) Assembly URL will have language code langugae in case of dual language
                  this.countryCode = langParamFromAssembly.toLowerCase();
                } else if(langParamFromAssembly.indexOf('deco') != -1) { // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
                  this.countryCode = localStorage.getItem('gigyaLangDecoupled');
                } else { // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
                  this.countryCode = iframeLocationDetails.hash.replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, '$2').split('_')[0].toLowerCase();
                }
            }
        } else {
            localStorage.clear();
        }
        this.translateService.get('HOME').subscribe((translated) => {
            this.logoutMessagesObj = translated.LOGOUT;
            this.countryCode = translated.LANGUAGE_CODE || this.countryCode;
            if (profile && profile.UID) {
                document.getElementById('logoutmsg').innerText = this.logoutMessagesObj.PRE_LOGOUT_MESSAGE;
                const uid: string = profile.UID;
                const params = {
                    UID: uid,
                    lang: this.countryCode,
                    callback: (response) => {
                        if ( response && response.errorCode == 0 ) {
                            localStorage.clear();
                            document.getElementById('logoutmsg').innerText = this.logoutMessagesObj.LOGOUT_MESSAGE;
                        } else {
                            document.getElementById('logoutmsg').innerText = this.logoutMessagesObj.LOGOUT_ERROR_MESSAGE;
                        }
                    }
                };
                this.callGigyaScreen(params);
            } else {
                localStorage.clear();
                document.getElementById('logoutmsg').innerText = this.logoutMessagesObj.POST_LOGOUT_MESSAGE;
            }
        });
    }

    /* This method waits until gigya defined and loads gigya screen */
    callGigyaScreen(params) {
        this.isGigyaScriptLoadedInstance = this.stateService.isGigyaScriptLoaded.subscribe((flag: boolean) => {
            if (flag) {
                gigya.accounts.logout(params);
            }
        });
    }

    /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
    ngAfterViewChecked() {
        if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
        this.stateService.setIframeHeight('iFrameResizer0');
        this.isOnceLoadingDone = true;
        }
    }

    /* Go to login page */
    public goToLogin() {
        this.router.navigate(['/save']);
    }

    /* called when component destroyed */
    ngOnDestroy(): void {
        if (this.isGigyaScriptLoadedInstance) {
            this.isGigyaScriptLoadedInstance.unsubscribe();
        }      
    }
}
