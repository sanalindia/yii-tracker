import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitaminCounterComponent } from './vitamin-counter.component';

describe('VitaminCounterComponent', () => {
  let component: VitaminCounterComponent;
  let fixture: ComponentFixture<VitaminCounterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitaminCounterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitaminCounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
