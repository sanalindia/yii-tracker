import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JourneyPlanningComponent } from './journey-planning/journey-planning.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { CalendarParentComponent } from './calendar-parent/calendar-parent.component';
import { PregnancyPlanningComponent } from './pregnancy-planning/pregnancy-planning.component';
import { SaveJourneyComponent } from './save-your-journey/save-journey.component';
import { LogoutComponent } from './logout/logout.component';
import { CompleteFlowConfirmationComponent } from './complete-flow-confirmation/complete-flow-confirmation.component';
import { GigyaProfileComponent } from './gigya-profile/gigya-profile.component';
import { GigyaResetPasswordComponent } from './gigya-reset-password/gigya-reset-password.component';
import { VitaminCounterComponent } from './vitamin-counter/vitamin-counter.component';
import { UserMessageComponent } from './user-message/user-message.component';
import { WelcomeExperiencePurchaseComponent } from './welcome-experience-purchase/welcome-experience-purchase.component';
import { WelcomeExperienceOrganicComponent } from './welcome-experience-organic/welcome-experience-organic.component';
import { VitaminOnlyCounterComponent } from './vitamin-only-counter/vitamin-only-counter.component';

const routes: Routes = [
  //pregnancy decouple apps routes
  {path: '', redirectTo: '/journey', pathMatch: 'full'},
  {path: 'journey', component: LandingPageComponent},
  {path: 'planning', component: JourneyPlanningComponent},
  {path: 'pregnancy', component: PregnancyPlanningComponent},
  {path: 'calendar', component: CalendarParentComponent},
  {path: 'save', component: SaveJourneyComponent},
  {path: 'complete-journey', component: CompleteFlowConfirmationComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'profile', component: GigyaProfileComponent},
  {path: 'newPassword', component: GigyaResetPasswordComponent},
  // every beginging
  {path: 'everybeginning', component: VitaminCounterComponent},
  {path: 'eebOnlyCounter', component: VitaminOnlyCounterComponent},
  {path: 'welcomeExperiencePurchase', component: WelcomeExperiencePurchaseComponent},
  {path: 'welcomeExperienceOrganic', component: WelcomeExperienceOrganicComponent},
  {path: 'user-message', component: UserMessageComponent},
  {path: '**', component: LandingPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
