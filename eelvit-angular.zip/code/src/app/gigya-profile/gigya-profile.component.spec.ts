import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GigyaProfileComponent } from './gigya-profile.component';

describe('GigyaProfileComponent', () => {
  let component: GigyaProfileComponent;
  let fixture: ComponentFixture<GigyaProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GigyaProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GigyaProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
