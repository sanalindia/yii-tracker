import { Component, OnInit, AfterViewChecked, OnDestroy } from "@angular/core";
import { StateService } from "../shared/services/state/state.service";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { AdobeSoapService } from "../shared/services/adobe-soap/adobe-soap.service";

declare let gigya: any;
@Component({
  selector: "app-gigya-profile",
  templateUrl: "./gigya-profile.component.html",
  styleUrls: ["./gigya-profile.component.scss"],
})
export class GigyaProfileComponent
  implements OnInit, AfterViewChecked, OnDestroy
{
  userType: string;
  isOnceLoadingDone: boolean;
  countryCode: string;
  isGigyaScriptLoadedInstance: any;

  constructor(
    private stateService: StateService,
    private router: Router,
    private translateService: TranslateService,
    private adobeSoapService: AdobeSoapService
  ) {}

  ngOnInit() {
    this.userType = localStorage.getItem("userType");
    this.isOnceLoadingDone = false;
    if (this.userType === "LoggedIn") {
      this.countryCode = localStorage.getItem("gigyaLangDefault") || "en";
      const iframeLocationDetails =
        this.stateService.getIframeLocationDetails("iFrameResizer0");
      if (
        iframeLocationDetails &&
        iframeLocationDetails.pathname &&
        iframeLocationDetails.pathname.length > 1 &&
        iframeLocationDetails.hash.replace(
          /(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/,
          "$2"
        ) &&
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") == -1
      ) {
        this.countryCode = iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .toLowerCase();
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") != -1
        ) {
          // (Without assembly integration) language code will be stored in case of checking angular URL directly
          this.countryCode = localStorage.getItem("gigyaLangDecoupled");
        }
      } else if (
        iframeLocationDetails.hash
          .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
          .indexOf("_") != -1
      ) {
        // (Dual language support) for example lang parameter DE_FR(SWISS) have two langugae one is DE and other is FR
        const langParamFromAssembly =
          window.parent.location.pathname.split("/")[1];
        if (
          langParamFromAssembly &&
          langParamFromAssembly.indexOf("deco") == -1
        ) {
          // (With assembly integration) Assembly URL will have language code langugae in case of dual language
          this.countryCode = langParamFromAssembly.toLowerCase();
        } else if (langParamFromAssembly.indexOf("deco") != -1) {
          // (Without assembly integration) Through prompt, language code will be passed in case of checking angular URL directly
          this.countryCode = localStorage.getItem("gigyaLangDecoupled");
        } else {
          // In case of Dual langugae support, IF assembly URL do not have language parameter then default first lang parsmeter will be selected. For example DE will be default selected in case of DE_FR(SWISS)
          this.countryCode = iframeLocationDetails.hash
            .replace(/(.*lang=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2")
            .split("_")[0]
            .toLowerCase();
        }
      }
    }
    this.translateService.get("HOME").subscribe((translated) => {
      if (this.userType === "LoggedIn") {
        this.countryCode = translated.LANGUAGE_CODE || this.countryCode;
        this.callGigyaScreen(
          translated.GIGYA_SCREEN_ID.PROFILE,
          translated.GIGYA_SCREEN_SET_ID.PROFILE
        );
      }
    });
  }

  /* This method waits until gigya defined and loads gigya screen */
  callGigyaScreen(profileScreenID: string, profileScreenSetID: string) {
    this.isGigyaScriptLoadedInstance =
      this.stateService.isGigyaScriptLoaded.subscribe((flag: boolean) => {
        if (flag) {
          gigya.accounts.showScreenSet({
            screenSet: profileScreenSetID || "bayer-ProfileUpdate",
            startScreen: profileScreenID || "bayer-update-profile-screen",
            containerID: "profile-container",
            lang: this.countryCode,
            onAfterSubmit: this.onAfterSubmit.bind(this),
            onAfterScreenLoad: this.onAfterScreenLoad.bind(this),
          });
        }
      });
  }

  /* This method called after gigya screen change/load for setting content heigth equals to Iframe height */
  onAfterScreenLoad(event) {
    gigya.accounts.getAccountInfo({
      callback: this.getAccountInfoResponse.bind(this),
    });
    this.stateService.setIframeHeight("iFrameResizer0");
  }

  getAccountInfoResponse(event) {
    var profile = {
      ...event,
    };

    let formatSexualInterCourse;
    this.adobeSoapService.getUserNewsLetterData(event.UID).subscribe(
      (data: any) => {
        if (data && data.items.length > 0) {
          const responseData = data.items[data.items.length - 1]["values"];
          let NewsletterFlag = responseData.filter(
            (val) => val.name === "NewsletterFlag"
          );

          if (NewsletterFlag[0].value === "True") {
            formatSexualInterCourse = true;
          } else if (NewsletterFlag[0].value === "False") {
            formatSexualInterCourse = false;
          }
          profile.preferences = {
            o2090441_746966504792_ElevitEmailNotif: {
              isConsentGranted: formatSexualInterCourse,
            },
          };

          gigya.accounts.setAccountInfo(profile);
        }
      },
      (error) => {}
    );
  }

  public onAfterSubmit(obj) {
    console.log("obj", obj);
    if (obj.response && obj.response.status !== "FAIL") {
      let weeklyPregnancyEmailCheckboxConsent: boolean;
      let privacyPolicyCheckboxConsent: boolean;
      let collectionNoticeCheckboxConsent: boolean;
      Object.keys(obj.response.preferences).forEach((value) => {
        if (value.indexOf("ElevitEmailNotif") !== -1) {
          weeklyPregnancyEmailCheckboxConsent = obj.response.preferences[value]
            .isConsentGranted
            ? true //"1"
            : false; //"0";
        } else if (value.indexOf("terms") !== -1) {
          Object.keys(obj.response.preferences.terms).forEach((val) => {
            if (val.indexOf("ElevitPrivPolicy") !== -1) {
              privacyPolicyCheckboxConsent = obj.response.preferences.terms[val]
                .isConsentGranted
                ? true //"1"
                : false; //"0";
            } else if (val.indexOf("ElevitCollectionNotice") !== -1) {
              collectionNoticeCheckboxConsent = obj.response.preferences.terms[
                val
              ].isConsentGranted
                ? true //"1"
                : false; //"0";
            }
          });
        }
      });
      // console.log(
      //   "weeklyPregnancyEmailCheckboxConsent",
      //   weeklyPregnancyEmailCheckboxConsent
      // );
      // console.log("privacyPolicyCheckboxConsent", privacyPolicyCheckboxConsent);
      // console.log(
      //   "collectionNoticeCheckboxConsent",
      //   collectionNoticeCheckboxConsent
      // );
      this.adobeSoapService
        .setUserProfile(
          obj.profile,
          obj.response.UID,
          "1",
          weeklyPregnancyEmailCheckboxConsent,
          privacyPolicyCheckboxConsent,
          collectionNoticeCheckboxConsent
        )
        .subscribe(
          (resp) => {
            console.log("welcome user", resp);
          },
          (error) => {}
        );
    }
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && !this.isOnceLoadingDone) {
      this.stateService.setIframeHeight("iFrameResizer0");
      this.isOnceLoadingDone = true;
    }
  }

  /* Go to login page */
  public goToLogin() {
    this.router.navigate(["/save"]);
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
    if (this.isGigyaScriptLoadedInstance) {
      this.isGigyaScriptLoadedInstance.unsubscribe();
    }
  }
}
