import { Component, OnInit } from "@angular/core";
import * as $ from "jquery";
import { StateService } from "../shared/services/state/state.service";
import { ActivatedRoute } from "@angular/router";
@Component({
  selector: "app-vitamin-only-counter",
  templateUrl: "./vitamin-only-counter.component.html",
  styleUrls: ["./vitamin-only-counter.component.scss"],
})
export class VitaminOnlyCounterComponent implements OnInit {
  internal: {
    name: string;
    $e: any;
    secondsElapsed: number;
    UPDATE_INTERVAL: number;
    START_DATE: number;
    START_VAL: any;
    SEC_INCREASE_VAL: number;
  };

  elements: any;
  isOnceLoadingDone: boolean;
  options: any;

  defaults = {
    from: 0, // the number the element should start at
    to: 100, // the number the element should end at
    speed: 1000, // how long it should take to count between the target numbers
    refreshInterval: 100, // how often the element should be updated
    decimals: 0, // the number of decimal places to show
    onUpdate: null, // callback method for every time the element is updated,
    onComplete: null, // callback method for when the element finishes updating
  };
  increment: any;
  loopCount: number = 0;
  interval: any;
  isOnlyCounter: string;
  textContent: any = {
    thanksToComunity: "Thanks to our community",
    bodyContent:
      "Pregnant women and babies have gained access to essential prenatal vitamins through our partnership with Vitamin Angels.",
    subbodyContent:
      "Our goal is to reach up to four million women and babies each year.",
  };
  constructor(
    private stateService: StateService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      console.log(params.lang.toLowerCase());
      if (params.lang.toLowerCase() === "es-mx") {
        this.textContent = {
          thanksToComunity: "Gracias a nuestra comunidad",
          bodyContent:
            "Mujeres embarazadas y sus bebés han tenido acceso a multivitaminas prenatales esenciales a través de nuestra alianza con Vitamin Angels.",
          subbodyContent:
            "Nuestra meta es llegar a 4 millones de mujeres y sus bebés cada año alrededor del mundo",
        };
      }
      if (params.lang.toLowerCase() === "de") {
        this.textContent = {
          thanksToComunity: "Dank unserer Community haben",
          bodyContent:
            "schwangere Frauen und ihre Babys aus unterversorgten Regionen, über unsere Partnerschaft mit Vitamin Angels, Zugang zu lebenswichtigen pränatalen Vitaminen erhalten.",
          subbodyContent:
            "Unser Ziel ist es, jedes Jahr bis zu 4 Millionen Frauen und ihre Neugeborenen zu unterstützen.",
        };
      }
      if (params.lang.toLowerCase() === "vi") {
        document.getElementsByClassName('headline_counter')[0].classList.add('custom_class_font_remove')
        document.getElementsByClassName('body_counter')[0].classList.add('custom_class_font_remove')
        // document.getElementsByTagName('body')[0].classList.add('custom_class_font_remove')
        this.textContent = {
          thanksToComunity: "Thông qua dự án",
          bodyContent:
            "Phụ nữ mang thai và trẻ em đã được tiếp cận nguồn vitamins và khoáng chất thai kỳ thiết yếu thông qua sự hợp tác với Vitamin Angels.",
          subbodyContent:
            "Mục tiêu của chúng tôi là hỗ trợ 4 triệu phụ nữ và trẻ em mỗi năm trên toàn cầu.",
        };
      }
    });
    this.isOnceLoadingDone = false;
    this.isOnlyCounter = "";
    (function ($) {
      $.fn.countTo = function (options) {
        // merge the default plugin settings with the custom options
        options = $.extend({}, $.fn.countTo.defaults, options || {});
        // how many times to update the value, and how much to increment the value on each update
        let loops = Math.ceil(options.speed / options.refreshInterval),
          increment = (options.to - options.from) / loops;
        return $(this).each(function () {
          let _this = this,
            loopCount = 0,
            value = options.from,
            interval = setInterval(updateTimer, options.refreshInterval);
          function updateTimer() {
            value += increment;
            loopCount++;
            $(_this).html(commaSeparateNumber(value.toFixed(options.decimals)));
            if (typeof options.onUpdate == "function") {
              options.onUpdate.call(_this, value);
            }
            if (loopCount >= loops) {
              clearInterval(interval);
              value = options.to;
              if (typeof options.onComplete == "function") {
                options.onComplete.call(_this, value);
              }
            }
          }
          function commaSeparateNumber(val) {
            while (/(\d+)(\d{3})/.test(val.toString())) {
              val = val.toString().replace(/(\d+)(\d{3})/, "$1" + "," + "$2");
            }
            val =
              (val &&
                val.replace(/,/g, '<span class="comma-separate">,</span>')) ||
              val;
            return val;
          }
        });
      };
      $.fn.countTo.defaults = {
        from: 0, // the number the element should start at
        to: 100, // the number the element should end at
        speed: 1000, // how long it should take to count between the target numbers
        refreshInterval: 100, // how often the element should be updated
        decimals: 0, // the number of decimal places to show
        onUpdate: null, // callback method for every time the element is updated,
        onComplete: null, // callback method for when the element finishes updating
      };
    })($);
    // const ifrm = window.parent.document.getElementById(
    //   "iFrameResizer0"
    // ) as HTMLIFrameElement;
    const ifrm = window.parent.document.querySelector(
      'iframe[src*="deco/new-elevit-journey-elements"]'
    ) as HTMLIFrameElement;
    const doc = ifrm && ifrm.contentWindow;
    if (!ifrm && !doc) {
      this.VitaminCounter({
        startCount: 6560000,
        startDate: Date.parse("August 12, 2015"),
        dailyGrowth: 63302,
      });
    }
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && !this.isOnceLoadingDone) {
      this.stateService.setIframeHeight("iFrameResizer0");
      this.isOnceLoadingDone = true;
      setTimeout(() => {
        this.stateService.setIframeHeight("iFrameResizer0");
        setTimeout(() => {
          // const ifrm = window.parent.document.getElementById(
          //   "iFrameResizer0"
          // ) as HTMLIFrameElement;
          const ifrm = window.parent.document.querySelector(
            'iframe[src*="deco/new-elevit-journey-elements"]'
          ) as HTMLIFrameElement;
          const doc = ifrm && ifrm.contentWindow;
          if (
            doc &&
            doc.location &&
            doc.location.hash &&
            doc.location.hash.match(/startCount=([^&#]*)/) &&
            doc.location.hash.match(/startDate=([^&#]*)/) &&
            doc.location.hash.match(/dailyGrowth=([^&#]*)/)
          ) {
            if (
              doc.location.hash.match(/isOnlyCounter=([^#]*)/) &&
              doc.location.hash.match(/isOnlyCounter=([^#]*)/)[0]
            ) {
              this.isOnlyCounter = doc.location.hash
                .match(/isOnlyCounter=([^#]*)/)[0]
                .replace(/(.*isOnlyCounter=)([0-9a-zA-Z-]{2,})(&.*)?/, "$2");
              // this.isOnlyCounter values could be either 'partner' or 'home' to identify two different pages in drupal so we can apply different styles(differnt width); value to be passed from drupal url through iframe
              this.stateService.setIframeHeight(
                "iFrameResizer0",
                "vitamin-counter-container-block"
              );
            }
            this.VitaminCounter({
              startCount: +doc.location.hash.match(/startCount=([^&#]*)/)[1],
              startDate: Date.parse(
                doc.location.hash
                  .match(/startDate=([^&#]*)/)[1]
                  .replace(/-/g, "/")
              ),
              dailyGrowth: +doc.location.hash.match(/dailyGrowth=([^&#]*)/)[1],
            });
          } else {
            // alert(
            //   "Start count, start date and daily growth values have not been recorded."
            // );
          }
        }, 100);
      }, 1000);
    }
  }

  VitaminCounter(option) {
    // merge the default plugin settings with the custom options
    this.options = $.extend({}, this.defaults, option || {});
    this.internal = {
      name: "VitaminCounterNumber",
      $e: $("#vitamin-counter"),
      secondsElapsed: 0,
      UPDATE_INTERVAL: 8000,
      START_DATE: this.options.startDate,
      START_VAL: this.options.startCount,
      SEC_INCREASE_VAL: this.options.dailyGrowth / 24 / 60 / 60,
    };

    this.elements = {
      display: this.internal.$e.find("#display"),
    };

    const now = new Date().getTime() - this.internal.START_DATE;
    this.internal.secondsElapsed = parseInt(String(now / 1000));

    setTimeout(() => {
      this.updateDisplay();
      $(this.internal.$e).countTo({
        from: 12000,
        to: this.elements.display.val(),
        speed: 1500,
        refreshInterval: 50,
        onComplete: () => {
          setInterval(
            () => this.updateCounter(),
            this.internal.UPDATE_INTERVAL
          );
        },
      });
    }, 400);
  }

  updateDisplay() {
    this.internal.secondsElapsed++;
    let displayVal =
      parseInt(
        this.internal.START_VAL +
          this.internal.secondsElapsed * this.internal.SEC_INCREASE_VAL
      ) + "";
    let displayValTxt = this.digits(displayVal);
    $(this.internal.$e).html(displayValTxt);
    this.elements.display.val(displayVal).change();
  }

  updateCounter() {
    let displayVal = this.elements.display.val();
    displayVal = parseInt(displayVal) + 1;
    let displayValTxt = this.digits(displayVal);
    $(this.internal.$e).html(displayValTxt);
    this.elements.display.val(displayVal).change();
  }

  digits(val) {
    while (/(\d+)(\d{3})/.test(val.toString())) {
      val = val.toString().replace(/(\d+)(\d{3})/, "$1" + "," + "$2");
    }
    val =
      (val && val.replace(/,/g, '<span class="comma-separate">,</span>')) ||
      val;
    return val;
  }
}
