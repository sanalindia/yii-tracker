import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VitaminOnlyCounterComponent } from './vitamin-only-counter.component';

describe('VitaminOnlyCounterComponent', () => {
  let component: VitaminOnlyCounterComponent;
  let fixture: ComponentFixture<VitaminOnlyCounterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VitaminOnlyCounterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VitaminOnlyCounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
