import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WelcomeExperiencePurchaseComponent } from './welcome-experience-purchase.component';

describe('WelcomeExperiencePurchaseComponent', () => {
  let component: WelcomeExperiencePurchaseComponent;
  let fixture: ComponentFixture<WelcomeExperiencePurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WelcomeExperiencePurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeExperiencePurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
