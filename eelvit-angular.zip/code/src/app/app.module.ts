import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { NgbModule, NgbDatepickerI18n, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { JourneyPlanningComponent } from './journey-planning/journey-planning.component';
import { PregnancyPlanningComponent } from './pregnancy-planning/pregnancy-planning.component';
import { PregnancyCalendarComponent, CalendarPopupModelContentComponent } from './shared/components/pregnancy-calendar/pregnancy-calendar.component';
import { PregnancyAccordianListComponent } from './shared/components/pregnancy-accordian-list/pregnancy-accordian-list.component';
import { NgbcDatepickerI18nService } from './shared/services/ngbc-datepicker-i18n/ngbc-datepicker-i18n.service';
import { StateService } from './shared/services/state/state.service';
import { AdobeSoapService } from './shared/services/adobe-soap/adobe-soap.service';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { JourneyStageComponent } from './shared/components/journey-stage/journey-stage.component';
import { TypicalOvulationCycleComponent } from './shared/components/typical-ovulation-cycle/typical-ovulation-cycle.component';
import { CalendarParentComponent } from './calendar-parent/calendar-parent.component';
import { SaveJourneyComponent } from './save-your-journey/save-journey.component';
import { DatePickerComponent } from './shared/components/elements/date-picker/date-picker.component';
import { SanitizeHtmlPipe } from './shared/pipe/sanitize-html.pipe';
import { StorageProvider } from './shared/services/storageProvider';
import { StoreModule } from '@ngrx/store';
import { PregnancyPlanningReducer } from './shared/store/pregnancy-planning.reducer';
import { LocalStorageModule } from '@ngx-pwa/local-storage';
import { APP_BASE_HREF } from '@angular/common';
import { GoogleAnalyticsService } from './google-analytics.service';
import { LogoutComponent } from './logout/logout.component';
import { CompleteFlowConfirmationComponent } from './complete-flow-confirmation/complete-flow-confirmation.component';
import { GigyaProfileComponent } from './gigya-profile/gigya-profile.component';
import { GigyaResetPasswordComponent } from './gigya-reset-password/gigya-reset-password.component';
import { VitaminCounterComponent } from './vitamin-counter/vitamin-counter.component';
import { UserMessageComponent } from './user-message/user-message.component';
import { WelcomeExperiencePurchaseComponent } from './welcome-experience-purchase/welcome-experience-purchase.component';
import { WelcomeExperienceOrganicComponent } from './welcome-experience-organic/welcome-experience-organic.component';
import { VitaminOnlyCounterComponent } from './vitamin-only-counter/vitamin-only-counter.component';


// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

export function storageProviderFactory(provider: StorageProvider) {
  return () => provider.load();
}

@NgModule({
  declarations: [
    AppComponent,
    JourneyPlanningComponent,
    PregnancyPlanningComponent,
    PregnancyCalendarComponent,
    CalendarPopupModelContentComponent,
    PregnancyAccordianListComponent,
    LandingPageComponent,
    JourneyStageComponent,
    TypicalOvulationCycleComponent,
    CalendarParentComponent,
    SaveJourneyComponent,
    DatePickerComponent,
    SanitizeHtmlPipe,
    LogoutComponent,
    CompleteFlowConfirmationComponent,
    GigyaProfileComponent,
    GigyaResetPasswordComponent,
    VitaminCounterComponent,
    UserMessageComponent,
    WelcomeExperiencePurchaseComponent,
    WelcomeExperienceOrganicComponent,
    VitaminOnlyCounterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    NgbModule,
    AngularFontAwesomeModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    StoreModule.forRoot({ PregnancyPlanningReducer }),
    LocalStorageModule
  ],
  providers: [
    { provide: NgbDatepickerI18n, useClass: NgbcDatepickerI18nService },
    StateService,
    StorageProvider, GoogleAnalyticsService,
    { provide: APP_INITIALIZER, useFactory: storageProviderFactory, deps: [StorageProvider], multi: true }
  ],
  bootstrap: [AppComponent],
  entryComponents: [CalendarPopupModelContentComponent]
})
export class AppModule { }
