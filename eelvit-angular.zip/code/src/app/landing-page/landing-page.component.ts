import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { StateService } from '../shared/services/state/state.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit, AfterViewChecked {

  isOnceLoadingDone: boolean;

  constructor(private stateService: StateService) { }

  ngOnInit() {
    this.isOnceLoadingDone = false;
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
      this.stateService.setIframeHeight('iFrameResizer0');
      this.isOnceLoadingDone = true;
     }
  }

}
