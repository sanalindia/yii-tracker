import { Component, OnInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { StateService } from '../shared/services/state/state.service';
import { Router } from '@angular/router';

declare let gigya: any;
@Component({
  selector: 'app-user-message',
  templateUrl: './user-message.component.html',
  styleUrls: ['./user-message.component.scss']
})
export class UserMessageComponent implements OnInit, AfterViewChecked, OnDestroy {

  userMessage: string;
  isOnceLoadingDone: boolean;

  constructor(private stateService: StateService, private router: Router) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation.extras.state as {data: string};
    this.userMessage = state ? state.data : 'Page could not be loaded. Please try again later.';
  }

  ngOnInit() {
    this.isOnceLoadingDone = false;
  }

  /* This method is used to render functianality iframe height equals to Decoupled component page after Elevit Assembly screen loaded */
  ngAfterViewChecked() {
    if (window.location !== window.parent.location && (!this.isOnceLoadingDone)) {
        this.stateService.setIframeHeight('iFrameResizer0');
        this.isOnceLoadingDone = true;
    }
  }

  /* called when component destroyed */
  ngOnDestroy(): void {
  }

}
