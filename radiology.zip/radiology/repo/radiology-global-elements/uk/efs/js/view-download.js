{
    // ----

    window.webapp = window.webapp || {};
    window.webapp.efs_events = window.webapp.efs_events || {};
    window.webapp.efs_events.server = 'https://rtm-apis-live.baywsf.com/rad/uk';

    var efsInterface = function () {
        var t = this;
        this.apiServerUrl = window.webapp.efs_events.server;
        this.userParameterNames = 'vaid';
        this.prodDomain = "radiology.bayer.co.uk";

        // ----

        this.setValue = function (name, value) {
            window.sessionStorage.setItem(name, value);
        };

        this.getValue = function (name) {
            return window.sessionStorage.getItem(name);
        };


        // ----

        this.getCookie = function (cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }

        // ----

        this.getMarketCode = function () {
            return 'GB';
        };


        // ----
        // -- Identify 'vaid' parameter

        var url = new URLSearchParams(location.search);
        var urlParams = this.userParameterNames.split(",");

        for (var i in urlParams) {
            var urlParam = urlParams[i];
            // ----

            if (url.has(urlParam)) {
                t.setValue(
                    'efs_vaid',
                    url.get(urlParam));
            }
        }

        if (url.has('campaign')) {
            t.setValue(
                'efs_campaign',
                url.get('campaign'));
        }

        // ----

        var userId = t.getValue('efs_vaid');
        var campaignCode = t.getValue('efs_campaign');
        var marketCode = t.getMarketCode();
        var brandCode = "WS";

        // -- No use ID specified
        if (!userId) {
            return false;
        }

        // -- User has not selected country or market yet
        if (!marketCode || !campaignCode) {
            console.debug("EMS not loading, market or campaign code not specified.")
            return false;
        }


        // ----
        // -- Event functions

        this.trackEvent = function (eventType, eventAction, detail, brandCodeOverride) {
            if (!userId)
                return;

            var brandCodeUsed = brandCode;
            if (brandCodeOverride !== undefined)
                brandCodeUsed = brandCodeOverride;

            var data = {
                "vid": userId,
                "country": marketCode,
                "detail": detail,
                "event_action": eventAction,
                "event_type": eventType,
                "brand_label": brandCodeUsed,
                "campaign": campaignCode,
                "test": location.hostname.indexOf(t.prodDomain) == -1
            };

            jQuery.ajax({
                type: "POST",
                url: t.apiServerUrl + "/apiHandler.php",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                cache: false,
                data: data,
                dataType: "json"
            });
        };


        // ----
        // -- Event definitions
        // ----


        // -- Global events

        t.trackEvent("pageview", "load", location.pathname);

        // ----

        switch (location.pathname) {
            case "/iaws":
            case "/products/iaws":
                // ----

                setTimeout(function () {
                    t.trackEvent("pageview", "open 10s", location.pathname);
                }, 10000);

                jQuery('a[href^="/iaws/radiographer"], a[href^="/products/iaws/radiographer"]').on('click', function () {
                    t.trackEvent('click', 'cta', '/products/iaws/radiographer');
                    return true;
                });

                jQuery('a[href^="/iaws/radiologist"], a[href^="/products/iaws/radiologist"]').on('click', function () {
                    t.trackEvent('click', 'cta', '/products/iaws/radiologist');
                    return true;
                });

                jQuery('a[href^="/iaws/manager"], a[href^="/products/iaws/manager"]').on('click', function () {
                    t.trackEvent('click', 'cta', '/products/iaws/manager');
                    return true;
                });

                // -- Video playback event
                jQuery('.video-element').each(function (index, element) {

                    var listener = function (e) {
                        var target = e.detail.target;
                        var target$ = jQuery(target.mediaElement);
                        var currentSeconds = target.getCurrentTime();
                        var videoUrl = target$.find('iframe').attr('src');

                        // ----

                        if (currentSeconds > 0 && target$.attr('event-play') != 'true') {
                            target$.attr('event-play', 'true');
                            t.trackEvent("video", "start", videoUrl);
                        }

                        if (currentSeconds >= 30 && target$.attr('event-30') != 'true') {
                            target$.attr('event-30', 'true');
                            t.trackEvent("video", "30 seconds", videoUrl);
                        }

                        if (currentSeconds >= 45 && target$.attr('event-45') != 'true') {
                            target$.attr('event-45', 'true');
                            t.trackEvent("video", "45 seconds", videoUrl);
                        }

                        if (currentSeconds >= 60 && target$.attr('event-60') != 'true') {
                            target$.attr('event-60', 'true');
                            t.trackEvent("video", "60 seconds", videoUrl);
                        }
                    };

                    var setupVideoTracker = function (el) {
                        var el$ = jQuery(el);
                        var player = el$.find('mediaelementwrapper');

                        if (player.length == 0) {
                            return false;
                        }

                        player[0].addEventListener('timeupdate', listener);
                        return true;
                    };

                    var check = function () {
                        if (!setupVideoTracker(element)) {
                            window.setTimeout(
                                check,
                                200);
                        }
                    };

                    check();
                });

                // ----
                break; // -- /products/iaws

            case "/products/iaws/manager":
                // ----

                setTimeout(function () {
                    t.trackEvent("pageview", "open 5s", location.pathname);
                }, 5000);

                // ----
                break; // -- /products/iaws/manager

            case "/products/iaws/radiologist":
                // ----

                setTimeout(function () {
                    t.trackEvent("pageview", "open 5s", location.pathname);
                }, 5000);

                // ----
                break; // -- /products/iaws/radiologist

            case "/products/iaws/radiographer":
                // ----

                setTimeout(function () {
                    t.trackEvent("pageview", "open 5s", location.pathname);
                }, 5000);

                // ----
                break; // -- /products/iaws/radiographer
        }

        // ----
    };

    jQuery(document).ready(function () {
        var efsInstance = new efsInterface();
    });
}
