/* Drupal Behaviour */
(function ($, Drupal) {
    jQuery("div.coh-style-top-header-row-alternative div#block-cohesion-pharma-brand-mainnavigationtabsmenu ul.coh-menu-list-container li.level-1-item").bind('click mouseover', function () {
        jQuery("div.coh-style-top-header-row div#block-topnavigationmenu ul.coh-menu-list-container li.coh-menu-list-item").each(function(){
            if(jQuery(this).hasClass("is-expanded")){
                //console.log("yes am trigger when main nav clicked or hover");
                jQuery(this).removeClass("is-expanded").addClass("is-collapsed");
                jQuery(this).children('a.js-coh-menu-item-link').attr("aria-expanded","false");
                jQuery(this).children('ul.sub-menu').css("display","none");
            }
        });
    });

    jQuery("div.coh-style-top-header-row div#block-topnavigationmenu ul.coh-menu-list-container li.coh-menu-list-item").bind('click', function () {
        jQuery("div.coh-style-top-header-row div#block-topnavigationmenu ul.coh-menu-list-container li.coh-menu-list-item").each(function(){
            jQuery(this).children('a.js-coh-menu-item-link').attr("aria-expanded","false");
            jQuery(this).children('ul.sub-menu').css("display","none");
            if(jQuery(this).hasClass("is-expanded")){
                jQuery(this).removeClass("is-expanded").addClass("is-collapsed");                
            }
        });
        jQuery(this).addClass("is-expanded");
        jQuery(this).children('a.js-coh-menu-item-link').attr("aria-expanded","true");
        jQuery(this).children('ul.sub-menu').css("display","block");
        jQuery("div.coh-style-top-header-row-alternative div#block-cohesion-pharma-brand-mainnavigationtabsmenu ul.coh-menu-list-container li.level-1-item").each(function(){
            if(jQuery(this).hasClass("is-expanded")){
                //console.log("yes am trigger when top menu clicked");
                jQuery(this).removeClass("is-expanded").addClass("is-collapsed");
                jQuery(this).children('div.sub-menus-container').css("height","0px");
                jQuery(this).children('a.toggle-section-link').attr("aria-expanded","false");
            }
        });
    });
  }(jQuery, Drupal));