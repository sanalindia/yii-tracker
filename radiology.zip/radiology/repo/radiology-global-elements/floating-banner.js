console.log("This is first am added for testing...");
var cssStyles = "<style>.banner_media-custom-position{position:fixed;width:400px;height:144px;background-color:#fff;z-index:20;box-shadow:0 3px 10px rgb(0 0 0 / 20%);padding:10px 30px 10px 10px}.banner-over{outline:5px solid #6f757c}.banner_media-close{position:absolute;top:-10px;right:-10px;background-color:black;color:white;font-size:25px;border-radius:50%;width:30px}.fullimageonly{padding:2px!important}.fullimageonly img{display:block;width:100%;margin:0!important}.halfimageonly img{width:100px}.banner_media-animate-right-to-left-1{bottom:80px;left:calc(100vw - 440px);animation-duration:3s;animation-name:slideinbannermediarighttoleft}.banner_media-animate-right-to-left-2{bottom:250px;left:calc(100vw - 440px);animation-duration:3s;animation-name:slideinbannermediarighttoleft}.banner_media-animate-right-to-left-3{bottom:420px;left:calc(100vw - 440px);animation-duration:3s;animation-name:slideinbannermediarighttoleft}.banner_media-animate-right-to-left-4{bottom:590px;left:calc(100vw - 440px);animation-duration:3s;animation-name:slideinbannermediarighttoleft}.banner_media-animate-right-to-left-5{bottom:760px;left:calc(100vw - 440px);animation-duration:3s;animation-name:slideinbannermediarighttoleft}@keyframes slideinbannermediarighttoleft{from{left:calc(100vw + 440px)}to{left:calc(100vw - 440px)}}@keyframes slideinbannermediarighttoleftmobile{from{left:calc(100vw + 440px)}to{left:calc(100vw - 320px)}}.banner_media-animate-bottom-to-top-1{left:calc(100vw - 440px);top:calc(100vh - 225px);animation-duration:3s;animation-name:slideinbannermediabottomtotop}@keyframes slideinbannermediabottomtotop{from{top:calc(100vh + 300px)}to{top:calc(100vh - 220px)}}.banner_media-animate-bottom-to-top-2{left:calc(100vw - 440px);top:calc(100vh - 390px);animation-duration:3s;animation-name:slideinbannermediabottomtotoptwo}@keyframes slideinbannermediabottomtotoptwo{from{top:calc(100vh + 300px)}to{top:calc(100vh - 390px)}}.banner_media-animate-bottom-to-top-3{left:calc(100vw - 440px);top:calc(100vh - 560px);animation-duration:3s;animation-name:slideinbannermediabottomtotopthree}@keyframes slideinbannermediabottomtotopthree{from{top:calc(100vh + 300px)}to{top:calc(100vh - 560px)}}.banner_media-animate-bottom-to-top-4{left:calc(100vw - 440px);top:calc(100vh - 730px);animation-duration:3s;animation-name:slideinbannermediabottomtotopfour}@keyframes slideinbannermediabottomtotopfour{from{top:calc(100vh + 300px)}to{top:calc(100vh - 730px)}}.banner_media-animate-bottom-to-top-5{left:calc(100vw - 440px);top:calc(100vh - 900px);animation-duration:3s;animation-name:slideinbannermediabottomtotopfive}@keyframes slideinbannermediabottomtotopfive{from{top:calc(100vh + 300px)}to{top:calc(100vh - 900px)}}@media(max-width:576px){.banner_media-custom-position{width:300px}.banner_media-animate-right-to-left-1,.banner_media-animate-right-to-left-2,.banner_media-animate-right-to-left-3,.banner_media-animate-right-to-left-4,.banner_media-animate-right-to-left-5{left:calc(100vw - 320px);animation-name:slideinbannermediarighttoleftmobile}.banner_media-animate-bottom-to-top-1,.banner_media-animate-bottom-to-top-2,.banner_media-animate-bottom-to-top-3,.banner_media-animate-bottom-to-top-4,.banner_media-animate-bottom-to-top-5{left:calc(100vw - 320px)}}</style>";
function getQueryParams(qs) {
  qs = qs.split('+').join(' ');
  var params = {},
      tokens,
      re = /[?&]?([^=]+)=([^&]*)/g;
  while (tokens = re.exec(qs)) {
      params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
  }
  return params;
}

function seconds_with_leading_zeros(dt) 
{ 
  return (today.getHours() < 10 ? '0' : '') + today.getHours();
}

// function activationParameters(paramValues){
//   var paramValues
//   for (let i = 0; i < paramValues.length; i++) {
//     paramValues[i]['uri'];
//   }
// }

setTimeout(
  function() 
  {
    console.log("yes am triggerrrrr.....");
    //do something special
    jQuery(".coh-modal-overlay-open").append(cssStyles); 
    jQuery(".toolbar-tray-open").append(cssStyles); 
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var hoursCurrent = ((((today.getHours() + 24) % 12 || 12) < 10 ? '0' : '') + ((today.getHours() + 24) % 12 || 12));
    var time =  hoursCurrent+ ":" + ((today.getMinutes() < 10 ? '0' : '') + today.getMinutes()) + ":" + ((today.getSeconds() < 10 ? '0' : '') + today.getSeconds());
    var dateTime = date+'T'+time+'+00:00';
    //console.log(hoursCurrent, " hoursCurrent ", ((parseInt(hoursCurrent) + 24) % 12 || 12));
    //var mytime = today.format("YYYY-MM-DD HH:mm:");

    var domainPathName = '';
    var activationValues = '';
    var cstorevalue = {};
    var cookieBannerStoredValues = '';
    //var currentPathName = '';
    var reqPathName = '';
    //currentPathName = document.location.pathname+document.location.search;
    //domainPathName = document.location.pathname.replace("/ja/", "internal:/");
    domainPathName = "internal:"+document.location.pathname;
    activationValues = document.location.search;
    reqcurrentPathName = domainPathName+activationValues;
    //console.log(domainPathName," domainPathName");
    //var reqcurrentPathName = sfsdf;
    //var query = getQueryParams(document.location.search);    
    var retValues = '';
    var recipesValues = '';
    var bannerCount = 0;
    //getCompareComponent()
    //console.log("This is first am added for query...",domainPathName);
    //console.log("This is first am added for reqcurrentPathName...",reqcurrentPathName);

    //function getCompareComponent(nid) {
      //let jsonStorageData = sessionStorage.getItem('jsonData');
      //if (jsonStorageData === null) {
          var settings = {
            "url": "/jsonapi/node/floating_banner?include=field_fb_upload_image&fields[file--file]=uri,url",
            "method": "GET",
            "timeout": 0,
            "async": false,
          };
          jQuery.ajax(settings).done(function (response) {
              //console.log(response, "response");
              retValues = response;
              //var storageBanners = JSON.stringify(retValues);
              //sessionStorage.setItem('jsonData', storageBanners);
              return retValues;
          });
      //}
    //jsonStorageDataArray = sessionStorage.getItem('jsonData');
    //retValues = JSON.parse(jsonStorageDataArray);
    //console.log("All values: ", retValues);

    function getInstantiate(){
      //console.log("yes am in getInstantiate method...");
      if (jQuery.cookie('fbannerValue')) {
        //console.log("yes am in getInstantiate method1...");
        var savedBannerArray = '';
        var cookieids = jQuery.cookie('fbannerValue');
        savedBannerArray = JSON.parse(cookieids || '[]'); 
        jQuery.each(savedBannerArray, function (index, row) {
          if(row.content){    
            //jQuery(".toolbar-tray-open a.banner_media-custom-position").attr("data-fid", row.fbanner_id).remove();            
            //jQuery(".toolbar-vertical a.banner_media-custom-position").attr("data-fid", row.fbanner_id).remove();            
            //jQuery(".toolbar-vertical").find("[data-fid='"+row.fbanner_id+"']").remove();            
            jQuery(".coh-modal-overlay-open").append(row.content); 
            jQuery(".toolbar-tray-open").append(row.content); 
            jQuery(".toolbar-vertical").append(row.content);             
          }
        });
        // if((savedBannerArray[0].domain) && (savedBannerArray[0].param)){
        //   domainPathName = savedBannerArray[0].domain;
        //   activationValues = savedBannerArray[0].param;
        //   reqcurrentPathName = domainPathName+activationValues;
        // }
        
      }
    }

    function removeParticularCookieWhenClose(fbid){
      //console.log(fbid);
      var cookieids = jQuery.cookie('fbannerValue');
      savedBannerArray = JSON.parse(cookieids || '[]');
      for (var i = 0; i < savedBannerArray.length; i++) 
      {
        if ((savedBannerArray[i].fbanner_id == fbid)) {
          //console.log("yes am in removeParticularCookieWhenClose", fbid);
          savedBannerArray.splice(i, 1);  
        }
      }
      // jQuery.each(savedBannerArray, function (index, row) {
      //   if ((row.fbanner_id == fbid)) {
      //     console.log("yes am in removeParticularCookieWhenClose", fbid);
      //     savedBannerArray.splice(index, 1);           
      //   }
      // });
      var jsonBanners = JSON.stringify(savedBannerArray);
      //console.log("yes am in removeParticularCookieWhenClose: ", jsonBanners);
      jQuery.cookie("fbannerValue", jsonBanners, { path: '/', expires: 1 });

    }
    function getImagePath(imagefieldId, includeArrayValues, fContent){
      for (let index = 0; index < includeArrayValues.length; index++) {
        if(imagefieldId == includeArrayValues[index]['id']){
          //console.log(imagefieldId," image path and id ", includeArrayValues[index]['attributes']['uri']['url']);
            return "<img src='"+includeArrayValues[index]['attributes']['uri']['url']+"' height='140' class='mr-3' alt='"+fContent+"'>";
        }        
      }
      return '';
    }

    function getStoredValues(fbannerUrl){
      if (jQuery.cookie('fbannerValue')) {
          var savedBannersValues = checkCookieValues(fbannerUrl);
          //console.log("yes am in getStoredValues if: ", savedBannersValues);
          var jsonBanners = JSON.stringify(savedBannersValues);
          //var jsonRecipe = '';
          //jQuery.cookie("fbannerValue", jsonBanners, { expires: 1 }, { path: '/' });
          jQuery.cookie("fbannerValue", jsonBanners, { path: '/', expires: 1 });
      } else {
          bannerArray = [];
          bannerArray.push(fbannerUrl);
          //finalValue = recipeArray;
          jsonBanners = JSON.stringify(bannerArray);
          //console.log("Am in else: ", jsonBanners);
          //jQuery.cookie("fbannerValue", jsonBanners, { expires: 1 }, { path: '/' });
          jQuery.cookie("fbannerValue", jsonBanners, { path: '/', expires: 1 });
      }
    }

    function checkCookieValues(fid) {
      var savedBannerArray = '';
      var setFlag = true; var setBannerRemove = false;
      var cookieids = jQuery.cookie('fbannerValue');
      savedBannerArray = JSON.parse(cookieids || '[]');
      //console.log("Am in checkCookieValues: ", savedBannerArray);
      for(var r=0; r < savedBannerArray.length; r++){
        //console.log(savedBannerArray[r], "yes am in loop.. ");
        //console.log(savedBannerArray[r].fbanner_id, "yes am in loop.. ");
        if ((savedBannerArray[r].fbanner_id == fid.fbanner_id) && (savedBannerArray[r].domain == fid.domain) && (savedBannerArray[r].param == fid.param)) {
          //console.log("yes both condition true and am in");
          //savedBannerArray.splice(index, 1); 
          setFlag = false;
        }
        if ((savedBannerArray[r].domain != fid.domain) || (savedBannerArray[r].param != fid.param)) {
          //savedBannerArray.splice(index, 1); 
          setBannerRemove = true;
        }
      }
    if(setBannerRemove){
      //console.log("yes am setBannerRemove trigger..");
      savedBannerArray.length = 0;
    }
    if(setFlag){
      //console.log("yes am setFlag trigger..",fid);
        savedBannerArray.push(fid);
    }
      return savedBannerArray;
  }

//   function firstreadCookieValues() {
//     var savedBannerArray = '';
//     var cookieids = jQuery.cookie('fbannerValue');
//     savedBannerArray = JSON.parse(cookieids);    
//     //savedBannerArray.push(fid);
//     return savedBannerArray;
// }
    
    var floatingBannerArray = [];
    var k = 1;
    function getAllFloatingBanners(retValues){      
      var fromCookie = true;
      console.log("getAllFloatingBanners am in 1", retValues);
      for (let i = 0; i < retValues.data.length; i++) {   
        if(i==4)
        return '';
        // Get validity Period Values
        var startDate = new Date(retValues.data[i]['attributes']['field_fb_validity_period']['value']);
        var endDate = new Date(retValues.data[i]['attributes']['field_fb_validity_period']['end_value']);
        let today = new Date();
        //console.log(today, "getAllFloatingBanners am in 1", startDate, " : ", endDate);
        if((today > startDate) && (today < endDate)){          
          //console.log(i, " getAllFloatingBanners am in 2", retValues.data[i]);
          for (let j = 0; j < retValues.data[i]['attributes']['field_fb_activation_parameter'].length; j++) {
            var giveActivationValue = retValues.data[i]['attributes']['field_fb_activation_parameter'][j]['uri'];
            var foundStringValue = giveActivationValue.split('*');
            var indexSpecialString = giveActivationValue.indexOf("*"); 
            //console.log(" getAllFloatingBanners am in 3 ", foundStringValue);
            //console.log(giveActivationValue, " --fljsdkfs---- ", foundStringValue.length);
            //console.log(domainPathName, " --domainPathName---- ", activationValues, " --activationValues-- ",foundStringValue[0]," --foundStringValue[0]--", foundStringValue[1]," --foundStringValue[1]" );
            if((foundStringValue.length > 1) && (indexSpecialString !== -1)){ 
              if((domainPathName.indexOf(foundStringValue[0]) != -1) && ((activationValues.indexOf(foundStringValue[1]) != -1) && (foundStringValue[1] != '')  && (domainPathName != 'internal:/'))){
                //console.log("Am in if domainPathName one");
                //if((today > startDate) && (today < endDate)){
                  var reqOutput = '';  
                   cstorevalue['domain']  = domainPathName;
                   cstorevalue['param']  = activationValues;
                   cstorevalue['fbanner_id']  = retValues.data[i]['id'];              
                    
                    //var classAnimation = 'banner_media-animate-top-to-bottom';
                    var classAnimation = 'banner_media-animate-bottom-to-top-'+k;
                    if(retValues.data[i]['attributes']['field_fb_animation_slide_in_dire'] == 'left-to-right'){
                        //classAnimation = 'banner_media-animate-left-to-right';
                        classAnimation = 'banner_media-animate-right-to-left-'+k;
                    }              
                    var fullImage = 'fullimageonly';
                    var fContent = '';
                    if(retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt']){
                      fContent = retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt'];
                    }                    
                    var fUrl = "href='javascript:void(0)'";
                    if(retValues.data[i]['attributes']['field_fb_cta_url'] != null){
                      fUrl = "target='_blank' href='"+retValues.data[i]['attributes']['field_fb_cta_url']['uri']+"'";
                    }
                    var reqImage = '';
                    var imgpathId = retValues.data[i]['relationships']['field_fb_upload_image']['data']['id'];
                    reqImage =  getImagePath(imgpathId,retValues.included,fContent);
                    // if(retValues.included[i]['attributes']['uri']['url']){
                    //   reqImage = "<img src='"+retValues.included[i]['attributes']['uri']['url']+"' height='150' class='mr-3' alt='"+fContent+"'>";
                    // }              
                    var reqOutput = "<a data-fid='"+retValues.data[i]['id']+"' class='banner_media-custom-position "+classAnimation+" "+fullImage+" fbanner_order"+(k)+"' "+fUrl+"><button class='banner_media-close' type='button' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button><div class='media'>"+reqImage+"</div></a>";
                    jQuery(".coh-modal-overlay-open").append(reqOutput); 
                    jQuery(".toolbar-tray-open").append(reqOutput); 
                    jQuery(".toolbar-vertical").append(reqOutput); 
                    cstorevalue['content']  = reqOutput;
                    //getStoredValues(cstorevalue);
                    fromCookie = false;
                    k++;
                    //console.log("This is first am added for reqOutput...",i," ", reqOutput);
                //}
              //}else if((domainPathName.indexOf(foundStringValue[0]) != -1) && ((foundStringValue[1] == '') && (activationValues == ''))){
              }else if((domainPathName.indexOf(foundStringValue[0]) != -1) && ((foundStringValue[1] == '') && (domainPathName != 'internal:/'))){
                //console.log("Am in if domainPathName two");
                var reqOutput = '';  
                   cstorevalue['domain']  = domainPathName;
                   cstorevalue['param']  = activationValues;
                   cstorevalue['fbanner_id']  = retValues.data[i]['id'];              
                    
                    //var classAnimation = 'banner_media-animate-top-to-bottom';
                    var classAnimation = 'banner_media-animate-bottom-to-top-'+k;
                    if(retValues.data[i]['attributes']['field_fb_animation_slide_in_dire'] == 'left-to-right'){
                        //classAnimation = 'banner_media-animate-left-to-right';
                        classAnimation = 'banner_media-animate-right-to-left-'+k;
                    }              
                    var fullImage = 'fullimageonly';
                    var fContent = '';
                    if(retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt']){
                      fContent = retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt'];
                    }
                    var fUrl = "href='javascript:void(0)'";
                    if(retValues.data[i]['attributes']['field_fb_cta_url'] != null){
                      fUrl = "target='_blank' href='"+retValues.data[i]['attributes']['field_fb_cta_url']['uri']+"'";
                    }
                    var reqImage = '';
                    var imgpathId = retValues.data[i]['relationships']['field_fb_upload_image']['data']['id'];
                    reqImage =  getImagePath(imgpathId,retValues.included,fContent);           
                    var reqOutput = "<a data-fid='"+retValues.data[i]['id']+"' class='banner_media-custom-position "+classAnimation+" "+fullImage+" fbanner_order"+(k)+"' "+fUrl+"> <button class='banner_media-close' type='button' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button><div class='media'>"+reqImage+"</div></a>";
                    jQuery(".coh-modal-overlay-open").append(reqOutput); 
                    jQuery(".toolbar-tray-open").append(reqOutput); 
                    jQuery(".toolbar-vertical").append(reqOutput); 
                    cstorevalue['content']  = reqOutput;
                    //getStoredValues(cstorevalue);
                    fromCookie = false;
                    k++;                
              }
            }else{
              //var apiUrlAssigned = retValues.data[i]['attributes']['field_fb_activation_parameter'][j]['uri'];              
              var giveAbsActivationValue = retValues.data[i]['attributes']['field_fb_activation_parameter'][j]['uri'];
              var indexString = giveAbsActivationValue.indexOf("?");    
              if(indexString !== -1){
                  var foundAbsStringValue = giveAbsActivationValue.split('?');                  
                  //console.log(foundAbsStringValue[0], " Substring found! ", foundAbsStringValue[1]);
                  if(((domainPathName === foundAbsStringValue[0]) && (activationValues.indexOf(foundAbsStringValue[1]) != -1))){
                    //console.log("Am in if domainPathName three");
                    //if((today > startDate) && (today < endDate)){
                      var reqOutput = '';      
                      cstorevalue['domain']  = domainPathName;
                      cstorevalue['param']  = activationValues; 
                      cstorevalue['fbanner_id']  = retValues.data[i]['id'];
                      //var classAnimation = 'banner_media-animate-top-to-bottom';
                      var classAnimation = 'banner_media-animate-bottom-to-top-'+k;
                      if(retValues.data[i]['attributes']['field_fb_animation_slide_in_dire'] == 'left-to-right'){
                          //classAnimation = 'banner_media-animate-left-to-right';
                          classAnimation = 'banner_media-animate-right-to-left-'+k;
                      }              
                      var fullImage = 'fullimageonly';
                      var fContent = '';
                      if(retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt']){
                        fContent = retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt'];
                      }
                      var fUrl = "href='javascript:void(0)'";
                      if(retValues.data[i]['attributes']['field_fb_cta_url'] != null){
                        fUrl = "target='_blank' href='"+retValues.data[i]['attributes']['field_fb_cta_url']['uri']+"'";
                      }
                      var reqImage = '';
                      var imgpathId = retValues.data[i]['relationships']['field_fb_upload_image']['data']['id'];
                      reqImage =  getImagePath(imgpathId,retValues.included,fContent);       
                      var reqOutput = "<a data-fid='"+retValues.data[i]['id']+"' class='banner_media-custom-position "+classAnimation+" "+fullImage+" fbanner_order"+(k)+"' "+fUrl+"> <button class='banner_media-close' type='button' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button><div class='media'>"+reqImage+"</div></a>";
                      jQuery(".coh-modal-overlay-open").append(reqOutput); 
                      jQuery(".toolbar-tray-open").append(reqOutput); 
                      jQuery(".toolbar-vertical").append(reqOutput);
                      cstorevalue['content']  = reqOutput;                  
                      //getStoredValues(cstorevalue); 
                      fromCookie = false; 
                      k++;
                      //console.log("This is first am added for reqOutput...",i," ", reqOutput); 
                    //}            
                  }
              } else{
                  //console.log("Substring not found!");              
                  if((retValues.data[i]['attributes']['field_fb_activation_parameter'][j]['uri'] === domainPathName)){
                    //console.log("Am in if domainPathName four");
                    //if((today > startDate) && (today < endDate)){
                      var reqOutput = '';      
                      cstorevalue['domain']  = domainPathName;
                      cstorevalue['param']  = activationValues; 
                      cstorevalue['fbanner_id']  = retValues.data[i]['id'];
                      //var classAnimation = 'banner_media-animate-top-to-bottom';
                      var classAnimation = 'banner_media-animate-bottom-to-top-'+k;
                      if(retValues.data[i]['attributes']['field_fb_animation_slide_in_dire'] == 'left-to-right'){
                          //classAnimation = 'banner_media-animate-left-to-right';
                          classAnimation = 'banner_media-animate-right-to-left-'+k;
                      }              
                      var fullImage = 'fullimageonly';
                      var fContent = '';
                      if(retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt']){
                        fContent = retValues.data[i]['relationships']['field_fb_upload_image']['data']['meta']['alt'];
                      }
                      var fUrl = "href='javascript:void(0)'";
                      if(retValues.data[i]['attributes']['field_fb_cta_url'] != null){
                        fUrl = "target='_blank' href='"+retValues.data[i]['attributes']['field_fb_cta_url']['uri']+"'";
                      }
                      var reqImage = '';
                      var imgpathId = retValues.data[i]['relationships']['field_fb_upload_image']['data']['id'];
                      reqImage =  getImagePath(imgpathId,retValues.included,fContent);       
                      var reqOutput = "<a data-fid='"+retValues.data[i]['id']+"' class='banner_media-custom-position "+classAnimation+" "+fullImage+" fbanner_order"+(k)+"' "+fUrl+"> <button class='banner_media-close' type='button' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button><div class='media'>"+reqImage+"</div></a>";
                      jQuery(".coh-modal-overlay-open").append(reqOutput); 
                      jQuery(".toolbar-tray-open").append(reqOutput); 
                      jQuery(".toolbar-vertical").append(reqOutput);
                      cstorevalue['content']  = reqOutput;                  
                      //getStoredValues(cstorevalue); 
                      fromCookie = false; 
                      k++;
                      //console.log("This is first am added for reqOutput...",i," ", reqOutput); 
                    //}            
                  }
              }
            }
            //k++;
          }          
        }
      }
      if(fromCookie){
        //console.log("am in if using full url five");
        //getInstantiate();
      }
    }   
    // if(!(activationValues.indexOf("fbanner=") != -1)){    
    //   console.log("am in if using full url five");
    //   getInstantiate();
    // }
    console.log(retValues, " retValues");
    getAllFloatingBanners(retValues);
    
    
    ////////////////////////for testing
        /*var settings = {
            "url": "/jsonapi/node/floating_banner?filter[field_fb_activation_parameter.uri]=internal:"+reqcurrentPathName+"&include=field_fb_upload_image&fields[file--file]=uri,url",
            "method": "GET",
            "timeout": 0,
            "async": false,
        };
        jQuery.ajax(settings).done(function (response) {
            //console.log(response, "response");
            retValues = response;
            return retValues;
        });*/
    //}
    //console.log("This is first am added for reqPathName...", retValues);
    /*
    for (let i = 0; i < retValues.data.length; i++) {
      var reqOutput = '';
      // do something with `item`
      console.log(dateTime, " This is first am added for reqPathName .item...", retValues.data[i]['attributes']['field_fb_validity_period']['value']);
    
      var classAnimation = 'banner_media-animate-top-to-bottom';
      if(retValues.data[i]['attributes']['field_fb_animation_slide_in_dire'] == 'left-to-right'){
          classAnimation = 'banner_media-animate-left-to-right';
      }
      var reqImage = '';
      if(retValues.included[i]['attributes']['uri']['url']){
        reqImage = "<img src='"+retValues.included[i]['attributes']['uri']['url']+"' height='150' class='mr-3' alt='"+retValues.data[i]['attributes']['field_fb_description']['value']+"'>";
      }
      var fullImage = 'fullimageonly';
      var fContent = '';
      if(retValues.data[i]['attributes']['field_fb_description']){
        fContent = "<div class='media-body'><h6 class='mt-0'>"+retValues.data[i]['attributes']['title']+"</h6>"+retValues.data[i]['attributes']['field_fb_description']['value']+"</div>";
        //fullImage = 'halfimageonly';
      }
      
      var reqOutput = "<a class='banner_media-custom-position "+classAnimation+" "+fullImage+" fbanner_order"+(i+1)+"' href='"+retValues.data[i]['attributes']['field_fb_cta_url']['uri']+"'> <button class='banner_media-close' type='button' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button><div class='media'>"+reqImage+"</div></a>";
      jQuery(".toolbar-tray-open").append(reqOutput); 
      console.log("This is first am added for reqOutput...",i," ", reqOutput); 
    }*/

    jQuery("a.banner_media-custom-position button.banner_media-close").click(function(){
      event.preventDefault();
      event.stopPropagation();
      //alert("yes am clicked");
      //console.log(" sjfklsf ",jQuery(this).parent().prop('className'));
      var cntClass = jQuery(this).parent().prop('className');
      var closeClassName = cntClass.replace(/ /g, ".");
      jQuery(".coh-modal-overlay-open ."+closeClassName).remove();
      jQuery(".toolbar-tray-open ."+closeClassName).remove();
      jQuery(".toolbar-vertical ."+closeClassName).remove();
      //removeParticularCookieWhenClose(jQuery(this).parent().attr("data-fid"));
      //jQuery.removeCookie("fbannerValue");
      //jQuery.cookie("fbannerValue", "", { path: '/' });
    });

    jQuery("a.banner_media-custom-position").click(function(){      
      
      //alert(jQuery(this).attr("data-fid"));
      var cntClass = jQuery(this).prop('className');
      var closeClassName = cntClass.replace(/ /g, ".");
      jQuery(".coh-modal-overlay-open ."+closeClassName).remove();
      jQuery(".toolbar-tray-open ."+closeClassName).remove();
      jQuery(".toolbar-vertical ."+closeClassName).remove();
      //removeParticularCookieWhenClose(jQuery(this).attr("data-fid"));
      //event.preventDefault();
      event.stopPropagation();
      
    })


    jQuery(".banner_media-close").on('mouseover', function(){
      var cntClass = jQuery(this).parent().addClass('banner-over');
    });
    jQuery(".banner_media-close").on('mouseout', function(){
      var cntClass = jQuery(this).parent().removeClass('banner-over');
    });
     

    

    //This is first am added for ram... Title- Floating Banner One : Animation- left-to-right : CTAURL- https://google.com : Description- <p>Floating Banner One Descriptions</p>
 //: Validity period start- 2021-11-08T07:42:36+00:00 : EndDate- 2021-11-09T07:42:36+00:00 : ImageURL- /sites/default/files/2021-06/info-bnr-4.png

  }, 100);
