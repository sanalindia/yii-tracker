var config = {
  course: "BA-PT",
  host: "https://qa.training.radiologyresources.bayer.com",
  prod: true,
  linearProgression: false,
  numberOfAttempts: 3,
  showAssessmentPdf: true,
  maxScore: 80,
};
