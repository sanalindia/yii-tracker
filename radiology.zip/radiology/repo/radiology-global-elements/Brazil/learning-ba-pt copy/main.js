let iframe = document.getElementById("quiz-container");
let src = [config.host, "#", config.course, 0, 0].join("/");

if (window.postMessage) {
  window.addEventListener("message", (messageEvent) => {
    console.log("MESSAGE FROM IFRAME CONTENT -", messageEvent);
  });
}

iframe.addEventListener("load", function (e) {
  window.frames["quiz-container"].postMessage(
    {
      type: "Post from LMS",
      payload: {
        type: "Load State",
        data: {
          config: config,
          bookmark: "",
          score: {
            intScore: null,
            intMaxScore: 100,
            intMinScore: 0,
          },
          progress: JSON.parse("{}"),
          status: { passed: null },
        },
      },
    },
    config.host
  );
});

iframe.src = src;
