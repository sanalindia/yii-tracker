var $ = jQuery;
$("#vialassaytime,#primetime,#timePatientSchedule0,#mcinumber,#unitsConfig,#min_activity,#max_activity,#step_activity,#min_volume,#max_volume,#step_volume").on("focus", function() {
  showCalculate();
});
$("#vialassaytime,#primetime,#timePatientSchedule0").on("blur", function() {
  validatetime(this.id);
});
$("#min_activity,#max_activity,#step_activity,#min_volume,#max_volume,#step_volume").on("blur", function() {
  validateConfiguration(this.id)
});
$("#unitsConfig").on("change", function() {
  unitsChange(this.value);
});

//Globals
var chart; //D3 chart variable to plot graph
var tooltipDisplay = true;
/*No area vertical work-around*/
var detectSwitch = false;
/*No area vertical work-around*/
var deletePoint = 0;


//MVP Objects
var outputChartConfig = {}; //outputChartConfig Object Data
var mvpConfig = {};
var mvpConfig_static = {};
var doses = {};


var curActivityUnit = "mci";

//Chart Array 
var chartDataPointsObj = []; //Store points for JSON conversion

//Schedule
var activity = []; //store the activities for patient schedule
var times = []; //store the times for patient schedule

//http://stackoverflow.com/questions/30042060/c3js-area-range-chart

function validatePoint(volume, min, max) {
  var success = false;
  console.log("Volume:" + parseFloat(volume) + " min:" + parseFloat(min) + " max:" + parseFloat(max) + " VALIDATING");
  for (var i = 0; i <= _test.length - 1; i++) {
    if (parseFloat(_test[i].volume) == parseFloat(volume) && parseFloat(_test[i].min) == parseFloat(min) && parseFloat(_test[i].max) == parseFloat(max)) {
      console.log("Volume:" + parseFloat(volume) + " min:" + parseFloat(min) + " max:" + parseFloat(max) + " PASS");
      success = true;
      break;
    }
  }
  if (!success) {
    console.log("Volume:" + parseFloat(volume) + " min:" + parseFloat(min) + " max:" + parseFloat(max) + " FAIL");
    var index = _test.map(function(o) {
      return o.volume;
    }).indexOf(volume);
    console.log("Volume:" + parseFloat(_test[index].volume) + " min:" + parseFloat(_test[index].min) + " max:" + parseFloat(_test[index].max) + " EXPECTED");
  }
  return success;
}

function validateConfiguration(elementId) {
  var value = $("#" + elementId).val();

  switch (elementId) {
    case "step_volume":
      if (value <= 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    case "max_volume":
      if (value <= 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    case "min_volume":
      if (value < 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    case "step_activity":
      if (value <= 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    case "max_activity":
      if (value <= 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    case "min_activity":
      if (value < 0) {
        $("#" + elementId).addClass("errorText");
      } else {
        $("#" + elementId).removeClass("errorText");
      }
      break;
    default:
      $("#" + elementId).removeClass("errorText");
      break;
  }

  if ($('#container_intego_vial .errorText').length <= 0) {
    configureInputs();
    generateChart();
    ivpcalculate();
  }

}

function validatetime(elementId) {
  var time = $("#" + elementId).val();
  var constructNewTime = "";
  var errorSwitch = false;
  if (/^([01]?[0-9]|2[0-3])[0-5][0-9]$/.test(time)) {
    if (time.length === 3) {
      for (var i = 0; i < time.length; i++) {
        constructNewTime += time[i];
        if (i === 0)
          constructNewTime += ":";
      }
      errorSwitch = true;
    } else if (time.length === 4) {
      for (var i = 0; i < time.length; i++) {
        constructNewTime += time[i];
        if (i === 1)
          constructNewTime += ":";
      }
      errorSwitch = true;
    }
    $("#" + elementId).val(constructNewTime);
  }
  if (!/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time) && !errorSwitch) {
    $("#" + elementId).addClass("errorText");
    TriggerAlert('timeformat', 5, time);
  } else {
    $("#" + elementId).removeClass("errorText");
  }
}

function showCalculate() {
  $('#graph_section_btn_calculate').show();
}

function unitsChange(unit) {
  switch (unit.toLowerCase()) {
    case "mci":

      //Modify mbq labels 
      $(".unit").removeClass("mbq").addClass("mci");

      //Modify Minimum Activity 
      var calc = document.getElementById('min_activity').value / mvpConfig.MBq_per_mCi;
      document.getElementById('min_activity').value = calc;

      //Modify Maximum Activity
      var calc = document.getElementById('max_activity').value / mvpConfig.MBq_per_mCi;
      document.getElementById('max_activity').value = calc;

      //Modify Activity Step
      var calc = parseFloat(document.getElementById('step_activity').value) / parseFloat(mvpConfig.MBq_per_mCi);
      document.getElementById('step_activity').value = parseFloat(calc).toFixed(1);

      //Update Config
      mvpConfig.maxConcentrationAtPriming = parseFloat(mvpConfig.maxConcentrationAtPriming) / parseFloat(mvpConfig.MBq_per_mCi);
      mvpConfig.maxActivityAtPriming = parseFloat(mvpConfig.maxActivityAtPriming) / parseFloat(mvpConfig.MBq_per_mCi);
      mvpConfig.maxActivityAtFirstPatient = parseFloat(mvpConfig.maxActivityAtFirstPatient) / parseFloat(mvpConfig.MBq_per_mCi);

      //Needed for chart configuration
      mvpConfig.minVolume = parseFloat(document.getElementById('min_volume').value);
      mvpConfig.maxVolume = parseFloat(document.getElementById('max_volume').value);
      mvpConfig.volumeStepSize = parseFloat(document.getElementById('step_volume').value)
      mvpConfig.minActivity = parseFloat(document.getElementById('min_activity').value);
      mvpConfig.maxActivity = parseFloat(document.getElementById('max_activity').value);
      mvpConfig.activityStepSize = parseFloat(document.getElementById('step_activity').value);

      //Recompute statics
      mvpConfig_static.maxActivity = parseFloat(mvpConfig_static.maxActivity) / parseFloat(mvpConfig_static.MBq_per_mCi);

      outputChartConfig.minVolume = mvpConfig.minVolume;
      outputChartConfig.maxVolume = mvpConfig.maxVolume;
      outputChartConfig.volumeStep = mvpConfig.volumeStepSize;
      outputChartConfig.minActivity = mvpConfig.minActivity;
      outputChartConfig.maxActivity = mvpConfig.maxActivity;
      outputChartConfig.activityStep = mvpConfig.activityStepSize;

      curActivityUnit = "mci";

      $('input[name^=activity]').each(function(index, value) {
        var curVal = parseInt($(this).val() / mvpConfig_static.MBq_per_mCi);
        $(this).val(curVal);
      });
      generateChart();

      break;

    case "mbq":

      //Modify mci labels 
      $(".unit").removeClass("mci").addClass("mbq");

      //Modify Minimum Activity 
      var val = document.getElementById('min_activity').value;
      var calc = val * mvpConfig.MBq_per_mCi;
      document.getElementById('min_activity').value = calc;

      //Modify Maximum Activity
      var val = document.getElementById('max_activity').value;
      var calc = val * mvpConfig.MBq_per_mCi;
      document.getElementById('max_activity').value = calc;

      //Modify Activity Step
      var val = document.getElementById('step_activity').value;
      var calc = parseFloat(val) * parseFloat(mvpConfig.MBq_per_mCi);
      document.getElementById('step_activity').value = parseFloat(calc).toFixed(1);

      //Update Config
      mvpConfig.maxConcentrationAtPriming = parseFloat(mvpConfig.MBq_per_mCi) * parseFloat(mvpConfig.maxConcentrationAtPriming);
      mvpConfig.maxActivityAtPriming = parseFloat(mvpConfig.MBq_per_mCi) * parseFloat(mvpConfig.maxActivityAtPriming);
      mvpConfig.maxActivityAtFirstPatient = parseFloat(mvpConfig.MBq_per_mCi) * parseFloat(mvpConfig.maxActivityAtFirstPatient);

      //Needed for chart configuration
      mvpConfig.minVolume = parseFloat(document.getElementById('min_volume').value);
      mvpConfig.maxVolume = parseFloat(document.getElementById('max_volume').value);
      mvpConfig.volumeStepSize = parseFloat(document.getElementById('step_volume').value)
      mvpConfig.minActivity = parseFloat(document.getElementById('min_activity').value);
      mvpConfig.maxActivity = parseFloat(document.getElementById('max_activity').value);
      mvpConfig.activityStepSize = parseFloat(document.getElementById('step_activity').value);

      //Recompute statics
      mvpConfig_static.maxActivity = parseFloat(mvpConfig_static.maxActivity) * parseFloat(mvpConfig_static.MBq_per_mCi);

      outputChartConfig.minVolume = mvpConfig.minVolume;
      outputChartConfig.maxVolume = mvpConfig.maxVolume;
      outputChartConfig.volumeStep = mvpConfig.volumeStepSize;
      outputChartConfig.minActivity = mvpConfig.minActivity;
      outputChartConfig.maxActivity = mvpConfig.maxActivity;
      outputChartConfig.activityStep = mvpConfig.activityStepSize;

      curActivityUnit = "mbq";

      $('input[name^=activity]').each(function(index, value) {
        var curVal = $(this).val() * mvpConfig_static.MBq_per_mCi;
        $(this).val(curVal);
      });

      generateChart();

      break;

    default:
      curActivityUnit = "mci";
      break;
  }

}

function calcDifPrimeAssay(prime, assay) {
  var startTime = moment(assay, 'H:mm');
  var endTime = moment(prime, 'H:mm');
  return (endTime.diff(startTime, 'minutes'));
}

function concentration_at_assay(vial_activity_at_assay, volume) {
  return parseFloat(parseFloat(vial_activity_at_assay) / parseFloat(volume));
}


function concentration_at_prime(rtn_concentration_at_assay, timeDelta) {
  return parseFloat(parseFloat(rtn_concentration_at_assay) * parseFloat(Math.exp(parseFloat(-Math.log(2)) * parseFloat(timeDelta) / parseFloat(mvpConfig.halflife))));
}

function concentration_at_dosing(rtn_concentration_at_assay, timeDelta) {
  return parseFloat(parseFloat(rtn_concentration_at_assay) * parseFloat(Math.exp(parseFloat(-Math.log(2)) * parseFloat(timeDelta) / parseFloat(mvpConfig.halflife))));
}


function retrieveprimeVol() {
  return parseFloat(parseFloat(mvpConfig.primeSlugSize) * parseFloat(mvpConfig.numberOfPrimingSlugs));
}

function buildSchedule() {
  var success = true;
  activity.length = 0;
  times.length = 0;

  //Detect any errors
  $('input[name^=time]').each(function(index, value) {
    if (isNaN(times[index]) && !(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(this.value))) {
      success = false;
      TriggerAlert('timeformat', 5, time);
    }
    if (success) {
      times.push(this.value);
    }
  });

  $('input[name^=activity]').each(function(index, value) {
    if (curActivityUnit == "mci" && ((curActivityUnit == "mci" && parseFloat(this.value) < 1) || isNaN(parseFloat(this.value)))) {
      TriggerAlert('norm', 1, [times[index], 1]);
      success = false;
    }
    if (curActivityUnit == "mbq" && ((parseFloat(this.value) < parseFloat(mvpConfig.MBq_per_mCi)) || isNaN(parseFloat(this.value)))) {
      TriggerAlert('norm', 1, [times[index], mvpConfig.MBq_per_mCi]);
      success = false;
    }
    if (success) {
      activity.push(parseFloat(this.value));
    }
  });

  if ($('#container_intego_vial .errorText').length > 0) {
    success = false;
  }

  return success;
}

function sorting(json_object, key_to_sort_by) {
  function sortByKey(a, b) {
    var x = a[key_to_sort_by];
    var y = b[key_to_sort_by];
    return ((x < y) ? -1 : ((x > y) ? 1 : 0));
  }
  json_object.sort(sortByKey);
}

function sortSchedule(timesRef, activityRef) {

  var dose = {};
  var doses = [];

  for (var i = 0; i < timesRef.length; i++) {
    dose = {
      time: timesRef[i],
      activity: activityRef[i]
    };
    doses.push(dose);
  }

  sorting(doses, 'time');

  for (var i = 0; i < timesRef.length; i++) {
    times[i] = doses[i].time;
    activity[i] = doses[i].activity;
  }

  return true;
}

function validateSchedule(activity, times) {
  var success = true;
  if (times.length == activity.length) {
    for (var i = 0; i < times.length; i++) {
      /* if (!/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(times[i])) {
                  success = false;
          return false;
              }*/
      if ((parseFloat(activity[i]) > parseFloat(mvpConfig.maxDoseLimit)) && curActivityUnit == "mci") {
        TriggerAlert('norm', 2, [times[i], mvpConfig.maxDoseLimit]);
        success = false;
        return false;
      }
      if ((parseFloat(activity[i]) > parseFloat(mvpConfig.maxDoseLimit * mvpConfig.MBq_per_mCi)) && curActivityUnit == "mbq") {
        var maxDose = parseFloat(mvpConfig.maxDoseLimit * mvpConfig.MBq_per_mCi);
        TriggerAlert('norm', 2, [times[i], maxDose]);
        success = false;
        return false;
      }
    }
  } else {
    success = false;
  }
  return success;
}

function validatePrimeTime(times, prime) {
  var success = true;
  var dose1Time = moment(times[0], 'H:mm');
  var primeTime = moment(prime, 'H:mm');
  if (primeTime >= dose1Time) {
    primeTime = moment(dose1Time).subtract(5, 'minutes').format('H:mm');
    prime = primeTime;
    TriggerAlert('confirm', 4, [prime]);
    success = false;
  } else {
    success = true;
  }

  return success;
}

function checkAssay(volumeRef, concentrationRef, activityRef) {
  var success = true;

  var tSPrimeDifference = parseFloat(parseFloat(calcDifPrimeAssay(doses.prime, doses.assay)));
  var startConc = parseFloat(concentration_at_prime(parseFloat(concentrationRef), parseFloat(tSPrimeDifference)));
  var startVol = parseFloat(volumeRef);
  var startExtVol = parseFloat(parseFloat(startVol) - parseFloat(mvpConfig.unextractableVolume));
  var startAct = parseFloat(parseFloat(startConc) * parseFloat(startVol));
  var startExtAct = parseFloat(parseFloat(startConc) * parseFloat(startExtVol));
  var extDose = parseFloat(parseFloat(startConc) * parseFloat(doses.primeVol));
  var extVol = parseFloat(parseFloat(doses.primeVol) + parseFloat(mvpConfig.vialToConfVolume));
  var endAct = parseFloat(parseFloat(startExtAct) - parseFloat(startConc) * parseFloat(extVol));
  var endVol = parseFloat(parseFloat(startVol) - parseFloat(extVol));

  //Errors
  if (parseFloat(startAct) > parseFloat(mvpConfig.maxActivityAtPriming) /*&& errCode > DoseError.HighPrimeActivity*/ ) // Too much activity
  {
    //errCode = DoseError.HighPrimeActivity;
    //console.log("High Prime Activity");
    success = false;
  } else if (parseFloat(startConc) > parseFloat(mvpConfig.maxConcentrationAtPriming) /*&& errCode > DoseError.HighVialConcentration*/ ) // High concentration
  {
    //errCode = DoseError.HighVialConcentration;
    //console.log("High Vial Concentration");
    success = false;
  }

  if (!success) {
    /*
    if (errCode < DoseError.Success)
    {
      return false;
    }*/

    success = false;

  } else {

    var curConc = parseFloat(startConc);
    var curVol = parseFloat(endVol) - parseFloat(mvpConfig.unextractableVolume);

    //var refTime = moment(doses.prime, 'H:mm');
    var refTime = doses.prime;

    for (var i = 0; i < times.length; i++) {
      tSDifference = parseFloat(calcDifPrimeAssay(times[i], refTime));
      startConc = parseFloat(concentration_at_dosing(parseFloat(curConc), parseFloat(tSDifference)));
      startVol = parseFloat(curVol) + parseFloat(mvpConfig.unextractableVolume);
      startExtVol = parseFloat(curVol);
      startAct = parseFloat(startConc) * parseFloat(startVol);
      startExtAct = parseFloat(startConc) * parseFloat(startExtVol);

      var maxExtAct = parseFloat(startConc) * parseFloat(mvpConfig.maxDoseVolume);

      if (parseFloat(startExtVol) < parseFloat(mvpConfig.maxDoseVolume)) {
        maxExtAct = parseFloat(startExtAct);
      }
      if (parseFloat(maxExtAct) > parseFloat(mvpConfig.maxDoseLimit)) {
        maxExtAct = parseFloat(mvpConfig.maxDoseLimit);
      }

      var minExtAct = parseFloat(startConc) * parseFloat(mvpConfig.minDoseVolume);
      if (parseFloat(minExtAct) < parseFloat(mvpConfig.minDoseLimit)) {
        minExtAct = parseFloat(mvpConfig.minDoseLimit);
      }

      if (parseFloat(startAct) > parseFloat(mvpConfig.maxActivityAtFirstPatient)) {
        /*if (errCode > DoseError.HighVialActivity)
        {
          errCode = DoseError.HighVialActivity;
        }*/
        success = false;
      } else if (parseFloat(activity[i]) > parseFloat(startExtAct)) {
        /*
        if (errCode > DoseError.LowDoseActivity)
        {
          errCode = DoseError.LowDoseActivity;
        }*/
        //console.log("Low Dose Activity");
        success = false;
      } else {
        extDose = parseFloat(activity[i]);
        extVol = parseFloat(extDose) / parseFloat(startConc);
        endAct = parseFloat(startExtAct) - parseFloat(extDose);
        endVol = parseFloat(startVol) - parseFloat(extVol);

        if (parseFloat(extVol) >= parseFloat(mvpConfig.maxDoseVolume)) {
          /*
          if (errCode > DoseError.HighDoseVolume)
          {
            errCode = DoseError.HighDoseVolume;
          }*/
          //console.log("High Dose Volume");
          success = false;
        } else if (parseFloat(extVol) < parseFloat(mvpConfig.minDoseVolume)) {
          /*
          if (errCode > DoseError.LowDoseVolume)
          {
            errCode = DoseError.LowDoseVolume;
          }*/
          //console.log("Low Dose Volume");
          success = false;
        }
      }

      if (success) {
        //success continue in the loop
        curConc = parseFloat(startConc);
        curVol = parseFloat(startExtVol) - parseFloat(extVol);
        refTime = times[i];
      } else {
        success = false;
        break;
      }
    }
  }
  return success;
}

function isValidPoint(activity) {
  if ((parseFloat(activity) > parseFloat(mvpConfig.unextractableVolume)) && (parseFloat(activity) > 0)) {
    return true;
  } else {
    return false;
  }
}


function generateChart() {
  var initialX = ['x']
  var initialMax = ['Max'];
  var initialMin = ['Min'];
  var activityMeasurement = "mCi";
  var catchTooltipMinMaxStart = false;

  //Determine activity measurement
  switch (curActivityUnit) {
    case 'mci':
      activityMeasurement = "mCi";
      break;
    case 'mbq':
      activityMeasurement = "MBq";
      break;
    default:
      activityMeasurement = "mCi";
      break;
  }

  //Generate Volumes 
  for (var volumesLoop = parseFloat(outputChartConfig.minVolume); volumesLoop <= parseFloat(outputChartConfig.maxVolume); volumesLoop += +outputChartConfig.volumeStep) {
    initialX.push(parseInt(volumesLoop));
  }

  //Generate Activities   
  for (var activitiesLoop = parseFloat(outputChartConfig.minActivity); activitiesLoop <= parseFloat(outputChartConfig.maxActivity); activitiesLoop += +outputChartConfig.activityStep) {
    initialMax.push(parseInt(outputChartConfig.maxActivity));
    initialMin.push(parseInt(outputChartConfig.maxActivity));
  }

  chart = c3.generate({
    data: {
      x: 'x',
      columns: [
        initialX,
        initialMax,
        initialMin,
      ],
      types: {
        Max: 'area',
        Score: 'area-step',
        Min: 'area'
      },
      colors: {
        Max: '#688caf',
        Min: '#ffffff'
      }
    },
    legend: {
      show: false
    },
    tooltip: {
      show: tooltipDisplay,
      format: {
        /*title: function (d) { return 'Volume (mL) ' + d; },*/
        name: function(name, ratio, id, index) {
          if (id === "Max") {
            return "Maximum Activity";
          } else {
            return "Minimum Activity";
          }
        },
        value: function(value, ratio, id) {
          if (id === 'Max' && value === 800 && !catchTooltipMinMaxStart) {
            catchTooltipMinMaxStart = true;
            return 0;
          }
          if (id === 'Min' && value === 800 && catchTooltipMinMaxStart) {
            catchTooltipMinMaxStart = false;
            return 0;
          }
          return value;
        }
      },
      //http://stackoverflow.com/questions/24754239/how-to-change-tooltip-content-in-c3js
      contents: function(d, defaultTitleFormat, defaultValueFormat, color) {
        var $$ = this,
          config = $$.config,
          titleFormat = config.tooltip_format_title || defaultTitleFormat,
          nameFormat = config.tooltip_format_name || function(name) {
            return name;
          },
          valueFormat = config.tooltip_format_value || defaultValueFormat,
          text, concat = "",
          i, title, value, name, bgcolor;

        for (i = d.length - 1; i >= 0; i--) {
          /*No area horiztonal work-around*/
          var name = nameFormat(d[i].name);
          var value = valueFormat(d[i].value, d[i].ratio, d[i].id, d[i].index);

          if (!(d[i] && (d[i].value || d[i].value === 0))) {
            continue;
          }
          if (!text) {
            title = titleFormat ? titleFormat(d[i].x) : d[i].x;
            /*No area horiztonal work-around*/
            var horizontalCorrect = d[1].value + 2;
            if (d[0].value === horizontalCorrect) {
              value = d[1].value;
            }
            /*No area horiztonal work-around*/
            /*First load no data nothing to show min / max*/
            if (d[0].value === d[1].value) {
              concat += "";
            } else {
              if (d[i].name === "Min") {
                concat += value;
              }

            }
            /*First load no data nothing to show min / max*/
          }
        }
        /*No area vertical work-around*/
        if (!detectSwitch) {
          text = "<table class='" + $$.CLASS.tooltip + "'>" + (title || title === 0 ? "<tr><th colspan='2'>" + concat + "<sup>[" + title + " mL] </sup>" + "</th></tr>" : "");
        } else {
          var index = chartDataPointsObj.map(function(e) {
            return e.x;
          }).indexOf(parseFloat(title).toFixed(1));
          if (index === deletePoint) {
            index--;
          }
          text = "<table class='" + $$.CLASS.tooltip + "'>" + (title || title === 0 ? "<tr><th colspan='2'>" + chartDataPointsObj[index].Min + "<sup>[" + chartDataPointsObj[index].x + " mL] </sup>" + "</th></tr>" : "");

        }

        /*No area vertical work-around*/
        return text + "</table>";
      }

    },
    axis: {
      y: {
        label: {
          text: 'Activity (' + activityMeasurement + ')',
          position: 'outer-middle'
        },
        max: outputChartConfig.maxActivity,
        min: outputChartConfig.minActivity + 1.0,
        ticks: outputChartConfig.activityStep,

      },
      x: {
        label: {
          text: 'Volume (mL)',
          position: 'center',
        },
        max: outputChartConfig.maxVolume,
        min: outputChartConfig.minVolume,
        ticks: outputChartConfig.volumeStep,
      }
    },
    grid: {
      y: {
        show: true
      },
      focus: {
        show: false
      }
    }
  });


  d3.selection.prototype.moveToFront = function() {
    return this.each(function() {
      this.parentNode.appendChild(this);
    });
  };
  d3.select("svg g.c3-grid").moveToFront();

}