var $ = jQuery;
window.onload = function () {

  var calcElem = $('')
  getConfigurations();
  generateChart();

}

$('document').ready(function () {
  var calcWrapper = $('#container_intego_vial');
  if (calcWrapper.length) {
    $('body').addClass('invento-vial-tool');
    $('.messages--error').remove();

    $('body').append('<div id="invent-overlay"></div>');
    $("#invent-overlay").css({
      'opacity': 0.4,
      'position': 'absolute',
      'top': 0,
      'left': 0,
      'background-color': 'rgb(0, 0, 0)',
      'width': '100%',
      'z-index': 30,
      'height': $(document).height()
    })
  }

  $("#container_intego_vial #config-2 h3").click(function () {
    if ($("#container_intego_vial #config-1, #container_intego_vial #config-2").hasClass("opClose")) {
      $("#container_intego_vial #config-1, #container_intego_vial #config-2").removeClass("opClose");
      $("#container_intego_vial #config-1, #container_intego_vial #config-2").addClass("opOpen");
    } else {
      $("#container_intego_vial #config-1, #container_intego_vial #config-2").addClass("opClose");
      $("#container_intego_vial #config-1, #container_intego_vial #config-2").removeClass("opOpen");
    }
  });
  var host = window.location.origin;
  $("a.serviceClose").attr("href", host);

  /*Instructions + Buttons*/
  $("#btn-begin").on("click", function () {
    btnBegin();
  });
  $("#btn-prev").on("click", function () {
    btnPrev();
  });
  $("#btn-next").on("click", function () {
    btnNext();
  });
  $("#plus_dose").on("click", function () {
    plus('rowsDynamic');
  });
  $("#minus_dose").on("click", function () {
    minus();
  });
  $("#x,#btn-OK,#btn-CANCEL").on("click", function () {
    AlertConfirm(this.id);
  });
  $("#btn-refresh-app").on("click", function () {
    btnRefresh();
  });
  $("#btn-close-app").on("click", function () {
    btnClose();
  });
  $("#btn-previous-app").on("click", function () {
    btnPrevApp();
  });
  $("#graph_section_btn_calculate").on("click", function () {
    ivpcalculate();
  });
})

function readCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
}


function btnBegin() {

  $("#splash2").removeClass("hide");
  $("#splash").addClass("hide");
}

function btnPrev() {
  $("#splash2").addClass("hide");
  $("#splash").removeClass("hide");
}

function btnNext() {
  $("#splash2, #splash").addClass("hide");
  $("#application-btns").removeClass("hide");
}

function btnRefresh() {
  $('#graph_section_btn_calculate').show();
  getConfigurations();
}

function btnPrevApp() {
  $("#application-btns").addClass("hide");
  $("#splash2").removeClass("hide");
}

function btnClose() {
  var host = window.location.origin;
  window.top.location.href = host;
  return false;
}

/*End Instructions + Buttons*/

function getDosages() {
  var counter = 0;
  $('input[name^=activity]').each(function (index, value) {
    counter++;
  });
  return counter;
}

function clearGraph() {
  chartDataPointsObj.length = 0;
  return true;
}

function ivpcalculate() {
  configureInputs();
  clearErrors();

  var trackMin = 0,
    trackMax = 0,
    trackFirstVolume = -1,
    trackFirstActivity = -1,
    trackFirstInvalidPoint = -1,
    chartDataPoints = {},
    nopoints = 0;
  /*No area vertical work-around*/
  detectSwitch = false;
  /*No area vertical work-around*/


  var concentration;

  //Build dosing schedule
  if (buildSchedule()) {
    //Validate schedule 
    if (validateSchedule(activity, times) && sortSchedule(times, activity)) {
      //Validate the PrimeTime value
      if (validatePrimeTime(times, doses.prime)) {
        clearGraph();
        //Establish the primeVol to use for the plot
        doses.primeVol = retrieveprimeVol();
        for (var volumesLoop = parseFloat(outputChartConfig.minVolume); volumesLoop <= parseFloat(outputChartConfig.maxVolume); volumesLoop += +outputChartConfig.volumeStep) {
          for (var activitiesLoop = parseFloat(outputChartConfig.minActivity); activitiesLoop <= parseFloat(outputChartConfig.maxActivity); activitiesLoop += +outputChartConfig.activityStep) {
            //Break out of Activity Loop
            if (parseFloat(mvpConfig_static.maxVolume) < parseFloat(volumesLoop)) {
              break;
            }
            //Break out of Activity Loop
            if (isValidPoint(parseFloat(activitiesLoop))) {
              concentration = parseFloat(concentration_at_assay(parseFloat(activitiesLoop), parseFloat(volumesLoop)));
              if (checkAssay(parseFloat(volumesLoop), parseFloat(concentration), parseFloat(activitiesLoop)) && (parseFloat(mvpConfig_static.maxVolume) >= parseFloat(volumesLoop)) && (parseFloat(mvpConfig_static.maxActivity) >= parseFloat(activitiesLoop))) {
                if (trackFirstVolume == -1) {
                  trackFirstVolume = volumesLoop;
                }
                if (trackFirstActivity == -1) {
                  trackMin = activitiesLoop;
                  trackFirstActivity = activitiesLoop;
                  trackMax = trackMin;
                } else {
                  trackMax = activitiesLoop;
                }
              } else {
                //Not a valid point
                if (trackFirstInvalidPoint == -1) {
                  trackFirstInvalidPoint = trackMax;
                }
                //console.log('Not a valid point');
              }
            } else {
              //console.log("LowDoseVolume");
            }
          }

          if (trackFirstVolume != -1) {
            //Handle Vertical straight line                         
            var _volumesLoop = parseFloat(volumesLoop - outputChartConfig.volumeStep).toFixed(1);
            var detectMin, detectXvol;
            if (chartDataPointsObj.length === 0) {
              detectMin = activitiesLoop;
              detectXvol = volumesLoop;
            } else {
              detectMin = chartDataPointsObj[chartDataPointsObj.length - 1]["Min"];
              detectXvol = chartDataPointsObj[chartDataPointsObj.length - 1]["x"];
            }
            if ((((outputChartConfig.volumeStep * 2) > outputChartConfig.maxVolume) && trackFirstInvalidPoint == 0) || (!detectMin && detectXvol === _volumesLoop)) {

              deletePoint = chartDataPointsObj.length + 1;
              /*No area vertical work-around*/
              detectSwitch = true;
              /*No area vertical work-around*/
              chartDataPointsObj.push({
                x: parseFloat(volumesLoop).toFixed(1),
                Max: parseFloat(trackMax).toFixed(1),
                Min: parseFloat(trackMin).toFixed(1)
              });

              var newX = parseFloat(parseFloat(volumesLoop) + parseFloat('0.1')).toFixed(1); //0.1
              chartDataPointsObj.push({
                x: newX,
                Max: parseFloat(trackMax).toFixed(1),
                Min: parseFloat(trackMin).toFixed(1)
              });
            } else {
              //Handle Horizontal straight line
              if (parseFloat(trackMax).toFixed(1) == parseFloat(trackMin).toFixed(1)) {
                var newMax = parseFloat(parseFloat(trackMax) + parseFloat(mvpConfig_static.horizontalCorrection)).toFixed(1);
                chartDataPointsObj.push({
                  x: parseFloat(volumesLoop).toFixed(1),
                  Max: newMax,
                  Min: parseFloat(trackMin).toFixed(1)
                });
              } else {
                chartDataPointsObj.push({
                  x: parseFloat(volumesLoop).toFixed(1),
                  Max: parseFloat(trackMax).toFixed(1),
                  Min: parseFloat(trackMin).toFixed(1)
                });
              }
            }
            //Validate Point
            //validatePoint(parseFloat(volumesLoop),parseFloat(trackMin),parseFloat(trackMax));             
            trackFirstVolume = -1;
            trackFirstActivity = -1;
            trackFirstInvalidPoint = -1;
          } else {
            chartDataPointsObj.push({
              x: parseFloat(volumesLoop).toFixed(1)
            });
            trackFirstVolume = -1;
            trackFirstActivity = -1;
            trackFirstInvalidPoint = -1;
            nopoints++;
          }
        }
        if (nopoints == chartDataPointsObj.length) {
          TriggerAlert('norm', 3, null);
        } else {
          chart.destroy();
          generateChart();
          chart.load({
            json: chartDataPointsObj,
            keys: {
              value: ['x', 'Max', 'Min'],
            },
            done: function () {
              $('#graph_section_btn_calculate').hide();
            }
          });
          /*No area vertical work-around*/
          /*Performane issue - for some reason multiple*/
          if (detectSwitch) {
            //var lastTick = parseInt(chartDataPointsObj.length);
            var lastTickVal = chartDataPointsObj[deletePoint];
            $(".c3-axis-x .tick").each(function (index) {
              if (parseFloat($(this).text()) === parseFloat(lastTickVal.x))
                this.style.display = "none";
            });
          }
          /*No area vertical work-around*/
        }
      }
    }
  }
}

function plus(div) {
  $.blockUI({
    message: null
  });
  var newdiv = document.createElement('div');
  var patientdosages = getDosages();
  var Id = patientdosages++;
  if (patientdosages > 1) {
    $("#patient_schedule").addClass("active");
  }
  newdiv.innerHTML = "<div class=\"patient_times\"><input id=\"timePatientSchedule" + Id + "\" type=\"text\" name=\"time[]\" onfocus=\"showCalculate()\" onblur=\"validatetime(this.id)\" autocomplete=\"off\" value=\"6:00\"></div><div class=\"patient_activities\"><input type=\"number\" min=\"1\" value=\"1\" name=\"activity[]\" onfocus=\"showCalculate()\" autocomplete=\"off\" value=\"1\"></div>";
  document.getElementById(div).appendChild(newdiv);
  setTimeout($.unblockUI, 150);
}

function minus() {
  $.blockUI({
    message: null
  });
  var patientdosages = getDosages();
  if (patientdosages > 1) {
    $('.patient_times').last().remove();
    $('.patient_activities').last().remove();
    if (patientdosages <= 3) {
      $("#patient_schedule").removeClass("active").addClass("inactive");
    }
  }
  setTimeout($.unblockUI, 150);
}

function clearErrors() {
  $("#alerts").addClass("hide");
  $("#buttons").addClass("hide");
}

function configureInputs() {
  outputChartConfig = {
    minActivity: parseFloat(document.getElementById('min_activity').value),
    maxActivity: parseFloat(document.getElementById('max_activity').value),
    activityStep: parseFloat(document.getElementById('step_activity').value),
    minVolume: parseFloat(document.getElementById('min_volume').value),
    maxVolume: parseFloat(document.getElementById('max_volume').value),
    volumeStep: parseFloat(document.getElementById('step_volume').value)
  }

  doses = {
    primeVol: retrieveprimeVol(),
    prime: document.getElementById('primetime').value,
    assay: document.getElementById('vialassaytime').value
  }
}

function getConfigurations() {
  mvpConfig = {
    vialToConfVolume: 0.36,
    minDoseLimit: 1.0,
    maxDoseLimit: 25.0,
    halflife: 109.77,
    primeSlugSize: 0.0349,
    MBq_per_mCi: 37.0,
    //Taken from configuration (Constraints)
    minActivity: 0,
    maxActivity: 700.0,
    activityStepSize: 1.0,
    minVolume: 0.0,
    maxVolume: 30.0,
    volumeStepSize: 5.0,
    maxConcentrationAtPriming: 100.0,
    maxActivityAtPriming: 750.0,
    maxActivityAtFirstPatient: 700.0,
    maxVialVolume: 30.0,
    maxDoseVolume: 3.0,
    minDoseVolume: 0.125,
    numberOfPrimingSlugs: 4.00,
    unextractableVolume: 0.640
  }

  //Static configuration to CAP out the limits
  mvpConfig_static = {
    MBq_per_mCi: 37.0,
    maxActivity: 5000.0,
    maxVolume: 30.0,
    horizontalCorrection: 2.0
  }

  outputChartConfig = {
    minActivity: mvpConfig.minActivity,
    maxActivity: mvpConfig.maxActivity,
    activityStep: mvpConfig.activityStepSize,
    minVolume: mvpConfig.minVolume,
    maxVolume: mvpConfig.maxVolume,
    volumeStep: mvpConfig.volumeStepSize
  }

  //Fill in text boxes  
  document.getElementById('vialassaytime').value = "5:00";
  document.getElementById('primetime').value = "5:55";
  document.getElementById('unitsConfig').value = "mci";
  curActivityUnit = "mci";
  document.getElementById('min_activity').value = 0;
  document.getElementById('max_activity').value = 700;
  document.getElementById('step_activity').value = 1.0;
  document.getElementById('min_volume').value = 0;
  document.getElementById('max_volume').value = 30;
  document.getElementById('step_volume').value = 5.0;

  //Clear activities
  var patientdosages = getDosages();
  for (var i = 0; i < patientdosages; i++) {
    minus();
  }

  generateChart();
}
