var err_prime_5_min = "";
/*Error messages*/
var err_messages = [];
err_messages.push("<strong>The Activity entered for #TIME# is less<br/> than Intego's minimum allowed value of #NUMBER#.</strong>");
err_messages.push("<strong>The Activity entered for #TIME# is more<br/> than Intego's maximum allowed value of #NUMBER#.</strong>");
err_messages.push("<strong>No valid solution exists for the given schedule and Assay time.</strong>");
err_messages.push("<strong>The Prime Time cannot be after (or at the same time as) the dosing time for the first patient</strong>.<br/><br/>Press <strong>OK</strong> to continue and automatically set the Prime Time to 5 minutes before the first dose.<br/><br/> Press <strong>CANCEL</strong> to fix the Prime Time value manually.");
err_messages.push("<strong>The Time entered for #TIME# is outside Intego's allowed range of 0:00 to 23:59.</strong>");
/*Error Logic*/
function TriggerAlert(type, error, params) {
  $("#alerts").removeClass("hide");
  $("#container_intego_vial :input").prop("disabled", true);
  document.getElementById('btn-refresh-app').style.pointerEvents = 'none';
  document.getElementById('btn-close-app').style.pointerEvents = 'none';
  document.getElementById('btn-previous-app').style.pointerEvents = 'none';

  switch (type) {
    case "norm":
      if (params !== null) {
        var edit = err_messages[error - 1];
        var newStr = edit.replace("#TIME#", params[0]);
        edit = newStr;
        newStr = edit.replace("#NUMBER#", params[1]);
        $(".err").html(newStr);
      } else {
        $(".err").html(err_messages[error - 1]);
      }
      break;
    case "timeformat":
      var edit = err_messages[error - 1];
      var newStr = edit.replace("#TIME#", params);
      $(".err").html(newStr);
      break;

    case "confirm":
      $("#buttons").removeClass("hide");
      $(".err").html(err_messages[error - 1]);
      //Global
      err_prime_5_min = params[0];
      break;
    default:
      break;
  }
}

function AlertConfirm(action) {

  var success = false;

  $("#container_intego_vial :input").removeProp("disabled", true);

  switch (action) {
    case "x":
      success = true;
      break;
    case "btn-CANCEL":
      success = false;
      break;
    case "btn-OK":
      document.getElementById('primetime').value = err_prime_5_min;
      success = true;
      break;
    default:
      break;
  }

  $("#alerts").addClass("hide");
  $("#buttons").addClass("hide");
  document.getElementById('btn-refresh-app').style.pointerEvents = 'auto';
  document.getElementById('btn-close-app').style.pointerEvents = 'auto';
  document.getElementById('btn-previous-app').style.pointerEvents = 'auto';

  return success;
}