  /*
   * @file Downtime Calculator
   * This script comes from the live Pharma Radiology US site.
   */ 

  function calculate() {

    /** Calculation */
    var numOfAffected = jQuery('.numOfAffected').val(); 
    var scansPerHour = jQuery('.scansPerHour').val();
    var hoursPerDay = jQuery('.hoursPerDay').val();
    var calc ='';
    var peoplePerDay = numOfAffected*scansPerHour*.51*.97*hoursPerDay;
    var dollarsPerDay = numOfAffected*scansPerHour*.51*.97*hoursPerDay*249;
    jQuery('#answerA').text(numOfAffected);
    jQuery('#answerB').text(scansPerHour);
    jQuery('#answerC').text(hoursPerDay);
    calc = peoplePerDay / hoursPerDay;
    calc = Math.round(calc);
    jQuery('#answerD').text(calc);
    calc = peoplePerDay;
    calc = Math.round(calc);
    jQuery('#answerE').text(calc);
    calc = peoplePerDay *5;
    calc = Math.round(calc);
    jQuery('#answerF').text(calc);
    calc = peoplePerDay / hoursPerDay;
    calc = Math.round(calc);
    jQuery('#answerG').text(calc);
    calc = peoplePerDay;
    calc = Math.round(calc);
    jQuery('#answerH').text(calc);
    calc = peoplePerDay *5;
    calc = Math.round(calc);
    jQuery('#answerI').text(calc);
    calc = dollarsPerDay / hoursPerDay;
    calc = calc.toFixed(2);
    calc = calc.toString();
    calc = numeral(calc).format('jQuery0,0');
    jQuery('#answerJ').text(calc);
    calc = dollarsPerDay;
    calc = calc.toFixed(2);
    calc = calc.toString();
    calc = numeral(calc).format('jQuery0,0');
    jQuery('#answerK').text(calc);
    calc = dollarsPerDay *5;
    calc = calc.toFixed(2);
    calc = calc.toString();
    calc = numeral(calc).format('jQuery0,0');
    jQuery('#answerL').text(calc);
    calc = peoplePerDay *5;
    calc = calc.toFixed(2);
    calc = Math.round(calc);
    jQuery('#answerM').text(calc);
    calc = dollarsPerDay *5;
    calc = calc.toFixed(2);
    calc = calc.toString();
    calc = numeral(calc).format('jQuery0,0');
    jQuery('#answerN').text(calc);
  }

  jQuery(document).ready(function() {

    /* When you click the Calculate or Re-Calculate button */
    jQuery('.calculate').click(function(){
      jQuery('.downtime-error-message').hide();
      jQuery('.downtime-error-nan').hide();
      var error = false;
      var nan_error = false;
      var user_number = jQuery('.numOfAffected').val();
      var scans_per_hour = jQuery('.scansPerHour').val();
      var hours_per_day = jQuery('.hoursPerDay').val();
      
      /* Form validation */
      /* Checks if Field is blank */
      if(user_number == '' ) {
        var error = true;
        jQuery('.numOfAffected').addClass('downtime-error');
      }

      if(scans_per_hour == '') {
        var error = true;
        jQuery('.scansPerHour').addClass('downtime-error');
      }

      if(hours_per_day == '') {
        var error = true;
        jQuery('.hoursPerDay').addClass('downtime-error');
      }

      /* Checks if entered field is a number */
      if(isNaN(parseInt(user_number))) {
        var nan_error = true;
        jQuery('.numOfAffected').addClass('downtime-error');
      }

      if(isNaN(parseInt(scans_per_hour))) {
        var nan_error = true;
        jQuery('.scansPerHour').addClass('downtime-error');
      }

      if(isNaN(parseInt(hours_per_day))) {
        var nan_error = true;
        jQuery('.hoursPerDay').addClass('downtime-error');
      }

      /* If field is empty */
      if(error){
        jQuery('.downtime-error-message').show();
        jQuery('.calculate').addClass('downtime-error-button');
        jQuery('.downtime-calculator__slide-three').hide();
        jQuery('.downtime-calculator__slide-four').hide();
      } else {

        /* If entered field is not a number */
        if(nan_error) {
          jQuery('.downtime-error-nan').show();
          jQuery('.calculate').addClass('downtime-error-button');
          jQuery('.downtime-calculator__slide-three').hide();
          jQuery('.downtime-calculator__slide-four').hide();
        }else{
          
        /* If all validations pass */
        jQuery('.downtime-error-message').hide();
        jQuery('.downtime-error-nan').hide();
        jQuery('.calculate').removeClass('downtime-error-button');
        jQuery('.userNumber').removeClass('downtime-error');
        calculate();
        jQuery('.downtime-calculator__slide-three').slideDown('slow');
        jQuery('.downtime-calculator__slide-four').slideDown('slow');
        jQuery('.calculate').html('Calculate');
        jQuery('.calculate').addClass('calculate-active');
        }
      }
    });

    jQuery('#downtime-calculator__close-btn').click(function(){
      jQuery('.downtime-calculator__slide-three').slideUp();
      jQuery('.downtime-calculator__slide-four').slideUp();
    });

    jQuery('.downtime-calculator__results').hide();
    jQuery('#downtime-calculator__per-week').show();
    jQuery('#btn-tabs-week').addClass('active');
    jQuery('#downtime-calculator__dollars-per-week').show();
    jQuery('#btn-tabs-dollars-week').addClass('active');

	/* jquery added for closebtn2 */
	/*
	jQuery('#downtime-calculator__close-btn2').click(function(){
      jQuery('.downtime-calculator__results').hide();     
    });
	*/
	
    /* If Per Week Tab is clicked */
    jQuery('#btn-tabs-week').click(function(){
      jQuery('.downtime-calculator__results').hide();
      jQuery('.btn-tabs').removeClass('active');
      jQuery('#btn-tabs-week').addClass('active');
      jQuery('#downtime-calculator__per-week').show();
    });

    /* If Dollar Per Week Tab is clicked */
    jQuery('#btn-tabs-dollars-week').click(function(){
      jQuery('.downtime-calculator__slide-four .downtime-calculator__results').hide();
      jQuery('.downtime-calculator__slide-four .btn-tabs').removeClass('active');
      jQuery('#btn-tabs-dollars-week').addClass('active');
      jQuery('#downtime-calculator__dollars-per-week').show();
      jQuery('.time').html('a week');
    });

    /* If Per Day Tab is clicked */
    jQuery('#btn-tabs-day').click(function(){
      jQuery('.downtime-calculator__results').hide();
      jQuery('.btn-tabs').removeClass('active');
      jQuery('#btn-tabs-day').addClass('active');
      jQuery('#downtime-calculator__per-day').show();
    });

    /* If Dollar Per Day Tab is clicked */
     jQuery('#btn-tabs-dollars-day').click(function(){
      jQuery('.downtime-calculator__slide-four .downtime-calculator__results').hide();
      jQuery('.downtime-calculator__slide-four .btn-tabs').removeClass('active');
      jQuery('#btn-tabs-dollars-day').addClass('active');
      jQuery('#downtime-calculator__dollars-per-day').show();
      jQuery('.time').html('a day');
    });

    /* If Dollar Per Hour Tab is clicked */
    jQuery('#btn-tabs-dollars-hour').click(function(){
      jQuery('.downtime-calculator__slide-four .downtime-calculator__results').hide();
      jQuery('.downtime-calculator__slide-four .btn-tabs').removeClass('active');
      jQuery('#btn-tabs-dollars-hour').addClass('active');
      jQuery('#downtime-calculator__dollars-per-hour').show();
      jQuery('.time').html('an hour');
    });

    /* If Per Hour Tab is clicked */
    jQuery('#btn-tabs-hour').click(function(){
      jQuery('.downtime-calculator__results').hide();
      jQuery('.btn-tabs').removeClass('active');
      jQuery('#btn-tabs-hour').addClass('active');
      jQuery('#downtime-calculator__per-hour').show();
    });
  });

  /* Drupal Behaviour */
  (function ($, Drupal) {
    'use strict';
    Drupal.behaviors.downtimeCalculator = {
      attach: function (context, settings) {

        /* If Per Day Tab is clicked */
        
      }
    };
  }(jQuery, Drupal));
  ;
  /**
  * @file
  * Video-grid.js initiallizes.
  */
  ;
  window.cookieconsent_options = {
    // The message shown by the plugin.
    message: drupalSettings.cookieconsent.message,
    // The text used on the dismiss button.
    dismiss: drupalSettings.cookieconsent.dismiss,
    // The text shown on the link to the cookie policy (requires the link option to also be set)
    learnMore: drupalSettings.cookieconsent.learnMore,
    // The url of your cookie policy. If it’s set to null, the link is hidden.
    link: drupalSettings.cookieconsent.link,
    // The element you want the Cookie Consent notification to be appended to. If null, the Cookie Consent plugin
    // is appended to the body.
    container: drupalSettings.cookieconsent.container,
    // The theme you wish to use. Can be any of the themes from the style directory, e.g. dark-top.
    // If you wish to use your own CSS instead, specify the URL of your CSS file. e.g. styles/my_custom_theme.css.
    // This can be a relative or absolute URL.
    // To stop Cookie Consent from loading CSS at all, specify false
    theme: drupalSettings.cookieconsent.theme,
    // The path for the consent cookie that Cookie Consent uses, to remember that users have consented to cookies.
    // Use to limit consent to a specific path within your website.
    path: drupalSettings.cookieconsent.path,
    // The domain for the consent cookie that Cookie Consent uses, to remember that users have consented to cookies.
    // Useful if your website uses multiple subdomains, e.g. if your script is hosted at www.example.com you might
    // override this to example.com, thereby allowing the same consent cookie to be read by subdomains
    // like foo.example.com.
    domain: drupalSettings.cookieconsent.domain,
    // The number of days Cookie Consent should store the user’s consent information for.
    expiryDays: drupalSettings.cookieconsent.expiry,
    // The target of the link to your cookie policy. Use to open a link in a new window, or specific frame, if you wish.
    target: drupalSettings.cookieconsent.target,
    markup: [
      '<div class="cc_banner-wrapper {{containerClasses}}">',
      drupalSettings.cookieconsent.markup,
      '</div>'
    ]
  };;
  /*! jquery.cookie v1.4.1 | MIT */
  !function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?a(require("jquery")):a(jQuery)}(function(a){function b(a){return h.raw?a:encodeURIComponent(a)}function c(a){return h.raw?a:decodeURIComponent(a)}function d(a){return b(h.json?JSON.stringify(a):String(a))}function e(a){0===a.indexOf('"')&&(a=a.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\"));try{return a=decodeURIComponent(a.replace(g," ")),h.json?JSON.parse(a):a}catch(b){}}function f(b,c){var d=h.raw?b:e(b);return a.isFunction(c)?c(d):d}var g=/\+/g,h=a.cookie=function(e,g,i){if(void 0!==g&&!a.isFunction(g)){if(i=a.extend({},h.defaults,i),"number"==typeof i.expires){var j=i.expires,k=i.expires=new Date;k.setTime(+k+864e5*j)}return document.cookie=[b(e),"=",d(g),i.expires?"; expires="+i.expires.toUTCString():"",i.path?"; path="+i.path:"",i.domain?"; domain="+i.domain:"",i.secure?"; secure":""].join("")}for(var l=e?void 0:{},m=document.cookie?document.cookie.split("; "):[],n=0,o=m.length;o>n;n++){var p=m[n].split("="),q=c(p.shift()),r=p.join("=");if(e&&e===q){l=f(r,g);break}e||void 0===(r=f(r))||(l[q]=r)}return l};h.defaults={},a.removeCookie=function(b,c){return void 0===a.cookie(b)?!1:(a.cookie(b,"",a.extend({},c,{expires:-1})),!a.cookie(b))}});;
  /**
   * @file
   * Handles AJAX login and register events.
   */

  (function ($, Drupal, drupalSettings) {

      'use strict';

  	/**
  	 * @type {{attach: Drupal.behaviors.gigyaRassDynamicSession.attach}}
  	 *
  	 * @property drupalSettings.gigyaExtra.session_type
  	 */
  	Drupal.behaviors.gigyaRassDynamicSession = {
  		attach: function (context, settings) {
              if ("dynamic" === drupalSettings.gigyaExtra.session_type) {
  				Drupal.ajax({url: drupalSettings.path.baseUrl + 'gigya/extcookie'}).execute();
              }
          }
      };

  	/* For Internet Explorer */
  	if (!String.prototype.startsWith) {
  		String.prototype.startsWith = function (searchString, position) {
  			position = position || 0;
  			return this.indexOf(searchString, position) === position;
  		};
  	}

  	/**
  	 * Invoked using InvokeCommand by Drupal's controller
  	 *
  	 * @param redirectTarget
  	 *
  	 * @property gigya.setSSOToken
  	 */
  	jQuery.fn.loginRedirect = function (redirectTarget) {
  		/**
  		 * @var bool sendSetSSOToken	Should be set in Gigya's global configuration.
  		 * 								Set this to True if you would like setSSOToken to be called
  		 * 								(a redirect to Gigya to set the site's cookies, for browsers that do not support 3rd party cookies)
  		 */

  		if (!redirectTarget.startsWith('http'))
  			redirectTarget = window.location.origin + drupalSettings.path.baseUrl + redirectTarget;

  		if (typeof sendSetSSOToken === 'undefined' || sendSetSSOToken === false)
  			location.replace(redirectTarget);
  		else if (sendSetSSOToken === true)
  			gigya.setSSOToken({redirectURL: redirectTarget});
  	};

  	jQuery.fn.logoutRedirect = function (redirectTarget) {
  		if (!redirectTarget.startsWith('http'))
  			redirectTarget = window.location.origin + drupalSettings.path.baseUrl + redirectTarget;

  		document.location = redirectTarget;
  	};

  	/**
  	 * @property drupalSettings.gigya.loginUIParams
  	 * @property gigya.services.socialize.showLoginUI
  	 */
      var initLoginUI = function () {
          if (typeof drupalSettings.gigya.loginUIParams !== 'undefined') {
              $.each(drupalSettings.gigya.loginUIParams, function (index, value) {
                  value.context = {id: value.containerID};
                  gigya.services.socialize.showLoginUI(value);
              });
          }
      };

      var getRememberMeStatus = function(res) {
  		var remember = false;
  		/* Pull remember me status from the group context */
  		if (typeof res.groupContext !== 'undefined') {
  			var groupRemember = JSON.parse(res.groupContext).remember;
  			if (typeof groupRemember !== 'undefined') {
  				remember = groupRemember;
  			}
  		}
  		/* "Remember Me" clicked on the current site always overrides the group context remember */
  		if (typeof res.remember !== 'undefined') {
  			remember = res.remember;
  		}

  		return remember;
  	};

  	/**
  	 * @param res
  	 *
  	 * @property gigya.setGroupContext
  	 * @property res.groupContext
  	 */
  	var onLoginHandler = function (res) {
  		var remember = getRememberMeStatus(res);
  		/* Propagate Remember Me status to the SSO group */
  		gigya.setGroupContext({
  			"remember": remember
  		});

  		var data = {
              "uid": res.UID,
              "uid_sig": res.UIDSignature,
              "sig_timestamp": res.signatureTimestamp,
  			"remember": remember
          };

          var ajaxSettings = {
              url: drupalSettings.path.baseUrl + 'gigya/raas-login',
              submit: data
          };

          var myAjaxObject = Drupal.ajax(ajaxSettings);
          myAjaxObject.execute();
      };

      var profileUpdated = function (data) {
  		if (data.response.errorCode === 0) {
              var gigyaData = {
                  UID: data.response.UID,
                  UIDSignature: data.response.UIDSignature,
                  signatureTimestamp: data.response.signatureTimestamp
              };

              var ajaxSettings = {
                  url: drupalSettings.path.baseUrl + 'gigya/raas-profile-update',
  				submit: {gigyaData: gigyaData}
              };

              var myAjaxObject = Drupal.ajax(ajaxSettings);
              myAjaxObject.execute();
          }
      };

      var checkLogout = function () {
          var logoutCookie = gigya.utils.cookie.get('Drupal.visitor.gigya');
  		    if (logoutCookie === 'gigyaLogOut') {
              gigya.accounts.logout();
              gigya.utils.cookie.remove('Drupal.visitor.gigya');
          }
      };

  	/**
  	 * @property drupalSettings.path.baseUrl
  	 * @property myAjaxObject.execute()
  	 */
  	var onLogoutHandler = function () {
  		var data = {};

  		var ajaxSettings = {
  			url: drupalSettings.path.baseUrl + 'gigya/raas-logout',
  			submit: data
  		};
  		var myAjaxObject = Drupal.ajax(ajaxSettings);
  		myAjaxObject.execute();
      };

  	/**
  	 * @property gigya.accounts.showScreenSet
  	 * @property drupalSettings.gigya.enableRaaS
  	 * @property drupalSettings.gigya.raas
  	 * @property drupalSettings.gigya.raas.login
  	 */
      var initRaaS = function () {
          if (drupalSettings.gigya.enableRaaS) {
          	var id;
              $('.gigya-raas-login').once('gigya-raas').click(function (e) {
                  e.preventDefault();
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.login);
                  drupalSettings.gigya.raas.linkId = $(this).attr('id');
              });
              $('.gigya-raas-reg').once('gigya-raas').click(function (e) {
                  e.preventDefault();
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.register);
                  drupalSettings.gigya.raas.linkId = $(this).attr('id');
              });
              $('.gigya-raas-prof, a[href="/user"]').once('gigya-raas').click(function (e) {
                  e.preventDefault();
                  drupalSettings.gigya.raas.profile.onAfterSubmit = profileUpdated;
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.profile);
              });
              var loginDiv = $('#gigya-raas-login-div');
              if (loginDiv.length > 0 && (typeof drupalSettings.gigya.raas.login !== 'undefined')) {
  				id = loginDiv.eq(0).attr('id');
                  drupalSettings.gigya.raas.login.containerID = id;
                  drupalSettings.gigya.raas.linkId = id;
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.login);
              }
              var regDiv = $('#gigya-raas-register-div');
              if (regDiv.length > 0 && (typeof drupalSettings.gigya.raas.register !== 'undefined')) {
  				id = regDiv.eq(0).attr('id');
                  drupalSettings.gigya.raas.register.containerID = id;
                  drupalSettings.gigya.raas.linkId = id;
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.register);
              }
              var profDiv = $('#gigya-raas-profile-div');
              if ((profDiv.length > 0) && (typeof drupalSettings.gigya.raas.profile !== 'undefined')) {
                  drupalSettings.gigya.raas.profile.containerID = profDiv.eq(0).attr('id');
                  drupalSettings.gigya.raas.profile.onAfterSubmit = profileUpdated;
                  gigya.accounts.showScreenSet(drupalSettings.gigya.raas.profile);
              }
          }
      };

  	/**
  	 * @property gigya.accounts.showScreenSet
  	 * @property drupalSettings.gigya.raas.customScreenSets
  	 */
  	var initCustomScreenSet = function () {
  		if (drupalSettings.gigya.enableRaaS) {
  			var customScreenSets = drupalSettings.gigya.raas.customScreenSets;

  			/**
  			 * @property custom_screenset.display_type
  			 * @property custom_screenset.link_id
  			 * @property custom_screenset.container_id
  			 * @property custom_screenset.desktop_screenset
  			 * @property custom_screenset.mobile_screenset
  			 * @property custom_screenset.sync_data
  			 */
  			customScreenSets.forEach(function (custom_screenset) {
  				if (typeof custom_screenset.display_type !== 'undefined') {
  					var screenset_params = {
  						screenSet: custom_screenset.desktop_screenset,
  						mobileScreenSet: custom_screenset.mobile_screenset
  					};
  					if (parseInt(custom_screenset.sync_data) === 1)
  						screenset_params['onAfterSubmit'] = processFieldMapping;

  					if (custom_screenset.display_type === 'popup') {
  						$('#' + custom_screenset.link_id).once('gigya-raas').click(function (e) {
  							e.preventDefault();
  							gigya.accounts.showScreenSet(screenset_params);
  							drupalSettings.gigya.raas.linkId = $(this).attr('id');
  						});
  					} else if (custom_screenset.display_type === 'embed') {
  						screenset_params['containerID'] = custom_screenset.container_id;
  						gigya.accounts.showScreenSet(screenset_params);
  					}
  				}
  			});
  		}
  	};

  	var processFieldMapping = function (data) {
  		var gigyaData = {
  			UID: data.response.UID,
  			UIDSignature: data.response.UIDSignature,
  			signatureTimestamp: data.response.signatureTimestamp
  		};
  		var ajaxSettings = {
  			url: drupalSettings.path.baseUrl + 'gigya/raas-process-fieldmapping',
  			submit: {gigyaData: gigyaData}
  		};
  		var myAjaxObject = Drupal.ajax(ajaxSettings);
  		myAjaxObject.execute();
  	};

      var init = function () {
          if (drupalSettings.gigya.enableRaaS) {
              gigyaHelper.addGigyaFunctionCall('accounts.addEventHandlers', {
                  onLogin: onLoginHandler,
                  onLogout: onLogoutHandler
              });
          }

          drupalSettings.gigya.isRaasInit = true;
      };

  	/**
  	 * @type {{attach: Drupal.behaviors.gigyaRaasInit.attach}}
  	 *
  	 * @param context
  	 * @param settings
  	 *
  	 * @property Drupal.behaviors
  	 */
  	Drupal.behaviors.gigyaRaasInit = {
          attach: function (context, settings) {
              if (!('isRaasInit' in drupalSettings.gigya)) {
  				/**
  				 * @param serviceName
  				 */
  				window.onGigyaServiceReady = function (serviceName) {
                      checkLogout();
                      gigyaHelper.runGigyaCmsInit();
                      initLoginUI();
                      initRaaS();
  					initCustomScreenSet();
                  };
                  init();
              }
          }
      };

  })(jQuery, Drupal, drupalSettings);;
  /**
   * @file
   * Improved multi select module JS library.
   */

  /**
   * Attaches improved multi select.
   */

  (function ($, Drupal) {
    'use strict';

    Drupal.behaviors.improved_multi_select = {

      /**
       * Detaches registered behaviors from a page element.
       *
       * @param {HTMLDocument|HTMLElement} [context=document]
       *   An element to detach behaviors from.
       * @param {object} [settings=drupalSettings]
       *   An object containing settings for the current context.
       * @param {string} [trigger='unload']
       *   A string containing what's causing the behaviors to be detached.
       */
      detach: function (context, settings, trigger) {
        const options = settings.improved_multi_select;

        // Unbind listeners.
        $('.improvedselect_filter', context).off('input');
        $('.improvedselect .add', context).off('click');
        $('.improvedselect .del', context).off('click');
        $('.improvedselect .add_all', context).off('click');
        $('.improvedselect .del_all', context).off('click');
        $('.improvedselect .move_up', context).off('click');
        $('.improvedselect .move_down', context).off('click');

        // Remove added elements.
        options.selectors.forEach(function (selector) {
          $(selector, context).once('improvedselect').each(function () {
            let $select = $(this);
            let imsSelectId = $select.attr('id');

            // Prevent duplicates on AJAX.
            $('#improvedselect-' + imsSelectId).remove();
            $('#' + imsSelectId + '-cloned').remove();
          });
        });
      },

      /**
       * Attach improved multi select.
       *
       * @param {Element} context
       *   The context for attaching the behavior.
       * @param {object} settings
       *   Options object.
       */
      attach: function (context, settings) {

        // Add placeholder text in the search box
        $(document).ready(function () {
          let searchBox = $('input.improvedselect_filter');
          if (searchBox && settings.improved_multi_select && settings.improved_multi_select.placeholder_text) {
            searchBox.attr("placeholder", settings.improved_multi_select.placeholder_text);
          }
        });

        if (!settings.improved_multi_select || !settings.improved_multi_select.selectors) {
          // Let other scripts know improvedSelect has been attached.
          $.event.trigger('improvedMultiSelectAttached');

          return;
        }

        const options = settings.improved_multi_select;

        options.selectors.forEach(function (selector) {
          improvedselectAttach(selector, options, context);
        });

        $('.improvedselect_filter', context).bind('input', function () {
          improvedselectFilter($(this).attr('sid'), options, context);
        });

        // Add selected items.
        $('.improvedselect .add', context).click(function () {
          let sid = $(this).attr('sid');
          $('#improvedselect-' + sid + ' .improvedselect_all .selected', context).each(function () {
            let $opt = $(this);
            $opt.removeClass('selected');
            improvedselectUpdateGroupVisibility($opt, 1);
            $('#improvedselect-' + sid + ' .improvedselect_sel', context).append($opt);
          });
          improvedselectUpdate(sid, context);
        });

        // Remove selected items.
        $('.improvedselect .del', context).click(function () {
          let sid = $(this).attr('sid');
          $('#improvedselect-' + sid + ' .improvedselect_sel .selected', context).each(function () {
            let $opt = $(this);
            $opt.removeClass('selected');
            $('#improvedselect-' + sid + ' .improvedselect_all', context).append($opt);
            improvedselectUpdateGroupVisibility($opt, 0);
          });
          // Force re-filtering.
          $('#improvedselect-' + sid + ' .improvedselect_filter', context).attr('prev', '');
          // Re-filtering will handle the rest.
          improvedselectFilter(sid, options, context);
          improvedselectUpdate(sid, context);
        });

        // Add all items.
        $('.improvedselect .add_all', context).click(function () {
          let sid = $(this).attr('sid');
          $('#improvedselect-' + sid + ' .improvedselect_all li[isgroup!=isgroup]', context).each(function () {
            let $opt = $(this);
            if ($opt.css('display') !== 'none') {
              $opt.removeClass('selected');
              improvedselectUpdateGroupVisibility($opt, 1);
              $('#improvedselect-' + sid + ' .improvedselect_sel', context).append($opt);
            }
          });
          improvedselectUpdate(sid, context);
        });

        // Remove all items.
        $('.improvedselect .del_all', context).click(function () {
          let sid = $(this).attr('sid');
          $('#improvedselect-' + sid + ' .improvedselect_sel li', context).each(function () {
            let $opt = $(this);
            $opt.removeClass('selected');
            $('#improvedselect-' + sid + ' .improvedselect_all', context).append($opt);
            improvedselectUpdateGroupVisibility($opt, 0);
          });
          // Force re-filtering.
          $('#improvedselect-' + sid + ' .improvedselect_filter', context).attr('prev', '');
          // Re-filtering will handle the rest.
          improvedselectFilter(sid, options, context);
          improvedselectUpdate(sid, context);
        });

        // Move selected items up.
        $('.improvedselect .move_up', context).click(function () {
          let sid = $(this).attr('sid');
          $('#improvedselect-' + sid + ' .improvedselect_sel .selected', context).each(function () {
            let $selected = $(this);
            // Don't move selected items past other selected items or there will
            // be problems when moving multiple items at once.
            $selected.prev(':not(.selected)').before($selected);
          });
          improvedselectUpdate(sid, context);
        });

        // Move selected items down.
        $('.improvedselect .move_down', context).click(function () {
          let sid = $(this).attr('sid');
          // Run through the selections in reverse, otherwise problems occur
          // when moving multiple items at once.
          $($('#improvedselect-' + sid + ' .improvedselect_sel .selected', context).get().reverse()).each(function () {
            let $selected = $(this);
            // Don't move selected items past other selected items or there will
            // be problems when moving multiple items at once.
            $selected.next(':not(.selected)').after($selected);
          });
          improvedselectUpdate(sid, context);
        });
        // Let other scripts know improvedSelect was initialized.
        $.event.trigger('improvedMultiSelectInitialized', [$(this)]);

        // Let other scripts know improvedSelect has been attached.
        $.event.trigger('improvedMultiSelectAttached');
      }
    };

    /**
     * Filter the all options list.
     *
     * @param {String} sid
     *   Select Id.
     * @param {object} options
     *   Options object.
     * @param {Element} context
     *   The context for attaching the behavior.
     */
    function improvedselectFilter(sid, options, context) {
      let $filter = $('#improvedselect-' + sid + ' .improvedselect_filter', context);
      // Get current selected group.
      let $selectedGroup = $('#improvedselect-' + sid + ' .improvedselect_tabs li.selected:not(.all) a', context);
      let text = $filter.val();
      let pattern;
      let regex;
      let words;

      if (text.length && text !== $filter.attr('prev')) {
        $filter.attr('prev', text);

        // Do not allow JavaScript regular expressions.
        if (!options.js_regex) {
          text = text.replace(/[[\]^$.\\()|?*+]/g, "\\$&").replace(/{([0-9]+,?[0-9]*)}/g, '\\{$1\\}');
        }

        switch (options.filtertype) {
          case 'partial':
          default:
            pattern = text;
            break;

          case 'exact':
            pattern = '^' + text + '$';
            break;

          case 'anywords':
            words = text.split(' ');
            pattern = '';
            for (let i = 0; i < words.length; i++) {
              if (words[i]) {
                pattern += (pattern) ? '|\\b' + words[i] + '\\b' : '\\b' + words[i] + '\\b';
              }
            }
            break;

          case 'anywords_partial':
            words = text.split(' ');
            pattern = '';
            for (let i = 0; i < words.length; i++) {
              if (words[i]) {
                pattern += (pattern) ? '|' + words[i] + '' : words[i];
              }
            }
            break;

          case 'allwords':
            words = text.split(' ');
            pattern = '^';
            // Add a lookahead for each individual word.
            // Lookahead is used because the words can match in any order
            // so this makes it simpler and faster.
            for (let i = 0; i < words.length; i++) {
              if (words[i]) {
                pattern += '(?=.*?\\b' + words[i] + '\\b)';
              }
            }
            break;

          case 'allwords_partial':
            words = text.split(' ');
            pattern = '^';
            // Add a lookahead for each individual word.
            // Lookahead is used because the words can match in any order
            // so this makes it simpler and faster.
            for (let i = 0; i < words.length; i++) {
              if (words[i]) {
                pattern += '(?=.*?' + words[i] + ')';
              }
            }
            break;
        }

        // Hide JS error if a regular expression isn't completed yet.
        try {
          regex = new RegExp(pattern, 'i');
        }
        catch (e) {
          return;
        }

        $('#improvedselect-' + sid + ' .improvedselect_all li', context).each(function () {
          let $opt = $(this);
          if ($opt.attr('isgroup') !== 'isgroup') {
            let str = $opt.text();
            if (str.match(regex) && (!$selectedGroup.length || $selectedGroup.text() === $opt.attr('group'))) {
              $opt.show();
              if ($opt.attr('group')) {
                // If a group is selected we don't need to show groups.
                if (!$selectedGroup.length) {
                  $opt.siblings('li[isgroup="isgroup"][so="---' + $opt.attr('group') + '---"]').show();
                }
                else {
                  $opt.siblings('li[isgroup="isgroup"][so="---' + $opt.attr('group') + '---"]').hide();
                }
              }
            }
            else {
              $opt.hide();
              if ($opt.attr('group')) {
                if ($opt.siblings('li[isgroup!="isgroup"][group="' + $opt.attr('group') + '"]:visible').length === 0) {
                  $opt.siblings('li[isgroup="isgroup"][so="---' + $opt.attr('group') + '---"]').hide();
                }
              }
            }
          }
        });
      }
      else {
        if (!text.length) {
          $filter.attr('prev', '');
        }
        $('#improvedselect-' + sid + ' .improvedselect_all li', context).each(function () {
          let $opt = $(this);
          if ($opt.attr('isgroup') !== 'isgroup') {
            if (!$selectedGroup.length || $selectedGroup.text() === $opt.attr('group')) {
              $opt.show();
            }
            else {
              $opt.hide();
            }
            improvedselectUpdateGroupVisibility($opt, 0);
          }
        });
      }
    }

    /**
     * Contains attach logic for a select element.
     *
     * @param {String} selector
     *   jQuery selector.
     * @param {object} options
     *   Options object.
     * @param {Element} context
     *   The context for attaching the behavior.
     */
    function improvedselectAttach(selector, options, context) {
      $(selector, context).once('improvedselect').each(function () {
        let $select = $(this);
        let moveButtons = '';
        let imsSelectId = $select.attr('id');
        let $cloned_select = null;

        if (options.orderable) {
          // If the select is orderable then we clone the original select to keep
          // opt groups.
          $cloned_select = $select.clone();
          $cloned_select.attr('id', imsSelectId + '-cloned');
          $cloned_select.attr('name', 'cloned-' + $select.attr('name'));
          $cloned_select.appendTo($select.parent()).hide();
          // Move button markup to add to the widget.
          moveButtons = '<span class="move_up" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_moveup) + '</span>' +
              '<span class="move_down" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_movedown) + '</span>';
        }

        $select.parent().append(
            '<div class="improvedselect" sid="' + imsSelectId + '" id="improvedselect-' + imsSelectId + '">' +
            '<div class="improvedselect-text-wrapper">' +
            '<input type="text" class="improvedselect_filter" sid="' + imsSelectId + '" prev="" />' +
            '</div><ul class="improvedselect_sel"></ul><ul class="improvedselect_all"></ul><div class="improvedselect_control">' +
            '<span class="add" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_add) + '</span>' +
            '<span class="del" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_del) + '</span>' +
            '<span class="add_all" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_addall) + '</span>' +
            '<span class="del_all" sid="' + imsSelectId + '">' + Drupal.checkPlain(options.buttontext_delall) + '</span>' +
            moveButtons +
            '</div><div class="clear"></div></div>');

        if ($select.find('optgroup').has('option').length > 0) {
          $select.parent().find('.improvedselect').addClass('has_group');
          // Build groups.
          $('#improvedselect-' + imsSelectId + ' .improvedselect-text-wrapper', context)
              .after('<div class="improvedselect_tabs-wrapper" sid="' + imsSelectId + '"><ul class="improvedselect_tabs"></ul></div>');
          $select.find('optgroup').has('option').each(function () {
            $('#improvedselect-' + imsSelectId + ' .improvedselect_tabs', context)
                .append('<li><a href="">' + $(this).attr('label') + '</a></li>');
          });
          // Show all groups option.
          $('#improvedselect-' + imsSelectId + ' .improvedselect_tabs', context)
              .prepend('<li class="all"><a href="">' + Drupal.t('All') + '</a></li>');
          // Select group.
          $('#improvedselect-' + imsSelectId + ' .improvedselect_tabs li a', context).click(function (e) {
            let $group = $(this);
            let sid = $group.parent().parent().parent().attr('sid');
            $('#improvedselect-' + imsSelectId + ' .improvedselect_tabs li.selected', context).removeClass('selected').find('a').unwrap();
            $group.wrap('<div>').parents('li').first().addClass('selected');

            // Any existing selections in the all list need to be unselected
            // if they aren't part of the newly selected group.
            if (!$group.hasClass('all')) {
              $('#improvedselect-' + imsSelectId + ' .improvedselect_all li.selected[group!="' + $group.text() + '"]', context).removeClass('selected');
            }

            // Clear the filter if we have to.
            if (options.groupresetfilter) {
              // Clear filter box.
              $('#improvedselect-' + imsSelectId + ' .improvedselect_filter', context).val('');
            }
            // Force re-filtering.
            $('#improvedselect-' + imsSelectId + ' .improvedselect_filter', context).attr('prev', '');
            // Re-filtering will handle the rest.
            improvedselectFilter(sid, options, context);
            e.preventDefault();
          });
          // Select all to begin.
          $('#improvedselect-' + imsSelectId + ' .improvedselect_tabs li.all a', context).click();
        }

        $select.find('option, optgroup').each(function () {
          let $opt = $(this);
          let group = '';
          if ($opt[0].tagName === 'OPTGROUP') {
            if ($opt.has('option').length) {
              $('#improvedselect-' + imsSelectId + ' .improvedselect_all', context)
                  .append('<li isgroup="isgroup" so="---' + $opt.attr('label') + '---">--- ' + $opt.attr('label') + ' ---</li>');
            }
          }
          else {
            group = $opt.parent('optgroup').attr('label');
            if (group) {
              group = ' group="' + group + '"';
            }
            else {
              group = '';
            }
            if ($opt.attr('value') !== '_none') {
              if ($opt.attr('selected')) {
                $('#improvedselect-' + imsSelectId + ' .improvedselect_sel', context)
                    .append('<li so="' + $opt.attr('value') + '"' + group + '>' + $opt.html() + '</li>');
              }
              else {
                $('#improvedselect-' + imsSelectId + ' .improvedselect_all', context)
                    .append('<li so="' + $opt.attr('value') + '"' + group + '>' + $opt.html() + '</li>');
              }
            }
          }
        });

        $('#improvedselect-' + imsSelectId + ' .improvedselect_sel li, #improvedselect-' + imsSelectId + ' .improvedselect_all li[isgroup!="isgroup"]', context).click(function () {
          $(this).toggleClass('selected');
        });

        $select.hide();

        // Double click feature request.
        $('#improvedselect-' + imsSelectId + ' .improvedselect_sel li, #improvedselect-' + imsSelectId + ' .improvedselect_all li[isgroup!="isgroup"]', context).dblclick(function () {
          // Store selected items.
          let selected = $(this).parent().find('li.selected');
          let current_class = $(this).parent().attr('class');
          // Add item.
          if (current_class === 'improvedselect_all') {
            $(this).parent().find('li.selected').removeClass('selected');
            $(this).addClass('selected');
            $(this).parent().parent().find('.add').click();
          }
          // Remove item.
          else {
            $(this).parent().find('li.selected').removeClass('selected');
            $(this).addClass('selected');
            $(this).parent().parent().find('.del').click();
          }
          // Restore selected items.
          if (selected.length) {
            for (let k = 0; k < selected.length; k++) {
              if ($(selected[k]).parent().attr('class') === current_class) {
                $(selected[k]).addClass('selected');
              }
            }
          }
        });

        // Set the height of the select fields based on the height of the
        // parent, otherwise it can end up with a lot of wasted space.
        $('.improvedselect_sel, .improvedselect_all').each(function () {
          if ($(this).parent().height() > 0) {
            $(this).height($(this).parent().height() - 35);
          }
          // @todo: Element is hidden - we can't detect its height.
        });
      });
    }

    /**
     * Update the visibility of an option's group.
     *
     * @param {jQuery} $opt
     *   A jQuery object of a select option.
     * @param {Number} numItems
     *   How many items should be considered an empty group. Generally zero or one
     *   depending on if an item has been or is going to be removed or added.
     */
    function improvedselectUpdateGroupVisibility($opt, numItems) {
      let $selectedGroup = $opt.parents('.improvedselect').first().find('.improvedselect_tabs li.selected:not(.all) a');

      // Don't show groups if a group is selected.
      if ($opt.parent().children('li[isgroup!="isgroup"][group="' + $opt.attr('group') + '"]:visible').length <= numItems || $selectedGroup.length) {
        $opt.siblings('li[isgroup="isgroup"][so="---' + $opt.attr('group') + '---"]').hide();
      }
      else {
        $opt.siblings('li[isgroup="isgroup"][so="---' + $opt.attr('group') + '---"]').show();
      }
    }

    /**
     * Updates the select values by its id.
     *
     * @param {string} sid
     *   Select Id.
     * @param {Element} context
     *   The context for attaching the behavior.
     */
    function improvedselectUpdate(sid, context) {
      // If we have sorting enabled, make sure we have the results sorted.
      let $select = $('#' + sid);
      let $cloned_select = $('#' + sid + '-cloned');

      if ($cloned_select.length) {
        $select.find('option, optgroup').remove();
        $cloned_select.find('option:selected').prop('selected', false);
        $('#improvedselect-' + sid + ' .improvedselect_sel li', context).each(function () {
          let $li = $(this);
          $select.append($('<option></option>').attr('value', $li.attr('so')).prop('selected', true).text($li.text()));
          $('#' + sid + '-cloned [value="' + $(this).attr('so') + '"]', context).prop('selected', true);
        });
      }
      else {
        $select.find('option:selected').prop('selected', false);
        $('#improvedselect-' + sid + ' .improvedselect_sel li', context).each(function () {
          $('#' + sid + ' [value="' + $(this).attr('so') + '"]', context).prop('selected', true);
        });
      }

      $select.find('option, optgroup').each(function () {
        let $opt = $(this);
        if ($opt[0].tagName === 'OPTGROUP') {
          if ($opt.has('option').length) {
            $('#improvedselect-' + sid + ' .improvedselect_all', context).append($('#improvedselect-' + sid + ' .improvedselect_all [so="---' + $opt.attr('label') + '---"]', context));
          }
        }
        else {
          // When using reordering, the options will be from the cloned select,
          // meaning that there will be none selected, which means that items
          // in the selected list will not be reordered, which is what we want.
          if ($opt.attr('selected')) {
            $('#improvedselect-' + sid + ' .improvedselect_sel', context).append($('#improvedselect-' + sid + ' .improvedselect_sel [so="' + $opt.attr('value') + '"]', context));
          }
          else {
            $('#improvedselect-' + sid + ' .improvedselect_all', context).append($('#improvedselect-' + sid + ' .improvedselect_all [so="' + $opt.attr('value') + '"]', context));
          }
        }
      });
      // Don't use the $select variable here as it might be the clone.
      // Tell the ajax system the select has changed.
      $('#' + sid, context).trigger('change');
    }

  })(jQuery, Drupal);
  ;
  /*!
   * SmartMenus jQuery Plugin - v1.1.0 - September 17, 2017
   * http://www.smartmenus.org/
   *
   * Copyright Vasil Dinkov, Vadikom Web Ltd.
   * http://vadikom.com
   *
   * Licensed MIT
   */

  (function(factory) {
  	if (typeof define === 'function' && define.amd) {
  		// AMD
  		define(['jquery'], factory);
  	} else if (typeof module === 'object' && typeof module.exports === 'object') {
  		// CommonJS
  		module.exports = factory(require('jquery'));
  	} else {
  		// Global jQuery
  		factory(jQuery);
  	}
  } (function($) {

  	var menuTrees = [],
  		mouse = false, // optimize for touch by default - we will detect for mouse input
  		touchEvents = 'ontouchstart' in window, // we use this just to choose between toucn and pointer events, not for touch screen detection
  		mouseDetectionEnabled = false,
  		requestAnimationFrame = window.requestAnimationFrame || function(callback) { return setTimeout(callback, 1000 / 60); },
  		cancelAnimationFrame = window.cancelAnimationFrame || function(id) { clearTimeout(id); },
  		canAnimate = !!$.fn.animate;

  	// Handle detection for mouse input (i.e. desktop browsers, tablets with a mouse, etc.)
  	function initMouseDetection(disable) {
  		var eNS = '.smartmenus_mouse';
  		if (!mouseDetectionEnabled && !disable) {
  			// if we get two consecutive mousemoves within 2 pixels from each other and within 300ms, we assume a real mouse/cursor is present
  			// in practice, this seems like impossible to trick unintentianally with a real mouse and a pretty safe detection on touch devices (even with older browsers that do not support touch events)
  			var firstTime = true,
  				lastMove = null,
  				events = {
  					'mousemove': function(e) {
  						var thisMove = { x: e.pageX, y: e.pageY, timeStamp: new Date().getTime() };
  						if (lastMove) {
  							var deltaX = Math.abs(lastMove.x - thisMove.x),
  								deltaY = Math.abs(lastMove.y - thisMove.y);
  		 					if ((deltaX > 0 || deltaY > 0) && deltaX <= 2 && deltaY <= 2 && thisMove.timeStamp - lastMove.timeStamp <= 300) {
  								mouse = true;
  								// if this is the first check after page load, check if we are not over some item by chance and call the mouseenter handler if yes
  								if (firstTime) {
  									var $a = $(e.target).closest('a');
  									if ($a.is('a')) {
  										$.each(menuTrees, function() {
  											if ($.contains(this.$root[0], $a[0])) {
  												this.itemEnter({ currentTarget: $a[0] });
  												return false;
  											}
  										});
  									}
  									firstTime = false;
  								}
  							}
  						}
  						lastMove = thisMove;
  					}
  				};
  			events[touchEvents ? 'touchstart' : 'pointerover pointermove pointerout MSPointerOver MSPointerMove MSPointerOut'] = function(e) {
  				if (isTouchEvent(e.originalEvent)) {
  					mouse = false;
  				}
  			};
  			$(document).on(getEventsNS(events, eNS));
  			mouseDetectionEnabled = true;
  		} else if (mouseDetectionEnabled && disable) {
  			$(document).off(eNS);
  			mouseDetectionEnabled = false;
  		}
  	}

  	function isTouchEvent(e) {
  		return !/^(4|mouse)$/.test(e.pointerType);
  	}

  	// returns a jQuery on() ready object
  	function getEventsNS(events, eNS) {
  		if (!eNS) {
  			eNS = '';
  		}
  		var eventsNS = {};
  		for (var i in events) {
  			eventsNS[i.split(' ').join(eNS + ' ') + eNS] = events[i];
  		}
  		return eventsNS;
  	}

  	$.SmartMenus = function(elm, options) {
  		this.$root = $(elm);
  		this.opts = options;
  		this.rootId = ''; // internal
  		this.accessIdPrefix = '';
  		this.$subArrow = null;
  		this.activatedItems = []; // stores last activated A's for each level
  		this.visibleSubMenus = []; // stores visible sub menus UL's (might be in no particular order)
  		this.showTimeout = 0;
  		this.hideTimeout = 0;
  		this.scrollTimeout = 0;
  		this.clickActivated = false;
  		this.focusActivated = false;
  		this.zIndexInc = 0;
  		this.idInc = 0;
  		this.$firstLink = null; // we'll use these for some tests
  		this.$firstSub = null; // at runtime so we'll cache them
  		this.disabled = false;
  		this.$disableOverlay = null;
  		this.$touchScrollingSub = null;
  		this.cssTransforms3d = 'perspective' in elm.style || 'webkitPerspective' in elm.style;
  		this.wasCollapsible = false;
  		this.init();
  	};

  	$.extend($.SmartMenus, {
  		hideAll: function() {
  			$.each(menuTrees, function() {
  				this.menuHideAll();
  			});
  		},
  		destroy: function() {
  			while (menuTrees.length) {
  				menuTrees[0].destroy();
  			}
  			initMouseDetection(true);
  		},
  		prototype: {
  			init: function(refresh) {
  				var self = this;

  				if (!refresh) {
  					menuTrees.push(this);

  					this.rootId = (new Date().getTime() + Math.random() + '').replace(/\D/g, '');
  					this.accessIdPrefix = 'sm-' + this.rootId + '-';

  					if (this.$root.hasClass('sm-rtl')) {
  						this.opts.rightToLeftSubMenus = true;
  					}

  					// init root (main menu)
  					var eNS = '.smartmenus';
  					this.$root
  						.data('smartmenus', this)
  						.attr('data-smartmenus-id', this.rootId)
  						.dataSM('level', 1)
  						.on(getEventsNS({
  							'mouseover focusin': $.proxy(this.rootOver, this),
  							'mouseout focusout': $.proxy(this.rootOut, this),
  							'keydown': $.proxy(this.rootKeyDown, this)
  						}, eNS))
  						.on(getEventsNS({
  							'mouseenter': $.proxy(this.itemEnter, this),
  							'mouseleave': $.proxy(this.itemLeave, this),
  							'mousedown': $.proxy(this.itemDown, this),
  							'focus': $.proxy(this.itemFocus, this),
  							'blur': $.proxy(this.itemBlur, this),
  							'click': $.proxy(this.itemClick, this)
  						}, eNS), 'a');

  					// hide menus on tap or click outside the root UL
  					eNS += this.rootId;
  					if (this.opts.hideOnClick) {
  						$(document).on(getEventsNS({
  							'touchstart': $.proxy(this.docTouchStart, this),
  							'touchmove': $.proxy(this.docTouchMove, this),
  							'touchend': $.proxy(this.docTouchEnd, this),
  							// for Opera Mobile < 11.5, webOS browser, etc. we'll check click too
  							'click': $.proxy(this.docClick, this)
  						}, eNS));
  					}
  					// hide sub menus on resize
  					$(window).on(getEventsNS({ 'resize orientationchange': $.proxy(this.winResize, this) }, eNS));

  					if (this.opts.subIndicators) {
  						this.$subArrow = $('<span/>').addClass('sub-arrow');
  						if (this.opts.subIndicatorsText) {
  							this.$subArrow.html(this.opts.subIndicatorsText);
  						}
  					}

  					// make sure mouse detection is enabled
  					initMouseDetection();
  				}

  				// init sub menus
  				this.$firstSub = this.$root.find('ul').each(function() { self.menuInit($(this)); }).eq(0);

  				this.$firstLink = this.$root.find('a').eq(0);

  				// find current item
  				if (this.opts.markCurrentItem) {
  					var reDefaultDoc = /(index|default)\.[^#\?\/]*/i,
  						reHash = /#.*/,
  						locHref = window.location.href.replace(reDefaultDoc, ''),
  						locHrefNoHash = locHref.replace(reHash, '');
  					this.$root.find('a').each(function() {
  						var href = this.href.replace(reDefaultDoc, ''),
  							$this = $(this);
  						if (href == locHref || href == locHrefNoHash) {
  							$this.addClass('current');
  							if (self.opts.markCurrentTree) {
  								$this.parentsUntil('[data-smartmenus-id]', 'ul').each(function() {
  									$(this).dataSM('parent-a').addClass('current');
  								});
  							}
  						}
  					});
  				}

  				// save initial state
  				this.wasCollapsible = this.isCollapsible();
  			},
  			destroy: function(refresh) {
  				if (!refresh) {
  					var eNS = '.smartmenus';
  					this.$root
  						.removeData('smartmenus')
  						.removeAttr('data-smartmenus-id')
  						.removeDataSM('level')
  						.off(eNS);
  					eNS += this.rootId;
  					$(document).off(eNS);
  					$(window).off(eNS);
  					if (this.opts.subIndicators) {
  						this.$subArrow = null;
  					}
  				}
  				this.menuHideAll();
  				var self = this;
  				this.$root.find('ul').each(function() {
  						var $this = $(this);
  						if ($this.dataSM('scroll-arrows')) {
  							$this.dataSM('scroll-arrows').remove();
  						}
  						if ($this.dataSM('shown-before')) {
  							if (self.opts.subMenusMinWidth || self.opts.subMenusMaxWidth) {
  								$this.css({ width: '', minWidth: '', maxWidth: '' }).removeClass('sm-nowrap');
  							}
  							if ($this.dataSM('scroll-arrows')) {
  								$this.dataSM('scroll-arrows').remove();
  							}
  							$this.css({ zIndex: '', top: '', left: '', marginLeft: '', marginTop: '', display: '' });
  						}
  						if (($this.attr('id') || '').indexOf(self.accessIdPrefix) == 0) {
  							$this.removeAttr('id');
  						}
  					})
  					.removeDataSM('in-mega')
  					.removeDataSM('shown-before')
  					.removeDataSM('scroll-arrows')
  					.removeDataSM('parent-a')
  					.removeDataSM('level')
  					.removeDataSM('beforefirstshowfired')
  					.removeAttr('role')
  					.removeAttr('aria-hidden')
  					.removeAttr('aria-labelledby')
  					.removeAttr('aria-expanded');
  				this.$root.find('a.has-submenu').each(function() {
  						var $this = $(this);
  						if ($this.attr('id').indexOf(self.accessIdPrefix) == 0) {
  							$this.removeAttr('id');
  						}
  					})
  					.removeClass('has-submenu')
  					.removeDataSM('sub')
  					.removeAttr('aria-haspopup')
  					.removeAttr('aria-controls')
  					.removeAttr('aria-expanded')
  					.closest('li').removeDataSM('sub');
  				if (this.opts.subIndicators) {
  					this.$root.find('span.sub-arrow').remove();
  				}
  				if (this.opts.markCurrentItem) {
  					this.$root.find('a.current').removeClass('current');
  				}
  				if (!refresh) {
  					this.$root = null;
  					this.$firstLink = null;
  					this.$firstSub = null;
  					if (this.$disableOverlay) {
  						this.$disableOverlay.remove();
  						this.$disableOverlay = null;
  					}
  					menuTrees.splice($.inArray(this, menuTrees), 1);
  				}
  			},
  			disable: function(noOverlay) {
  				if (!this.disabled) {
  					this.menuHideAll();
  					// display overlay over the menu to prevent interaction
  					if (!noOverlay && !this.opts.isPopup && this.$root.is(':visible')) {
  						var pos = this.$root.offset();
  						this.$disableOverlay = $('<div class="sm-jquery-disable-overlay"/>').css({
  							position: 'absolute',
  							top: pos.top,
  							left: pos.left,
  							width: this.$root.outerWidth(),
  							height: this.$root.outerHeight(),
  							zIndex: this.getStartZIndex(true),
  							opacity: 0
  						}).appendTo(document.body);
  					}
  					this.disabled = true;
  				}
  			},
  			docClick: function(e) {
  				if (this.$touchScrollingSub) {
  					this.$touchScrollingSub = null;
  					return;
  				}
  				// hide on any click outside the menu or on a menu link
  				if (this.visibleSubMenus.length && !$.contains(this.$root[0], e.target) || $(e.target).closest('a').length) {
  					this.menuHideAll();
  				}
  			},
  			docTouchEnd: function(e) {
  				if (!this.lastTouch) {
  					return;
  				}
  				if (this.visibleSubMenus.length && (this.lastTouch.x2 === undefined || this.lastTouch.x1 == this.lastTouch.x2) && (this.lastTouch.y2 === undefined || this.lastTouch.y1 == this.lastTouch.y2) && (!this.lastTouch.target || !$.contains(this.$root[0], this.lastTouch.target))) {
  					if (this.hideTimeout) {
  						clearTimeout(this.hideTimeout);
  						this.hideTimeout = 0;
  					}
  					// hide with a delay to prevent triggering accidental unwanted click on some page element
  					var self = this;
  					this.hideTimeout = setTimeout(function() { self.menuHideAll(); }, 350);
  				}
  				this.lastTouch = null;
  			},
  			docTouchMove: function(e) {
  				if (!this.lastTouch) {
  					return;
  				}
  				var touchPoint = e.originalEvent.touches[0];
  				this.lastTouch.x2 = touchPoint.pageX;
  				this.lastTouch.y2 = touchPoint.pageY;
  			},
  			docTouchStart: function(e) {
  				var touchPoint = e.originalEvent.touches[0];
  				this.lastTouch = { x1: touchPoint.pageX, y1: touchPoint.pageY, target: touchPoint.target };
  			},
  			enable: function() {
  				if (this.disabled) {
  					if (this.$disableOverlay) {
  						this.$disableOverlay.remove();
  						this.$disableOverlay = null;
  					}
  					this.disabled = false;
  				}
  			},
  			getClosestMenu: function(elm) {
  				var $closestMenu = $(elm).closest('ul');
  				while ($closestMenu.dataSM('in-mega')) {
  					$closestMenu = $closestMenu.parent().closest('ul');
  				}
  				return $closestMenu[0] || null;
  			},
  			getHeight: function($elm) {
  				return this.getOffset($elm, true);
  			},
  			// returns precise width/height float values
  			getOffset: function($elm, height) {
  				var old;
  				if ($elm.css('display') == 'none') {
  					old = { position: $elm[0].style.position, visibility: $elm[0].style.visibility };
  					$elm.css({ position: 'absolute', visibility: 'hidden' }).show();
  				}
  				var box = $elm[0].getBoundingClientRect && $elm[0].getBoundingClientRect(),
  					val = box && (height ? box.height || box.bottom - box.top : box.width || box.right - box.left);
  				if (!val && val !== 0) {
  					val = height ? $elm[0].offsetHeight : $elm[0].offsetWidth;
  				}
  				if (old) {
  					$elm.hide().css(old);
  				}
  				return val;
  			},
  			getStartZIndex: function(root) {
  				var zIndex = parseInt(this[root ? '$root' : '$firstSub'].css('z-index'));
  				if (!root && isNaN(zIndex)) {
  					zIndex = parseInt(this.$root.css('z-index'));
  				}
  				return !isNaN(zIndex) ? zIndex : 1;
  			},
  			getTouchPoint: function(e) {
  				return e.touches && e.touches[0] || e.changedTouches && e.changedTouches[0] || e;
  			},
  			getViewport: function(height) {
  				var name = height ? 'Height' : 'Width',
  					val = document.documentElement['client' + name],
  					val2 = window['inner' + name];
  				if (val2) {
  					val = Math.min(val, val2);
  				}
  				return val;
  			},
  			getViewportHeight: function() {
  				return this.getViewport(true);
  			},
  			getViewportWidth: function() {
  				return this.getViewport();
  			},
  			getWidth: function($elm) {
  				return this.getOffset($elm);
  			},
  			handleEvents: function() {
  				return !this.disabled && this.isCSSOn();
  			},
  			handleItemEvents: function($a) {
  				return this.handleEvents() && !this.isLinkInMegaMenu($a);
  			},
  			isCollapsible: function() {
  				return this.$firstSub.css('position') == 'static';
  			},
  			isCSSOn: function() {
  				return this.$firstLink.css('display') != 'inline';
  			},
  			isFixed: function() {
  				var isFixed = this.$root.css('position') == 'fixed';
  				if (!isFixed) {
  					this.$root.parentsUntil('body').each(function() {
  						if ($(this).css('position') == 'fixed') {
  							isFixed = true;
  							return false;
  						}
  					});
  				}
  				return isFixed;
  			},
  			isLinkInMegaMenu: function($a) {
  				return $(this.getClosestMenu($a[0])).hasClass('mega-menu');
  			},
  			isTouchMode: function() {
  				return !mouse || this.opts.noMouseOver || this.isCollapsible();
  			},
  			itemActivate: function($a, hideDeeperSubs) {
  				var $ul = $a.closest('ul'),
  					level = $ul.dataSM('level');
  				// if for some reason the parent item is not activated (e.g. this is an API call to activate the item), activate all parent items first
  				if (level > 1 && (!this.activatedItems[level - 2] || this.activatedItems[level - 2][0] != $ul.dataSM('parent-a')[0])) {
  					var self = this;
  					$($ul.parentsUntil('[data-smartmenus-id]', 'ul').get().reverse()).add($ul).each(function() {
  						self.itemActivate($(this).dataSM('parent-a'));
  					});
  				}
  				// hide any visible deeper level sub menus
  				if (!this.isCollapsible() || hideDeeperSubs) {
  					this.menuHideSubMenus(!this.activatedItems[level - 1] || this.activatedItems[level - 1][0] != $a[0] ? level - 1 : level);
  				}
  				// save new active item for this level
  				this.activatedItems[level - 1] = $a;
  				if (this.$root.triggerHandler('activate.smapi', $a[0]) === false) {
  					return;
  				}
  				// show the sub menu if this item has one
  				var $sub = $a.dataSM('sub');
  				if ($sub && (this.isTouchMode() || (!this.opts.showOnClick || this.clickActivated))) {
  					this.menuShow($sub);
  				}
  			},
  			itemBlur: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				this.$root.triggerHandler('blur.smapi', $a[0]);
  			},
  			itemClick: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				if (this.$touchScrollingSub && this.$touchScrollingSub[0] == $a.closest('ul')[0]) {
  					this.$touchScrollingSub = null;
  					e.stopPropagation();
  					return false;
  				}
  				if (this.$root.triggerHandler('click.smapi', $a[0]) === false) {
  					return false;
  				}
  				var subArrowClicked = $(e.target).is('.sub-arrow'),
  					$sub = $a.dataSM('sub'),
  					firstLevelSub = $sub ? $sub.dataSM('level') == 2 : false,
  					collapsible = this.isCollapsible(),
  					behaviorToggle = /toggle$/.test(this.opts.collapsibleBehavior),
  					behaviorLink = /link$/.test(this.opts.collapsibleBehavior),
  					behaviorAccordion = /^accordion/.test(this.opts.collapsibleBehavior);
  				// if the sub is hidden, try to show it
  				if ($sub && !$sub.is(':visible')) {
  					if (!behaviorLink || !collapsible || subArrowClicked) {
  						if (this.opts.showOnClick && firstLevelSub) {
  							this.clickActivated = true;
  						}
  						// try to activate the item and show the sub
  						this.itemActivate($a, behaviorAccordion);
  						// if "itemActivate" showed the sub, prevent the click so that the link is not loaded
  						// if it couldn't show it, then the sub menus are disabled with an !important declaration (e.g. via mobile styles) so let the link get loaded
  						if ($sub.is(':visible')) {
  							this.focusActivated = true;
  							return false;
  						}
  					}
  				// if the sub is visible and we are in collapsible mode
  				} else if (collapsible && (behaviorToggle || subArrowClicked)) {
  					this.itemActivate($a, behaviorAccordion);
  					this.menuHide($sub);
  					if (behaviorToggle) {
  						this.focusActivated = false;
  					}
  					return false;
  				}
  				if (this.opts.showOnClick && firstLevelSub || $a.hasClass('disabled') || this.$root.triggerHandler('select.smapi', $a[0]) === false) {
  					return false;
  				}
  			},
  			itemDown: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				$a.dataSM('mousedown', true);
  			},
  			itemEnter: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				if (!this.isTouchMode()) {
  					if (this.showTimeout) {
  						clearTimeout(this.showTimeout);
  						this.showTimeout = 0;
  					}
  					var self = this;
  					this.showTimeout = setTimeout(function() { self.itemActivate($a); }, this.opts.showOnClick && $a.closest('ul').dataSM('level') == 1 ? 1 : this.opts.showTimeout);
  				}
  				this.$root.triggerHandler('mouseenter.smapi', $a[0]);
  			},
  			itemFocus: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				// fix (the mousedown check): in some browsers a tap/click produces consecutive focus + click events so we don't need to activate the item on focus
  				if (this.focusActivated && (!this.isTouchMode() || !$a.dataSM('mousedown')) && (!this.activatedItems.length || this.activatedItems[this.activatedItems.length - 1][0] != $a[0])) {
  					this.itemActivate($a, true);
  				}
  				this.$root.triggerHandler('focus.smapi', $a[0]);
  			},
  			itemLeave: function(e) {
  				var $a = $(e.currentTarget);
  				if (!this.handleItemEvents($a)) {
  					return;
  				}
  				if (!this.isTouchMode()) {
  					$a[0].blur();
  					if (this.showTimeout) {
  						clearTimeout(this.showTimeout);
  						this.showTimeout = 0;
  					}
  				}
  				$a.removeDataSM('mousedown');
  				this.$root.triggerHandler('mouseleave.smapi', $a[0]);
  			},
  			menuHide: function($sub) {
  				if (this.$root.triggerHandler('beforehide.smapi', $sub[0]) === false) {
  					return;
  				}
  				if (canAnimate) {
  					$sub.stop(true, true);
  				}
  				if ($sub.css('display') != 'none') {
  					var complete = function() {
  						// unset z-index
  						$sub.css('z-index', '');
  					};
  					// if sub is collapsible (mobile view)
  					if (this.isCollapsible()) {
  						if (canAnimate && this.opts.collapsibleHideFunction) {
  							this.opts.collapsibleHideFunction.call(this, $sub, complete);
  						} else {
  							$sub.hide(this.opts.collapsibleHideDuration, complete);
  						}
  					} else {
  						if (canAnimate && this.opts.hideFunction) {
  							this.opts.hideFunction.call(this, $sub, complete);
  						} else {
  							$sub.hide(this.opts.hideDuration, complete);
  						}
  					}
  					// deactivate scrolling if it is activated for this sub
  					if ($sub.dataSM('scroll')) {
  						this.menuScrollStop($sub);
  						$sub.css({ 'touch-action': '', '-ms-touch-action': '', '-webkit-transform': '', transform: '' })
  							.off('.smartmenus_scroll').removeDataSM('scroll').dataSM('scroll-arrows').hide();
  					}
  					// unhighlight parent item + accessibility
  					$sub.dataSM('parent-a').removeClass('highlighted').attr('aria-expanded', 'false');
  					$sub.attr({
  						'aria-expanded': 'false',
  						'aria-hidden': 'true'
  					});
  					var level = $sub.dataSM('level');
  					this.activatedItems.splice(level - 1, 1);
  					this.visibleSubMenus.splice($.inArray($sub, this.visibleSubMenus), 1);
  					this.$root.triggerHandler('hide.smapi', $sub[0]);
  				}
  			},
  			menuHideAll: function() {
  				if (this.showTimeout) {
  					clearTimeout(this.showTimeout);
  					this.showTimeout = 0;
  				}
  				// hide all subs
  				// if it's a popup, this.visibleSubMenus[0] is the root UL
  				var level = this.opts.isPopup ? 1 : 0;
  				for (var i = this.visibleSubMenus.length - 1; i >= level; i--) {
  					this.menuHide(this.visibleSubMenus[i]);
  				}
  				// hide root if it's popup
  				if (this.opts.isPopup) {
  					if (canAnimate) {
  						this.$root.stop(true, true);
  					}
  					if (this.$root.is(':visible')) {
  						if (canAnimate && this.opts.hideFunction) {
  							this.opts.hideFunction.call(this, this.$root);
  						} else {
  							this.$root.hide(this.opts.hideDuration);
  						}
  					}
  				}
  				this.activatedItems = [];
  				this.visibleSubMenus = [];
  				this.clickActivated = false;
  				this.focusActivated = false;
  				// reset z-index increment
  				this.zIndexInc = 0;
  				this.$root.triggerHandler('hideAll.smapi');
  			},
  			menuHideSubMenus: function(level) {
  				for (var i = this.activatedItems.length - 1; i >= level; i--) {
  					var $sub = this.activatedItems[i].dataSM('sub');
  					if ($sub) {
  						this.menuHide($sub);
  					}
  				}
  			},
  			menuInit: function($ul) {
  				if (!$ul.dataSM('in-mega')) {
  					// mark UL's in mega drop downs (if any) so we can neglect them
  					if ($ul.hasClass('mega-menu')) {
  						$ul.find('ul').dataSM('in-mega', true);
  					}
  					// get level (much faster than, for example, using parentsUntil)
  					var level = 2,
  						par = $ul[0];
  					while ((par = par.parentNode.parentNode) != this.$root[0]) {
  						level++;
  					}
  					// cache stuff for quick access
  					var $a = $ul.prevAll('a').eq(-1);
  					// if the link is nested (e.g. in a heading)
  					if (!$a.length) {
  						$a = $ul.prevAll().find('a').eq(-1);
  					}
  					$a.addClass('has-submenu').dataSM('sub', $ul);
  					$ul.dataSM('parent-a', $a)
  						.dataSM('level', level)
  						.parent().dataSM('sub', $ul);
  					// accessibility
  					var aId = $a.attr('id') || this.accessIdPrefix + (++this.idInc),
  						ulId = $ul.attr('id') || this.accessIdPrefix + (++this.idInc);
  					$a.attr({
  						id: aId,
  						'aria-haspopup': 'true',
  						'aria-controls': ulId,
  						'aria-expanded': 'false'
  					});
  					$ul.attr({
  						id: ulId,
  						'role': 'group',
  						'aria-hidden': 'true',
  						'aria-labelledby': aId,
  						'aria-expanded': 'false'
  					});
  					// add sub indicator to parent item
  					if (this.opts.subIndicators) {
  						$a[this.opts.subIndicatorsPos](this.$subArrow.clone());
  					}
  				}
  			},
  			menuPosition: function($sub) {
  				var $a = $sub.dataSM('parent-a'),
  					$li = $a.closest('li'),
  					$ul = $li.parent(),
  					level = $sub.dataSM('level'),
  					subW = this.getWidth($sub),
  					subH = this.getHeight($sub),
  					itemOffset = $a.offset(),
  					itemX = itemOffset.left,
  					itemY = itemOffset.top,
  					itemW = this.getWidth($a),
  					itemH = this.getHeight($a),
  					$win = $(window),
  					winX = $win.scrollLeft(),
  					winY = $win.scrollTop(),
  					winW = this.getViewportWidth(),
  					winH = this.getViewportHeight(),
  					horizontalParent = $ul.parent().is('[data-sm-horizontal-sub]') || level == 2 && !$ul.hasClass('sm-vertical'),
  					rightToLeft = this.opts.rightToLeftSubMenus && !$li.is('[data-sm-reverse]') || !this.opts.rightToLeftSubMenus && $li.is('[data-sm-reverse]'),
  					subOffsetX = level == 2 ? this.opts.mainMenuSubOffsetX : this.opts.subMenusSubOffsetX,
  					subOffsetY = level == 2 ? this.opts.mainMenuSubOffsetY : this.opts.subMenusSubOffsetY,
  					x, y;
  				if (horizontalParent) {
  					x = rightToLeft ? itemW - subW - subOffsetX : subOffsetX;
  					y = this.opts.bottomToTopSubMenus ? -subH - subOffsetY : itemH + subOffsetY;
  				} else {
  					x = rightToLeft ? subOffsetX - subW : itemW - subOffsetX;
  					y = this.opts.bottomToTopSubMenus ? itemH - subOffsetY - subH : subOffsetY;
  				}
  				if (this.opts.keepInViewport) {
  					var absX = itemX + x,
  						absY = itemY + y;
  					if (rightToLeft && absX < winX) {
  						x = horizontalParent ? winX - absX + x : itemW - subOffsetX;
  					} else if (!rightToLeft && absX + subW > winX + winW) {
  						x = horizontalParent ? winX + winW - subW - absX + x : subOffsetX - subW;
  					}
  					if (!horizontalParent) {
  						if (subH < winH && absY + subH > winY + winH) {
  							y += winY + winH - subH - absY;
  						} else if (subH >= winH || absY < winY) {
  							y += winY - absY;
  						}
  					}
  					// do we need scrolling?
  					// 0.49 used for better precision when dealing with float values
  					if (horizontalParent && (absY + subH > winY + winH + 0.49 || absY < winY) || !horizontalParent && subH > winH + 0.49) {
  						var self = this;
  						if (!$sub.dataSM('scroll-arrows')) {
  							$sub.dataSM('scroll-arrows', $([$('<span class="scroll-up"><span class="scroll-up-arrow"></span></span>')[0], $('<span class="scroll-down"><span class="scroll-down-arrow"></span></span>')[0]])
  								.on({
  									mouseenter: function() {
  										$sub.dataSM('scroll').up = $(this).hasClass('scroll-up');
  										self.menuScroll($sub);
  									},
  									mouseleave: function(e) {
  										self.menuScrollStop($sub);
  										self.menuScrollOut($sub, e);
  									},
  									'mousewheel DOMMouseScroll': function(e) { e.preventDefault(); }
  								})
  								.insertAfter($sub)
  							);
  						}
  						// bind scroll events and save scroll data for this sub
  						var eNS = '.smartmenus_scroll';
  						$sub.dataSM('scroll', {
  								y: this.cssTransforms3d ? 0 : y - itemH,
  								step: 1,
  								// cache stuff for faster recalcs later
  								itemH: itemH,
  								subH: subH,
  								arrowDownH: this.getHeight($sub.dataSM('scroll-arrows').eq(1))
  							})
  							.on(getEventsNS({
  								'mouseover': function(e) { self.menuScrollOver($sub, e); },
  								'mouseout': function(e) { self.menuScrollOut($sub, e); },
  								'mousewheel DOMMouseScroll': function(e) { self.menuScrollMousewheel($sub, e); }
  							}, eNS))
  							.dataSM('scroll-arrows').css({ top: 'auto', left: '0', marginLeft: x + (parseInt($sub.css('border-left-width')) || 0), width: subW - (parseInt($sub.css('border-left-width')) || 0) - (parseInt($sub.css('border-right-width')) || 0), zIndex: $sub.css('z-index') })
  								.eq(horizontalParent && this.opts.bottomToTopSubMenus ? 0 : 1).show();
  						// when a menu tree is fixed positioned we allow scrolling via touch too
  						// since there is no other way to access such long sub menus if no mouse is present
  						if (this.isFixed()) {
  							var events = {};
  							events[touchEvents ? 'touchstart touchmove touchend' : 'pointerdown pointermove pointerup MSPointerDown MSPointerMove MSPointerUp'] = function(e) {
  								self.menuScrollTouch($sub, e);
  							};
  							$sub.css({ 'touch-action': 'none', '-ms-touch-action': 'none' }).on(getEventsNS(events, eNS));
  						}
  					}
  				}
  				$sub.css({ top: 'auto', left: '0', marginLeft: x, marginTop: y - itemH });
  			},
  			menuScroll: function($sub, once, step) {
  				var data = $sub.dataSM('scroll'),
  					$arrows = $sub.dataSM('scroll-arrows'),
  					end = data.up ? data.upEnd : data.downEnd,
  					diff;
  				if (!once && data.momentum) {
  					data.momentum *= 0.92;
  					diff = data.momentum;
  					if (diff < 0.5) {
  						this.menuScrollStop($sub);
  						return;
  					}
  				} else {
  					diff = step || (once || !this.opts.scrollAccelerate ? this.opts.scrollStep : Math.floor(data.step));
  				}
  				// hide any visible deeper level sub menus
  				var level = $sub.dataSM('level');
  				if (this.activatedItems[level - 1] && this.activatedItems[level - 1].dataSM('sub') && this.activatedItems[level - 1].dataSM('sub').is(':visible')) {
  					this.menuHideSubMenus(level - 1);
  				}
  				data.y = data.up && end <= data.y || !data.up && end >= data.y ? data.y : (Math.abs(end - data.y) > diff ? data.y + (data.up ? diff : -diff) : end);
  				$sub.css(this.cssTransforms3d ? { '-webkit-transform': 'translate3d(0, ' + data.y + 'px, 0)', transform: 'translate3d(0, ' + data.y + 'px, 0)' } : { marginTop: data.y });
  				// show opposite arrow if appropriate
  				if (mouse && (data.up && data.y > data.downEnd || !data.up && data.y < data.upEnd)) {
  					$arrows.eq(data.up ? 1 : 0).show();
  				}
  				// if we've reached the end
  				if (data.y == end) {
  					if (mouse) {
  						$arrows.eq(data.up ? 0 : 1).hide();
  					}
  					this.menuScrollStop($sub);
  				} else if (!once) {
  					if (this.opts.scrollAccelerate && data.step < this.opts.scrollStep) {
  						data.step += 0.2;
  					}
  					var self = this;
  					this.scrollTimeout = requestAnimationFrame(function() { self.menuScroll($sub); });
  				}
  			},
  			menuScrollMousewheel: function($sub, e) {
  				if (this.getClosestMenu(e.target) == $sub[0]) {
  					e = e.originalEvent;
  					var up = (e.wheelDelta || -e.detail) > 0;
  					if ($sub.dataSM('scroll-arrows').eq(up ? 0 : 1).is(':visible')) {
  						$sub.dataSM('scroll').up = up;
  						this.menuScroll($sub, true);
  					}
  				}
  				e.preventDefault();
  			},
  			menuScrollOut: function($sub, e) {
  				if (mouse) {
  					if (!/^scroll-(up|down)/.test((e.relatedTarget || '').className) && ($sub[0] != e.relatedTarget && !$.contains($sub[0], e.relatedTarget) || this.getClosestMenu(e.relatedTarget) != $sub[0])) {
  						$sub.dataSM('scroll-arrows').css('visibility', 'hidden');
  					}
  				}
  			},
  			menuScrollOver: function($sub, e) {
  				if (mouse) {
  					if (!/^scroll-(up|down)/.test(e.target.className) && this.getClosestMenu(e.target) == $sub[0]) {
  						this.menuScrollRefreshData($sub);
  						var data = $sub.dataSM('scroll'),
  							upEnd = $(window).scrollTop() - $sub.dataSM('parent-a').offset().top - data.itemH;
  						$sub.dataSM('scroll-arrows').eq(0).css('margin-top', upEnd).end()
  							.eq(1).css('margin-top', upEnd + this.getViewportHeight() - data.arrowDownH).end()
  							.css('visibility', 'visible');
  					}
  				}
  			},
  			menuScrollRefreshData: function($sub) {
  				var data = $sub.dataSM('scroll'),
  					upEnd = $(window).scrollTop() - $sub.dataSM('parent-a').offset().top - data.itemH;
  				if (this.cssTransforms3d) {
  					upEnd = -(parseFloat($sub.css('margin-top')) - upEnd);
  				}
  				$.extend(data, {
  					upEnd: upEnd,
  					downEnd: upEnd + this.getViewportHeight() - data.subH
  				});
  			},
  			menuScrollStop: function($sub) {
  				if (this.scrollTimeout) {
  					cancelAnimationFrame(this.scrollTimeout);
  					this.scrollTimeout = 0;
  					$sub.dataSM('scroll').step = 1;
  					return true;
  				}
  			},
  			menuScrollTouch: function($sub, e) {
  				e = e.originalEvent;
  				if (isTouchEvent(e)) {
  					var touchPoint = this.getTouchPoint(e);
  					// neglect event if we touched a visible deeper level sub menu
  					if (this.getClosestMenu(touchPoint.target) == $sub[0]) {
  						var data = $sub.dataSM('scroll');
  						if (/(start|down)$/i.test(e.type)) {
  							if (this.menuScrollStop($sub)) {
  								// if we were scrolling, just stop and don't activate any link on the first touch
  								e.preventDefault();
  								this.$touchScrollingSub = $sub;
  							} else {
  								this.$touchScrollingSub = null;
  							}
  							// update scroll data since the user might have zoomed, etc.
  							this.menuScrollRefreshData($sub);
  							// extend it with the touch properties
  							$.extend(data, {
  								touchStartY: touchPoint.pageY,
  								touchStartTime: e.timeStamp
  							});
  						} else if (/move$/i.test(e.type)) {
  							var prevY = data.touchY !== undefined ? data.touchY : data.touchStartY;
  							if (prevY !== undefined && prevY != touchPoint.pageY) {
  								this.$touchScrollingSub = $sub;
  								var up = prevY < touchPoint.pageY;
  								// changed direction? reset...
  								if (data.up !== undefined && data.up != up) {
  									$.extend(data, {
  										touchStartY: touchPoint.pageY,
  										touchStartTime: e.timeStamp
  									});
  								}
  								$.extend(data, {
  									up: up,
  									touchY: touchPoint.pageY
  								});
  								this.menuScroll($sub, true, Math.abs(touchPoint.pageY - prevY));
  							}
  							e.preventDefault();
  						} else { // touchend/pointerup
  							if (data.touchY !== undefined) {
  								if (data.momentum = Math.pow(Math.abs(touchPoint.pageY - data.touchStartY) / (e.timeStamp - data.touchStartTime), 2) * 15) {
  									this.menuScrollStop($sub);
  									this.menuScroll($sub);
  									e.preventDefault();
  								}
  								delete data.touchY;
  							}
  						}
  					}
  				}
  			},
  			menuShow: function($sub) {
  				if (!$sub.dataSM('beforefirstshowfired')) {
  					$sub.dataSM('beforefirstshowfired', true);
  					if (this.$root.triggerHandler('beforefirstshow.smapi', $sub[0]) === false) {
  						return;
  					}
  				}
  				if (this.$root.triggerHandler('beforeshow.smapi', $sub[0]) === false) {
  					return;
  				}
  				$sub.dataSM('shown-before', true);
  				if (canAnimate) {
  					$sub.stop(true, true);
  				}
  				if (!$sub.is(':visible')) {
  					// highlight parent item
  					var $a = $sub.dataSM('parent-a'),
  						collapsible = this.isCollapsible();
  					if (this.opts.keepHighlighted || collapsible) {
  						$a.addClass('highlighted');
  					}
  					if (collapsible) {
  						$sub.removeClass('sm-nowrap').css({ zIndex: '', width: 'auto', minWidth: '', maxWidth: '', top: '', left: '', marginLeft: '', marginTop: '' });
  					} else {
  						// set z-index
  						$sub.css('z-index', this.zIndexInc = (this.zIndexInc || this.getStartZIndex()) + 1);
  						// min/max-width fix - no way to rely purely on CSS as all UL's are nested
  						if (this.opts.subMenusMinWidth || this.opts.subMenusMaxWidth) {
  							$sub.css({ width: 'auto', minWidth: '', maxWidth: '' }).addClass('sm-nowrap');
  							if (this.opts.subMenusMinWidth) {
  							 	$sub.css('min-width', this.opts.subMenusMinWidth);
  							}
  							if (this.opts.subMenusMaxWidth) {
  							 	var noMaxWidth = this.getWidth($sub);
  							 	$sub.css('max-width', this.opts.subMenusMaxWidth);
  								if (noMaxWidth > this.getWidth($sub)) {
  									$sub.removeClass('sm-nowrap').css('width', this.opts.subMenusMaxWidth);
  								}
  							}
  						}
  						this.menuPosition($sub);
  					}
  					var complete = function() {
  						// fix: "overflow: hidden;" is not reset on animation complete in jQuery < 1.9.0 in Chrome when global "box-sizing: border-box;" is used
  						$sub.css('overflow', '');
  					};
  					// if sub is collapsible (mobile view)
  					if (collapsible) {
  						if (canAnimate && this.opts.collapsibleShowFunction) {
  							this.opts.collapsibleShowFunction.call(this, $sub, complete);
  						} else {
  							$sub.show(this.opts.collapsibleShowDuration, complete);
  						}
  					} else {
  						if (canAnimate && this.opts.showFunction) {
  							this.opts.showFunction.call(this, $sub, complete);
  						} else {
  							$sub.show(this.opts.showDuration, complete);
  						}
  					}
  					// accessibility
  					$a.attr('aria-expanded', 'true');
  					$sub.attr({
  						'aria-expanded': 'true',
  						'aria-hidden': 'false'
  					});
  					// store sub menu in visible array
  					this.visibleSubMenus.push($sub);
  					this.$root.triggerHandler('show.smapi', $sub[0]);
  				}
  			},
  			popupHide: function(noHideTimeout) {
  				if (this.hideTimeout) {
  					clearTimeout(this.hideTimeout);
  					this.hideTimeout = 0;
  				}
  				var self = this;
  				this.hideTimeout = setTimeout(function() {
  					self.menuHideAll();
  				}, noHideTimeout ? 1 : this.opts.hideTimeout);
  			},
  			popupShow: function(left, top) {
  				if (!this.opts.isPopup) {
  					alert('SmartMenus jQuery Error:\n\nIf you want to show this menu via the "popupShow" method, set the isPopup:true option.');
  					return;
  				}
  				if (this.hideTimeout) {
  					clearTimeout(this.hideTimeout);
  					this.hideTimeout = 0;
  				}
  				this.$root.dataSM('shown-before', true);
  				if (canAnimate) {
  					this.$root.stop(true, true);
  				}
  				if (!this.$root.is(':visible')) {
  					this.$root.css({ left: left, top: top });
  					// show menu
  					var self = this,
  						complete = function() {
  							self.$root.css('overflow', '');
  						};
  					if (canAnimate && this.opts.showFunction) {
  						this.opts.showFunction.call(this, this.$root, complete);
  					} else {
  						this.$root.show(this.opts.showDuration, complete);
  					}
  					this.visibleSubMenus[0] = this.$root;
  				}
  			},
  			refresh: function() {
  				this.destroy(true);
  				this.init(true);
  			},
  			rootKeyDown: function(e) {
  				if (!this.handleEvents()) {
  					return;
  				}
  				switch (e.keyCode) {
  					case 27: // reset on Esc
  						var $activeTopItem = this.activatedItems[0];
  						if ($activeTopItem) {
  							this.menuHideAll();
  							$activeTopItem[0].focus();
  							var $sub = $activeTopItem.dataSM('sub');
  							if ($sub) {
  								this.menuHide($sub);
  							}
  						}
  						break;
  					case 32: // activate item's sub on Space
  						var $target = $(e.target);
  						if ($target.is('a') && this.handleItemEvents($target)) {
  							var $sub = $target.dataSM('sub');
  							if ($sub && !$sub.is(':visible')) {
  								this.itemClick({ currentTarget: e.target });
  								e.preventDefault();
  							}
  						}
  						break;
  				}
  			},
  			rootOut: function(e) {
  				if (!this.handleEvents() || this.isTouchMode() || e.target == this.$root[0]) {
  					return;
  				}
  				if (this.hideTimeout) {
  					clearTimeout(this.hideTimeout);
  					this.hideTimeout = 0;
  				}
  				if (!this.opts.showOnClick || !this.opts.hideOnClick) {
  					var self = this;
  					this.hideTimeout = setTimeout(function() { self.menuHideAll(); }, this.opts.hideTimeout);
  				}
  			},
  			rootOver: function(e) {
  				if (!this.handleEvents() || this.isTouchMode() || e.target == this.$root[0]) {
  					return;
  				}
  				if (this.hideTimeout) {
  					clearTimeout(this.hideTimeout);
  					this.hideTimeout = 0;
  				}
  			},
  			winResize: function(e) {
  				if (!this.handleEvents()) {
  					// we still need to resize the disable overlay if it's visible
  					if (this.$disableOverlay) {
  						var pos = this.$root.offset();
  	 					this.$disableOverlay.css({
  							top: pos.top,
  							left: pos.left,
  							width: this.$root.outerWidth(),
  							height: this.$root.outerHeight()
  						});
  					}
  					return;
  				}
  				// hide sub menus on resize - on mobile do it only on orientation change
  				if (!('onorientationchange' in window) || e.type == 'orientationchange') {
  					var collapsible = this.isCollapsible();
  					// if it was collapsible before resize and still is, don't do it
  					if (!(this.wasCollapsible && collapsible)) { 
  						if (this.activatedItems.length) {
  							this.activatedItems[this.activatedItems.length - 1][0].blur();
  						}
  						this.menuHideAll();
  					}
  					this.wasCollapsible = collapsible;
  				}
  			}
  		}
  	});

  	$.fn.dataSM = function(key, val) {
  		if (val) {
  			return this.data(key + '_smartmenus', val);
  		}
  		return this.data(key + '_smartmenus');
  	};

  	$.fn.removeDataSM = function(key) {
  		return this.removeData(key + '_smartmenus');
  	};

  	$.fn.smartmenus = function(options) {
  		if (typeof options == 'string') {
  			var args = arguments,
  				method = options;
  			Array.prototype.shift.call(args);
  			return this.each(function() {
  				var smartmenus = $(this).data('smartmenus');
  				if (smartmenus && smartmenus[method]) {
  					smartmenus[method].apply(smartmenus, args);
  				}
  			});
  		}
  		return this.each(function() {
  			// [data-sm-options] attribute on the root UL
  			var dataOpts = $(this).data('sm-options') || null;
  			if (dataOpts) {
  				try {
  					dataOpts = eval('(' + dataOpts + ')');
  				} catch(e) {
  					dataOpts = null;
  					alert('ERROR\n\nSmartMenus jQuery init:\nInvalid "data-sm-options" attribute value syntax.');
  				};
  			}
  			new $.SmartMenus(this, $.extend({}, $.fn.smartmenus.defaults, options, dataOpts));
  		});
  	};

  	// default settings
  	$.fn.smartmenus.defaults = {
  		isPopup:		false,		// is this a popup menu (can be shown via the popupShow/popupHide methods) or a permanent menu bar
  		mainMenuSubOffsetX:	0,		// pixels offset from default position
  		mainMenuSubOffsetY:	0,		// pixels offset from default position
  		subMenusSubOffsetX:	0,		// pixels offset from default position
  		subMenusSubOffsetY:	0,		// pixels offset from default position
  		subMenusMinWidth:	'10em',		// min-width for the sub menus (any CSS unit) - if set, the fixed width set in CSS will be ignored
  		subMenusMaxWidth:	'20em',		// max-width for the sub menus (any CSS unit) - if set, the fixed width set in CSS will be ignored
  		subIndicators: 		true,		// create sub menu indicators - creates a SPAN and inserts it in the A
  		subIndicatorsPos: 	'append',	// position of the SPAN relative to the menu item content ('append', 'prepend')
  		subIndicatorsText:	'',		// [optionally] add text in the SPAN (e.g. '+') (you may want to check the CSS for the sub indicators too)
  		scrollStep: 		30,		// pixels step when scrolling long sub menus that do not fit in the viewport height
  		scrollAccelerate:	true,		// accelerate scrolling or use a fixed step
  		showTimeout:		250,		// timeout before showing the sub menus
  		hideTimeout:		500,		// timeout before hiding the sub menus
  		showDuration:		0,		// duration for show animation - set to 0 for no animation - matters only if showFunction:null
  		showFunction:		null,		// custom function to use when showing a sub menu (the default is the jQuery 'show')
  							// don't forget to call complete() at the end of whatever you do
  							// e.g.: function($ul, complete) { $ul.fadeIn(250, complete); }
  		hideDuration:		0,		// duration for hide animation - set to 0 for no animation - matters only if hideFunction:null
  		hideFunction:		function($ul, complete) { $ul.fadeOut(200, complete); },	// custom function to use when hiding a sub menu (the default is the jQuery 'hide')
  							// don't forget to call complete() at the end of whatever you do
  							// e.g.: function($ul, complete) { $ul.fadeOut(250, complete); }
  		collapsibleShowDuration:0,		// duration for show animation for collapsible sub menus - matters only if collapsibleShowFunction:null
  		collapsibleShowFunction:function($ul, complete) { $ul.slideDown(200, complete); },	// custom function to use when showing a collapsible sub menu
  							// (i.e. when mobile styles are used to make the sub menus collapsible)
  		collapsibleHideDuration:0,		// duration for hide animation for collapsible sub menus - matters only if collapsibleHideFunction:null
  		collapsibleHideFunction:function($ul, complete) { $ul.slideUp(200, complete); },	// custom function to use when hiding a collapsible sub menu
  							// (i.e. when mobile styles are used to make the sub menus collapsible)
  		showOnClick:		false,		// show the first-level sub menus onclick instead of onmouseover (i.e. mimic desktop app menus) (matters only for mouse input)
  		hideOnClick:		true,		// hide the sub menus on click/tap anywhere on the page
  		noMouseOver:		false,		// disable sub menus activation onmouseover (i.e. behave like in touch mode - use just mouse clicks) (matters only for mouse input)
  		keepInViewport:		true,		// reposition the sub menus if needed to make sure they always appear inside the viewport
  		keepHighlighted:	true,		// keep all ancestor items of the current sub menu highlighted (adds the 'highlighted' class to the A's)
  		markCurrentItem:	false,		// automatically add the 'current' class to the A element of the item linking to the current URL
  		markCurrentTree:	true,		// add the 'current' class also to the A elements of all ancestor items of the current item
  		rightToLeftSubMenus:	false,		// right to left display of the sub menus (check the CSS for the sub indicators' position)
  		bottomToTopSubMenus:	false,		// bottom to top display of the sub menus
  		collapsibleBehavior:	'default'	// parent items behavior in collapsible (mobile) view ('default', 'toggle', 'link', 'accordion', 'accordion-toggle', 'accordion-link')
  							// 'default' - first tap on parent item expands sub, second tap loads its link
  							// 'toggle' - the whole parent item acts just as a toggle button for its sub menu (expands/collapses on each tap)
  							// 'link' - the parent item acts as a regular item (first tap loads its link), the sub menu can be expanded only via the +/- button
  							// 'accordion' - like 'default' but on expand also resets any visible sub menus from deeper levels or other branches
  							// 'accordion-toggle' - like 'toggle' but on expand also resets any visible sub menus from deeper levels or other branches
  							// 'accordion-link' - like 'link' but on expand also resets any visible sub menus from deeper levels or other branches
  	};

  	return $;
  }));;
  /**
  * jquery-match-height master by @liabru
  * http://brm.io/jquery-match-height/
  * License: MIT
  */

  ;(function(factory) { // eslint-disable-line no-extra-semi
      'use strict';
      if (typeof define === 'function' && define.amd) {
          // AMD
          define(['jquery'], factory);
      } else if (typeof module !== 'undefined' && module.exports) {
          // CommonJS
          module.exports = factory(require('jquery'));
      } else {
          // Global
          factory(jQuery);
      }
  })(function($) {
      /*
      *  internal
      */

      var _previousResizeWidth = -1,
          _updateTimeout = -1;

      /*
      *  _parse
      *  value parse utility function
      */

      var _parse = function(value) {
          // parse value and convert NaN to 0
          return parseFloat(value) || 0;
      };

      /*
      *  _rows
      *  utility function returns array of jQuery selections representing each row
      *  (as displayed after float wrapping applied by browser)
      */

      var _rows = function(elements) {
          var tolerance = 1,
              $elements = $(elements),
              lastTop = null,
              rows = [];

          // group elements by their top position
          $elements.each(function(){
              var $that = $(this),
                  top = $that.offset().top - _parse($that.css('margin-top')),
                  lastRow = rows.length > 0 ? rows[rows.length - 1] : null;

              if (lastRow === null) {
                  // first item on the row, so just push it
                  rows.push($that);
              } else {
                  // if the row top is the same, add to the row group
                  if (Math.floor(Math.abs(lastTop - top)) <= tolerance) {
                      rows[rows.length - 1] = lastRow.add($that);
                  } else {
                      // otherwise start a new row group
                      rows.push($that);
                  }
              }

              // keep track of the last row top
              lastTop = top;
          });

          return rows;
      };

      /*
      *  _parseOptions
      *  handle plugin options
      */

      var _parseOptions = function(options) {
          var opts = {
              byRow: true,
              property: 'height',
              target: null,
              remove: false
          };

          if (typeof options === 'object') {
              return $.extend(opts, options);
          }

          if (typeof options === 'boolean') {
              opts.byRow = options;
          } else if (options === 'remove') {
              opts.remove = true;
          }

          return opts;
      };

      /*
      *  matchHeight
      *  plugin definition
      */

      var matchHeight = $.fn.matchHeight = function(options) {
          var opts = _parseOptions(options);

          // handle remove
          if (opts.remove) {
              var that = this;

              // remove fixed height from all selected elements
              this.css(opts.property, '');

              // remove selected elements from all groups
              $.each(matchHeight._groups, function(key, group) {
                  group.elements = group.elements.not(that);
              });

              // TODO: cleanup empty groups

              return this;
          }

          if (this.length <= 1 && !opts.target) {
              return this;
          }

          // keep track of this group so we can re-apply later on load and resize events
          matchHeight._groups.push({
              elements: this,
              options: opts
          });

          // match each element's height to the tallest element in the selection
          matchHeight._apply(this, opts);

          return this;
      };

      /*
      *  plugin global options
      */

      matchHeight.version = 'master';
      matchHeight._groups = [];
      matchHeight._throttle = 80;
      matchHeight._maintainScroll = false;
      matchHeight._beforeUpdate = null;
      matchHeight._afterUpdate = null;
      matchHeight._rows = _rows;
      matchHeight._parse = _parse;
      matchHeight._parseOptions = _parseOptions;

      /*
      *  matchHeight._apply
      *  apply matchHeight to given elements
      */

      matchHeight._apply = function(elements, options) {
          var opts = _parseOptions(options),
              $elements = $(elements),
              rows = [$elements];

          // take note of scroll position
          var scrollTop = $(window).scrollTop(),
              htmlHeight = $('html').outerHeight(true);

          // get hidden parents
          var $hiddenParents = $elements.parents().filter(':hidden');

          // cache the original inline style
          $hiddenParents.each(function() {
              var $that = $(this);
              $that.data('style-cache', $that.attr('style'));
          });

          // temporarily must force hidden parents visible
          $hiddenParents.css('display', 'block');

          // get rows if using byRow, otherwise assume one row
          if (opts.byRow && !opts.target) {

              // must first force an arbitrary equal height so floating elements break evenly
              $elements.each(function() {
                  var $that = $(this),
                      display = $that.css('display');

                  // temporarily force a usable display value
                  if (display !== 'inline-block' && display !== 'flex' && display !== 'inline-flex') {
                      display = 'block';
                  }

                  // cache the original inline style
                  $that.data('style-cache', $that.attr('style'));

                  $that.css({
                      'display': display,
                      'padding-top': '0',
                      'padding-bottom': '0',
                      'margin-top': '0',
                      'margin-bottom': '0',
                      'border-top-width': '0',
                      'border-bottom-width': '0',
                      'height': '100px',
                      'overflow': 'hidden'
                  });
              });

              // get the array of rows (based on element top position)
              rows = _rows($elements);

              // revert original inline styles
              $elements.each(function() {
                  var $that = $(this);
                  $that.attr('style', $that.data('style-cache') || '');
              });
          }

          $.each(rows, function(key, row) {
              var $row = $(row),
                  targetHeight = 0;

              if (!opts.target) {
                  // skip apply to rows with only one item
                  if (opts.byRow && $row.length <= 1) {
                      $row.css(opts.property, '');
                      return;
                  }

                  // iterate the row and find the max height
                  $row.each(function(){
                      var $that = $(this),
                          style = $that.attr('style'),
                          display = $that.css('display');

                      // temporarily force a usable display value
                      if (display !== 'inline-block' && display !== 'flex' && display !== 'inline-flex') {
                          display = 'block';
                      }

                      // ensure we get the correct actual height (and not a previously set height value)
                      var css = { 'display': display };
                      css[opts.property] = '';
                      $that.css(css);

                      // find the max height (including padding, but not margin)
                      if ($that.outerHeight(false) > targetHeight) {
                          targetHeight = $that.outerHeight(false);
                      }

                      // revert styles
                      if (style) {
                          $that.attr('style', style);
                      } else {
                          $that.css('display', '');
                      }
                  });
              } else {
                  // if target set, use the height of the target element
                  targetHeight = opts.target.outerHeight(false);
              }

              // iterate the row and apply the height to all elements
              $row.each(function(){
                  var $that = $(this),
                      verticalPadding = 0;

                  // don't apply to a target
                  if (opts.target && $that.is(opts.target)) {
                      return;
                  }

                  // handle padding and border correctly (required when not using border-box)
                  if ($that.css('box-sizing') !== 'border-box') {
                      verticalPadding += _parse($that.css('border-top-width')) + _parse($that.css('border-bottom-width'));
                      verticalPadding += _parse($that.css('padding-top')) + _parse($that.css('padding-bottom'));
                  }

                  // set the height (accounting for padding and border)
                  $that.css(opts.property, (targetHeight - verticalPadding) + 'px');
              });
          });

          // revert hidden parents
          $hiddenParents.each(function() {
              var $that = $(this);
              $that.attr('style', $that.data('style-cache') || null);
          });

          // restore scroll position if enabled
          if (matchHeight._maintainScroll) {
              $(window).scrollTop((scrollTop / htmlHeight) * $('html').outerHeight(true));
          }

          return this;
      };

      /*
      *  matchHeight._applyDataApi
      *  applies matchHeight to all elements with a data-match-height attribute
      */

      matchHeight._applyDataApi = function() {
          var groups = {};

          // generate groups by their groupId set by elements using data-match-height
          $('[data-match-height], [data-mh]').each(function() {
              var $this = $(this),
                  groupId = $this.attr('data-mh') || $this.attr('data-match-height');

              if (groupId in groups) {
                  groups[groupId] = groups[groupId].add($this);
              } else {
                  groups[groupId] = $this;
              }
          });

          // apply matchHeight to each group
          $.each(groups, function() {
              this.matchHeight(true);
          });
      };

      /*
      *  matchHeight._update
      *  updates matchHeight on all current groups with their correct options
      */

      var _update = function(event) {
          if (matchHeight._beforeUpdate) {
              matchHeight._beforeUpdate(event, matchHeight._groups);
          }

          $.each(matchHeight._groups, function() {
              matchHeight._apply(this.elements, this.options);
          });

          if (matchHeight._afterUpdate) {
              matchHeight._afterUpdate(event, matchHeight._groups);
          }
      };

      matchHeight._update = function(throttle, event) {
          // prevent update if fired from a resize event
          // where the viewport width hasn't actually changed
          // fixes an event looping bug in IE8
          if (event && event.type === 'resize') {
              var windowWidth = $(window).width();
              if (windowWidth === _previousResizeWidth) {
                  return;
              }
              _previousResizeWidth = windowWidth;
          }

          // throttle updates
          if (!throttle) {
              _update(event);
          } else if (_updateTimeout === -1) {
              _updateTimeout = setTimeout(function() {
                  _update(event);
                  _updateTimeout = -1;
              }, matchHeight._throttle);
          }
      };

      /*
      *  bind events
      */

      // apply on DOM ready event
      $(matchHeight._applyDataApi);

      // use on or bind where supported
      var on = $.fn.on ? 'on' : 'bind';

      // update heights on load and resize events
      $(window)[on]('load', function(event) {
          matchHeight._update(false, event);
      });

      // throttled update heights on resize events
      $(window)[on]('resize orientationchange', function(event) {
          matchHeight._update(true, event);
      });

  });
  ;
  (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
  try{var ce=new window.CustomEvent("test");if(ce.preventDefault(),!0!==ce.defaultPrevented)throw new Error("Could not prevent default")}catch(e){var CustomEvent=function(e,t){var n,r;return t=t||{bubbles:!1,cancelable:!1,detail:void 0},n=document.createEvent("CustomEvent"),n.initCustomEvent(e,t.bubbles,t.cancelable,t.detail),r=n.preventDefault,n.preventDefault=function(){r.call(this);try{Object.defineProperty(this,"defaultPrevented",{get:function(){return!0}})}catch(e){this.defaultPrevented=!0}},n};CustomEvent.prototype=window.Event.prototype,window.CustomEvent=CustomEvent}
  },{}],2:[function(require,module,exports){
  "use strict";function builder(e,t){function n(e){x&&x.classList.remove(t.hasFocusClass),void 0!==e?(x=e,x.classList.add(t.hasFocusClass),T&&(e.offsetTop<e.offsetParent.scrollTop||e.offsetTop>e.offsetParent.scrollTop+e.offsetParent.clientHeight-e.clientHeight)&&e.dispatchEvent(new CustomEvent("custom-select:focus-outside-panel",{bubbles:!0}))):x=void 0}function s(e){w&&(w.classList.remove(t.isSelectedClass),w.removeAttribute("id"),A.removeAttribute("aria-activedescendant")),void 0!==e?(e.classList.add(t.isSelectedClass),e.setAttribute("id",E+"-"+L+"-selectedOption"),A.setAttribute("aria-activedescendant",E+"-"+L+"-selectedOption"),w=e,A.children[0].textContent=w.customSelectOriginalOption.text):(w=void 0,A.children[0].textContent=""),n(e)}function o(e){var t=S.querySelector("option[value='"+e+"']");if(!t){t=_slicedToArray(S.options,1)[0]}t.selected=!0,s(S.options[S.selectedIndex].customSelectCstOption)}function a(e){var t=[].indexOf.call(S.options,x.customSelectOriginalOption);S.options[t+e]&&n(S.options[t+e].customSelectCstOption)}function r(e){if(e||void 0===e){var s=document.querySelector("."+E+"."+t.isOpenClass);s&&(s.customSelect.open=!1),y.classList.add(t.isOpenClass),y.classList.add(t.isOpenClass),A.setAttribute("aria-expanded","true"),w&&(N.scrollTop=w.offsetTop),y.dispatchEvent(new CustomEvent("custom-select:open")),T=!0}else y.classList.remove(t.isOpenClass),A.setAttribute("aria-expanded","false"),T=!1,n(w),y.dispatchEvent(new CustomEvent("custom-select:close"));return T}function i(e){e.target===A||A.contains(e.target)?T?r(!1):r():e.target.classList&&e.target.classList.contains(t.optionClass)&&N.contains(e.target)?(s(e.target),w.customSelectOriginalOption.selected=!0,r(!1),S.dispatchEvent(new CustomEvent("change"))):e.target===S?A!==document.activeElement&&S!==document.activeElement&&A.focus():T&&!y.contains(e.target)&&r(!1)}function c(e){e.target.classList&&e.target.classList.contains(t.optionClass)&&n(e.target)}function l(e){if(T)switch(e.keyCode){case 13:case 32:s(x),w.customSelectOriginalOption.selected=!0,S.dispatchEvent(new CustomEvent("change")),r(!1);break;case 27:r(!1);break;case 38:a(-1);break;case 40:a(1);break;default:if(e.keyCode>=48&&e.keyCode<=90){P&&clearTimeout(P),P=setTimeout(function(){k=""},1500),k+=String.fromCharCode(e.keyCode);for(var t=0,o=S.options.length;t<o;t++)if(S.options[t].text.toUpperCase().substr(0,k.length)===k){n(S.options[t].customSelectCstOption);break}}}else 40!==e.keyCode&&38!==e.keyCode&&32!==e.keyCode||r()}function d(){var e=S.selectedIndex;s(-1===e?void 0:S.options[e].customSelectCstOption)}function u(e){var t=e.currentTarget,n=e.target;n.offsetTop<t.scrollTop?t.scrollTop=n.offsetTop:t.scrollTop=n.offsetTop+n.clientHeight-t.clientHeight}function p(){document.addEventListener("click",i),N.addEventListener("mouseover",c),N.addEventListener("custom-select:focus-outside-panel",u),S.addEventListener("change",d),y.addEventListener("keydown",l)}function m(){document.removeEventListener("click",i),N.removeEventListener("mouseover",c),N.removeEventListener("custom-select:focus-outside-panel",u),S.removeEventListener("change",d),y.removeEventListener("keydown",l)}function f(e){e&&!S.disabled?(y.classList.add(t.isDisabledClass),S.disabled=!0,A.removeAttribute("tabindex"),y.dispatchEvent(new CustomEvent("custom-select:disabled")),m()):!e&&S.disabled&&(y.classList.remove(t.isDisabledClass),S.disabled=!1,A.setAttribute("tabindex","0"),y.dispatchEvent(new CustomEvent("custom-select:enabled")),p())}function v(e){var n=e,o=[];if(void 0===n.length)throw new TypeError("Invalid Argument");for(var a=0,r=n.length;a<r;a++)if(n[a]instanceof HTMLElement&&"OPTGROUP"===n[a].tagName.toUpperCase()){var i=document.createElement("div");i.classList.add(t.optgroupClass),i.setAttribute("data-label",n[a].label),i.customSelectOriginalOptgroup=n[a],n[a].customSelectCstOptgroup=i;for(var c=v(n[a].children),l=0,d=c.length;l<d;l++)i.appendChild(c[l]);o.push(i)}else{if(!(n[a]instanceof HTMLElement&&"OPTION"===n[a].tagName.toUpperCase()))throw new TypeError("Invalid Argument");var u=document.createElement("div");u.classList.add(t.optionClass),u.textContent=n[a].text,u.setAttribute("data-value",n[a].value),u.setAttribute("role","option"),u.customSelectOriginalOption=n[a],n[a].customSelectCstOption=u,n[a].selected&&s(u),o.push(u)}return o}function C(e,t,n){var s=void 0;if(void 0===n||n===S)s=N;else{if(!(n instanceof HTMLElement&&"OPTGROUP"===n.tagName.toUpperCase()&&S.contains(n)))throw new TypeError("Invalid Argument");s=n.customSelectCstOptgroup}var o=e instanceof HTMLElement?[e]:e;if(t)for(var a=0,r=o.length;a<r;a++)s===N?S.appendChild(o[a]):s.customSelectOriginalOptgroup.appendChild(o[a]);for(var i=v(o),c=0,l=i.length;c<l;c++)s.appendChild(i[c]);return o}function g(e,t){var n=void 0;if(t instanceof HTMLElement&&"OPTION"===t.tagName.toUpperCase()&&S.contains(t))n=t.customSelectCstOption;else{if(!(t instanceof HTMLElement&&"OPTGROUP"===t.tagName.toUpperCase()&&S.contains(t)))throw new TypeError("Invalid Argument");n=t.customSelectCstOptgroup}var s=v(e.length?e:[e]);return n.parentNode.insertBefore(s[0],n),t.parentNode.insertBefore(e.length?e[0]:e,t)}function b(e){var t=void 0;if(e instanceof HTMLElement&&"OPTION"===e.tagName.toUpperCase()&&S.contains(e))t=e.customSelectCstOption;else{if(!(e instanceof HTMLElement&&"OPTGROUP"===e.tagName.toUpperCase()&&S.contains(e)))throw new TypeError("Invalid Argument");t=e.customSelectCstOptgroup}t.parentNode.removeChild(t);var n=e.parentNode.removeChild(e);return d(),n}function h(){for(var e=[];S.children.length;)N.removeChild(N.children[0]),e.push(S.removeChild(S.children[0]));return s(),e}function O(){for(var e=0,t=S.options.length;e<t;e++)delete S.options[e].customSelectCstOption;for(var n=S.getElementsByTagName("optgroup"),s=0,o=n.length;s<o;s++)delete n.customSelectCstOptgroup;return m(),y.parentNode.replaceChild(S,y)}var E="customSelect",T=!1,L="",S=e,y=void 0,A=void 0,x=void 0,w=void 0,N=void 0,j=void 0,P=void 0,k="";y=document.createElement("div"),y.classList.add(t.containerClass,E),A=document.createElement("span"),A.className=t.openerClass,A.setAttribute("role","combobox"),A.setAttribute("aria-autocomplete","list"),A.setAttribute("aria-expanded","false"),A.innerHTML="<span>\n   "+(-1!==S.selectedIndex?S.options[S.selectedIndex].text:"")+"\n   </span>",N=document.createElement("div");for(var H="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",U=0;U<5;U++)L+=H.charAt(Math.floor(Math.random()*H.length));return N.id=E+"-"+L+"-panel",N.className=t.panelClass,N.setAttribute("role","listbox"),A.setAttribute("aria-owns",N.id),C(S.children,!1),y.appendChild(A),S.parentNode.replaceChild(y,S),y.appendChild(S),y.appendChild(N),document.querySelector('label[for="'+S.id+'"]')?j=document.querySelector('label[for="'+S.id+'"]'):"LABEL"===y.parentNode.tagName.toUpperCase()&&(j=y.parentNode),void 0!==j&&(j.setAttribute("id",E+"-"+L+"-label"),A.setAttribute("aria-labelledby",E+"-"+L+"-label")),S.disabled?y.classList.add(t.isDisabledClass):(A.setAttribute("tabindex","0"),S.setAttribute("tabindex","-1"),p()),y.customSelect={get pluginOptions(){return t},get open(){return T},set open(e){r(e)},get disabled(){return S.disabled},set disabled(e){f(e)},get value(){return S.value},set value(e){o(e)},append:function(e,t){return C(e,!0,t)},insertBefore:function(e,t){return g(e,t)},remove:b,empty:h,destroy:O,opener:A,select:S,panel:N,container:y},S.customSelect=y.customSelect,y.customSelect}function customSelect(e,t){var n=[],s=[];return function(){if(e&&e instanceof HTMLElement&&"SELECT"===e.tagName.toUpperCase())n.push(e);else if(e&&"string"==typeof e)for(var o=document.querySelectorAll(e),a=0,r=o.length;a<r;++a)o[a]instanceof HTMLElement&&"SELECT"===o[a].tagName.toUpperCase()&&n.push(o[a]);else if(e&&e.length)for(var i=0,c=e.length;i<c;++i)e[i]instanceof HTMLElement&&"SELECT"===e[i].tagName.toUpperCase()&&n.push(e[i]);for(var l=0,d=n.length;l<d;++l)s.push(builder(n[l],_extends({},defaultParams,t)));return s}()}Object.defineProperty(exports,"__esModule",{value:!0});var _extends=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&(e[s]=n[s])}return e},_slicedToArray=function(){function e(e,t){var n=[],s=!0,o=!1,a=void 0;try{for(var r,i=e[Symbol.iterator]();!(s=(r=i.next()).done)&&(n.push(r.value),!t||n.length!==t);s=!0);}catch(e){o=!0,a=e}finally{try{!s&&i.return&&i.return()}finally{if(o)throw a}}return n}return function(t,n){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return e(t,n);throw new TypeError("Invalid attempt to destructure non-iterable instance")}}();exports.default=customSelect,require("custom-event-polyfill");var defaultParams={containerClass:"custom-select-container",openerClass:"custom-select-opener",panelClass:"custom-select-panel",optionClass:"custom-select-option",optgroupClass:"custom-select-optgroup",isSelectedClass:"is-selected",hasFocusClass:"has-focus",isDisabledClass:"is-disabled",isOpenClass:"is-open"};
  },{"custom-event-polyfill":1}],3:[function(require,module,exports){
  "use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}var _index=require("./index"),_index2=_interopRequireDefault(_index);if("undefined"==typeof jQuery)throw new Error("Custom Select jQuery requires jQuery");!function(e){var t=e;t.fn.customSelect=function(e){for(var r=arguments.length,n=Array(r>1?r-1:0),u=1;u<r;u++)n[u-1]=arguments[u];var i;return this.each(function(){var r=t(this),u=r.data("customSelect");u?"string"==typeof e&&("function"==typeof u[e]?(i=u[e].apply(u,n),"destroy"===e&&r.removeData("customSelect")):n.length?(u[e]=n[0],i=this):i="container"===e||"opener"===e||"select"===e||"panel"===e?t(u[e]):u[e]):(r.data("customSelect",(0,_index2.default)(this,e)[0]),i=this)}),i}}(jQuery);
  },{"./index":2}]},{},[3]);
  ;
  "use strict";

  /* eslint-disable */
  /* Drupal Behaviour */
  (function (w, $, Drupal) {
    Drupal.behaviors.bayerradiology = {
      attach: function attach(context, settings) {

        // Auto select the country on contact page
        var countrySelector = jQuery('select#edit-field-bayph-radlgy-country-code-value');

        if (countrySelector.length > 0) {
          var client = new XMLHttpRequest();
          client.open("GET", "/", true);
          client.send();

          client.onreadystatechange = function () {
            if (this.readyState === this.HEADERS_RECEIVED) {
              var country = client.getResponseHeader("x-geo-country");
              client.abort();

              if (country !== '') {
                countrySelector.val(country).trigger('change');
              }
            }
          };
        }

        /*
          * This initializes the smartMenus js library
          */
        /* SmartMenus Top Menu Init */
        jQuery('#top-menu').smartmenus({
          noMouseOver: true, /* Removes on Hover functionality and makes it on Click */
          subMenusMaxWidth: '30em'
        });

        /* SmartMenus Main Menu Init */
        jQuery('#main-menu').smartmenus({
          noMouseOver: true, /* Removes on Hover functionality and makes it on Click */
          subMenusMaxWidth: '30em'
        });

        /* SmartMenus Mobile Menu Init */
        jQuery('#mobile-menu').smartmenus({
          subMenusSubOffsetX: 1,
          subMenusSubOffsetY: -8,
          collapsibleBehavior: 'toggle',
          keepInViewport: false
        });

        /* Make submenus open and close without go to link */
        jQuery('#mobile-menu a.has-submenu').click(function (event) {
          event.preventDefault();
        });

        /* SmartMenus Mobile Menu toggle button */
        jQuery(function () {
          var $mobileMenuState = jQuery('#mobile-menu-state');
          if ($mobileMenuState.length) {
            /* Animate mobile menu */
            $mobileMenuState.change(function (e) {
              var $menu = jQuery('#mobile-menu');
              if (this.checked) {
                $menu.hide().slideDown(250, function () {
                  $menu.css('display', '');
                });
              } else {
                $menu.show().slideUp(250, function () {
                  $menu.css('display', '');
                });
              }
            });
            /* Hide mobile menu beforeunload */
            jQuery(window).bind('beforeunload unload', function () {
              if ($mobileMenuState[0].checked) {
                $mobileMenuState[0].click();
              }
            });
          }

          /* Force footer to be at bottom of page */
          var docHeight = jQuery(window).height();
          var footerHeight = jQuery('#footer').height();
          var footerPos = jQuery('#footer').position();
          var footerTop = footerPos.top + footerHeight;
          var marginOffset = -70 + (docHeight - footerTop);

          if (footerTop < docHeight) {
            jQuery('#footer').css('margin-top', marginOffset);
          }
        });

        /* Sets slide-equalheight on Carousel Banner */
        /* If below 767px screensize then show dropdown menu */
        if (window.matchMedia('screen and (max-width: 767px)').matches) {
          var slideHeight = 0;

          jQuery('.slide-equalheight').each(function () {
            if (jQuery(this).height() > slideHeight) {
              slideHeight = jQuery(this).height();
            }
          });

          jQuery('.slide-equalheight').height(slideHeight);
        }

        /*
          * This initializes the matchHeight js library
          */
        /* Make items equal height */
        jQuery('.equalheight').matchHeight();

        /* Make items equal height in same row */
        jQuery('.equalheight-row').matchHeight(true);

        /* Make items equal height on titles */
        jQuery('.equalheight-title').matchHeight(true);

        /* Article Teaser Categories */
        jQuery('.equalheight-art-teaser-cat').matchHeight(true);

        /* Article Teaser Tags */
        jQuery('.equalheight-art-teaser-tag').matchHeight(true);

        /* Article Teaser Title */
        jQuery('.equalheight-art-teaser-title').matchHeight(true);

        /* Article Teaser Intro */
        jQuery('.equalheight-art-teaser-intro').matchHeight(true);

        /* Downtime Calculator form fields */
        jQuery('.downtime-calculator__form-fields .textTitle').matchHeight(true);

        /* Need to execute when Load More is clicked */
        jQuery(document).ajaxComplete(function () {
          /* Article Teaser Categories */
          jQuery('.equalheight-art-teaser-cat').matchHeight(true);

          /* Article Teaser Tags */
          jQuery('.equalheight-art-teaser-tag').matchHeight(true);

          /* Article Teaser Title */
          jQuery('.equalheight-art-teaser-title').matchHeight(true);

          /* Article Teaser Intro */
          jQuery('.equalheight-art-teaser-intro').matchHeight(true);
        });

        /* Webform wrapper for Styled Select */
        jQuery('.form-item.form-type-select select').once('form-type-select').wrap("<div class='select-wrap'></div>");

        /* Radilogy US Email Shrare */
        var current_link_text = jQuery('a.email-share-button').attr('href');
        var current_page_url = window.location.href;
        jQuery('a.email-share-button').attr('href', current_link_text + 'View Now ' + current_page_url);

        /* Check if document listing exists */
        if (jQuery('.document-listing-wrapper').length) {
          /* Bind sort select */
          jQuery('#edit-sort-by').on('change', function () {
            jQuery('#views-exposed-form-document-listing-page-1').trigger('submit');
          });

          /* Custom Select */
          jQuery('select').customSelect();

          // Bind click table row
          jQuery('.document-listing-wrapper .views-table tr').on('click', function (event) {
            var $element = jQuery(event.currentTarget);
            var href = $element.children('td').last().find('a').attr('href');

            window.location = href;
          });
        }

        if (document.querySelector('.icon-finger')) {
          IntersectionObserver.prototype.POLL_INTERVAL = 100;

          var finger = document.querySelector('.icon-finger');

          var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
              if (entry.intersectionRatio > 0) {
                if ($(window).width() < 768) {
                  finger.classList.add('animated');
                }
              }
            });
          });

          observer.observe(finger);

          jQuery(window).on('resize', function () {
            if (jQuery(window) > 768) {
              jQuery('.icon-finger').removeClass('animated');
            }
          });
        }
      }
    };

    if (jQuery('#vid')) {
      var step = function step() {
        if (document.activeElement.nodeName === 'IFRAME' && document.activeElement.src.indexOf('https://video-streaming.bayer.com/') >= 0) {
          document.activeElement.blur();
          scrollingElement.scrollTop = lastScrollTop;
        } else {
          lastScrollTop = scrollingElement.scrollTop;
        }
        window.requestAnimationFrame(step);
      };

      var scrollingElement = document.scrollingElement || document.documentElement;
      var lastScrollTop = scrollingElement.scrollTop;

      window.requestAnimationFrame(step);
    }
  })(window, jQuery, Drupal);

  ;
  'use strict';

  function slideInSearch() {
    jQuery('.search-action').addClass('slide-in');
    jQuery('.search-action').removeClass('slide-out');
    jQuery('.menu--bayph-radlgy-main-menu').addClass('search-menu-hide');
  }

  function slideOutSearch() {
    jQuery('.search-action').addClass('slide-out');
    jQuery('.search-action').removeClass('slide-in');
    jQuery('.menu--bayph-radlgy-main-menu').removeClass('search-menu-hide');
  }

  jQuery(document).ready(function () {
    jQuery('.branding__search .search-action input[type=search]').attr('placeholder', 'Search');

    if (jQuery(document).width() > 1023) {
      var mouseOverActiveElement = false;

      jQuery('#block-searchform .form-actions').prepend('<i class="icon search-dark-blue"></i>');
      jQuery('#block-searchform .form-actions').append('<div class=\'close-icon\'><i class=\'icon close-dark-blue\'></i></div>');

      jQuery('.branding__search').on('mouseenter', function () {
        mouseOverActiveElement = true;
      });

      jQuery('.branding__search').on('mouseleave', function () {
        mouseOverActiveElement = false;
      });

      jQuery('html').click(function () {
        if (!mouseOverActiveElement) {
          slideOutSearch();
        }
      });

      jQuery('.search-icon').click(function () {
        slideInSearch();
      });

      jQuery('.close-icon').click(function () {
        slideOutSearch();
      });
    } else {
      jQuery('.search-action').removeClass('slide-out');
    }
  });

  ;
  'use strict';

  jQuery(document).ready(function () {
    if (!jQuery('body').hasClass('logged-in') && jQuery('body').width() > 1023) {
      jQuery('.block-gigya-rass-links').append('<div class=\'login-register-icon\'><i class=\'icon profile\'></i></div>');
    }

    if (jQuery('body').width() > 1023) {
      jQuery('.profile-login').append('<div class=\'login-register-icon\'><i class=\'icon profile\'></i></div>');
    } else {
      jQuery('.profile-login').html('');
      jQuery('.profile-login').append('<div class=\'login-register-icon\'><i class=\'icon profile\'></i></div>');
    }
  });

  ;
  'use strict';

  jQuery(document).ready(function () {
    if (jQuery(document).width() <= 460 && !jQuery('.document-listing-wrapper').length) {
      jQuery('table').wrap('<div class="table-wrapper"></div>');
      jQuery('.table-wrapper').wrap('<div class="table-outer-wrapper"></div>');
      jQuery('.table-wrapper').append('<div class="table-arrow-right"><i class=\'icon chevron-right-dark-blue\'></i></div>');
      jQuery('.table-wrapper').append('<div class="table-arrow-left"><i class=\'icon chevron-left-dark-blue\'></i></div>');
      jQuery('.table-arrow-left').fadeOut('fast');

      jQuery('.table-arrow-right').click(function () {
        var scrollEdge = jQuery('.table-wrapper').width();
        var scrollPosition = (jQuery('.table-wrapper').scrollLeft() + scrollEdge) * 0.75;
        var scrollLeft = jQuery('.table-wrapper').scrollLeft();

        if (scrollLeft === scrollEdge) {
          jQuery('.table-wrapper').animate({ scrollLeft: scrollEdge }, 1000);
        } else {
          jQuery('.table-wrapper').animate({ scrollLeft: scrollPosition }, 1000);
        }
      });

      jQuery('.table-arrow-left').click(function () {
        var scrollPosition = jQuery('.table-wrapper').scrollLeft() * 0.25;
        var scrollLeft = jQuery('.table-wrapper').scrollLeft();

        if (scrollLeft <= 100) {
          jQuery('.table-wrapper').animate({ scrollLeft: 0 }, 1000);
        } else {
          jQuery('.table-wrapper').animate({ scrollLeft: scrollPosition }, 1000);
        }
      });

      jQuery('.table-wrapper').scroll(function () {
        var scrollLeft = jQuery('.table-wrapper').scrollLeft();
        var scrollWindowWidth = parseInt(jQuery('.table-wrapper').width(), 0);

        if (scrollWindowWidth === scrollLeft) {
          jQuery('.table-arrow-right').fadeOut('fast');
        } else {
          jQuery('.table-arrow-right').fadeIn();
        }

        if (scrollLeft === 0) {
          jQuery('.table-arrow-left').fadeOut('fast');
        } else {
          jQuery('.table-arrow-left').fadeIn();
        }
      });
    }
  });

  ;
  /* Drupal Behaviour */
  (function ($, Drupal, drupalSettings) {
    Drupal.behaviors.bayer_ph_radiology_basetheme = {
      attach: function attach(context, settings) {
        jQuery(function () {
          var email_share = drupalSettings.bayer_ph_radiology_basetheme.share;
          var title = drupalSettings.bayer_ph_radiology_basetheme.subject;

          if (typeof title === 'undefined' || !title) {
            title = 'Bayer MR Contrast Agent';
          }
          var url = window.location.href; 
          var count = jQuery('a.'+email_share).length;
          if(count > 0) {
            jQuery('a.'+email_share).attr('href','mailto:?subject=' + title + ' : ' + url);
          }
        });
      }
    };
  })(jQuery, Drupal, drupalSettings);

  ;
  /**
   * @file
   * Contains the utility functions for cookie compliance.
   */

  (function ($, Drupal, drupalSettings) {
    Drupal.bayerCookieCompliance = Drupal.bayerCookieCompliance || {};
    // SERVICE LIST to check the list of services - Start.
    var SERVICE_LIST = [];
    var services = drupalSettings.bayerglobaleucookiecompliance.servicesList;
    $.each(services, function(index, data) {
      SERVICE_LIST.push(data.service_name);
    });
    // SERVICE LIST to check the list of services - End.
    /**
     * Erase all the cookies for a given service.
     */
    Drupal.bayerCookieCompliance.eraseCookieForService = function (service) {
      Drupal.bayerCookieCompliance.log('deleting' + service);

      if (drupalSettings.bayerglobaleucookiecompliance.servicesList.hasOwnProperty(service)) {
        var cookiesToDelete = drupalSettings.bayerglobaleucookiecompliance.servicesList[service].cookies;
        var domains = drupalSettings.bayerglobaleucookiecompliance.domainsList;
        cookiesToDelete.forEach(function (item, index) {
          if ('undefined' != typeof(domains) && domains.length > 0) {
            domains.forEach(function (domain, domainIndex) {
              Drupal.bayerCookieCompliance.eraseCookie(item, domain, '/');
            })
          }

        });
      }
    };

    Drupal.bayerCookieCompliance.log = function (message) {
      // Un-comment below line in local to see all messages.
      // console.log(message);
    };

    Drupal.bayerCookieCompliance.setCookie = function setCookie(name, value, expiryDays, domain, path) {
      expiryDays = parseInt(expiryDays) || 365;

      var cookieOptions = {
        expires: expiryDays,
        path: path
      };

      if (domain) {
        cookieOptions.domain = domain;
      }

      $.cookie(name, value, cookieOptions);
    };

    Drupal.bayerCookieCompliance.eraseCookieInDomains = function (item) {
      var domains = drupalSettings.bayerglobaleucookiecompliance.domainsList;
      if ('undefined' != typeof(domains) && domains.length > 0) {
        domains.forEach(function (domain, domainIndex) {
          Drupal.bayerCookieCompliance.eraseCookie(item, domain, '/');
        });
      }
    };

    Drupal.bayerCookieCompliance.eraseCookie = function (name, domain, path) {
      return $.removeCookie(name, {
        path: path,
        domain: domain
      });
    };

    Drupal.bayerCookieCompliance.createPopup = function (html, url) {
      var popup = $(html)
        .attr({id: 'sliding-popup'})
        .height(drupalSettings.bayerglobaleucookiecompliance.popup_height)
        .width(drupalSettings.bayerglobaleucookiecompliance.popup_width)
        .hide();
      var height = '400px';
      if (drupalSettings.bayerglobaleucookiecompliance.popup_position) {
        popup.prependTo('body');
        popup.show()
          .attr({class: 'sliding-popup-top clearfix'})
          .css({
            top: -1 * height
          })
          .animate({top: 0}, drupalSettings.bayerglobaleucookiecompliance.popup_delay);
      }
      else {
        popup.appendTo('body');
        popup.show()
          .attr({class: 'sliding-popup-bottom'})
          .css({
            bottom: -1 * height
          })
          .animate({bottom: 0}, drupalSettings.bayerglobaleucookiecompliance.popup_delay);
      }
      popup.css({
        background: '#' + drupalSettings.bayerglobaleucookiecompliance.popup_bg_hex
      }).find('h2, p').css('color', '#' + drupalSettings.bayerglobaleucookiecompliance.popup_text_hex);
      Drupal.bayerCookieCompliance.attachEvents();
    };

    Drupal.bayerCookieCompliance.attachEvents = function () {
      $('.agree-button').bind('click', function () {
        if (drupalSettings.bayerglobaleucookiecompliance.popup_position) {
          $('.sliding-popup-top').animate({top: $('#sliding-popup').height() * -1}, drupalSettings.bayerglobaleucookiecompliance.popup_delay, function () {
            $('#sliding-popup').remove();
          });
        }
        else {
          $('.sliding-popup-bottom').animate({bottom: $('#sliding-popup').height() * -1}, drupalSettings.bayerglobaleucookiecompliance.popup_delay, function () {

            $('#sliding-popup').remove();
            $('#sliding-popup').remove();
          });
        }

        Drupal.bayerCookieCompliance.eraseCookie('cookiemoreinfo', document.location.hostname, '/');
        Drupal.bayerCookieCompliance.setCookie('cookieaccepted', 'yes', drupalSettings.cookieconsent.expiry, document.location.hostname, '/');
        Drupal.bayerCookieCompliance.setCookie('cookieconsent_dismissed', 'yes', drupalSettings.cookieconsent.expiry, document.location.hostname, '/');
        if (window.location.href.indexOf('bayer') > -1) {
          var serviceDomain = document.location.hostname.split('bayer');
          var liftDomain = serviceDomain[1];
        }
        else {
          var serviceDomain = document.location.hostname.split('.');
          var liftDomain = "." + serviceDomain[serviceDomain.length-2] + "." + serviceDomain[serviceDomain.length-1];
        }
        // GDPR - Condition for AL DND OFF - Tracking will start.
        if ($.inArray('acquia_lift', SERVICE_LIST) != -1) {
          Drupal.bayerpheucookiecompliance.setCookie('tc_dnt', 'false', 365, liftDomain, '/');
          _tcaq.push(['setDoNotTrack', false]);
          setTimeout(function(){ location.reload(); }, 2000);
        }
        // GDPR - Function for AL DND OFF - Tracking will start.
      });
    };


    Drupal.bayerCookieCompliance.setOptionalSerivceValue = function (service_name) {
      // check service consent is allow
      var consents = $.cookie('WHGCOOKIECONSENT');
      consents = JSON.parse(consents);
      if (consents[service_name] === "allow") {
        return true;
      }
      else {
        // Check first if service consent is given.
        var cookie_consent = drupalSettings.bayerglobaleucookiecompliance.cookie_values[service_name];

        // If no redirect to privacy statement.
        if (cookie_consent === 'dismiss' || typeof cookie_consent === 'undefined') {
          location.href = drupalSettings.bayerglobaleucookiecompliance.privacy_statement_path;
          return false;
        }
        return true;
      }
    }

  })(jQuery, Drupal, drupalSettings);
  ;
  /**
   * Bayer Cookie Consent
   *
   * @preserve
   * @package CookieConsent
   * @version $Rev: 25440 $ - $Date: 2017-12-13 17:04:33 +0100 (Mi, 13 Dez 2017) $
   */
  "use strict";

  /**
   * Object which holds AJAX functions
   */
  var WHG_AJAX = (function (obj) {

    /**
     * Returns a xhr object depending on the browser
     *
     * @return {Object} xhr object, type is depending on the browser
     */
    obj.getXhr = function () {
      if ("undefined" !== typeof XMLHttpRequest) {
        return new XMLHttpRequest();
      }
      var activeXTypes = [
        "MSXML2.XmlHttp.6.0",
        "MSXML2.XmlHttp.5.0",
        "MSXML2.XmlHttp.4.0",
        "MSXML2.XmlHttp.3.0",
        "MSXML2.XmlHttp.2.0",
        "Microsoft.XmlHttp"
      ];

      var xhr;
      for (var i = 0; i < activeXTypes.length; i++) {
        try {
          xhr = new ActiveXObject(activeXTypes[i]);
          break;
        }
        catch (e) {
        }
      }
      return xhr;
    }

    /**
     * Send a request
     *
     * @param {string} url The url to send the request to
     * @param {function} callback A function to call after retrieving the
     *     request finished
     * @param {string} method The method to use (GET or POST)
     * @param {array} data The data to send
     * @param {boolean} async Set to false for synchronous ajax call
     *     (default is true)
     * @return {undefined}
     */
    obj.send = function (url, callback, method, data, async) {
      if ("undefined" === typeof async) {
        async = true;
      }
      var xhr = obj.getXhr();
      xhr.open(method, url, async);
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && "function" === typeof callback) {
          callback(xhr.responseText, xhr.status);
        }
      };
      if (method == 'POST') {
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
      }
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
      xhr.send(data)
    };

    /**
     * Send a GET request
     *
     * @param {string} url The url to send the request to
     * @param {array} data The data to send
     * @param {function} callback A function to call after retrieving the
     *     request finished
     * @param {boolean} async Set to false for synchronous ajax call
     *     (default is true)
     * @return {undefined}
     */
    obj.get = function (url, data, callback, async) {
      var query = encodeQueryString(data);
      obj.send(url + (query.length ? '?' + query.join('&') : ''), callback, 'GET', null, async)
    };

    /**
     * Send a POST request
     *
     * @param {string} url The url to send the request to
     * @param {array} data The data to send
     * @param {function} callback A function to call after retrieving the
     *     request finished
     * @param {boolean} async Set to false for synchronous ajax call
     *     (default is true)
     * @return {undefined}
     */
    obj.post = function (url, data, callback, async) {
      var query = encodeQueryString(data);
      obj.send(url, callback, 'POST', query.join('&'), async)
    };

    /**
     * Encodes the data as query string
     *
     * @param {array} data The data as array (key => value)
     * @return {string} The data formated as querystring
     */
    function encodeQueryString(data) {
      var query = [];
      for (var key in data) {
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
      }
      return query;
    }

    return obj;
  })(WHG_AJAX || {});

  /**
   * Object which holds helper functions
   */
  var WHG_HELPER = (function (obj, window, undefined) {

    /**
     * @var {array} browserStorageIsAvailable Flag to save if browser
     *     storage (session or local storage as configured above)can be
     *     used
     */
    var browserStorageIsAvailable = [];

    /**
     * Add support for string method startsWith if not existing already
     */
    if (!String.prototype.startsWith) {
      String.prototype.startsWith = function (searchString, position) {
        position = position || 0;
        return this.indexOf(searchString, position) === position;
      };
    }

    /**
     * Inject JS or CSS file in html head
     *
     * @param {string} filename The filename (+path) of the file to inject
     * @param {string} type The type of the file to inject (either js or
     *     css)
     * @param {function} onload Callback which is called after the injected
     *     file has been loaded
     */
    obj.injectHeadFile = function (filename, type, onload) {
      if (typeof filename !== "string" || typeof type !== "string") {
        return;
      }
      if (!filename.indexOf("//")) {
        filename = window.location.protocol + filename;
      }
      else if (!filename.indexOf("/")) {
        filename = window.location.origin + filename;
      }
      if (!filename.startsWith("http")) {
        return;
      }
      var fileref;
      type = type.toLowerCase();
      if ("js" === type) {
        fileref = document.createElement('script');
        fileref.setAttribute("type", "text/javascript");
        fileref.setAttribute("src", filename);
      }
      else if ("css" === type) {
        fileref = document.createElement("link");
        fileref.setAttribute("rel", "stylesheet");
        fileref.setAttribute("type", "text/css");
        fileref.setAttribute("href", filename);
      }
      if ("undefined" !== typeof fileref) {
        if ("function" === typeof onload) {
          fileref.onload = onload;
          fileref.onreadystatechange = function () {
            if (this.readyState == "complete" || this.readyState == "loaded") {
              onload();
            }
          }
        }
        document.getElementsByTagName("head")[0].appendChild(fileref);
      }
    };

    /**
     * @var {string} browserStorageType The browser storage type which
     *     should be used if set by the configuration
     */
    var browserStorageType = "";
    /**
     * Retrieve the browser storage type from the configuration if
     * existing, otherwise fall back to "sessionStorage"
     *
     * @return {string} The storage type to use (either "sessionStorage" or
     *     "localStorage")
     */
    obj.getBrowserStorageType = function () {
      if (browserStorageType.length > 0) {
        return browserStorageType;
      }
      if ("object" === typeof WHG_COOKIECONSENT
        && "object" === typeof WHG_COOKIECONSENT.config
        && WHG_COOKIECONSENT.config.hasOwnProperty("browserStorageType")
        && (WHG_COOKIECONSENT.config.browserStorageType == "sessionStorage" || WHG_COOKIECONSENT.config.browserStorageType == "localStorage")
      ) {
        browserStorageType = WHG_COOKIECONSENT.config.browserStorageType;
        return browserStorageType;
      }
      return "sessionStorage";
    };

    /**
     * Checks if browser storage is available (session or local storage as
     * configured)
     *
     * @return {boolean} True if browser storage can be used, false if not.
     */
    obj.isBrowserStorageAvailable = function () {
      // @TODO: There are so many places where we use this but it is not
      // consistent, we need to redesign this to make it consistent.
      return false;
      var browserStorageType = obj.getBrowserStorageType();
      if (typeof browserStorageIsAvailable[browserStorageType] === "undefined") {
        try {
          var store = window[browserStorageType],
            t = '___storage_test___',
            result;
          store.setItem(t, t);
          result = (t === store.getItem(t));
          store.removeItem(t);
          browserStorageIsAvailable[browserStorageType] = result;
        }
        catch (e) {
          browserStorageIsAvailable[browserStorageType] = false;
        }
      }
      return browserStorageIsAvailable[browserStorageType];
    };

    /**
     * Load a value from browser storage by name (either from local or
     * session storage depending on configuration)
     * @param {string} name The name of the browser storage item
     *
     * @return {string} The value of the browser storage item
     */
    obj.loadFromBrowserStorage = function (name) {
      var browserStorageType = obj.getBrowserStorageType();
      return window[browserStorageType].getItem(name);
    };

    /**
     * Save a value in browser storage (either in local or session storage
     * depending on configuration)
     * @param {string} name The name of the browser storage item
     * @param {string} The value of the browser storage item
     */
    obj.saveInBrowserStorage = function (name, value) {
      var browserStorageType = obj.getBrowserStorageType();
      window[browserStorageType].setItem(name, value);
    };

    /**
     * Converts a JSON string into an object
     *
     * @param {string} data A JSON formatted string
     * @return {object} The JSON string as object
     */
    obj.parseJSON = function (data) {
      if ("string" === typeof data) {
        return (window.JSON && window.JSON.parse)
          ? window.JSON.parse(data)
          : (new Function("return " + data))();
      }
      return data;
    };

    /**
     * Returns if the given value is an empty object
     *
     * @param {object} obj An JS object
     * @return {boolean} True if the value is an empty object, false if it
     *     is not an object or not empty.
     */
    obj.isEmptyObject = function (obj) {
      if ("object" !== typeof obj) {
        return false;
      }
      for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
          return false;
        }
      }

      return JSON.stringify(obj) === JSON.stringify({});
    };

    /**
     * Returns the browsers DNT (DoNotTrack) Setting
     */
    obj.getBrowserDntSetting = function () {
      var dntSetting = undefined;
      if ("doNotTrack" in window) {
        dntSetting = window.doNotTrack;
      }
      else if ("doNotTrack" in navigator) {
        dntSetting = navigator.doNotTrack;
      }
      else if ("msDoNotTrack" in navigator) {
        dntSetting = navigator.msDoNotTrack;
      }
      return ("yes" == dntSetting || 1 == dntSetting);
    };

    return obj;

  })(WHG_HELPER || {}, window);
  ;
  /**
   * Bayer cookie consent main object
   * Implements logic and calls the vendor cookieconsent script to display
   * the banner.
   */
  var WHG_COOKIECONSENT = (function (obj, $, Drupal, window, undefined) {
    Drupal.bayerCookieCompliance = Drupal.bayerCookieCompliance || {};

    // SERVICE LIST to check the list of services - Start.
    var SERVICE_LIST = [];
    var services = drupalSettings.bayerglobaleucookiecompliance.servicesList;
    $.each(services, function(index, data) {
      SERVICE_LIST.push(data.service_name);
    });
    // SERVICE LIST to check the list of services - End.
    // private variables
    // flag to save if cookie has already been saved in browser storage
    var savedInStorage = false,
      // cache consent data (loaded either from cookie or from browser
      // storage)
      consentData = {},
      requestDntStatus = false;

    /**
     * Load cookie data and save it in browser storage
     *
     * @param {function} onCookieSaved Callback which is called after the
     *     cookie has been saved
     */
    var saveCookieInStorage = function (onCookieSaved) {
      loadFromCookie(function (response, status) {
        if (200 === status) {
          var responseObj = WHG_HELPER.parseJSON(response);
          if (WHG_HELPER.isBrowserStorageAvailable() && ("undefined" === responseObj.error || !responseObj.error)) {
            saveInStorage(response);
          }
          onCookieSaved();
        }
      });
    };

    /**
     * Load cookie data (either from browser storage or from cookie)
     *
     * @param {function} onConsentLoaded Callback which is called after the
     *     data has been loaded
     */
    var loadConsent = function (onConsentLoaded) {
      if (WHG_HELPER.isBrowserStorageAvailable()) {
        var consent = loadFromStorage();
        consentData = WHG_HELPER.parseJSON(consent);
        if (null === consentData) {
          consentData = {};
        }
        onConsentLoaded();
      }
      else {
        loadFromCookie(function (response, status) {
          if (200 === status) {
            consentData = WHG_HELPER.parseJSON(response);
          }
          else {
            consentData = {};
          }
          processResponseData(consentData);
          onConsentLoaded();
        });
      }
    };

    /**
     * Load cookie data from cookie
     *
     * @param {function} onCookieLoaded Callback which is called after the
     *     cookie data has been loaded
     */
    var loadFromCookie = function (onCookieLoaded) {
      WHG_AJAX.get(obj.config.ajaxEndpointUrl, {"action": "loadcookie"}, onCookieLoaded);
    };

    /**
     * Load cookie data from storage
     *
     * @return {string} The data from the storage as string
     */
    var loadFromStorage = function () {
      return WHG_HELPER.loadFromBrowserStorage(obj.config.storageItemName);
    };

    /**
     * Extract DNT status from server response and save it (var + browser
     * storage if available). DNT status is removed from data param.
     *
     * @param {object} data The response data object
     */
    var processResponseData = function (data) {
      if ("undefined" !== typeof data.dntstatus) {
        requestDntStatus = data.dntstatus;
        if (WHG_HELPER.isBrowserStorageAvailable()) {
          WHG_HELPER.saveInBrowserStorage(obj.config.dntStorageItemName, data.dntstatus);
        }
        delete data.dntstatus;
      }
    }

    /**
     * Save data in storage
     *
     * @param {string} data The data to store in the browser storage
     */
    var saveInStorage = function (data) {
      if ("string" === typeof data) {
        data = WHG_HELPER.parseJSON(data);
      }
      if ("object" === typeof data) {
        processResponseData(data);
        data = JSON.stringify(data);
      }
      WHG_HELPER.saveInBrowserStorage(obj.config.storageItemName, data);
      savedInStorage = (null !== WHG_HELPER.loadFromBrowserStorage(obj.config.storageItemName));
    };

    /**
     * Receive DNT status from server request (in case e.g. proxy sets DNT
     * to true)
     *
     * @return {boolean} True if DNT is set, false if not
     */
    var getRequestDntSetting = function () {
      if ("undefined" !== typeof requestDntStatus) {
        return requestDntStatus;
      }
      if (WHG_HELPER.isBrowserStorageAvailable() && "undefined" !== WHG_HELPER.loadFromBrowserStorage(obj.config.dntStorageItemName)) {
        requestDntStatus = !!WHG_HELPER.loadFromBrowserStorage(obj.config.dntStorageItemName);
        return requestDntStatus;
      }
      return false;
    };

    /**
     * Check if cookie is complete (= all services are in the cookie)
     *
     * @return {boolean} True if complete, false if not
     */
    var isCookieComplete = function () {
      var res = true;
      for (var i = 0; i < obj.config.serviceList.length; i++) {
        if (!consentData.hasOwnProperty(obj.config.serviceList[i])) {
          res = false;
          break;
        }
      }
      return res;
    };

    /**
     * Get the current consent data for the given service
     *
     * @param {string} serviceName The name of the service
     * @return {boolean} True if service is allowed, false if not
     */
    var getCookieValueOf = function (serviceName) {
      return consentData[serviceName];
    };

    /**
     * Check if the current page is a page without tracking
     *
     * @return {boolean} True if the current page is without tracking,
     *     false otherwise. Will also return true if the configuration does
     *     not hold the necessary information.
     */
    var isPrivacyPage = function () {
      var res;
      if ("undefined" === typeof obj.config.pageIdsWithoutTracking || "undefined" === typeof obj.config.currentPageId) {
        res = false;
      }
      else {
        res = obj.config.pageIdsWithoutTracking.indexOf(obj.config.currentPageId) !== -1;
      }
      // added check for privacy page:
      var currentUrl = window.location.pathname;
      if (currentUrl.endsWith('privacy-statement')) {
        res = true;
      }
      return res;
    }

    /**
     * Writes given status for all services at once to the cookie
     *
     * @param {boolean} newStatus True to allow, false to deny all services
     * @param {function} onFinished Callback which is called after new
     *     status for all services has been saved
     */
    var writeToCookieAllServices = function (newStatus, onFinished) {
      WHG_AJAX.post(
        obj.config.ajaxEndpointUrl,
        {
          "action": "saveallcookie",
          "value": newStatus
        },
        onFinished
      );
    };

    /**
     * Writes given status for all services which do not have a value yet
     * in the cookie
     *
     * @param {boolean} newStatus True to allow, false to deny all services
     *     which do not have a consent yet
     * @param {function} onFinished Callback which is called after status
     *     for the missing services has been saved
     */
    var writeToCookieMissingServices = function (newStatus, onFinished) {
      WHG_AJAX.post(
        obj.config.ajaxEndpointUrl,
        {
          "action": "savemissing",
          "value": newStatus
        },
        onFinished
      );
    };

    /**
     * Writes given status for a single service to the cookie
     *
     * @param {string} serviceName The name of the service
     * @param {boolean} newStatus True to allow, false to deny all services
     * @param {function} onFinished Callback which is called after new
     *     status for all services has been saved
     */
    var writeToCookieSingleService = function (serviceName, newStatus, onFinished) {
      WHG_AJAX.post(
        obj.config.ajaxEndpointUrl,
        {
          "action": "savecookie",
          "service": serviceName,
          "value": newStatus
        },
        onFinished
      );
    };

    /**
     * @var {array} alreadyInjected Array with names of services whos files
     *     already have been injected (to avoid double injection)
     */
    var alreadyInjected = [];
    /**
     * Inject head files of all currently active services
     * Services which have not been denied nor accepted by the user are NOT
     * injected
     */
    var injectServicesFiles = function () {
      for (var service in consentData) {
        if (service !== 'undefined') {
          if (-1 === alreadyInjected.indexOf(service)
            && consentData.hasOwnProperty(service)
            && true === consentData[service]
            && obj.config.scripts.hasOwnProperty(service)
          ) {
            WHG_HELPER.injectHeadFile(obj.config.scripts[service], "js");
            alreadyInjected.push(service);
          }
        }
      }
    };

     /**
     * Inject head files of all services if not inactive in cookie
     * Services which have not been denied nor accepted by the user are injected
     */

    var acquiaLiftDndOn = function() {
      if ($.inArray('acquia_lift', SERVICE_LIST) != -1) {
        Drupal.bayerCookieCompliance.eraseCookieForService('acquia_lift');
       _tcaq.push(['setDoNotTrack', true]);
      }
    };

    /**
     * Inject head files of all services if not inactive in cookie
     * Services which have not been denied nor accepted by the user are injected
     */

    var acquiaLiftDndOff = function() {
      if ($.inArray('acquia_lift', SERVICE_LIST) != -1) {
        _tcaq.push(['setDoNotTrack', false]);
      }
    };

    /**
     * Inject head files of all services if not inactive in cookie
     * Services which have not been denied nor accepted by the user are
     * injected
     */
    var injectActiveServicesFiles = function () {
      for (var serviceId in obj.config.serviceList) {
        var service = obj.config.serviceList[serviceId];
        if (-1 === alreadyInjected.indexOf(service)
          && obj.config.scripts.hasOwnProperty(service)
          && (!consentData.hasOwnProperty(service)
            || (consentData.hasOwnProperty(service) && consentData[service])
          )
        ) {
          WHG_HELPER.injectHeadFile(obj.config.scripts[service], "js");
          alreadyInjected.push(service);
        }
      }
    };

    /**
     * Set new status for all services (in var, browser storage and cookie)
     * which have not set consent yet Can only be used after data has been
     * loaded (e.g. in onLoadedCustom callback)
     *
     * @param {string} newStatus The new status for the missing services
     *     (either "allow" or "deny")
     * @param {function} onFinished Callback which is executed after status
     *     has been saved
     */
    var saveMissing = function (newStatus, onFinished) {
      if (newStatus !== "") {
        writeToCookieMissingServices(newStatus, function (response, status) {
          var responseData = WHG_HELPER.parseJSON(response);
          if (WHG_HELPER.isBrowserStorageAvailable()
            && "undefined" !== typeof responseData.cookievalue) {
            consentData = responseData.cookievalue;
            saveInStorage(consentData);
          }
          if ("function" === typeof onFinished) {
            onFinished(response, status);
          }
        });
      }
    };

    /**
     * Initialises the CookieConsent by either calling a custom initialise
     * function or the bannerInitialise
     */
    var initialise = function () {
      if ("function" === typeof obj.config.initialise) {
        obj.config.initialise.call(obj);
      }
      else {
        obj.bannerInitialise();
      }
    }

    /**
     * Shows the banner by
     * defining the banner click action and initialising the banner script
     */
    var doShowBanner = function () {
      if ("undefined" !== typeof window.cookieconsent) {
        window.cookieconsent.utils.setCookie = function (name, value, expiryDays, domain, path) {
          obj.saveAllServices(value, function () {
            injectServicesFiles();
          });
        };
        if ("string" === typeof obj.config.cookieConsentConfig.container) {
          var el = document.getElementById(obj.config.cookieConsentConfig.container);
          if (el) {
            obj.config.cookieConsentConfig.container = el;
          }
          else {
            obj.config.cookieConsentConfig.container = undefined;
          }
        }
        initialise();
      }
    };

    /**
     * Check if the current request is the first request of the users
     * session
     *
     * @return {boolean} True if the current request is the first request,
     *     false if not
     */
    var staticIsFirstRequest;
    var isFirstRequest = function () {
      staticIsFirstRequest = typeof $.cookie(drupalSettings.bayerglobaleucookiecompliance.consent_cookie_name) === 'undefined';
      return staticIsFirstRequest;
    };

    /**
     * Saves that the current request is the first has been done
     */
    var saveFirstRequestUrl = function (url) {
      if ("undefined" === typeof url) {
        url = window.location.href;
      }
      if (WHG_HELPER.isBrowserStorageAvailable()) {
        WHG_HELPER.saveInBrowserStorage(obj.config.firstRequestStorageItemName, url);
      }
    };

    /**
     * Returns if the overlay is currently used and open (instead of
     * banner)
     * To check if banner or overlay are open use obj.popup.isOpen method
     * (if popup exists).
     */
    obj.isOverlayOpen = function () {
      return (
        obj.consentType.id === obj.config.consentTypes.explicit_optin
        && isFirstRequest()
        && obj.isOpen()
      );
    }

    /**
     * Initialises the Insites CookieConsent and saves popup reference
     */
    obj.bannerInitialise = function () {
      if ("object" !== typeof obj.popup) {
        window.cookieconsent.initialise(obj.config.cookieConsentConfig, function (p) {
          obj.popup = p;
        });
      }
    }

    /**
     * Returns if the popup is currently open
     * @return {boolean} True if the popup is open, false otherwise
     */
    obj.isOpen = function () {
      return "object" === typeof obj.popup && obj.popup.isOpen();
    }

    /**
     * Check if consent for the given service (no matter if allowed or
     * denied)
     *
     * @param {string} serviceName The name of the service
     */
    obj.isConsentSet = function (serviceName) {
      return ("undefined" !== typeof consentData[serviceName]);
    };

    /**
     * Set new status for all services (in var, browser storage and cookie)
     * Can only be used after data has been loaded (e.g. in onLoadedCustom
     * callback)
     *
     * @param {string} newStatus The new status for all services (either
     *     "allow" or "deny")
     * @param {function} onFinished Callback which is executed after new
     *     status has been saved
     */
    obj.saveAllServices = function (newStatus, onFinished) {
      writeToCookieAllServices(newStatus, function (response, status) {
        if (newStatus !== "") {
          for (var i = 0; i < obj.config.serviceList.length; i++) {
            consentData[obj.config.serviceList[i]] = (newStatus === obj.consentType.allowClass);
          }
          if (WHG_HELPER.isBrowserStorageAvailable()) {
            saveInStorage(consentData);
          }
          if ("function" === typeof onFinished) {
            onFinished(response, status);
          }
        }
      });
    };

    /**
     * Inject asynchronously head files of all currently active services.
     * Services which have not been denied nor accepted by the user are NOT injected.
     */
    obj.asyncInjectServicesFiles = function() {
        for (var service in consentData) {
            if (-1 === alreadyInjected.indexOf(service)
                && consentData.hasOwnProperty(service)
                && true === consentData[service]
                && obj.config.scripts.hasOwnProperty(service)
            ) {
                $.getScript( obj.config.scripts[service], function( data, textStatus, jqxhr ) {
                    alreadyInjected.push(service);
                });
            }
        }
    }

    /**
     * Set new status for given service
     * Can only be used after data has been loaded (e.g. in onLoadedCustom
     * callback) The passed service will be set to the new status. For
     * "implicit_optin" all other services which do not yet have a status
     * will be set to "allow" additionally.
     *
     * @param {string} newStatus The new status for the service (either
     *     "allow" or "deny")
     * @param {string} serviceName Name of the service
     * @param {function} onFinished Callback which is executed after deny
     *     has been saved
     */
    obj.saveOneService = function (serviceName, newStatus, onFinished) {
      newStatus = newStatus === 'allow' ? obj.consentType.allowClass : obj.consentType.denyClass; // privacy only has allow and deny status independent of consenttype
      obj.consentType.saveOneService(serviceName, newStatus, onFinished);
    };

    obj.acceptAllCookies = function () {
      if (drupalSettings.bayerglobaleucookiecompliance.hasOwnProperty('servicesList')) {
        obj.allaccepted = true;
        var servicesListone = drupalSettings.bayerglobaleucookiecompliance.servicesList;
        for (var service in servicesList) {
          obj.saveOneService(service, 'allow', function () {
          });
        }
      }
    };

    var initializeServicesCookies = function (status) {
      if (drupalSettings.bayerglobaleucookiecompliance.hasOwnProperty('servicesList')) {
        obj.allaccepted = true;
        var servicesList = drupalSettings.bayerglobaleucookiecompliance.servicesList;
        for (var service in servicesList) {
          obj.saveOneService(service, status, function () {
          });
        }
      }
    };


    /**
     * Return the current status of the tracking (consentData)
     * This might differ from the given consent (e.g. if the user already
     * gave consent and then activated DNT, tracking might be completely
     * deactivated and thus this method will return false for all services)
     *
     * @return {object} The currently used consentData as object. (e.g. {
           *     gtm: false, ga: false, wt: false, aa: false, uet: false })
     */
    obj.getConsentData = function () {
      return obj.consentType.getConsentData();
    };


    /**
     * Returns combined request and browser dnt setting
     *
     * @return {boolean} True if DNT is set either in request or in
     *     browser, false if not set in both
     */
    obj.getDntSetting = function () {
      return getRequestDntSetting() || WHG_HELPER.getBrowserDntSetting();
    };

    /**
     * Determine which button class is used for "allow" (this depends on
     * the chosen consent type) Still needed for legacy implementations
     *
     * @return {array} An array with the name of the button classes
     *     (['allow': {string}, 'dismiss': {string}])
     */
    obj.determineActionClasses = function () {
      return {
        allow: obj.consentType.allowClass,
        dismiss: obj.consentType.denyClass,
        deny: obj.consentType.denyClass
      };
    };

    /**
     * Switches to the configured consent type by putting the consent type
     * logic into the obj.consentType object
     */
    var configureConsentType = function () {
      var consentTypes = {};
      consentType = obj.config.consentType;

      if (WHG_COOKIECONSENT.getDntSetting() == true) {
        if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'deactivate-tracking' ||
          drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'opt-out' ||
          drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'opt-out-first-request' ||
          drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'explict' ||
          drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'implict-consent'
          ) {
          consentType = drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type;
        }
        else if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'ignore-dnt') {
          if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out' ||
            drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out-first-request' ||
            drupalSettings.bayerglobaleucookiecompliance.consent_type == 'explict' ||
            drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict-consent') {
            consentType = drupalSettings.bayerglobaleucookiecompliance.consent_type;
          }
        }
      }
      else {
        if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out' ||
          drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out-first-request' ||
          drupalSettings.bayerglobaleucookiecompliance.consent_type == 'explict' ||
          drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict-consent') {
          consentType = drupalSettings.bayerglobaleucookiecompliance.consent_type;
        }
      }

      switch(consentType) {
        case 'explict':
          consentType = 0;
          break;
        case 'implict-consent':
          consentType = 1;
          break;
        case 'opt-out':
          consentType = 2;
          break;
        case 'opt-out-first-request':
          consentType = 4;
          break;
        default:
          consentType = 0;
          break;   
      }

      // Explicit
      consentTypes[obj.config.consentTypes["explicit_optin"]] = {
        name: "explicit_optin",
        id: obj.config.consentTypes["explicit_optin"],
        allowClass: 'allow',
        denyClass: 'dismiss',
        onLoaded: function () {
          if (!isCookieComplete()) {
            if (!isFirstRequest()) {
              if (!isPrivacyPage()) {
                $('body').addClass('body__cc-banner');
              }
              saveFirstRequestUrl('done');
            }

            if ($('.cc_overlay').length == 0 && document.cookie.indexOf('cookiemoreinfo') > -1) {
              Drupal.bayerCookieCompliance.createPopup(drupalSettings.bayerglobaleucookiecompliance.popup_html_info);
            }
          }
          injectServicesFiles();
          // GDPR - Remove AL cookies from Domain (Start).
          if ((document.cookie.indexOf('cookieaccepted') == -1) && ($.inArray('acquia_lift', SERVICE_LIST) != -1)) {
           acquiaLiftDndOn();
           Drupal.bayerCookieCompliance.eraseCookieInDomains('cookieaccepted');
          }
          // GDPR - Remove AL cookies from Domain (End).
          if (document.cookie.indexOf('cookieaccepted') > -1 && drupalSettings.bayerglobaleucookiecompliance.hasOwnProperty('servicesList')) {
            var servicesList = drupalSettings.bayerglobaleucookiecompliance.servicesList;
            var consentData = obj.getConsentData();
            for (var service in servicesList) {
              var status = consentData.cookievalue[service];
              obj.saveOneService(service, status, function () {
              });
            }
          }
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            consentData[serviceName] = (newStatus === obj.consentType.allowClass);
            if (WHG_HELPER.isBrowserStorageAvailable()) {
              saveInStorage(consentData);
            }
            if ("function" === typeof onFinished) {
              onFinished(response, status);
            }
            injectServicesFiles();
          });
        },
        getConsentData: function () {
          return consentData;
        }
      };

      // Implicit
      consentTypes[obj.config.consentTypes["explicit_oar_optin"]] = {
        name: "explicit_oar_optin",
        id: obj.config.consentTypes["explicit_oar_optin"],
        allowClass: 'allow',
        denyClass: 'dismiss',
        onLoaded: function () {
          if (!isFirstRequest() && !isPrivacyPage()) {
            saveMissing(obj.consentType.allowClass, onLoadedCallback);
          }
          else {
            onLoadedCallback();
          }

          function onLoadedCallback() {
            if (!isCookieComplete()) {
              doShowBanner();
            }
            if (isFirstRequest()) {
              saveFirstRequestUrl();
            }
            else {
              saveFirstRequestUrl('-');
              if (!isPrivacyPage()) {
                injectServicesFiles();
              }
            }
          }
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            consentData[serviceName] = (newStatus === obj.consentType.allowClass);
            if (WHG_HELPER.isBrowserStorageAvailable()) {
              saveInStorage(consentData);
            }
            if ("function" === typeof onFinished) {
              onFinished(response, status);
            }
            injectServicesFiles();
          });
        },
        getConsentData: function () {
          return consentData;
        }
      };

      // Opt-Out
      consentTypes[obj.config.consentTypes["implicit_optin"]] = {
        name: "implicit_optin",
        id: obj.config.consentTypes["implicit_optin"],
        allowClass: 'allow',//'dismiss',
        denyClass: 'deny',
        onLoaded: function () {
          if (!isCookieComplete()) {
            initializeServicesCookies('allow');
            doShowBanner();
            injectActiveServicesFiles();
          }
          else {
            injectServicesFiles();
          }
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            consentData[serviceName] = (newStatus === obj.consentType.allowClass);
            if (WHG_HELPER.isBrowserStorageAvailable()) {
              saveInStorage(consentData);
            }
            if ("function" === typeof onFinished) {
              onFinished(response, status);
            }
            injectServicesFiles();
          });
        },
        getConsentData: function () {
          var data = {};
          for (var i = 0; i < obj.config.serviceList.length; i++) {
            if (consentData.hasOwnProperty(obj.config.serviceList[i])) {
              data[obj.config.serviceList[i]] = consentData[obj.config.serviceList[i]];
            }
            else {
              data[obj.config.serviceList[i]] = true;
            }
          }
          return data;
        }
      };

      // Opt-Out with Banner only on first page
      consentTypes[obj.config.consentTypes["implicit_ofr_optin"]] = {
        name: "implicit_ofr_optin",
        id: obj.config.consentTypes["implicit_ofr_optin"],
        allowClass: 'allow',
        denyClass: 'deny',
        onLoaded: function () {
          if (!isCookieComplete()) {
            if (isFirstRequest()) {
              doShowBanner();
              saveFirstRequestUrl();
            }
            injectActiveServicesFiles();
          }
          else {
            injectServicesFiles();
          }
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            writeToCookieMissingServices(obj.consentType.allowClass, function (response, status) {
              consentData[serviceName] = (newStatus === obj.consentType.allowClass);
              if (WHG_HELPER.isBrowserStorageAvailable()) {
                saveInStorage(consentData);
              }
              if ("function" === typeof onFinished) {
                onFinished(response, status);
              }
              injectServicesFiles();
            });
          });
        },
        getConsentData: function () {
          var data = {};
          for (var i = 0; i < obj.config.serviceList.length; i++) {
            if (consentData.hasOwnProperty(obj.config.serviceList[i])) {
              data[obj.config.serviceList[i]] = consentData[obj.config.serviceList[i]];
            }
            else {
              data[obj.config.serviceList[i]] = true;
            }
          }
          return data;
        }
      };

      // Do Nothing
      consentTypes[obj.config.consentTypes["implicit_dn_optin"]] = {
        name: "implicit_dn_optin",
        id: obj.config.consentTypes["implicit_dn_optin"],
        allowClass: 'dismiss',
        denyClass: 'deny',
        onLoaded: function () {
          if (!isCookieComplete()) {
            saveMissing(obj.consentType.allowClass, function () {
              injectServicesFiles();
            });
          }
          else {
            injectServicesFiles();
          }
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            consentData[serviceName] = (newStatus === obj.consentType.allowClass);
            if (WHG_HELPER.isBrowserStorageAvailable()) {
              saveInStorage(consentData);
            }
            if ("function" === typeof onFinished) {
              onFinished(response, status);
            }
            injectServicesFiles();
          });
        },
        getConsentData: function () {
          var data = {};
          for (var i = 0; i < obj.config.serviceList.length; i++) {
            if (consentData.hasOwnProperty(obj.config.serviceList[i])) {
              data[obj.config.serviceList[i]] = consentData[obj.config.serviceList[i]];
            }
            else {
              data[obj.config.serviceList[i]] = true;
            }
          }
          return data;
        }
      };

      // Inactive
      consentTypes[obj.config.consentTypes["inactive"]] = {
        name: "inactive",
        id: obj.config.consentTypes["inactive"],
        allowClass: 'dismiss',
        denyClass: 'deny',
        onLoaded: function () {
        },
        saveOneService: function (serviceName, newStatus, onFinished) {
          writeToCookieSingleService(serviceName, newStatus, function (response, status) {
            consentData[serviceName] = (newStatus === obj.consentType.allowClass);
            if (WHG_HELPER.isBrowserStorageAvailable()) {
              saveInStorage(consentData);
            }
            if ("function" === typeof onFinished) {
              onFinished(response, status);
            }
          });
        },
        getConsentData: function () {
          var data = {};
          for (var i = 0; i < obj.config.serviceList.length; i++) {
            data[obj.config.serviceList[i]] = false;
          }
          return data;
        }
      };

      if (true == obj.getDntSetting() && obj.config.hasOwnProperty("dntConsentType") && consentTypes.hasOwnProperty(obj.config.dntConsentType)) {
        consentType = obj.config.dntConsentType;
        if (obj.config.hasOwnProperty("dntCookieConsentConfig")) {
          obj.config.cookieConsentConfig.type = obj.config.dntCookieConsentConfig.type;
          obj.config.cookieConsentConfig.elements.allow = obj.config.dntCookieConsentConfig.elements.allow;
          obj.config.cookieConsentConfig.elements.dismiss = obj.config.dntCookieConsentConfig.elements.dismiss;
          obj.config.cookieConsentConfig.elements.deny = obj.config.dntCookieConsentConfig.elements.deny;
          obj.config.cookieConsentConfig.content = obj.config.dntCookieConsentConfig.content;
        }
      }
      obj.consentType = consentTypes[consentType];
    };

    /**
     * Callback which is called after the consent has been loaded (from
     * browser storage or cookie)
     */
    obj.onLoaded = function () {
      configureConsentType();
      obj.consentType.onLoaded();

      if ("function" === typeof obj.onLoadedCustom) {
        obj.onLoadedCustom(consentData);
      }

      Drupal.bayerCookieCompliance.updateCookieStatus();
    };

    /**
     * Constructor function
     * If consent data is not saved in browser storage consent data is
     * loaded from cookie and stored in browser storage. Otherwise data is
     * loaded from browser storage. Then onLoaded callback is triggered.
     *
     * @constructor
     */
    Drupal.bayerCookieCompliance.init = function () {
      // @TODO: Check all config here, lot needs to be removed, lot needs to
      // be made dynamic.
      obj.config = {
        ajaxEndpointUrl: drupalSettings.bayerglobaleucookiecompliance.url,
        // banner configuration
        cookieConsentConfig: {
          // container: 'main', // uncomment to define root dom element for
          // banner
          revokable: 'false',
          revokeBtn: '<div></div>',

          palette: {
            popup: {
              background: "rgb(73, 131, 122)",
              text: "#ffffff"
            },
            button: {
              background: "#00a88f",

              text: "#ffffff"
            }
          },
          theme: "block",
          position: "top",
          "static": "true",
          type: "opt-in",
          elements: {
            header: '<span class="cc-header">{{header}}</span>&nbsp;',
            message: '<span id="cookieconsent:desc" class="cc-message">{{message}}</span>',
            messagelink: '<span id="cookieconsent:desc" class="cc-message">{{message}} <a aria-label="{{link}}" tabindex="0" class="cc-link" href="{{href}}">{{link}}</a></span>',

            allow: '<span aria-label="{{allow}}" tabindex="0" class="cc-btn cc-allow">{{allow}}</span>',
            dismiss: '',
            deny: '',
            link: '<a aria-label="{{link}}" tabindex="0" class="cc-link" href="{{href}}">{{link}}</a>',
            close: '<span aria-label="{{close}}" tabindex="0" class="cc-close">{{close}}</span>'
          },
          window: '<div role="dialog" aria-live="polite" aria-label="cookieconsent" aria-describedby="cookieconsent:desc" class="cc-window {{classes}}"><!--googleoff: all-->{{children}}<!--googleon: all--></div>',
          compliance: {
            'info': '<div class="cc-compliance">{{dismiss}}</div>',
            'opt-in': '<div class="cc-compliance cc-highlight">{{dismiss}}{{allow}}</div><div class="cc-clear"></div>',
            'opt-out': '<div class="cc-compliance cc-highlight">{{deny}}{{dismiss}}</div><div class="cc-clear"></div>'
          },
          overlay: {
            elements: {
              header: '<span class="cc-header">{{header}}</span>&nbsp;',
              message: '<div class="text-wrapper cc-message">{{message}}</div>',
              messagelink: '<span id="cookieconsent:desc" class="cc-message">{{message}} <a aria-label="{{link}}" tabindex="0" class="cc-link" href="{{href}}">{{link}}</a></span>',
              allow: '<span aria-label="{{allow}}" tabindex="0" class="cc-btn cc-allow">{{allow}}</span>',
              dismiss: '',
              deny: '',
              link: '<a aria-label="{{link}}" tabindex="0" class="cc-link" href="{{href}}">{{link}}</a>',
              close: '<span aria-label="{{close}}" tabindex="0" class="cc-close">{{close}}</span>'
            },
            window: '<div class="cc-window {{classes}}"><div id="cookie-bar-overlay" class="cookie-bar-overlay"></div><div id="cookie-bar" class="cookie-bar"><div class="cc-container"><div class="cc-row"><!--googleoff: all-->{{children}}<div class="settings"><p></p></div><!--googleon: all--></div></div></div></div>',
            compliance: {
              'info': '<div class="cc-compliance">{{dismiss}}</div>',
              'opt-in': '<div class=" button-wrapper cc-compliance">{{allow}}</div>',
              'opt-out': '<div class="cc-compliance cc-highlight">{{deny}}{{dismiss}}</div>'
            }
          },
          "content": {
            "message": "<p>Vorremmo usare i cookie per capire meglio come utilizzi questo sito web. Ci&ograve; ci permette di migliorare la tua futura esperienza sul nostro sito web. Inoltre, i cookie ci permettono e permetteranno alla rete pubblicitaria con cui noi lavoriamo di offrirti annunci pubblicitari basati sui tuoi interessi. Potrai trovare informazioni dettagliate circa l'utilizzo dei cookie su questo sito web, su come gestire o revocare il tuo consenso all&rsquo;uso degli stessi in qualsiasi momento, nella nostra <a href=\"/privacy.php\">dichiarazione sulla Privacy.</a></p>",
            "href": "/privacy.php#performance_cookies",
            "link": "Impostazioni dei cookie ",
            "cookiename_label": "Cookie(s)",
            "description_label": "Scopo e contenuto",
            "lifespan_label": "Durata",
            "provider_label": "Provider",
            "consent_label": "Consenso",
            "dismiss": "",
            "allow": "OK",
            "hint": "",
            "functional_cookies": "Cookie Funzionali",
            "performance_cookies": "Cookie  Opzionali",
          }
        },
        consentType: Drupal.bayerCookieCompliance.consentTypeConfig,
        consentTypes: {
          "explicit_optin": 0,
          "explicit_oar_optin": 1,
          "implicit_optin": 2,
          "implicit_dn_optin": 3,
          "implicit_ofr_optin": 4,
          "inactive": 5,
        },
        serviceList: Drupal.bayerCookieCompliance.serviceListConfig,// ['gtm'],
        // Removed this since the file does not exist.
        // @todo: Investigate why it was added and do we need this.
        scripts: drupalSettings.bayeraheucookiecompliance.consent_scripts,
        storageItemName: "cookieconsent",
        firstRequestStorageItemName: "firstrequest"
      };

      // Drupal.bayerCookieCompliance.updateCookieStatus();
      savedInStorage = WHG_HELPER.isBrowserStorageAvailable() && (loadFromStorage() !== null);
      if (!savedInStorage) {
        saveCookieInStorage(function () {
          loadConsent(obj.onLoaded);
        });
      }
      else {
        loadConsent(obj.onLoaded);
      }
    };

    Drupal.bayerCookieCompliance.updateCookieStatus = function () {
      var consentData = obj.getConsentData();
      for (var service in consentData.cookievalue) {
        var status = consentData.cookievalue[service];
        if (status != 'allow') {
          Drupal.bayerCookieCompliance.eraseCookieForService(service);
          alreadyInjected.pop(service);
        }
      }

      $('.whg-cookie-status').each(function () {
        var consentData = obj.getConsentData();
        return function (i, el) {
          var $el = $(el);
          var cons = 'unselected';
          if ($el.data('cookieservice')) {
            if (!consentData.hasOwnProperty($el.data('cookieservice'))) {
              consentData[$el.data('cookieservice')] = 'unselected';
            }
            switch (consentData[$el.data('cookieservice')]) {
              case true:
              case 'allow':
                $('.whg-cookie-allow', $el).removeClass('inactive').addClass('active');
                $('.whg-cookie-deny', $el).removeClass('active').addClass('inactive');
                break;
              case false:
              case 'deny':
                $('.whg-cookie-allow', $el).removeClass('active').addClass('inactive');
                $('.whg-cookie-deny', $el).removeClass('inactive').addClass('active');
                alreadyInjected.pop($el.data('cookieservice'));
                Drupal.bayerCookieCompliance.eraseCookieForService($el.data('cookieservice'));
                break;
              case 'notselectable':
                $('.whg-cookie-deny, .whg-cookie-allow', $el).removeClass('active').removeClass('inactive');
                break;
              case 'unselected':
                break;
              default:
                $('.whg-cookie-deny, .whg-cookie-allow', $el).removeClass('active').addClass('inactive');
            }
          }
        }
        //}
      });
    };

    return obj;

  })(WHG_COOKIECONSENT || {}, jQuery, Drupal, window);
  ;
  /**
   * @file
   * Contains the definition of the behaviour bayerGlobalEUCookieCompliance.
   */

  (function ($, Drupal, drupalSettings) {

    'use strict';

    Drupal.behaviors.bayerGlobalEUCookieCompliance = {
      attach: function (context, settings) {
        Drupal.bayerCookieCompliance = Drupal.bayerCookieCompliance || {};
        // Name of cookie to be set when dismissed
        Drupal.bayerCookieCompliance.dismissedCookie = 'cookieconsent_dismissed';
        Drupal.bayerCookieCompliance.consentTypeConfig = drupalSettings.bayerglobaleucookiecompliance.consent_type;
        Drupal.bayerCookieCompliance.serviceListConfig = Object.keys(drupalSettings.bayerglobaleucookiecompliance.servicesList);
        // Accept all cookies on clicking ok.
        $(document).on('click','.cc_btn_accept_all',function(){
          if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
            window.AcquiaLiftPublicApi.personalize();
          }

          if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
            if (window.fbp != null) {
              window.fbp.facebookPixel();
            }
          }
          // @TODO: Make these classes dynamic.
          $('body')
            .removeClass('cookie-consent-popup')
            .removeClass('cookie-consent-banner')
            .removeClass('body__cc-banner')
            .removeClass('cc_body_container--bottom')
            .removeClass('cc_body_container--top');
          WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
            WHG_COOKIECONSENT.asyncInjectServicesFiles();
          });
          apiTrrigger();
          if($(this).attr('href') != '#accept'){
            var exturl =isExternalurl($(this).attr('href'));
            if(exturl){
              window.open($(this).attr('href'), '_blank');
            }else{
              location.href = $(this).attr('href');
            }
          }
        });
        $(document).on('click','.cc_btn_not_accept_all',function() {
          // @TODO: Make these classes dynamic.
          $('body')
            .removeClass('cookie-consent-popup')
            .removeClass('cookie-consent-banner')
            .removeClass('body__cc-banner')
            .removeClass('cc_body_container--bottom')
            .removeClass('cc_body_container--top');
          $('.cc_banner-wrapper').remove();
        });
        // Process everything.
        $('html').once('process-cookie-compliance').each(function () {
          if (typeof $.cookie('cookieconsent_dismissed') !== 'undefined'
            || typeof $.cookie('cookieaccepted') !== 'undefined') {
            // @TODO: Make these classes dynamic.
            $('body')
              .removeClass('cookie-consent-popup')
              .removeClass('cookie-consent-banner')
              .removeClass('body__cc-banner')
              .removeClass('cc_body_container--bottom')
              .removeClass('cc_body_container--top');
          }
          Drupal.bayerCookieCompliance.init();
        });
      }
    };
    var isExternalurl = function (url) {
      var host = window.location.hostname;
      var linkHost = function (url) {
        if (/^https?:\/\//.test(url)) { // Absolute URL.
          // The easy way to parse an URL, is to create <a> element.
          // @see: https://gist.github.com/jlong/2428561
          var parser = document.createElement('a');
          parser.href = url;

          return parser.hostname;
        } else { // Relative URL.
          return window.location.hostname;
        }
      } (url);
      return host !== linkHost;
    };
    var apiTrrigger = function () {
      var domain = window.location.hostname;
      var ip = drupalSettings.bayerglobaleucookiecompliance.client_ip;
      var api_url = drupalSettings.bayerglobaleucookiecompliance.api.api_url;
      var api_method = drupalSettings.bayerglobaleucookiecompliance.api.api_method;;
      var api_key = drupalSettings.bayerglobaleucookiecompliance.api.api_key;
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": api_url,
        "method": api_method,
        "headers": {
          "content-type": "application/json",
          "x-api-key": api_key,
          "cache-control": "no-cache",
        },
        "processData": false,
        "data": JSON.stringify({
          "ip": ip,
          "domain": domain
        })
      }
      $.ajax(settings).done(function (response) {
      });
    };
  })(jQuery, Drupal, drupalSettings);
  ;
  (function (drupalSettings, $) {
    // Stop from running again, if accidently included more than once.
    if (window.hasCookieConsent) {
      return;
    }
    window.hasCookieConsent = true;

    /*
     Constants
     */

    // Client variable which may be present containing options to override with
    var OPTIONS_VARIABLE = 'cookieconsent_options';

    // Change cookie consent options on the fly.
    var OPTIONS_UPDATER = 'update_cookieconsent_options';

    // Name of cookie to be set when dismissed
    var DISMISSED_COOKIE = 'cookieconsent_dismissed';
    // Name of cookie to be set when user needs more info
    var MORE_INFO_COOKIE ='cookiemoreinfo';
    // Name of cookie to be set when user accepted all cookies
    var ACCEPTED_COOKIE ='cookieaccepted';

    // The path to built in themes
    // Note: Directly linking to a version on the CDN like this is horrible, but it's less horrible than people downloading the code
    // then discovering that their CSS bucket disappeared
    var THEME_BUCKET_PATH = '//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.10/';

    // SERVICE LIST to check the list of services - Start.
    var SERVICE_LIST = [];
    var services = drupalSettings.bayerglobaleucookiecompliance.servicesList;
    jQuery.each(services, function(index, data) {
      SERVICE_LIST.push(data.service_name);
    });
    // No point going further if they've already dismissed.
    if (document.cookie.indexOf(DISMISSED_COOKIE) > -1 || document.cookie.indexOf(MORE_INFO_COOKIE) > -1 ||(window.navigator && window.navigator.CookiesOK)) {
      return;
    }

    // IE8...
    if(typeof String.prototype.trim !== 'function') {
      String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, '');
      };
    }

    /*
     Helper methods
     */
    var Util = {
      isArray: function (obj) {
        var proto = Object.prototype.toString.call(obj);
        return proto == '[object Array]';
      },

      isObject: function (obj) {
        return Object.prototype.toString.call(obj) == '[object Object]';
      },

      each: function (arr, callback, /* optional: */context, force) {
        if (Util.isObject(arr) && !force) {
          for (var key in arr) {
            if (arr.hasOwnProperty(key)) {
              callback.call(context, arr[key], key, arr);
            }
          }
        } else {
          for (var i = 0, ii = arr.length; i < ii; i++) {
            callback.call(context, arr[i], i, arr);
          }
        }
      },

      merge: function (obj1, obj2) {
        if (!obj1) return;
        Util.each(obj2, function (val, key) {
          if (Util.isObject(val) && Util.isObject(obj1[key])) {
            Util.merge(obj1[key], val);
          } else {
            obj1[key] = val;
          }
        })
      },

      bind: function (func, context) {
        return function () {
          return func.apply(context, arguments);
        };
      },

      /*
       find a property based on a . separated path.
       i.e. queryObject({details: {name: 'Adam'}}, 'details.name') // -> 'Adam'
       returns null if not found
       */
      queryObject: function (object, query) {
        var queryPart;
        var i = 0;
        var head = object;
        query = query.split('.');
        while ( (queryPart = query[i++]) && head.hasOwnProperty(queryPart) && (head = head[queryPart]) )  {
          if (i === query.length) return head;
        }
        return null;
      },

      setCookie: function (name, value, expiryDays, domain, path) {
        expiryDays = expiryDays || 365;

        var exdate = new Date();
        exdate.setTime(exdate.getTime() + expiryDays*24*60*60*1000);

        var cookie = [
          name + '=' + value,
          'expires=' + exdate.toUTCString(),
          'path=' + path || '/'
        ];

        if (domain) {
          cookie.push(
            'domain=' + domain
          );
        }

        document.cookie = cookie.join(';');
      },

      addEventListener: function (el, event, eventListener) {
        if (el.addEventListener) {
          el.addEventListener(event, eventListener);
        } else {
          el.attachEvent('on' + event, eventListener);
        }
      }
    };

    var DomBuilder = (function () {
      /*
       The attribute we store events in.
       */
      var eventAttribute = 'data-cc-event';
      var conditionAttribute = 'data-cc-if';

      /*
       Shim to make addEventListener work correctly with IE.
       */
      var addEventListener = function (el, event, eventListener) {
        // Add multiple event listeners at once if array is passed.
        if (Util.isArray(event)) {
          return Util.each(event, function (ev) {
            addEventListener(el, ev, eventListener);
          });
        }

        if (el.addEventListener) {
          el.addEventListener(event, eventListener);
        } else {
          el.attachEvent('on' + event, eventListener);
        }
      };

      /*
       Replace {{variable.name}} with it's property on the scope
       Also supports {{variable.name || another.name || 'string'}}
       */
      var insertReplacements = function (htmlStr, scope) {
        return htmlStr.replace(/\{\{(.*?)\}\}/g, function (_match, sub) {
          var tokens = sub.split('||');
          var value, token;
          while (token = tokens.shift()) {
            token = token.trim();

            // If string
            if (token[0] === '"') return token.slice(1, token.length - 1);

            // If query matches
            value =  Util.queryObject(scope, token);

            if (value) return value;
          }

          return '';
        });
      };

      /*
       Turn a string of html into DOM
       */
      var buildDom = function (htmlStr) {
        var container = document.createElement('div');
        container.innerHTML = htmlStr;
        return container.children[0];
      };

      var applyToElementsWithAttribute = function (dom, attribute, func) {
        var els = dom.parentNode.querySelectorAll('[' + attribute + ']');
        Util.each(els, function (element) {
          var attributeVal = element.getAttribute(attribute);
          func(element, attributeVal);
        }, window, true);
      };

      /*
       Parse event attributes in dom and set listeners to their matching scope methods
       */
      var applyEvents = function (dom, scope) {
        applyToElementsWithAttribute(dom, eventAttribute, function (element, attributeVal) {
          var parts = attributeVal.split(':');
          var listener = Util.queryObject(scope, parts[1]);
          addEventListener(element, parts[0], Util.bind(listener, scope));
        });
      };

      var applyConditionals = function (dom, scope) {
        applyToElementsWithAttribute(dom, conditionAttribute, function (element, attributeVal) {
          var value = Util.queryObject(scope, attributeVal);
          if (!value) {
            element.parentNode.removeChild(element);
          }
        });
      };

      return {
        build: function (htmlStr, scope) {
          if (Util.isArray(htmlStr)) htmlStr = htmlStr.join('');

          htmlStr = insertReplacements(htmlStr, scope);
          var dom = buildDom(htmlStr);
          applyEvents(dom, scope);
          applyConditionals(dom, scope);

          return dom;
        }
      };
    })();


    /*
     Plugin
     */
    var cookieconsent = {
      options: {
        message: 'This website uses cookies to ensure you get the best experience on our website. ',
        dismiss: 'Got it!',
        learnMore: 'More info',
        link: null,
        target: '_self',
        container: null, // selector
        theme: 'light-floating',
        domain: null, // default to current domain.
        path: '/',
        expiryDays: drupalSettings.cookieconsent.expiry,
        markup: [
          '<div class="cc_banner-wrapper {{containerClasses}}">',
          '<div class="cc_banner cc_container cc_container--open">',
          '<a href="#null" data-cc-event="click:dismiss" target="_blank" class="cc_btn cc_btn_accept_all">{{options.dismiss}}</a>',

          '<p class="cc_message">{{options.message}} <a data-cc-if="options.link" target="{{ options.target }}" class="cc_more_info" href="{{options.link || "#null"}}">{{options.learnMore}}</a></p>',

          '<a class="cc_logo" target="_blank" href="http://silktide.com/cookieconsent">Cookie Consent plugin for the EU cookie law</a>',
          '</div>',
          '</div>'
        ]
      },

      init: function () {
        var options = window[OPTIONS_VARIABLE];
        if (options) this.setOptions(options);

        this.setContainer();

        // Calls render when theme is loaded.
        if (this.options.theme) {
          this.loadTheme(this.render);
        } else {
          this.render();
        }
      },

      setOptionsOnTheFly: function (options) {
        this.setOptions(options);
        this.render();
      },

      setOptions: function (options) {
        Util.merge(this.options, options);
      },

      setContainer: function () {
        if (this.options.container) {
          this.container = document.querySelector(this.options.container);
        } else {
          this.container = document.body;
        }

        // Add class to container classes so we can specify css for IE8 only.
        this.containerClasses = '';
        if (navigator.appVersion.indexOf('MSIE 8') > -1) {
          this.containerClasses += ' cc_ie8'
        }
      },

      loadTheme: function (callback) {
        var theme = this.options.theme;

        // If theme is specified by name
        if (theme.indexOf('.css') === -1) {
          theme = THEME_BUCKET_PATH + theme + '.css';
        }

        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = theme;

        var loaded = false;
        link.onload = Util.bind(function () {
          if (!loaded && callback) {
            callback.call(this);
            loaded = true;
          }
        }, this);

        document.getElementsByTagName("head")[0].appendChild(link);
      },

      render: function () {
        // remove current element (if we've already rendered)
        if (this.element && this.element.parentNode) {
          this.element.parentNode.removeChild(this.element);
          delete this.element;
        }

        this.element = DomBuilder.build(this.options.markup, this);
        if (!this.container.firstChild) {
          this.container.appendChild(this.element);
        } else {
          this.container.insertBefore(this.element, this.container.firstChild);
        }
      },

      dismiss: function (evt) {
        // GDPR - Setting AL cookies to DND OFF - AL Tracking will start (Start).
        if (jQuery.inArray('acquia_lift', SERVICE_LIST) != -1) {
          this.setAcquiaLiftDndOff();
        }
        // GDPR - Setting AL cookies to DND OFF - AL Tracking will start (End).
        evt.preventDefault && evt.preventDefault();
        evt.returnValue = false;
        this.setDismissedCookie();
        this.container.removeChild(this.element);
        Util.setCookie(ACCEPTED_COOKIE, 'yes', this.options.expiryDays, this.options.domain, this.options.path);
        if (jQuery.inArray('acquia_lift', SERVICE_LIST) != -1) {
          setTimeout(function(){ location.reload(); }, 2000);
        }
      },

      setDismissedCookie: function () {
        Util.setCookie(DISMISSED_COOKIE, 'yes', this.options.expiryDays, this.options.domain, this.options.path);
      },
      moreinfo:function(){
        Util.setCookie(MORE_INFO_COOKIE, 'yes', this.options.expiryDays, this.options.domain, this.options.path);
      },
      setAcquiaLiftDndOff: function() {
        // GDPR - Function for AL DND OFF - Tracking will start.
        if (window.location.href.indexOf('bayer') > -1) {
          var serviceDomain = document.location.hostname.split('bayer');
          var liftDomain = serviceDomain[1];
        }
        else {
          var serviceDomain = document.location.hostname.split('.');
          var liftDomain = "." + serviceDomain[serviceDomain.length-2] + "." + serviceDomain[serviceDomain.length-1];
        }

        _tcaq.push(['setDoNotTrack', false]);
        Util.setCookie('tc_dnt', 'false', this.options.expiryDays, liftDomain, '/');
      },
      setAcquiaLiftDndOn: function() {
        // GDPR - Function for AL DND ON - Tracking will stop.
        _tcaq.push(['setDoNotTrack', true]);
      }
    };

    var init;
    var initialized = false;
    (init = function () {
      if (!initialized && document.readyState == 'complete') {
        cookieconsent.init();
        initialized = true;
        window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
      }
    })();

    /*
    Triggers api
    */
     var apiTrrigger = function () {
      var domain = window.location.hostname;
      var ip = drupalSettings.bayerglobaleucookiecompliance.client_ip;
      var api_url = drupalSettings.bayerglobaleucookiecompliance.api.api_url;
      var api_method = drupalSettings.bayerglobaleucookiecompliance.api.api_method;;
      var api_key = drupalSettings.bayerglobaleucookiecompliance.api.api_key;
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": api_url,
        "method": api_method,
        "headers": {
          "content-type": "application/json",
          "x-api-key": api_key,
          "cache-control": "no-cache",
        },
        "processData": false,
        "data": JSON.stringify({
          "ip": ip,
          "domain": domain
        })
      }
      $.ajax(settings).done(function (response) {
      });
    };

    /*
    Check all the cookie items are selected or not.
    */
    var checkSetCookieItems = function() {
      if ($.cookie(drupalSettings.bayerglobaleucookiecompliance.consent_cookie_name)) {
        var consents = $.cookie(drupalSettings.bayerglobaleucookiecompliance.consent_cookie_name);
        if (consents.length > 2) {
          var consents = JSON.parse(consents);
          var consent_counnt = Object.keys(consents["cookievalue"]).length;
          var row_count = $('#bayer-optional-cookie-settings table tbody').children().length - 1;
          if (consent_counnt === row_count) {
            return true;
          }
          else {
            return false;
          }
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }
    };

    /*
    Initialize the cookie consent pop-up/banner.
    */
    var init;

    var initialized = false;

    (init = function () {

      if (!initialized && document.readyState == 'complete') {
        var isAllCookieItemsSet = checkSetCookieItems();
        if (WHG_COOKIECONSENT.getDntSetting() == true) {
          if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'deactivate-tracking' ) {
            //Nothing to do
          }
          else if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'ignore-dnt') {
            if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out') {
              WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
                WHG_COOKIECONSENT.asyncInjectServicesFiles();
              });
              apiTrrigger();
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();

              // Check for personalization.
              if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
                window.AcquiaLiftPublicApi.personalize();
              }
              // Check for fbp.
              if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
                if (window.fbp != null) {
                  window.fbp.facebookPixel();
                }
              }
            }
            else if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out-first-request') {
              WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
                WHG_COOKIECONSENT.asyncInjectServicesFiles();
              });
              apiTrrigger();
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();

              // Check for personalization.
              if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
                window.AcquiaLiftPublicApi.personalize();
              }
              // Check for fbp.
              if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
                if (window.fbp != null) {
                  window.fbp.facebookPixel();
                }
              }
            }
            else if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'explict') {
              if (isAllCookieItemsSet == false) {
                //Works like as default behaviour.
                cookieconsent.init();
                initialized = true;
                window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
                cookieBannerAtTopOrBottom();
              }
            }
            else if(drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict-consent') {
              WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
                WHG_COOKIECONSENT.asyncInjectServicesFiles();
              });
              apiTrrigger();

              // Check for personalization.
              if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
                window.AcquiaLiftPublicApi.personalize();
              }
              // Check for fbp.
              if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
                if (window.fbp != null) {
                  window.fbp.facebookPixel();
                }
              }
              if (WHG_COOKIECONSENT.getDntSetting() == true) {
                cookieconsent.init();
                initialized = true;
                window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
                cookieBannerAtTopOrBottom();
              }
            }
            else if(drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict') {
              WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
                WHG_COOKIECONSENT.asyncInjectServicesFiles();
              });
              apiTrrigger();
              // Check for personalization.
              if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
                window.AcquiaLiftPublicApi.personalize();
              }
              // Check for fbp.
              if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
                if (window.fbp != null) {
                  window.fbp.facebookPixel();
                }
              }
              if (WHG_COOKIECONSENT.getDntSetting() == true) {
                cookieconsent.init();
                initialized = true;
                window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
                cookieBannerAtTopOrBottom();
              }
            }
            else {
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'opt-out') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
          }
          else if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'opt-out-first-request') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }

          }
          else if (drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'explict') {
            if (isAllCookieItemsSet == false) {
              //Works like as default behaviour.
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else if(drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'implict-consent') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
            if (WHG_COOKIECONSENT.getDntSetting() == true) {
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else if(drupalSettings.bayerglobaleucookiecompliance.dnt_consent_type == 'implict') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
            if (WHG_COOKIECONSENT.getDntSetting() == true) {
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else {
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();
          }
        }
        else {
          if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
          }
          else if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'opt-out-first-request') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }

          }
          else if (drupalSettings.bayerglobaleucookiecompliance.consent_type == 'explict') {
            if (isAllCookieItemsSet == false) {
              //Works like as default behaviour.
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else if(drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict') {
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();
            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
            if (WHG_COOKIECONSENT.getDntSetting() == true) {
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else if(drupalSettings.bayerglobaleucookiecompliance.consent_type == 'implict-consent'){
            WHG_COOKIECONSENT.saveAllServices('allow', function(response) {
              WHG_COOKIECONSENT.asyncInjectServicesFiles();
            });
            apiTrrigger();

            // Check for personalization.
            if (drupalSettings.bayerglobaleucookiecompliance.acquia_lift_settings == true) {
              window.AcquiaLiftPublicApi.personalize();
            }
            // Check for fbp.
            if (drupalSettings.bayerglobaleucookiecompliance.fbp_gcc_settings == true) {
              if (window.fbp != null) {
                window.fbp.facebookPixel();
              }
            }
            if (WHG_COOKIECONSENT.getDntSetting() == true) {
              cookieconsent.init();
              initialized = true;
              window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
              cookieBannerAtTopOrBottom();
            }
          }
          else {
            cookieconsent.init();
            initialized = true;
            window[OPTIONS_UPDATER] = Util.bind(cookieconsent.setOptionsOnTheFly, cookieconsent);
            cookieBannerAtTopOrBottom();
          }
        }
      }
    })();

    Util.addEventListener(document, 'readystatechange', init);

    /*
    Resize window to adjust the banner on top/bottom of header/footer.
    */
    $(window).resize(function () {
      cookieBannerAtTopOrBottom();
    });

    /*
    Function to set banner on top header or bottom footer.
    */
    function cookieBannerAtTopOrBottom() {
      if ($(".cookie-consent-banner .subsequent_load_bottom")[0]) {
        var cookieHeight = $(".cookie-consent-banner .subsequent_load_bottom").outerHeight();
        var footer = $(".footer");
        if (footer != undefined) {
          $(".footer").css('margin-bottom', cookieHeight + 'px');
        }
        $(".cookie-consent-banner .subsequent_load_bottom .cc_btn.cc_btn_accept_all").click(function (e) {
          $(".footer").css('margin-bottom', 0 + 'px');
        });
      }
      else if ($(".cookie-consent-banner .subsequent_load_top")[0]) {
        var cookieHeight = $(".cookie-consent-banner .subsequent_load_top").outerHeight();
        if ($(".header div").hasClass("header__sticky")) {
          var header = $(".header .header__sticky");
        }
        else {
          var header = $(".header");
        }

        var headerHeight = header.outerHeight();
        if (header != undefined) {
          $(".header .header__sticky").css('top', cookieHeight + 'px');
        }
        $("body").css({"margin-top":cookieHeight + headerHeight + "px"});
        $(".cookie-consent-banner .subsequent_load_top").css({"position": "absolute", "margin-top": -(cookieHeight+headerHeight) + "px"});

        $(".cookie-consent-banner .subsequent_load_top .cc_btn.cc_btn_accept_all").click(function (e) {
          $(".header .header__sticky").css('top', 0 + 'px');
          $("body").css({"margin-top": headerHeight + "px"});
        });
      }
      // Remove BG color for pop-up.
      if ($('body').hasClass('cookie-consent-popup')) {
        $('div.cc_banner').css('background-color', '#ffffff');
      }
    }
    // Add banner class.
    if (!$('body').hasClass('cookie-consent-popup') && !$('body').hasClass('cookie-consent-banner')) {
      $('body.subsequent_load_top').addClass('cookie-consent-banner');
      $('body.subsequent_load_bottom').addClass('cookie-consent-banner');
     }

    /*
    window scroll for set the header with cookie banner.
    */
    $(window).scroll(function() {
      if ($(".cookie-consent-banner .subsequent_load_top")[0]) {
        if ($(window).scrollTop()<= $(".cookie-consent-banner .subsequent_load_top").outerHeight()) {
          var calculatedHeight= $(".cookie-consent-banner .subsequent_load_top").outerHeight() - $(window).scrollTop();
          $(".header .header__sticky").css('top',  calculatedHeight + 'px');
        }
        else {
          $(".header .header__sticky").css('top', 0 + 'px');
        }
      }
    });

     // Executes when complete page is fully loaded.
    $(window).on("load", function() {
      if (!$('body').hasClass('cookie-consent-popup') && !$('body').hasClass('cookie-consent-banner')) {
        $('body.subsequent_load_top').addClass('cookie-consent-banner');
        $('body.subsequent_load_bottom').addClass('cookie-consent-banner');
      }
    });
  })(drupalSettings, jQuery);
  ;
  /**
   * @file
   * Standard implementatiton.
   */

  (function ($, Drupal, drupalSettings) {
    $(document).ready(function () {
      var mriSettings = drupalSettings.bayph_radlgy_mri;
      if (mriSettings.verify_page && !mriSettings.is_user_logged_in) {

        window.onGigyaServiceReady = function (serviceName) {

          gigyaHelper.runGigyaCmsInit();

          var screenToLoad = drupalSettings.gigya.raas.register;
          if (mriSettings.user_exists){
             screenToLoad = drupalSettings.gigya.raas.login;
          }

          gigya.accounts.showScreenSet(screenToLoad);

          var onLoginHandler = function () {
            setTimeout(function () {
              jQuery.fn.loginRedirect(mriSettings.app_page_alias)
            }, 3000)
          };

          gigya.accounts.addEventHandlers(
            {onLogin: onLoginHandler}
          );
        };

      }

      if(mriSettings.is_user_logged_in){
        // Set unlock button
        $('.field--name-field-bayph-radlgy-btn-cta-link a').attr('href',mriSettings.app_verification_link)
      }

      // Default custom events.
      window.__gigyaConf.customEventMap.eventMap.push({
        events: '*',
        args: [function (e) {
          return e;
        }],
        method: function (e) {
          if (e.eventName === 'afterScreenLoad') {
            if(mriSettings.verify_page && !mriSettings.is_user_logged_in) {
              jQuery('div.gigya-screen-dialog-close a').remove();
              if (mriSettings.user_exists){
                $('[data-gigya-name="loginID"]').val(mriSettings.email_value);
              }else{
                $('[data-gigya-name="email"]').val(mriSettings.email_value)
              }
            }
          }
        }
      });
    });
  })(jQuery, Drupal, drupalSettings);
  ;
  /**
   * @file
   * Standard implementatiton.
   */

  (function ($, Drupal, drupalSettings) {
    $(document).ready(function () {
      window.bayerUserRolesSettings = drupalSettings.bayph_radlgy_user_roles;
      window.customSettings = bayerUserRolesSettings.custom_fields;

      // Method to update user with custom field data defined in Drupal
      window.SendCustomData = function () {
        var customFields = jQuery('.custom-field');
        var data_fields = {};
        if (customFields.length > 0) {
          customFields.each(function () {
            var fieldId = $(this).attr('id');
            var fieldElem = $('#' + fieldId);
            if (fieldElem.val() !== '') {
              data_fields[fieldId] = fieldElem.val()
            }
          })
        }
        jQuery.post(drupalSettings.path.baseUrl + "bayph-radlgy-user-roles/extend_gigya_data", data_fields
        );
      };

      // Method to push in custom field in Gigya Form.
      window.injectField = function (elem,  customSetting, label) {
        if (customSetting.type === 'textfield') {
          var textWrapper = $("<div></div>")
            .attr("class", "gigya-composite-control gigya-screen gigya-composite-control-textbox");

          var inputField = $("<input type='text' />").attr("id", customSetting.name)
            .attr("class", "gigya-input-text custom-field")
            .attr("placeholder", customSetting.label);

          textWrapper.append(inputField);

          if (label !== undefined) {
            labelWrapper = $("<label></label>").attr('class', 'gigya-label');
            labelText = $("<span>" + customSetting.label + ":</span>")
              .attr('class', 'gigya-label-text');

            labelText.appendTo(labelWrapper);
            textWrapper.prepend(labelWrapper);
          }

          textWrapper.insertBefore(elem);
        }

        if (customSetting.type === 'select') {

          var list = customSetting.default_values;
          var wrapperDiv = $("<div></div>")
            .attr("class", "gigya-composite-control gigya-composite-control-dropdown");
          var select = $("<select></select>")
            .attr("id",customSetting.name)
            .attr("class", 'custom-field');

          wrapperDiv.append(select);
          select.append($("<option>" + customSetting.label + "</option>"));
          $.each(list, function (key, value) {
            select.append($("<option></option>").attr("value", key).text(value));
          });

          if (label !== undefined) {
            labelWrapper = $("<label></label>").attr('class', 'gigya-label');
            labelText = $("<span>" + customSetting.label + ":</span>")
              .attr('class', 'gigya-label-text');

            labelText.appendTo(labelWrapper);
            wrapperDiv.prepend(labelWrapper);
          }

          wrapperDiv.insertBefore(elem);

        }
      };

      // Default custom events.
      window.__gigyaConf.customEventMap.eventMap.push({
        events: '*',
        args: [function (e) {
          return e;
        }],
        method: function (e) {
          if (e.eventName === 'afterScreenLoad') {
            var len = $('div.gigya-screen-content .custom-field').length;
            var el = $("#" + bayerUserRolesSettings.register_screen + " .gigya-composite-control-header.mandatory");

            if (e.currentScreen === bayerUserRolesSettings.register_screen) {

              if (typeof customSettings !== 'undefined') {
                if (len < customSettings.length) {

                  for (var i = 0; i < customSettings.length; i++) {

                    injectField(el, customSettings[i]);

                  }
                }
              }
            }

            if (e.currentScreen === bayerUserRolesSettings.profile_screen) {

              el = $("#" + bayerUserRolesSettings.profile_screen + " .gigya-composite-control.gigya-composite-control-submit");
              if (typeof customSettings !== 'undefined') {
                if (len < customSettings.length) {

                  for (var i = 0; i < customSettings.length; i++) {

                    injectField(el, customSettings[i], true);

                  }
                }
              }

              // Fetch information
              gigya.accounts.getAccountInfo({callback: function(ev){
                if (ev.status === 'OK'){
                  $.get( drupalSettings.path.baseUrl + "bayph-radlgy-user-roles/get_custom_data/"+ev.UID, function(data){

                    jQuery.each(data, function(k, v){
                      var field = jQuery('#'+k);
                      if(field.length > 0){
                        field.val(v[0].value)
                      }

                    })

                  });
                }

              }})
            }
          }

          if (e.eventName === 'submit' && (e.screen === bayerUserRolesSettings.register_screen
              || e.screen === bayerUserRolesSettings.profile_screen)) {
            SendCustomData();
          }

        }

      })
    });
  })(jQuery, Drupal, drupalSettings);
  ;
  /**
   * @file
   * In Page Navigation Logic.
   */

  /* Detect when to make menu sticky */
   function inPageStick() {
    var window_top = jQuery(window).scrollTop();
    var top = jQuery('.in-page-anchor').offset().top;

    if (window_top > top) {
      jQuery('.in-page-navigation').addClass('fix-menu');
      jQuery('.in-page-anchor').height(80);
    }
    else {
      jQuery('.in-page-navigation').removeClass('fix-menu');
      jQuery('.in-page-anchor').height(0);
      jQuery('#in-page-menu li.current').removeClass('current');
      jQuery('#in-page-menu li:first').addClass('current');
    }
  }

  jQuery(document).ready(function () {

    jQuery(window).scroll(inPageStick);
    inPageStick();

    /* Build menu from heading tags inside elements with these classes */
    var menuTitles = [];
    var menuTitlesFormatted = [];
    var topMenu = jQuery('#in-page-menu');
    var topMenuHeight = topMenu.outerHeight() + 1;
    var itemsOnPage = [];
    var scrollPosition = [];
    var components =   jQuery('.accordion-group__accordion .accordion-group__accordion-head, ' +
      '.video-gallery-wrapper .video-gallery-title, ' +
      '.content-panel__container .content-panel__headline, ' +
      '.document-teaser-wrapper__title, ' +
      '.video-grid .video-grid-title, .image-gallery__wrapper .image-gallery__wrapper--title');

    var offset = -200;

    if(jQuery('.contrast--menu-wrapper').length > 0) {
      var offset = -300;
    }

    components.each(function () {
      menuTitles.push(jQuery(this).find('h2, h3').first().text().trim());
      menuTitlesFormatted.push(jQuery(this).find('h2, h3').first().html().replace(/<(?!(sup)|(\/sup)\s*\/?)[^>]+>/gm,"").trim());
      var pos = jQuery.inArray(jQuery(this).find('h2, h3').first().text().trim(),menuTitles);
      if(pos !== -1){
        itemsOnPage.push('heading-' + pos);
        jQuery.inArray(jQuery(this).find('h2, h3').first().addClass('heading-' + pos));
      }
    })
    // We need this to have the position of the menu items for the logic on line 140.
    var setPosition = function () {
      jQuery(itemsOnPage).each(function (key, value) {
        if(jQuery('.' + value).length !== 0) {
          var position = jQuery('.' + value).offset().top;
          scrollPosition.push({
            'value': value,
            'position':  position
          });
        }

      });
    }

    setPosition();

    for (i = 0; i < menuTitlesFormatted.length; i++) {
      var listItem = document.createElement("li");

      listItem.className = 'heading-' + i + '-menu';
      listItem.innerHTML = menuTitlesFormatted[i];

      document.getElementById('in-page-menu').appendChild(listItem);
    }

    /* If below 1024px screensize then show dropdown menu */
    if (window.matchMedia('screen and (max-width: 1023px)').matches) {
      var listItem = document.createElement("li");
      var listTitle = document.createTextNode('Navigate to section');
      listItem.className = 'in-page-dropdown';
      listItem.appendChild(listTitle);
      document.getElementById('in-page-menu').insertBefore(listItem, document.getElementById('in-page-menu').firstChild);
      jQuery('#in-page-menu li.current').removeClass('current');

      jQuery('#in-page-menu').on('click', '.in-page-dropdown', function () {
        jQuery(this).closest('ul').children('li:not(.in-page-dropdown)').toggle();
        jQuery('#in-page-menu').toggleClass('open');
      });

      var allOptions = jQuery('#in-page-menu').children('#in-page-menu li:not(.in-page-dropdown)');
      jQuery('#in-page-menu').on('click', 'li:not(.in-page-dropdown)', function () {
        allOptions.removeClass('selected');
        jQuery(this).addClass('selected');
        jQuery('ul#in-page-menu').children('.in-page-dropdown').html(jQuery(this).html());
        allOptions.toggle();
        jQuery('#in-page-menu').toggleClass('open');

        if (jQuery(this).index() == 0) {
          jQuery('html, body').animate({
            scrollTop: jQuery('body').offset().top + (offset)
          }, 800);
        }
        else {
          var scrollToElement = this.classList[0].replace('-menu', '');
          jQuery('html, body').animate({
            scrollTop: jQuery('.' + scrollToElement).offset().top + (offset)
          }, 800);
        }
      });
    }
    else {
      jQuery('#in-page-menu li').click(function () {
        jQuery('#in-page-menu li.current').removeClass('current');
        jQuery(this).addClass('current');
        setPosition();
        if (jQuery(this).index() === 0) {
          jQuery('html, body').animate({
            scrollTop: jQuery('body').offset().top + (offset)
          }, 800);

          jQuery('#in-page-menu li:first').addClass('current');
        }
        else {
          var scrollToElement = this.classList[0].replace('-menu', '');

          jQuery('html, body').animate({
            scrollTop: jQuery('.' + scrollToElement).offset().top + (offset)
          }, 800);
        }
      });
    }

    /* Set active state on menu on section */
    var currentSection = '';
    /* If 1024px and above */
    if (!window.matchMedia('screen and (max-width: 1023px)').matches) {
      jQuery(window).scroll(function () {
        var menuPosition = jQuery('.in-page-anchor').offset().top;
        var fromTop = jQuery(this).scrollTop() + topMenuHeight;

        jQuery(scrollPosition).each(function (key, value) {
          var position = (value['position'] + (offset));
          var sectionName = value['value'];

          if ((fromTop >= position) && (currentSection !== sectionName)) {
            currentSection = sectionName;
          }

          var currentMenuSelected = jQuery('#in-page-menu li.current');

          if (currentMenuSelected.length !== 0) {
            currentMenuSelected.attr("class").split(' ');
            if (currentMenuSelected[0] !== 'current-menu') {
              if (currentSection !== currentMenuSelected) {
                currentMenuSelected.removeClass('current');
                jQuery('ul#in-page-menu li.' + currentSection + '-menu').addClass('current');
              }
            }
          }

        });
      });
    }
  });
  ;
