// jQuery.getJSON('deco-dev/radiology-global-elements/contactInfo.json', function(data) {
//     myObj = data;
// });
var myObj = {
  AR: {
    country: "Argentina",
    title: "Bayer S.A.",
    address: "Argentina, 1605 Munro Pcia. Buenos Aires, Ricardo Gutierrez 3652",
    phone: ["+54-11-47627000"],
    website: "http://www.bayer.com.ar",
  },
  AU: {
    country: "Australia",
    title: "Bayer Australia Limited",
    address: "Pymble NSW 2073, 875 Pacific Highway",
    phone: ["61 (2) 8845 4999"],
    website: "https://www.bayer.com.au",
  },
  AT: {
    country: "Austria",
    title: "Bayer Austria Ges. m.b.H.",
    address: "1160 Wien, Herbststraße 6-10",
    phone: ["+43-1-71146-0"],
    website: "https://www.bayer.at",
  },
  BE: {
    country: "Belgium",
    title: "Bayer SA-NV",
    address: "1831 Diegem (Machelen), Jan Emiel Mommaertslaan 14",
    phone: ["+32-2-5356311", "+32-2-5391750"],
    website: "http://www.bayer.be",
  },
  BO: {
    country: "Bolivia",
    title: "Bayer Boliviana Ltda.",
    address: "Santa Cruz, Av. Las Ramblas S/N Edificio Tacuaral II 2 do piso",
    phone: ["+591-3-337-8927", "+591-3-337-8879"],
    website: "http://www.bayer.bo",
  },
  BA: {
    country: "Bosnia and Herzegovina",
    title: "Bayer d.o.o. Sarajevo",
    address: "71000 Sarajevo, Trg solidamosti 2a",
    phone: ["+387-33-941-600", "+387-33-941-620"],
    website: "https://www.bayer.com",
  },
  BR: {
    country: "Brazil",
    title: "Bayer SA - Brazil",
    address: "04779-900 Sao Paulo SP, Rua Domingos Jorge 110",
    phone: ["+55-11-5694-5166"],
    website: "https://www.bayer.com.br",
  },
  BG: {
    country: "Bulgaria",
    title: "Bayer Bulgaria EOOD",
    address: "1510 Sofia, Rezbarska Str. 5",
    phone: ["+359-2-8140193"],
    website: "https://www.bayer.bg",
  },
  CA: {
    country: "Canada",
    title: "Bayer Inc.",
    address: "L4W 5R6 Mississauga, ON, 2920 Matheson Boulevard East",
    phone: ["+1-800-268-1432", "+1-800-622-2937 x 5689", "+1-800-265-7382"],
    website: "https://www.radiology.bayer.ca",
  },
  CL: {
    country: "Chile",
    title: "Bayer S.A.",
    address:
      "Chile, Santiago de Chile, Av. Andrés Bello N° 2457 Piso 21 Of. 2101",
    phone: ["+56-2-520 8200", "+56-2-550 8245"],
    website: "http://www.bayer.cl",
  },
  CO: {
    country: "Colombia",
    title: "Bayer S.A.",
    address: "Colombia, Bogota, D.C., Av. de las Americas No. 57-52",
    phone: ["+57-1-4234500"],
    website: "https://andina.bayer.com",
  },
  CR: {
    country: "Costa Rica",
    title: "Costa Rica",
    address:
      "S. A., San Jose, Avenida Prospero Fernandez Oficentro Plaza Tempo, edificio A, 2° piso",
    phone: ["+506-2589-8601", "+506-2257-1094 "],
    website: "https://centroamerica.bayer.com",
  },
  CZ: {
    country: "Czech Republic",
    title: "Bayer S.R.O.",
    address: "15500 Prague 5, Siemensova 2717/4",
    phone: ["420(266)101328 "],
    website: "http://www.bayer.cz",
  },
  DK: {
    country: "Denmark",
    title: "Bayer A/S",
    address: "2300 Kopenhagen, Arne Jacobsens Allé 13",
    phone: ["+45-45-235250"],
    website: "http://www.nordic.bayer.com/en/bayer-nordic/contact-us",
  },
  DO: {
    country: "Dominican Republic",
    title: "Dominican Rep.",
    address:
      "Santo Domingo, Av. General Gregorio Luperon Esquina Av. 27 de Febrero",
    phone: ["001-809-5308086"],
    website: "https://centroamerica.bayer.com",
  },
  EC: {
    country: "Ecuador",
    title: "Bayer S.A.",
    address:
      "Ecuador, Quito, Luxemburgo N34-359 y Portugal Cosmopolitan Parc, Pisos 6 y 7",
    phone: ["+59-3-23975-200", "0059-3-2567-983"],
    website: "https://andina.bayer.com",
  },
  FI: {
    country: "Finland",
    title: "Bayer Oy",
    address: "FI-20101 Turku, PO Box 415, Pansiontie 47",
    phone: ["358(20)7858396"],
    website: "http://www.nordic.bayer.com/en/bayer-nordic/contact-us",
  },
  FR: {
    country: "France",
    title: "Bayer HealthCare SAS",
    address: "F-69266 Lyon Cedex 09, 16, rue Jean-Marie Leclair - CS 90106",
    phone: ["33472854321"],
    website: "http://www.radiology.bayer.fr",
  },
  DE: {
    country: "Germany",
    title: "Bayer Vital GmbH",
    address: "51373 Leverkusen, Kaiser-Wilhelm-Allee 70",
    phone: [
      "01801 - 566 872 78",
      "Fax: 0214 - 309 648 441 (nur 3,9 ct/min aus dem dt. Festnetz; Mobilfunkpreise maximal 42 ct/min)",
    ],
    website: "http://www.radiologie.bayer.de",
  },
  GR: {
    country: "Greece",
    title: "Bayer Hellas AG",
    address: "151 25 Marousi-Athen, Sorou 18-20",
    phone: ["+30-210-6187500"],
    website: "http://www.bayer.gr",
  },
  GT: {
    country: "Guatemala",
    title: "Bayer S.A.",
    address: "Guatemala, Km 14.5 Carretera Roosevelt",
    phone: ["+502-2436-9090"],
    website: "https://centroamerica.bayer.com",
  },
  HN: {
    country: "Honduras",
    title: "Bayer S.A. de C.V.",
    address:
      "Tegucigalpa, DC, Cuarto piso, Edificio Interamericana Boulevard Morazan, Colonia Castaño Su",
    phone: ["+504-2692-100"],
    website: "https://centroamerica.bayer.com",
  },
  HK: {
    country: "Hong Kong",
    title: "Bayer HealthCare Limited",
    address: "Hong Kong, 6-8 Harbour Road Units 803-808, 8/F Shui On Centre",
    phone: ["+852-28147-337", "+852-35264750"],
    website: "https://www.bayer.com/en/hongkong.aspx",
  },
  HU: {
    country: "Hungary",
    title: "Bayer Hungaria Kft.",
    address: "1123 Budapest, Alkotas u. 50",
    phone: ["+36(1)4874253"],
    website: "http://bayer.co.hu",
  },
  IN: {
    country: "India",
    title: "Bayer Zydus Pharma Private Limited",
    address: "400607 Thane, 195 Kolshet Road",
    phone: ["+91-2225311234", "+91-22225455007"],
    website: "http://www.bayerzyduspharma.com",
  },
  ID: {
    country: "Indonesia",
    title: "PT Bayer Indonesia",
    address:
      "Jakarta 10220, MidPlaza I, 11-15 Floor Jalan Jenderal Sudirman Kaveling 10-11",
    phone: ["+62-21-570-3661", "+62-21-570-3660"],
    website: "http://www.bayer.co.id/id/produk/area-produk/pharmaceuticals",
  },
  IR: {
    country: "Iran",
    title: "Bayer Persian AG",
    address: "19948-34573 Theran, No. 3, Aftab St., Khoddami Av., Vanak Square",
    phone: ["+98 21 82268100"],
    website: "https://www.bayer.com/en/iran.aspx",
  },
  IE: {
    country: "Ireland",
    title: "Bayer Limited",
    address: "Dublin, The Atrium, Blackthorn Road",
    phone: ["+353(1)2999313"],
    website: "http://radiology.bayer.ie",
  },
  IT: {
    country: "Italy",
    title: "Bayer S.p.A.",
    address: "20156 Mailand, Viale Certosa 130",
    phone: ["+39(02)39783474"],
    website: "https://radiology.bayer.it",
  },
  JP: {
    country: "Japan",
    title: "Bayer Yakuhin Ltd.",
    address: "530-0001 Osaka, Breeze Tower 2-4-9, Umeda",
    phone: ["+81(6)61337364"],
    website: "https://radiology.bayer.jp",
  },
  JP2: {
    country: "",
    title: "Bayer KAZ LLP",
    address: "50057 Astana, 42, Timiryazev street Pavilion 15, officie 301",
    phone: ["+7-3172-580356", "+7-3172-580359"],
    website: "https://www.bayer.com",
  },
  JP3: {
    country: "",
    title: "Bayer Korea Ltd.",
    address: "07071 Seoul, 23, Boramae-ro 5-gil",
    phone: ["+82-2-8296-600", "+82-2-8470-761"],
    website: "http://www.bayer.co.kr",
  },
  MY: {
    country: "Malaysia",
    title: "Bayer Co. (Malaysia) Sdn Bhd",
    address:
      "47301 Petaling jaya, B-19-1 & B-19-2, The Ascent Paradigm No. 1, Jalan SS 7/26A, Kelana Jaya",
    phone: ["+603-62093088", "+603-79605718"],
    website: "https://www.bayer.com",
  },
  MA: {
    country: "Morocco",
    title: "Bayer S.A.",
    address:
      "20050 Casablanca, Tours Balzac, Angle Bd Anfa et Rue de l'Lepargne",
    phone: ["+216(71)267020107"],
    website: "https://www.bayer.com",
  },
  NL: {
    country: "Netherlands",
    title: "Bayer Medical Care B.V.",
    address: "Maastricht 6221 KV, Avenue Ceramique 27",
    phone: ["+31(43)3585667"],
    website: "http://www.bayer.nl",
  },
  NZ: {
    country: "New Zealand",
    title: "Bayer New Zealand Limited",
    address: "Auckland,South, P.O. Box 2825, 3 Argus Place",
    phone: ["6494433093"],
    website: "https://www.bayer.co.nz/en/bayerrsquos-products/pharmaceuticals",
  },
  NI: {
    country: "Nicaragua",
    title: "Bayer S.A.",
    address: "Managua, Km 11.5 Carretera a Masaya",
    phone: ["+505-2799777"],
    website: "https://centroamerica.bayer.com",
  },
  NO: {
    country: "Norway",
    title: "Bayer AS",
    address: "0283 Oslo, Drammensveien 288",
    phone: ["+47-2411-800"],
    website: "http://www.bayer.no/nn/produkter/pharmaceuticals",
  },
  PK: {
    country: "Pakistan",
    title: "Bayer Pakistan (Private)",
    address:
      "74000 Karachi, Moulvi Tamizuddin Khan Road Bahria Complex II, 4th Floor",
    phone: ["+92-21-35646700"],
    website: "https://www.bayer.com/en/pakistan.aspx",
  },
  PA: {
    country: "Panama",
    title: "Bayer S.A.",
    address:
      "0819 09281 El Dorado, Panama, Complejo Global Business Terminal Avenida Domingo Diaz, Torre A Piso 5to",
    phone: ["+507-441-4738"],
    website: "https://centroamerica.bayer.com",
  },
  PE: {
    country: "Peru",
    title: "Bayer S.A.",
    address:
      "Peru, Lima 27, Av. Paseo de la Republica No. 3074 Edif. Plaza del Sol P.10",
    phone: ["+51-1-4219601"],
    website: "https://centroamerica.bayer.com",
  },
  PH: {
    country: "Phiippines",
    title: "Bayer Philippines Inc.",
    address:
      "4028 Laguna, 8020 A Crcilia Araneta Yulo Ave. Canlubang industrial Estate Calamba",
    phone: ["+63-2-887-9710", "0063-2-893-1388 "],
    website: "https://www.bayer.com",
  },
  PL: {
    country: "Poland",
    title: "Bayer SP.Z.O.O.",
    address: "02-326 Warschau, ul. Jerozolimskie 158",
    phone: ["+48-22-572-3500"],
    website: "http://radiology.bayer.com.pl",
  },
  PT: {
    country: "Portugal",
    title: "Bayer Portugal S.A.",
    address: "2795-653 Portugal, Rua Quinta do Pinheiro N°5",
    phone: ["214172121"],
    website: "https://radiologia.bayer.pt",
  },
  PR: {
    country: "Puerto Rico",
    title: "Bayer Puerto Rico Inc.",
    address: "00969-4293 Guaynabo, 475 Calle C Suite 500",
    phone: ["001-787-7924545", "001-787-7937273"],
    website: "https://centroamerica.bayer.com",
  },
  RO: {
    country: "Romaina",
    title: "SC Bayer SRL",
    address: "020112 Bukarest, Soseaua Pipera nr. 42 Sector 2",
    phone: ["+40(21)5285989"],
    website: "https://www.bayer.ro",
  },
  RU: {
    country: "Russia",
    title: "A/O Bayer",
    address: "107113 Moskau, 3rd Rybinskaya Str., 18, build. 2",
    phone: ["+7(495)23112012304"],
    website: "http://radiology.bayer.ru",
  },
  SA: {
    country: "Saudi Arabia",
    title: "Bayer LLC Saudi Arabia",
    address: "21464 Jeddah, 3rd Floor, Al Kamal Building",
    phone: ["+966 2 657 1675"],
    website: "https://www.bayer.com/en/middle-east.aspx",
  },
  RS: {
    country: "Serbia",
    title: "Bayer d.o.o.",
    address: "11 070 Belgrad, Omladinskih brigada 88b",
    phone: ["+381(11)2070210"],
    website: "http://www.bayer.rs",
  },
  SG: {
    country: "Singapore",
    title: "Bayer (South East Asia) Pte Ltd.",
    address:
      "2 Tanjong Katong Road, Paya Lebar Quarter 3 #07-01, Singapore 437161",
    phone: ["+65-6496-1888"],
    website: "https://www.bayer.com",
  },
  SK: {
    country: "Slovakia",
    title: "Bayer spol. s.r.o.",
    address: "811 09 Bratislava, Karadzicova 2 Twin City, block A",
    phone: ["+421(2)32850205"],
    website: "http://www.bayer.sk",
  },
  SI: {
    country: "Slovenia",
    title: "Bayer d.o.o.",
    address: "1000 Ljubljana, Bravnicarjeva 13",
    phone: ["+386(1)5814483"],
    website: "http://www.bayer.si",
  },
  ZA: {
    country: "South Africa",
    title: "Bayer (Proprietary) Ltd",
    address: "1600 Isando, Viale Certosa 130",
    phone: ["27(27)119215774"],
    website: "https://www.bayer.co.za",
  },
  ES: {
    country: "Spain",
    title: "Bayer Hispania S.L",
    address: "Avda. Baix Llobregat, 3 - 5 E-08970 Sant Joan Despí, Barcelona",
    phone: ["+34(93)4956780"],
    website: "http://radiology.bayer.es",
  },
  SE: {
    country: "Sweden",
    title: "Bayer AB",
    address: "169 26 Solna (Stockholm), Gustav III's Boulevard 56",
    phone: ["+47 93 258 33"],
    website: "http://radiology.bayer.se",
  },
  CH: {
    country: "Switzerland",
    title: "Bayer (Schweiz) AG",
    address: "8045 Zürich, Grubenstrasse 6",
    phone: ["+41-44-4658111"],
    website: "https://www.bayer.ch/de/produkte/pharmaceuticals",
  },
  TW: {
    country: "Taiwan",
    title: "Bayer Taiwan Company Ltd.",
    address:
      "53-54F, Taipei 101 Tower, 7 XinYi Rd., Sec. 5, Taipei City, Taiwan, 11049",
    phone: ["+886-2-8101-1000", "00886-2-8101-0023"],
    website: "http://www.bayer.com.tw",
  },
  TH: {
    country: "Thailand",
    title: "Bayer Thai Company Limited",
    address: "Bangkok 10500, 130/1 North Sathon Road, Silom",
    phone: ["+662-232-7000", "+662-236-7738"],
    website: "http://www.bayer.co.th/en",
  },
  TR: {
    country: "Turkey",
    title: "Bayer Türk Kimya Sanayi Limited Sirketi",
    address:
      "Fatih Sultan Mehmet, Balkan Cad. No:53, 34770 Ümraniye/İstanbul, Turkey",
    phone: ["+90(216)5283926"],
    website: "https://www.radiyalog.com",
  },
  UA: {
    country: "Ukraine",
    title: "Bayer Ltd.",
    address: "04071 Kiew, 4-b, Verkhniy Val Str.",
    phone: ["+380(44)2203314"],
    website: "http://www.bayer.ua",
  },
  AE: {
    country: "United Arab Emirates",
    title: "Bayer Middle East FZE",
    address: "Dubai, Office Park Building, Block B 5th Floor",
    phone: ["+971-4-4452700", "+971-4-4413247"],
    website: "https://www.bayer.com/en/middle-east.aspx",
  },
  GB: {
    country: "United Kingdom",
    title: "Bayer plc",
    address: "Reading RG2 6AD. UK",
    phone: ["+44 (0)118 206 3999", "+44 (0)118 206 3000"],
    website: "http://radiology.bayer.co.uk",
  },
  US: {
    country: "United States",
    title: "Bayer HealthCare Indianola",
    address: "One Bayer Drive Indianola, PA 15051",
    phone: ["+1 862 404 3000"],
    website: "https://www.radiologysolutions.bayer.com",
  },
  US2: {
    country: "",
    title: "Bayer HealthCare Saxonburg",
    address: "150 Victory Road Saxonburg, PA 16056",
    phone: ["+1 862 404 3000"],
    website: "https://www.radiologysolutions.bayer.com",
  },
  US3: {
    country: "",
    title: "Bayer HealthCare Pittsburgh",
    address: "625 Alpha Drive Pittsburgh, PA 15238",
    phone: ["+1 862 404 3000"],
    website: "https://www.radiologysolutions.bayer.com",
  },
  US4: {
    country: "",
    title: "Bayer HealthCare Whippany",
    address: "100 Bayer Blvd Whippany, NJ 07981",
    phone: ["+1 862 404 3000"],
    website: "https://www.radiologysolutions.bayer.com",
  },
  VE: {
    country: "Venezuela",
    title: "Bayer S.A.",
    address: "Venezuela, Caracas 1010-A, Avenida Tamanaco, Torre Bayer",
    phone: ["+58-212-9052190"],
    website: "http://andina.bayer.com",
  },
};

jQuery("#country-code-value").change(function () {
  if (jQuery("#country-code-value").val() == "All") {
    jQuery("#contactInfo").html("");
    jQuery.each(myObj, function (k, v) {
      contatInfo = v;
      var phones = "";
      jQuery.each(contatInfo.phone, function (x, y) {
        phones += "<p>" + y + "</p>";
      });
      var contactStr =
        '<div class="coh-wysiwyg coh-component coh-component-instance-2dd61439-02c9-4c49-a771-14e40c7e384d contextual-component  coh-instance-160568759 coh-ce-c152252e"><h3 class="coh-style-thick-blue"><strong>' +
        contatInfo.country +
        '</strong></h3><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
        contatInfo.title +
        "</strong></p><p>" +
        contatInfo.address +
        '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
        phones +
        '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
        contatInfo.website +
        '">' +
        contatInfo.website +
        "</a></strong></p></div></div></div><hr/>";
      jQuery("#contactInfo").append(contactStr);
    });
  }
  //  else if(jQuery("#country-code-value").val() == 'PT'){
  //     var contatInfo = myObj[jQuery("#country-code-value").val()];
  //     var phones = '';
  //     jQuery.each(contatInfo.phone, function(k, v) {
  //         phones+='<p>'+v+'</p>';
  //     });
  //     var contactStr='<div class="coh-wysiwyg coh-component coh-component-instance-2dd61439-02c9-4c49-a771-14e40c7e384d contextual-component  coh-instance-160568759 coh-ce-c152252e"><h3 class="coh-style-thick-blue"><strong>'+contatInfo.country+'</strong></h3><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>'+contatInfo.title+'</strong></p><p>'+contatInfo.address+'</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>'+phones+'</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="'+contatInfo.website+'">'+contatInfo.website+'</a></strong></p></div></div><hr/>';
  //     jQuery("#contactInfo").html(contactStr);

  //     var contatInfo = myObj["PT2"];
  //     var phones = '';
  //     jQuery.each(contatInfo.phone, function(k, v) {
  //         phones+='<p>'+v+'</p>';
  //     });
  //     contactStr+='<div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>'+contatInfo.title+'</strong></p><p>'+contatInfo.address+'</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>'+phones+'</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="'+contatInfo.website+'">'+contatInfo.website+'</a></strong></p></div></div></div>';
  //     jQuery("#contactInfo").html(contactStr);
  //  }
  else if (jQuery("#country-code-value").val() == "US") {
    var contatInfo = myObj[jQuery("#country-code-value").val()];
    var phones = "";
    jQuery.each(contatInfo.phone, function (k, v) {
      phones += "<p>" + v + "</p>";
    });
    var contactStr =
      '<div class="coh-wysiwyg coh-component coh-component-instance-2dd61439-02c9-4c49-a771-14e40c7e384d contextual-component  coh-instance-160568759 coh-ce-c152252e"><h3 class="coh-style-thick-blue"><strong>' +
      contatInfo.country +
      '</strong></h3><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
      contatInfo.title +
      "</strong></p><p>" +
      contatInfo.address +
      '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
      phones +
      '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
      contatInfo.website +
      '">' +
      contatInfo.website +
      "</a></strong></p></div></div><hr/>";
    jQuery("#contactInfo").html(contactStr);

    var contatInfo = myObj["US2"];
    var phones = "";
    jQuery.each(contatInfo.phone, function (k, v) {
      phones += "<p>" + v + "</p>";
    });
    contactStr +=
      '<div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
      contatInfo.title +
      "</strong></p><p>" +
      contatInfo.address +
      '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
      phones +
      '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
      contatInfo.website +
      '">' +
      contatInfo.website +
      "</a></strong></p></div></div></div><hr/>";
    jQuery("#contactInfo").html(contactStr);

    var contatInfo = myObj["US3"];
    var phones = "";
    jQuery.each(contatInfo.phone, function (k, v) {
      phones += "<p>" + v + "</p>";
    });
    contactStr +=
      '<div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
      contatInfo.title +
      "</strong></p><p>" +
      contatInfo.address +
      '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
      phones +
      '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
      contatInfo.website +
      '">' +
      contatInfo.website +
      "</a></strong></p></div></div></div><hr/>";
    jQuery("#contactInfo").html(contactStr);

    var contatInfo = myObj["US4"];
    var phones = "";
    jQuery.each(contatInfo.phone, function (k, v) {
      phones += "<p>" + v + "</p>";
    });
    contactStr +=
      '<div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
      contatInfo.title +
      "</strong></p><p>" +
      contatInfo.address +
      '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
      phones +
      '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
      contatInfo.website +
      '">' +
      contatInfo.website +
      "</a></strong></p></div></div></div>";
    jQuery("#contactInfo").html(contactStr);
  } else {
    var contatInfo = myObj[jQuery("#country-code-value").val()];
    var phones = "";
    jQuery.each(contatInfo.phone, function (k, v) {
      phones += "<p>" + v + "</p>";
    });
    var contactStr =
      '<div class="coh-wysiwyg coh-component coh-component-instance-2dd61439-02c9-4c49-a771-14e40c7e384d contextual-component  coh-instance-160568759 coh-ce-c152252e"><h3 class="coh-style-thick-blue"><strong>' +
      contatInfo.country +
      '</strong></h3><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-location.png"></div><div><p><strong>' +
      contatInfo.title +
      "</strong></p><p>" +
      contatInfo.address +
      '</p></div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-phone.png"></div><div>' +
      phones +
      '</div></div><h5>&nbsp;</h5><div class="coh-style-inline-flex-start"><div><img width="20" height="20" alt="" class="coh-style-padding-3-10" src="/sites/g/files/vrxlpx21141/files/2021-07/icon-world.png"></div><div><p><strong><a class="coh-style-font-color-deepblue coh-style-word-wrap" href="' +
      contatInfo.website +
      '">' +
      contatInfo.website +
      "</a></strong></p></div></div></div>";
    jQuery("#contactInfo").html(contactStr);
  }
});
