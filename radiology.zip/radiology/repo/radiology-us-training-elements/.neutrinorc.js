const bayerReact = require('@bayer/wsf-decoupled-react-preset');

module.exports = {
  options: {
    root: __dirname,
  },
  use: [
    bayerReact({
      coverageThreshold: 0,
    }),
  ],
};
