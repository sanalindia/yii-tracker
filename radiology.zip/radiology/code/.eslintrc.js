// eslint-disable-next-line
const neutrino = require('neutrino');

module.exports = neutrino().eslintrc();
