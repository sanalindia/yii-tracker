// eslint-disable-next-line import/no-extraneous-dependencies
import '@bayer/wsf-decoupled-react-preset/packages/jest-dom';

// eslint-disable-next-line func-names
window.matchMedia = window.matchMedia || function () {
  return {
    matches: false,
    addListener() { },
    removeListener() { },
  };
};
