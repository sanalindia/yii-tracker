const bayerReact = require('@bayer/wsf-decoupled-react-preset');

module.exports = {
  options: {
    root: __dirname,
  },
  use: [
    bayerReact({
      coverageThreshold: 0,
    }),
  ],
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [ 'style-loader', 'postcss-loader' ]
      }
    ]
  }
};
