Please check our docs on separate topics

Licenses validation - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1674281268/Licenses+validation

Dependency management - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1674248253/Dependency+management

Folder structure - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1674805389/Folder+structure

Code maintainability - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1674772600/Code+maintainability

Linting - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1674739810/Linting

Testing - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1673888222/Testing

Separation of Concerns - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1694630007/Separation+of+Concerns

Internationalization - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1711439911/Internationalization

Creating a new project - https://bayerweb.atlassian.net/wiki/spaces/WSF/pages/1757478936/Creating+a+new+project
