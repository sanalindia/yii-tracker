import '../../services/i18n';

describe('Dialog Popup', () => {
  test('Mounts with no errors thrown', () => {
    const expected = { name: 'Dialog box' };
    const actual = { name: 'Dialog box', type: 'form' };
    expect(actual).toMatchObject(expected);
  });
});
