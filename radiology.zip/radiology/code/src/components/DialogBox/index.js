/* eslint-disable react/forbid-prop-types */
/* eslint-disable no-console */
import React from 'react';
import { useTranslation } from 'react-i18next';

import PropTypes from 'prop-types';
import {
  Button, Dialog, DialogContent, DialogActions, FormControl, OutlinedInput, IconButton,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import './dialog-box.scss';

function DialogBox(props) {
  const {
    onClose, selectedValue, open, isSendMail,
  } = props;
  let isMailSend = false;
  const isAttendWebinar = selectedValue.isAttend;
  const { t } = useTranslation();
  const handleClose = () => {
    onClose(selectedValue, isMailSend);
  };
  const sendMailSuccess = () => {
    isMailSend = true;
    handleClose();
  };
  const handleEmailSendClose = () => {
    isMailSend = false;
    selectedValue.isAttend = true;
    onClose(selectedValue, isMailSend);
  };
  if (isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <h1>{t('EventCalendarSuccessMessage')}</h1>
          <p className="text-center">{t('EventCalendarMailMessage')}</p>
        </DialogContent>
        <DialogActions>
          <Button variant="contained" color="primary" className="primary-button" onClick={handleEmailSendClose}>{t('Close')}</Button>
        </DialogActions>
      </Dialog>
    );
  }

  if (isAttendWebinar && !isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <div>{t('EventCalendarErrorMessage')}</div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>{t('Close')}</Button>
        </DialogActions>
      </Dialog>
    );
  }
  if (!isAttendWebinar && !isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <div className="text-right">
            <IconButton aria-label="close" onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </div>
          <p>{t('EventsCalendarDialogTitle')}</p>
          <p>{t('EventsCalendarDialogWelocmeText')}</p>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarTitle">{t('EventCalendarFormFieldName1')}</label>
              <OutlinedInput id="webinarTitle" defaultValue={selectedValue.title} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="speakerName">{t('EventCalendarFormFieldName2')}</label>
              <OutlinedInput id="speakerName" defaultValue={selectedValue.speakerName} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarEmail">{t('EventCalendarFormFieldName3')}</label>
              <OutlinedInput id="webinarEmail" defaultValue={selectedValue.email} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarContact">{t('EventCalendarFormFieldName4')}</label>
              <OutlinedInput id="webinarContact" defaultValue={selectedValue.contact} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="additionalComments">{t('EventCalendarFormFieldName5')}</label>
              <OutlinedInput id="additionalComments" multiline rows={4} defaultValue={selectedValue.additionalComments} />
            </FormControl>
          </div>
        </DialogContent>
        <DialogActions>
          <Button fullWidth variant="contained" color="primary" size="large" className="primary-button" onClick={sendMailSuccess}>{t('EventCalendarAttendButton')}</Button>
        </DialogActions>
      </Dialog>
    );
  }
}

DialogBox.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.object.isRequired,
  isSendMail: PropTypes.bool.isRequired,
};

export default DialogBox;
