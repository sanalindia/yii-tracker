/* eslint-disable react/no-danger */
/* eslint-disable react/no-unknown-property */
/* eslint-disable no-console */
import React from 'react';

import PropTypes from 'prop-types';
import {
  Dialog, DialogContent, IconButton, makeStyles,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import './dialog-box.scss';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme } from '@material-ui/core/styles';

function VideoPlayer(props) {
  const {
    onClose, selectedValue, open,
  } = props;
  const handleClose = () => {
    onClose(selectedValue);
  };
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  const useStyles = makeStyles({
    dialog: {
      zIndex: 1000,
    },
  });
  const classes = useStyles();
  return (
    <Dialog
      onClose={handleClose}
      maxWidth="md"
      fullWidth
      fullScreen={fullScreen}
      aria-labelledby="responsive-dialog-title"
      open={open}
      disableBackdropClick
      onBackdropClick={(e) => e.stopPropagation()}
      classes={{
        paper: classes.dialog,
      }}
    >
      <DialogContent className="movieDialogWarper" position="absolute" top={40}>
        <div className="text-right">
          <IconButton aria-label="close" onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </div>
        <div className="movie-wrapper">
          <iframe title="movie" frameborder="0" allowFullScreen="allowfullscreen" trakkvideo="true" src={selectedValue.video} />
        </div>
        <div className="movie-content">
          <h3 className="speakername">{selectedValue.speakerName}</h3>
          <h2 className="title">{selectedValue.title}</h2>
          <p className="details" dangerouslySetInnerHTML={{ __html: selectedValue.description }} />
        </div>
      </DialogContent>
    </Dialog>
  );
}

VideoPlayer.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
};

export default VideoPlayer;
