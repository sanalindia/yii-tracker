import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import MyAcademy from '.';

describe('My Academy', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<MyAcademy />);
    expect(container).toBeInTheDocument();
  });
});
