import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import getDate from '../../services/moment';
import getEnv from '../../helpers/environment';
import './greeting.scss';

function Greeting() {
  const [date, setDate] = useState(getDate());
  const { t } = useTranslation();

  useEffect(() => {
    const timer = setInterval(() => {
      setDate(getDate());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className={`greeting ${getEnv()}`}>
      <h1>{t('HelloWorld')}</h1>
      <div className="greeting_time">{date}</div>
    </div>
  );
}

export default Greeting;
