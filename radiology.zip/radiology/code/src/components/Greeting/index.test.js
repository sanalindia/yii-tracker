import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import Greeting from '.';
import '../../services/i18n';

describe('Greeting', () => {
  test('Сheck that the headline is rendered in the component', () => {
    const { getByText } = render(<Greeting />);
    expect(getByText(/HelloWorld/)).toBeInTheDocument();
  });
});
