import EventsCalendar from './EventsCalendar';
import Greeting from './Greeting';
import ScormPlayer from './ScormPlayer';
import MyAcademy from './MyAcademy';
import QuickEventsCalendar from './QuickEventsCalendar';
import MyEvents from './MyEvents';
import MyAcademyLatam from './MyAcademyLatam';
import QuickEventsCalendarLatam from './QuickEventsCalendarLatam';
import EventsCalendarLatam from './EventsCalendarLatam';
import MyEventsLatam from './MyEventsLatam';
import Resources from './Resources';

export {
  EventsCalendar,
  ScormPlayer,
  Greeting,
  MyAcademy,
  QuickEventsCalendar,
  MyEvents,
  MyAcademyLatam,
  QuickEventsCalendarLatam,
  EventsCalendarLatam,
  MyEventsLatam,
  Resources,
};
