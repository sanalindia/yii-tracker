import React, { useState, useLayoutEffect } from 'react';
import {
  Accordion, AccordionDetails, AccordionSummary, Typography, TextField, Button,
} from '@material-ui/core';
import { ExpandMore } from '@material-ui/icons';
import SendIcon from '@material-ui/icons/Send';
import Fuse from 'fuse.js';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import { Calendar } from 'react-modern-calendar-datepicker';
import './events-calendar.scss';
import moment from 'moment';
import DialogBoxLatam from '../DialogBoxLatam';
import eventsData from '../../assets/data/event-calendar-latam.json';

function EventsCalendarLatam() {
  const eventsDataInit = eventsData;
  const [searchValue, setSearchValue] = useState('');
  const [open, setOpen] = React.useState(false);
  const [isSendMail, setMailSend] = React.useState(false);
  const [selectedValue, setSelectedValue] = useState({});
  const [eventsList, setEventsList] = useState(eventsData);
  const options = {
    findAllMatches: true,
    threshold: 0,
    includeMatches: true,
    isCaseSensitive: false,
    keys: ['date', 'time', 'title', 'summery', 'description'],
  };
  const fuse = new Fuse(eventsData, options);
  const selectedDay = [];
  Object.keys(eventsDataInit).forEach((key) => {
    const webinarDate = {
      year: parseInt(moment(eventsDataInit[key].date).format('YYYY'), 10),
      month: parseInt(moment(eventsDataInit[key].date).format('M'), 10),
      day: parseInt(moment(eventsDataInit[key].date).format('D'), 10),
    };
    selectedDay.push(webinarDate);
  });
  const handleChange = (event) => {
    const { target } = event;
    event.persist();
    setSearchValue(target.value);
  };
  const handleClickOpen = (data, event) => {
    event.stopPropagation();
    event.preventDefault();
    setSelectedValue(data);
    setOpen(true);
  };
  const handleClose = (value, mailReq) => {
    setOpen(false);
    setMailSend(false);
    setSelectedValue(value);
    if (mailReq) {
      setTimeout(() => {
        setMailSend(true);
        setOpen(true);
      }, 1000);
    }
  };
  const handleSearch = () => {
    if (searchValue) {
      let result = fuse.search(searchValue);
      result = result.map((a) => a.item);
      setEventsList([...result]);
    } else {
      setEventsList([...eventsData]);
    }
  };
  const iframeResize = () => {
    const iframe = window.parent.document.getElementsByClassName('coh-iframe')[1];
    if (iframe) {
      setTimeout(() => {
        iframe.height = iframe.contentWindow.document.body.scrollHeight + 55;
      }, 1500);
    } else {
      const iframe0 = window.parent.document.getElementsByClassName('coh-iframe')[0];
      if (iframe0) {
        setTimeout(() => {
          iframe0.height = iframe0.contentWindow.document.body.scrollHeight + 55;
        }, 1500);
      }
    }
  };
  useLayoutEffect(() => {
    iframeResize();
  });
  const getEventsList = eventsList.map((item) => (
    <Accordion key={item.id} expanded={item.id === eventsList[0].id}>
      <AccordionSummary
        expandIcon={<ExpandMore />}
        aria-controls={`panel-${item.id}-content`}
        id={`panel-${item.id}-header`}
      >
        <div className="event-accordion-wrapper">
          <p>
            <span className="live-webinar-date">{item.lacalisedDate}</span>
            | &nbsp;
            <span className="live-webinar-time">{item.time}</span>
          </p>
          <h3 className="live-webinar-title">{item.title}</h3>
        </div>
      </AccordionSummary>
      <AccordionDetails>
        <Typography>
          <p className="item-description">{item.summery}</p>
          <p className="live-webinar-description">{item.description}</p>
          <div className="text-right">
            <Button variant="outlined" color="primary" value={item} onClick={(eve) => handleClickOpen(item, eve)} endIcon={<SendIcon />}>
              Atender
            </Button>
          </div>
        </Typography>
      </AccordionDetails>
    </Accordion>
  ));
  const myCustomLocale = {
    // months list by order
    months: [
      'enero',
      'febrero',
      'marzo',
      'abril',
      'mayo',
      'junio',
      'julio',
      'agosto',
      'septiembre',
      'octubre',
      'noviembre',
      'diciembre',
    ],

    // week days by order
    weekDays: [
      {
        name: 'domingo', // used for accessibility
        short: 'dom', // displayed at the top of days' rows
        isWeekend: true,
      },
      {
        name: 'lunes',
        short: 'lun',
      },
      {
        name: 'martes',
        short: 'mar',
      },
      {
        name: 'miércoles',
        short: 'mié',
      },
      {
        name: 'jueves',
        short: 'jue',
      },
      {
        name: 'viernes',
        short: 'vie',
      },
      {
        name: 'sábado',
        short: 'sáb',
        isWeekend: true,
      },
    ],
    // just play around with this number between 0 and 6
    weekStartingIndex: 0,

    // return a { year: number, month: number, day: number } object
    getToday(gregorainTodayObject) {
      return gregorainTodayObject;
    },
    // return a native JavaScript date here
    toNativeDate(date) {
      return new Date(date.year, date.month - 1, date.day);
    },
    // return a number for date's month length
    getMonthLength(date) {
      return new Date(date.year, date.month, 0).getDate();
    },
    // return a transformed digit to your locale
    transformDigit(digit) {
      return digit;
    },
    // texts in the date picker
    nextMonth: 'Next Month',
    previousMonth: 'Previous Month',
    openMonthSelector: 'Open Month Selector',
    openYearSelector: 'Open Year Selector',
    closeMonthSelector: 'Close Month Selector',
    closeYearSelector: 'Close Year Selector',
    defaultPlaceholder: 'Select...',
    // for input range value
    from: 'from',
    to: 'to',
    // used for input value when multi dates are selected
    digitSeparator: ',',
    // if your provide -2 for example, year will be 2 digited
    yearLetterSkip: 0,
    // is your language rtl or ltr?
    isRtl: false,
  };
  const date = new Date();
  const minimumDate = {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: 0,
  };
  return (
    <div className="event-container">
      <div className="search-content">
        <div className="search-input">
          <TextField id="outlined-basic" value={searchValue} onChange={handleChange} label="Buscar Live Webinar" fullWidth variant="outlined" />
        </div>
        <div className="search-button">
          <Button variant="contained" className="primary-button" color="primary" onClick={handleSearch} size="large">Buscar</Button>
        </div>
      </div>
      <div className="event-content-wrapper">
        <div className="calendar-wrapper">
          <Calendar
            colorPrimary="#0091df"
            calendarClassName="custom-calendar"
            calendarTodayClassName="custom-today-day"
            locale={myCustomLocale}
            minimumDate={minimumDate}
            value={selectedDay}
          />
        </div>
        <div className="event-content">
          <div className="event-details">
            {eventsList.length ? getEventsList : <p>No hay seminarios web para este mes.</p>}
          </div>
        </div>
      </div>
      <DialogBoxLatam
        selectedValue={selectedValue}
        open={open}
        onClose={handleClose}
        isSendMail={isSendMail}
      />
    </div>
  );
}

export default EventsCalendarLatam;
