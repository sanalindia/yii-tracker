import React, { useLayoutEffect } from 'react';
import {
  Select, MenuItem, FormControl, OutlinedInput, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Checkbox, FormControlLabel,
} from '@material-ui/core';
import Fuse from 'fuse.js';
import SearchOutlinedIcon from '@material-ui/icons/SearchOutlined';
import '../MyEvents/my-events.scss';
import filterData from '../../assets/data/my-events-latam-flter-data.json';
import minhaAcademiaData from '../../assets/data/my-events-latam.json';

function MyEventsLatam() {
  const [topic, setTopic] = React.useState('All');
  const [speaker, setSpeaker] = React.useState('All');
  const [priority, setPriority] = React.useState('All');
  const [search, setSearch] = React.useState('');
  const [myCalendarList, setMyCalendarDataList] = React.useState(minhaAcademiaData);
  const options = {
    findAllMatches: true,
    threshold: 0,
    includeMatches: true,
    isCaseSensitive: false,
    shouldSort: true,
    keys: ['date', 'qualification', 'topic', 'speakerName', 'type', 'Status', 'requestStatus'],
  };

  const fuse = new Fuse(minhaAcademiaData, options);
  // setting iframe height for parent window
  const iframeResize = () => {
    const iframe = window.parent.document.getElementsByClassName('coh-iframe')[1];
    if (iframe) {
      setTimeout(() => {
        iframe.height = iframe.contentWindow.document.body.scrollHeight + 55;
      }, 1500);
    } else {
      const iframe0 = window.parent.document.getElementsByClassName('coh-iframe')[0];
      if (iframe0) {
        setTimeout(() => {
          iframe0.height = iframe0.contentWindow.document.body.scrollHeight + 55;
        }, 1500);
      }
    }
  };
  useLayoutEffect(() => {
    iframeResize();
  });
  const prepareAndsetMyCalendarDataList = (values) => {
    setMyCalendarDataList([...values]);
  };
  const resetFilterData = (data) => {
    if (data === 'All') {
      prepareAndsetMyCalendarDataList([...minhaAcademiaData]);
    } else if (data) {
      let result = fuse.search(data);
      result = result.map((a) => a.item);
      prepareAndsetMyCalendarDataList([...result]);
    } else {
      prepareAndsetMyCalendarDataList([...minhaAcademiaData]);
    }
  };
  const handleTopicChange = (event) => {
    setTopic(event.target.value);
    resetFilterData(event.target.value);
  };
  const handleSpeakerChange = (event) => {
    setSpeaker(event.target.value);
    resetFilterData(event.target.value);
  };
  const handlePriorityChange = (event) => {
    setPriority(event.target.value);
    resetFilterData(event.target.value);
  };
  const handleSearch = (event) => {
    setSearch(event.target.value);
    resetFilterData(event.target.value);
  };
  const topicFilterData = filterData[0].topic;
  const speakerFilterData = filterData[0].speaker;
  const yearFilterData = filterData[0].year;
  const getTopicFilter = topicFilterData.map((item) => (
    <MenuItem key={item.id} value={item.name}>{item.name}</MenuItem>
  ));
  const getSpeakerFilter = speakerFilterData.map((item) => (
    <MenuItem key={item} value={item}>{item}</MenuItem>
  ));
  const getYearFilter = yearFilterData.map((item) => (
    <MenuItem key={item} value={item}>{item}</MenuItem>
  ));
  const [state, setState] = React.useState({
    checkedA: false,
    checkedB: false,
  });
  const filterwebinar = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
    if (event.target.checked) {
      const filteredArray = minhaAcademiaData.filter((data) => data.iswebinar === true);
      setMyCalendarDataList([...filteredArray]);
    } else {
      setMyCalendarDataList([...minhaAcademiaData]);
    }
  };
  const filterTraining = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
    if (event.target.checked) {
      const filteredArray = minhaAcademiaData.filter((data) => data.isTraing === true);
      setMyCalendarDataList([...filteredArray]);
    } else {
      setMyCalendarDataList([...minhaAcademiaData]);
    }
  };
  return (
    <div className="myEvents">
      <div className="filterWrapper">

        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="topic-filter-label"
              value={topic}
              onChange={handleTopicChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por tema
              </MenuItem>
              {getTopicFilter}
            </Select>
          </FormControl>
        </div>

        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="popularity-filter-label"
              value={priority}
              onChange={handlePriorityChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por año
              </MenuItem>
              {getYearFilter}
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="speaker-filter-label"
              value={speaker}
              onChange={handleSpeakerChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por speaker
              </MenuItem>
              {getSpeakerFilter}
            </Select>
          </FormControl>
        </div>
      </div>
      <div className="filterWrapper">
        <div className="myacademy-formGroup">
          <FormControlLabel
            control={(
              <Checkbox
                checked={state.checkedB}
                onChange={filterwebinar}
                name="checkedB"
                color="primary"
              />
            )}
            label="Mostrar seminarios web en vivo"
          />
        </div>
        <div className="myacademy-formGroup">
          <FormControlLabel
            control={(
              <Checkbox
                checked={state.checkedA}
                onChange={filterTraining}
                name="checkedA"
                color="primary"
              />
            )}
            label="Mostrar entrenamientos"
          />
        </div>
        <div className="myacademy-formGroup">
          <FormControl variant="outlined">
            <OutlinedInput
              id="search-text"
              type="text"
              value={search}
              onChange={handleSearch}
              onBlur={handleSearch}
              endAdornment={<SearchOutlinedIcon />}
              placeholder="Buscar"
            />
          </FormControl>
        </div>
      </div>
      <div className="my-academy-video-list">
        <h1 className="table-title">Entrenamientos previos</h1>
        <TableContainer>
          <Table aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Título</TableCell>
                <TableCell>Tema</TableCell>
                <TableCell>Tipo</TableCell>
                <TableCell>Speaker</TableCell>
                <TableCell>Estado</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {myCalendarList.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{row.date}</TableCell>
                  <TableCell>{row.qualification}</TableCell>
                  <TableCell>{row.topic}</TableCell>
                  <TableCell>{row.type}</TableCell>
                  <TableCell>{row.speakerName}</TableCell>
                  <TableCell>{row.requestStatus}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </div>
  );
}
export default MyEventsLatam;
