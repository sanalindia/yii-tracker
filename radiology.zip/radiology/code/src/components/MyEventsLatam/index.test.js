import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import MyEventsLatam from '.';

describe('My MyEventsLatam', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<MyEventsLatam />);
    expect(container).toBeInTheDocument();
  });
});
