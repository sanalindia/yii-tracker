/* eslint-disable react/forbid-prop-types */
/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';

import PropTypes from 'prop-types';
import {
  Button, Dialog, DialogContent, DialogActions, FormControl, OutlinedInput, IconButton,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import './dialog-box.scss';

function DialogBoxLatam(props) {
  const {
    onClose, selectedValue, open, isSendMail,
  } = props;
  let isMailSend = false;
  const isAttendWebinar = selectedValue.isAttend;
  const handleClose = () => {
    onClose(selectedValue, isMailSend);
  };
  const sendMailSuccess = () => {
    isMailSend = true;
    handleClose();
  };
  const handleEmailSendClose = () => {
    isMailSend = false;
    selectedValue.isAttend = true;
    onClose(selectedValue, isMailSend);
  };
  if (isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <h1>Gracias por su solicitud.</h1>
          <p className="text-center">Pronto le enviaremos detalles del entrenamiento a su correo.</p>
        </DialogContent>
        <DialogActions>
          <Button variant="contained" color="primary" className="primary-button" onClick={handleEmailSendClose}>Сerrar</Button>
        </DialogActions>
      </Dialog>
    );
  }

  if (isAttendWebinar && !isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <div>Disculpe, usted ya está inscripto en este Live Webinar</div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>cerca</Button>
        </DialogActions>
      </Dialog>
    );
  }
  if (!isAttendWebinar && !isSendMail) {
    return (
      <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open} disableBackdropClick onBackdropClick={(e) => e.stopPropagation()}>
        <DialogContent className="webinarDialogWarper">
          <div className="text-right">
            <IconButton aria-label="close" onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </div>
          <p>Hola, user</p>
          <p>Estás a solo unos minutos de una experiencia increíble.</p>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarTitle">Título</label>
              <OutlinedInput id="webinarTitle" defaultValue={selectedValue.title} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="speakerName">Nombre Speaker</label>
              <OutlinedInput id="speakerName" defaultValue={selectedValue.speakerName} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarEmail">Email</label>
              <OutlinedInput id="webinarEmail" defaultValue={selectedValue.email} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="webinarContact">Celular</label>
              <OutlinedInput id="webinarContact" defaultValue={selectedValue.contact} />
            </FormControl>
          </div>
          <div className="webinarFormGroup">
            <FormControl fullWidth>
              <label htmlFor="additionalComments">Comentários extras</label>
              <OutlinedInput id="additionalComments" multiline rows={4} defaultValue={selectedValue.additionalComments} />
            </FormControl>
          </div>
        </DialogContent>
        <DialogActions>
          <Button fullWidth variant="contained" color="primary" size="large" className="primary-button" onClick={sendMailSuccess}>Enviar</Button>
        </DialogActions>
      </Dialog>
    );
  }
}

DialogBoxLatam.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.object.isRequired,
  isSendMail: PropTypes.bool.isRequired,
};

export default DialogBoxLatam;
