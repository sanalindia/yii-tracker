/* eslint-disable react/jsx-props-no-spreading */
import React, { useState, useLayoutEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
} from '@material-ui/core';
import SendIcon from '@material-ui/icons/Send';
import Slider from 'react-slick';
import './quick-events-calendar.scss';
import moment from 'moment';
import DialogBox from '../DialogBox';
import eventsData from '../../assets/data/event-calendar.json';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

function QuickEventsCalendar() {
  const { t } = useTranslation();
  const eventsDataInit = eventsData;
  const [open, setOpen] = React.useState(false);
  const [isSendMail, setMailSend] = React.useState(false);
  const [selectedValue, setSelectedValue] = useState({});
  const selectedDay = [];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 2,
    responsive: [
      {
        breakpoint: 880,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
    ],
  };
  Object.keys(eventsDataInit).forEach((key) => {
    const webinarDate = {
      year: parseInt(moment(eventsDataInit[key].date).format('YYYY'), 10),
      month: parseInt(moment(eventsDataInit[key].date).format('M'), 10),
      day: parseInt(moment(eventsDataInit[key].date).format('D'), 10),
    };
    selectedDay.push(webinarDate);
  });
  const handleClickOpen = (data, event) => {
    event.stopPropagation();
    event.preventDefault();
    setSelectedValue(data);
    setOpen(true);
  };
  const handleClose = (value, mailReq) => {
    setOpen(false);
    setMailSend(false);
    setSelectedValue(value);
    if (mailReq) {
      setTimeout(() => {
        setMailSend(true);
        setOpen(true);
      }, 1000);
    }
  };
  const iframeResize = () => {
    const iframe = window.parent.document.getElementsByClassName('coh-iframe')[0];
    if (iframe) {
      setTimeout(() => {
        iframe.height = iframe.contentWindow.document.body.scrollHeight + 55;
      }, 1500);
    }
  };
  useLayoutEffect(() => {
    iframeResize();
  });
  const getEventsList = eventsData.map((item) => (
    <section className="event-accordion-wrapper" key={item.id}>
      <div className="event-accordion-content">
        <p>
          <span className="live-webinar-date">{moment(item.date).format('ddd DD MMMM, YYYY')}</span>
          |
          <span className="live-webinar-time">{item.time}</span>
        </p>
        <h3 className="live-webinar-title">{item.title}</h3>
        <div className="text-right">
          <Button variant="outlined" color="primary" value={item} onClick={(eve) => handleClickOpen(item, eve)} endIcon={<SendIcon />}>
            {t('Attend')}
          </Button>
        </div>
      </div>
    </section>
  ));

  return (
    <div className="quick-event-container">
      <div className="event-content-wrapper">
        <div className="event-content">
          <div className="">
            <Slider {...settings}>
              {getEventsList}
            </Slider>
          </div>
        </div>
      </div>
      <DialogBox
        selectedValue={selectedValue}
        open={open}
        onClose={handleClose}
        isSendMail={isSendMail}
      />
    </div>
  );
}

export default QuickEventsCalendar;
