/* eslint-disable jest/no-commented-out-tests */
import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import QuickEventsCalendar from '.';

describe('Quick Event Calendar', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<QuickEventsCalendar />);
    expect(container).toBeInTheDocument();
  });
});
