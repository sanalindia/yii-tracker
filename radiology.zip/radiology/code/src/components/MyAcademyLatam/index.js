/* eslint-disable react/no-danger */
import React, { useLayoutEffect } from 'react';
import {
  Select, MenuItem, FormControl, OutlinedInput, Button,
} from '@material-ui/core';
import Fuse from 'fuse.js';
import SearchOutlinedIcon from '@material-ui/icons/SearchOutlined';
import LockIcon from '@material-ui/icons/Lock';
import '../MyAcademy/my-academy.scss';
import filterData from '../../assets/data/myacademy-latam-flter-data.json';
import minhaAcademiaData from '../../assets/data/minha-academia-latam.json';
import VideoPlayer from '../DialogBox/VideoPlayer';
import { sortByKey } from '../../helpers/general';

function MyAcademyLatam() {
  const [topic, setTopic] = React.useState('All');
  const [open, setOpen] = React.useState(false);
  const [type, setType] = React.useState('All');
  const [product, setProduct] = React.useState('All');
  const [speaker, setSpeaker] = React.useState('All');
  const [priority, setPriority] = React.useState('field_bayph_radlgy_most_viewed');
  const [search, setSearch] = React.useState('');
  const [selectedMovieValue, setSelectedMovieValue] = React.useState({});
  const [myCalendarList, setMyCalendarDataList] = React.useState(minhaAcademiaData);
  const options = {
    findAllMatches: false,
    threshold: 0.1,
    includeMatches: true,
    isCaseSensitive: false,
    shouldSort: true,
    keys: ['title', 'description', 'speakerName', 'topic', 'product', 'type', 'rating', 'duration'],
  };
  const fuse = new Fuse(minhaAcademiaData, options);
  // setting iframe height for parent window
  const iframeResize = () => {
    const iframe = window.parent.document.getElementsByClassName('coh-iframe')[1];
    if (iframe) {
      setTimeout(() => {
        iframe.height = iframe.contentWindow.document.body.scrollHeight + 55;
      }, 1500);
    } else {
      const iframe0 = window.parent.document.getElementsByClassName('coh-iframe')[0];
      if (iframe0) {
        setTimeout(() => {
          iframe0.height = iframe0.contentWindow.document.body.scrollHeight + 55;
        }, 1500);
      }
    }
  };
  useLayoutEffect(() => {
    iframeResize();
  });
  const prepareAndsetMyCalendarDataList = (values) => {
    if (priority === 'field_bayph_radlgy_rating') {
      const sortedValues = sortByKey(values, 'rating');
      setMyCalendarDataList([...sortedValues]);
    } else {
      setMyCalendarDataList([...values]);
    }
  };
  const resetFilterData = (data) => {
    if (data) {
      let result = fuse.search(data);
      result = result.map((a) => a.item);
      prepareAndsetMyCalendarDataList([...result]);
    } else {
      prepareAndsetMyCalendarDataList([...minhaAcademiaData]);
    }
  };
  const handleTopicChange = (event) => {
    setTopic(event.target.value);
    if (event.target.value === 'All') {
      resetFilterData('');
    } else {
      resetFilterData(event.target.value);
    }
  };
  const handleTypeChange = (event) => {
    setType(event.target.value);
    resetFilterData(event.target.value);
  };
  const handleProductChange = (event) => {
    setProduct(event.target.value);
    resetFilterData(event.target.value);
  };
  const handleSpeakerChange = (event) => {
    setSpeaker(event.target.value);
    resetFilterData(event.target.value);
  };
  const handlePriorityChange = (event) => {
    setPriority(event.target.value);
    if (event.target.value === 'field_bayph_radlgy_most_viewed') {
      setMyCalendarDataList([...minhaAcademiaData]);
    } else {
      const sortedValues = sortByKey(minhaAcademiaData, 'rating');
      setMyCalendarDataList([...sortedValues]);
    }
  };
  const handleSearch = (event) => {
    setSearch(event.target.value);
    resetFilterData(event.target.value);
  };
  const handleStartMovie = (data, event) => {
    event.stopPropagation();
    event.preventDefault();
    setSelectedMovieValue(data);
    setOpen(true);
    window.parent.document.body.scrollTop = 400;
    window.parent.document.documentElement.scrollTop = 400;
  };
  const handleClose = () => {
    setOpen(false);
  };
  const topicFilterData = filterData[0].topic;
  const typeFilterData = filterData[0].type;
  const productFilterData = filterData[0].product;
  const speakerFilterData = filterData[0].speaker;
  const getTopicFilter = topicFilterData.map((item) => (
    <MenuItem key={item.id} value={item.name}>{item.name}</MenuItem>
  ));
  const getTypeFilter = typeFilterData.map((item) => (
    <MenuItem key={item.id} value={item.name}>{item.name}</MenuItem>
  ));
  const getProductFilter = productFilterData.map((item) => (
    <MenuItem key={item.id} value={item.name}>{item.name}</MenuItem>
  ));
  const getSpeakerFilter = speakerFilterData.map((item) => (
    <MenuItem key={item} value={item}>{item}</MenuItem>
  ));
  const getMyAcademyList = myCalendarList.map((item) => (
    <div className="video-wrapper" key={item.id}>
      <div className="thumbnail">
        <img src={item.thumbnail} alt={item.title} />
        <div className="tile-hover">
          <h3>
            <div className="radlgy-speaker">{item.speakerName}</div>
          </h3>
          {item.isAccess && (
            <Button variant="outlined" className="start-movie" color="primary" onClick={(eve) => handleStartMovie(item, eve)}>
              Comenzar película
            </Button>
          )}
          {!item.isAccess && (
            <Button variant="outlined" className="start-movie" color="primary">
              <LockIcon />
              {' '}
              sin acceso
            </Button>
          )}
          <div className="radlgy-duration">{item.duration}</div>
        </div>
      </div>
      <div className="video-detail-content">
        <h3>{item.title}</h3>
        <p dangerouslySetInnerHTML={{ __html: item.description }} />
      </div>
    </div>
  ));
  return (
    <div className="myAcademyWrapper">
      <div className="filterWrapper">
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="topic-filter-label"
              value={topic}
              onChange={handleTopicChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por tema
              </MenuItem>
              {getTopicFilter}
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="type-filter-label"
              value={type}
              onChange={handleTypeChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por modalidad
              </MenuItem>
              {getTypeFilter}
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="product-filter-label"
              value={product}
              onChange={handleProductChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Filtrar por producto
              </MenuItem>
              {getProductFilter}
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="speaker-filter-label"
              value={speaker}
              onChange={handleSpeakerChange}
              variant="outlined"
            >
              <MenuItem value="All">
                Seleccionar speaker
              </MenuItem>
              {getSpeakerFilter}
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl>
            <Select
              id="popularity-filter-label"
              value={priority}
              onChange={handlePriorityChange}
              variant="outlined"
            >
              <MenuItem value="field_bayph_radlgy_most_viewed">
                Más popular
              </MenuItem>
              <MenuItem value="field_bayph_radlgy_rating">
                Mas visto
              </MenuItem>
            </Select>
          </FormControl>
        </div>
        <div className="myacademy-formGroup">
          <FormControl variant="outlined">
            <OutlinedInput
              id="search-text"
              type="text"
              value={search}
              onChange={handleSearch}
              onBlur={handleSearch}
              endAdornment={<SearchOutlinedIcon />}
              placeholder="Buscar"
            />
          </FormControl>
        </div>
      </div>
      <div className="my-academy-video-list">
        {myCalendarList.length ? getMyAcademyList : <p>Sorry, no search results.</p>}

      </div>
      <VideoPlayer
        selectedValue={selectedMovieValue}
        open={open}
        onClose={handleClose}
      />
    </div>
  );
}

export default MyAcademyLatam;
