/* eslint-disable react/jsx-props-no-spreading */
import React, { useState, useEffect } from 'react';
import Slider from 'react-slick';
import { getMediaUrl } from '../../helpers/general';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const Video = ({ vidoes }) => {
  let videoData = [];
  videoData = vidoes;
  const [videoUrl, setVideoUrl] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState('');
  const [description2, setDescription2] = useState('');
  const [firstSlide, setfirstSlide] = useState(0);
  useEffect(() => {
    setVideoUrl(vidoes[0].url);
    setDescription(vidoes[0].description);
    setDuration(vidoes[0].duration);
    setDescription2(vidoes[0].description2);
    setfirstSlide(0);
  }, [vidoes]);

  const handleClick = (event) => {
    const dataValue = event.target.id;
    const player = videoData.filter((data) => data.id.includes(dataValue));
    setVideoUrl(player[0].url);
    setDescription(player[0].description);
    setDuration(player[0].duration);
    setDescription2(player[0].description2);
  };
  const mediaUrl = getMediaUrl();
  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: firstSlide,
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
    ],
  };
  const getVideoList = videoData.map((item) => (
    <div className="slider-image" key={`slider_${item.id}`}>
      <div className="img-container">
        <img id={item.id} src={mediaUrl + item.image} key={item.key} alt={item.alt} onClick={handleClick} role="presentation" />
      </div>
      <div className="bayph-radlgy-vidgal-title">
        <strong>{item.description}</strong>
        {item.duration}
      </div>
    </div>
  ));
  const getSlider = (
    <Slider {...settings}>
      {getVideoList}
    </Slider>
  );
  return (
    <div className="VideoContainer">
      <h2> Videos </h2>
      <div className="video">
        <div className="bayer-video">
          <div className="video-embed-field-responsive-video">
            <iframe title="video" width="554" height="480" frameBorder="0" allowFullScreen="allowfullscreen" src={videoUrl} />
          </div>
        </div>
      </div>
      <div className="VideoDescription">
        <p>
          <strong>
            {description}
            {' '}
            {duration}
            {' '}
          </strong>
          <span>{description2}</span>
        </p>
      </div>
      <div className="slider-wrapper">
        {videoData.length > 1 ? getSlider : ''}
      </div>
    </div>
  );
};

export default Video;
