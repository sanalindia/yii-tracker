import React from 'react';
import { getMediaUrl } from '../../helpers/general';

const mediaUrl = getMediaUrl();
const Download = ({ downloads }) => (
  <div className="download-container">
    <h2> Downloads</h2>
    <div className="download-content">
      {(downloads).map((product) => (
        <div className="download-item" key={product.key}>
          <a href={mediaUrl + product.url} target="_blank" rel="noreferrer">
            <div className="downloadImage">
              <img alt={product.alt} src={mediaUrl + product.image} />
            </div>
            <div className="downloadText">Download PDF </div>
          </a>
        </div>
      ))}
    </div>
  </div>
);
export default Download;
