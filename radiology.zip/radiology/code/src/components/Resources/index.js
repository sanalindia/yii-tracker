import React, { useLayoutEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  MenuItem, FormControl, Select,
} from '@material-ui/core';
import Video from './video';
import Download from './download';
import resources from '../../assets/data/resources.json';
import './resource.scss';

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

function Resources() {
  const classes = useStyles();
  const iframeResize = () => {
    const iframe = window.parent.document.getElementsByClassName('coh-iframe')[0];
    if (iframe) {
      setTimeout(() => {
        if (iframe.contentWindow.document.body.scrollHeight < 200) {
          iframe.height = iframe.contentWindow.document.body.scrollHeight + 200;
        } else {
          iframe.height = iframe.contentWindow.document.body.scrollHeight + 55;
        }
      }, 1500);
    }
  };
  useLayoutEffect(() => {
    iframeResize();
  });
  let items = [];
  const [productValue, setProductValue] = React.useState('');
  const [videos, setVideos] = React.useState([]);
  const [downloads, setDownloads] = React.useState([]);
  const getMenus = resources.map((item) => (
    <MenuItem value={item.id} key={item.key}>{item.name}</MenuItem>
  ));
  const changeProductOption = (event) => {
    iframeResize();
    const dataValue = event.target.value;
    setVideos([]);
    setDownloads([]);
    setProductValue(dataValue);
    if (dataValue) {
      setProductValue(dataValue);
      items = resources.filter((data) => data.id.includes(dataValue));
      setVideos(items[0].videos);
      setDownloads(items[0].downloads);
    }
  };

  return (
    <div className="resources">
      <FormControl variant="outlined" className={classes.formControl}>
        <h4 id="product_label">
          Product
        </h4>
        <Select
          labelId="product_label"
          id="product"
          value={productValue}
          onChange={changeProductOption}
          displayEmpty
        >
          <MenuItem value="" key="1">
            Select An Option
          </MenuItem>
          {getMenus}
        </Select>
      </FormControl>
      {videos.length ? (
        <Video
          vidoes={videos}
        />
      ) : ''}
      {downloads.length ? <Download downloads={downloads} /> : ''}
      {
      !videos.length && !downloads.length && productValue
        ? <div className="download-container"><h2> Downloads</h2></div>
        : ''
      }
    </div>
  );
}
export default Resources;
