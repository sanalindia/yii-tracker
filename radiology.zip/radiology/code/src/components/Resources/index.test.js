import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import Resources from '.';

describe('Resource', () => {
  test('Сheck that the headline is rendered in the component', () => {
    const { getByText } = render(<Resources />);
    expect(getByText(/Product/)).toBeInTheDocument();
  });
});
