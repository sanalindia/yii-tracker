/* eslint-disable jest/no-commented-out-tests */
import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import EventsCalendar from '.';

describe('Event Calendar', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<EventsCalendar />);
    expect(container).toBeInTheDocument();
  });
});
