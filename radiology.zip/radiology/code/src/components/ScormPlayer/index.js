/* eslint-disable jsx-a11y/iframe-has-title */
import React from 'react';
import { useTranslation } from 'react-i18next';
import './scormplayer.scss';

function ScormPlayer() {
  const { t } = useTranslation();
  return (
    <div className="scorm-player-wrapper">
      <h1>{t('SCORM Player')}</h1>
      <iframe
        name="container"
        src=""
        className="scorm-player-iframe"
        allowFullScreen="true"
        webkitallowfullscreen="true"
        mozallowfullscreen="true"
      />
    </div>
  );
}

export default ScormPlayer;
