/* eslint-disable jest/no-commented-out-tests */
import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import '../../services/i18n';
import QuickEventsCalendarLatam from '.';

describe('Quick Event Calendar', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<QuickEventsCalendarLatam />);
    expect(container).toBeInTheDocument();
  });
});
