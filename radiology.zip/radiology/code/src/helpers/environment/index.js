function getEnv() {
  return process.env.MODE;
}

export default getEnv;
