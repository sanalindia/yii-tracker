import getEnv from '.';

describe('Environment', () => {
  test('getEnv should return string', () => {
    expect(getEnv()).not.toBeNull();
  });
});
