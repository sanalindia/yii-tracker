import { getMediaUrl, sortByKey } from '.';

describe('Environment', () => {
  test('getMediaUrl should return string', () => {
    expect(getMediaUrl()).not.toBeNull();
  });
  test('sortByKey should return string', () => {
    const items = [{ value: 10 }, { value: 3 }, { value: 5 }];
    expect(sortByKey(items, 'value')).toEqual([{ value: 10 }, { value: 5 }, { value: 3 }]);
  });
});
