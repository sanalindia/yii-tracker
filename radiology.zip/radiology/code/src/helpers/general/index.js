export function getMediaUrl() {
  return process.env.MEDIA_URL;
}

export function sortByKey(array, key) {
  return array.sort((a, b) => {
    const x = a[key]; const y = b[key];
    // eslint-disable-next-line no-nested-ternary
    return ((x > y) ? -1 : ((x < y) ? 1 : 0));
  });
}
