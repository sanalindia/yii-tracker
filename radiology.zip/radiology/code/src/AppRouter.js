import React from 'react';
import { Route, Switch } from 'react-router-dom';
import {
  EventsCalendar, Greeting, ScormPlayer, MyAcademy, QuickEventsCalendar, MyEvents, MyAcademyLatam, QuickEventsCalendarLatam, EventsCalendarLatam, MyEventsLatam,
  Resources,
} from './components';

function AppRouter() {
  return (
    <div className="content">
      <Switch>
        <Route exact path="/" component={Greeting} />
        <Route exact path="/scorm-player" component={ScormPlayer} />
        <Route exact path="/events-calendar" component={EventsCalendar} />
        <Route exact path="/my-academy" component={MyAcademy} />
        <Route exact path="/quick-events-calendar" component={QuickEventsCalendar} />
        <Route exact path="/my-events" component={MyEvents} />
        <Route exact path="/my-academy-latam" component={MyAcademyLatam} />
        <Route exact path="/quick-events-calendar-latam" component={QuickEventsCalendarLatam} />
        <Route exact path="/events-calendar-latam" component={EventsCalendarLatam} />
        <Route exact path="/my-events-latam" component={MyEventsLatam} />
        <Route exact path="/resources" component={Resources} />
      </Switch>
    </div>
  );
}

export default AppRouter;
