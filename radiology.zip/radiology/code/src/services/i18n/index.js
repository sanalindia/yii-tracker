import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {};
const defaultLanguage = 'de';

function importAllTranslate(context) {
  context.keys().forEach((file) => {
    const key = file.split('/')[1];
    resources[key] = {
      translation: context(file),
    };
  });
}

importAllTranslate(require.context('../../../public/locales', true, /\.json$/));

function getLanguage() {
  // const html = document.querySelector('html');
  // const hrefLang = html.getAttribute('hreflang');
  // if (hrefLang && resources[hrefLang]) return hrefLang;
  // if (html.lang && resources[html.lang]) return html.lang;
  return defaultLanguage;
}

i18n.use(initReactI18next).init({
  lng: getLanguage(),
  resources,
  fallbackLng: defaultLanguage,
  keySeparator: false,
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
