import getDate from '.';

describe('Moment JS', () => {
  test('getDate should return string', () => {
    expect(getDate()).not.toBeNull();
  });
});
