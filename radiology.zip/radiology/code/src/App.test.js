import React from 'react';
import { render } from '@bayer/wsf-decoupled-react-preset/packages/testing-react';
import App from './App';

describe('App', () => {
  test('Mounts with no errors thrown', () => {
    const { container } = render(<App />);
    expect(container).toBeInTheDocument();
  });
});
