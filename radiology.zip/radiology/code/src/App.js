import { hot } from 'react-hot-loader';
import React, { Suspense } from 'react';
import './services/i18n';
import './style/main.scss';
import { HashRouter } from 'react-router-dom';
import AppRouter from './AppRouter';

function App() {
  return (
    <Suspense fallback="Loading...">
      <HashRouter basename="/">
        <AppRouter />
      </HashRouter>
    </Suspense>
  );
}

export default hot(module)(App);
