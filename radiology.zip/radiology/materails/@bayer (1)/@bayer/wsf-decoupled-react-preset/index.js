const react = require('@neutrinojs/react');
const { jest, airbnb, basePreset, templatePreset } = require('@bayer/wsf-decoupled-preset');
const Dotenv = require('dotenv-webpack');

module.exports = (config) => neutrino => {
  neutrino.use(basePreset());
  neutrino.use(airbnb({
    eslint: {
      rules: {
        "react/jsx-filename-extension": [
          1,
          {
            "extensions": [".js", ".jsx"]
          }
        ],
        "react/prop-types": 0,
        "linebreak-style": "off",
        "max-len": ["error", { "code": 200 }],
        "no-async-promise-executor": "off",
        "no-await-in-loop": "off"
      }
    }
  }));
  neutrino.use(react({
    publicPath: process.env.NODE_ENV == 'development' ? '/' : './',
    style: {
      test: /\.(css|sass|scss)$/,
      loaders: [
        {
          loader: require.resolve('sass-loader'),
          useId: 'sass'
        },
        {
          loader: require.resolve('postcss-loader'),
          options: {
            plugins: [require('autoprefixer')],
          },
        }
      ]
    },
    browserslist: {
      production: [
        '>0.25%',
        'not dead',
        'not op_mini all'
      ],
      development: [
        'last 1 chrome version',
        'last 1 firefox version',
        'last 1 safari version'
      ]
    },
    babel: {
      presets: [
        ['@babel/preset-env', {
          useBuiltIns: 'usage',
          corejs: { version: 3 }
        }],
        '@babel/preset-react'
      ],
      env: {
        test: {
          plugins: ['transform-require-context'],
        }
      }
    },
  }));
  neutrino.config
  .plugin('dotEnv')
  .use(Dotenv, [{
    path: `./.env.${process.env.NODE_ENV === 'production' ? 'production' : 'development'}`,
  }]);
  neutrino.use(jest({
    setupFilesAfterEnv: ['./setupTests.js'],
      testRegex: '\\.test\\.jsx?$',
      collectCoverage: true,
      collectCoverageFrom: [
        'src/**/*.{js,jsx}',
        '!src/index.js',
        '!**/node_modules/**',
      ],
      coverageThreshold: {
        global: {
          branches: config.coverageThreshold,
          functions: config.coverageThreshold,
          lines: config.coverageThreshold,
          statements: config.coverageThreshold
        }
      },
  }));
  neutrino.use(templatePreset());
};
