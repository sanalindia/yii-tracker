const airbnb = require('./presets/airbnbPreset.js');
const jest = require('./presets/jestPreset.js');
const basePreset = require('./presets/basePreset.js');
const templatePreset = require('./presets/templatePreset.js');

module.exports = { airbnb, jest, basePreset, templatePreset };
