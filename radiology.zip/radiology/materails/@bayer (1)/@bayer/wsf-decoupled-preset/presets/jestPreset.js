const jest = require('@neutrinojs/jest');

module.exports = jest;
