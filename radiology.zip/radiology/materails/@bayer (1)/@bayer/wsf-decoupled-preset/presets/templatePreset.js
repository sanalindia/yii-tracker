const htmlTemplate = require('@neutrinojs/html-template');

module.exports = (config = {}) => (neutrino) => {
  neutrino.use(htmlTemplate({
      template: require.resolve('./template.ejs'),
      inject: false,
      ...config
    })
  );
};
