const airbnb = require('@neutrinojs/airbnb');

module.exports = airbnb;
