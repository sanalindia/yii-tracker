const path = require('path');
const envPath = `./.env.${process.env.NODE_ENV == 'production' ? 'production' : 'development'}`;

require('dotenv').config({
  path: path.resolve(process.cwd(), envPath),
});

module.exports = (config = {}) => (neutrino) => {
  neutrino.config.devServer.headers({"Access-Control-Allow-Origin": "*"}),
  neutrino.config.devServer.set('allowedHosts', ['.main.acsf.baywsf.com']),
  neutrino.config.devServer.set('proxy', {
    '/' : {
      target: process.env.PROXY,
      changeOrigin: true,
    },
  }),
  neutrino.config.output.publicPath('https://localhost:5000/')
};
